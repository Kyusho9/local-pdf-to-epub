import * as Css from "./css";
import * as Exprs from "./exprs";
export interface PropertyReceiver {
    unknownProperty(name: string, value: Css.Val): void;
    invalidPropertyValue(name: string, value: Css.Val): void;
    simpleProperty(name: string, value: Css.Val, important: any): void;
}
export declare class Node {
    validator: PropertyValidator | null;
    success: Node | null;
    failure: Node | null;
    code: number;
    constructor(validator: PropertyValidator | null);
    isSpecial(): boolean;
    markAsStartGroup(): void;
    isStartGroup(): boolean;
    markAsEndGroup(): void;
    isEndGroup(): boolean;
    markAsStartAlternate(index: number): void;
    markAsEndAlternate(index: number): void;
    isEndAlternate(): boolean;
    getAlternate(): number;
}
export declare class Connection {
    where: number;
    success: boolean;
    what: number;
    constructor(where: number, success: boolean);
}
/**
 * @enum {number}
 */
export declare enum Add {
    FOLLOW = 1,
    OPTIONAL = 2,
    REPEATED = 3,
    ALTERNATE = 4
}
/**
 * A class to build a list validator from other validators.
 */
export declare class ValidatingGroup {
    nodes: Node[];
    connections: Connection[];
    match: number[];
    nomatch: number[];
    error: number[];
    emptyHead: boolean;
    connect(arr: number[], nodeIndex: number): void;
    clone(): ValidatingGroup;
    /**
     * Add "special" validation node to a given array (match, nomatch, or error).
     * @param start if this a start or the end of a clause/group
     * @param clause 0 indicates group start/end, otherwise clause index
     */
    private addSpecialToArr;
    endSpecialGroup(): void;
    startSpecialGroup(): void;
    endClause(clause: number): void;
    startClause(clause: number): void;
    addPrimitive(validator: PropertyValidator): void;
    isSimple(): boolean;
    isPrimitive(): boolean;
    addGroup(group: ValidatingGroup, how: Add): void;
    /**
     * @return how
     */
    finish(successTerminal: Node, failTerminal: Node): Node;
}
export declare const ALLOW_EMPTY = 1;
export declare const ALLOW_STR = 2;
export declare const ALLOW_IDENT = 4;
export declare const ALLOW_POS_NUMERIC = 8;
export declare const ALLOW_POS_NUM = 16;
export declare const ALLOW_POS_INT = 32;
export declare const ALLOW_COLOR = 64;
export declare const ALLOW_URL = 128;
export declare const ALLOW_NEGATIVE = 256;
export declare const ALLOW_ZERO = 512;
export declare const ALLOW_ZERO_PERCENT = 1024;
export declare const ALLOW_SLASH = 2048;
export declare const ALLOW_URANGE = 4096;
export declare const ALLOW_IMAGE = 8192;
export type ValueMap = {
    [key: string]: Css.Val;
};
/**
 * Abstract class to validate simple CSS property value (not a shorthand)
 */
export declare class PropertyValidator extends Css.Visitor {
    constructor();
    /**
     * Validate a subsequence of the given values from the given index. Return the
     * list of matched values or null if there is no match.
     */
    validateForShorthand(values: Css.Val[], index: number): Css.Val[] | null;
}
/**
 * Validate a primitive CSS value (not a list or function).
 * @param allowed mask of ALLOW_*** constants.
 */
export declare class PrimitiveValidator extends PropertyValidator {
    readonly allowed: number;
    readonly idents: ValueMap;
    readonly units: ValueMap;
    constructor(allowed: number, idents: ValueMap, units: ValueMap);
    visitEmpty(empty: Css.Val): Css.Val | null;
    visitSlash(slash: Css.Val): Css.Val | null;
    visitStr(str: Css.Str): Css.Val | null;
    visitIdent(ident: Css.Ident): Css.Val | null;
    visitNumeric(numeric: Css.Numeric): Css.Val | null;
    visitNum(num: Css.Num): Css.Val | null;
    visitInt(num: Css.Int): Css.Val | null;
    visitHexColor(color: Css.HexColor): Css.Val | null;
    visitURL(url: Css.URL): Css.Val | null;
    visitURange(urange: Css.URange): Css.Val | null;
    visitSpaceList(list: Css.SpaceList): Css.Val | null;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    visitFunc(func: Css.Func): Css.Val | null;
    visitExpr(expr: Css.Expr): Css.Val | null;
    combine(other: PrimitiveValidator): PrimitiveValidator;
}
export type AttrType = {
    kind: "string";
} | {
    kind: "url";
} | {
    kind: "syntax";
    syntax: string;
} | {
    kind: "unit";
    unit: string;
};
export type AttrFunction = {
    attributeName: string;
    type: AttrType;
    fallback: Css.Val | null;
};
export declare function parseAttrFunction(func: Css.Func): AttrFunction | null;
export declare function getImplicitAttrFallback(type: AttrType): Css.Val;
export declare function parseAttrValue(scope: Exprs.LexicalScope, value: string | null, type: AttrType): Css.Val | null;
export declare const ALWAYS_FAIL: PrimitiveValidator;
/**
 * Base class for list validation.
 */
export declare class ListValidator extends PropertyValidator {
    successTerminal: Node;
    failureTerminal: Node;
    first: Node;
    constructor(group: ValidatingGroup);
    validateList(arr: Css.Val[], slice: boolean, startIndex: number): Css.Val[] | null;
    validateSingle(inval: Css.Val): Css.Val | null;
    visitEmpty(empty: Css.Val): Css.Val | null;
    visitSlash(slash: Css.Val): Css.Val | null;
    visitStr(str: Css.Str): Css.Val | null;
    visitIdent(ident: Css.Ident): Css.Val | null;
    visitNumeric(numeric: Css.Numeric): Css.Val | null;
    visitNum(num: Css.Num): Css.Val | null;
    visitInt(num: Css.Int): Css.Val | null;
    visitHexColor(color: Css.HexColor): Css.Val | null;
    visitURL(url: Css.URL): Css.Val | null;
    visitURange(urange: Css.URange): Css.Val | null;
    visitSpaceList(list: Css.SpaceList): Css.Val | null;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    visitFunc(func: Css.Func): Css.Val | null;
    visitExpr(expr: Css.Expr): Css.Val | null;
}
export declare class SpaceListValidator extends ListValidator {
    constructor(group: ValidatingGroup);
    visitSpaceList(list: Css.SpaceList): Css.Val | null;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    validateForShorthand(values: Css.Val[], index: number): Css.Val[] | null;
}
export declare class CommaListValidator extends ListValidator {
    constructor(group: ValidatingGroup);
    visitSpaceList(list: Css.SpaceList): Css.Val | null;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    validateForShorthand(values: Css.Val[], index: number): Css.Val[] | null;
}
export declare class FuncValidator extends ListValidator {
    readonly name: string;
    constructor(name: string, group: ValidatingGroup);
    validateSingle(inval: Css.Val): Css.Val | null;
    visitFunc(func: Css.Func): Css.Val | null;
}
export declare class ShorthandSyntaxNode {
    /**
     * @return new index.
     */
    tryParse(values: Css.Val[], index: number, shorthandValidator: ShorthandValidator): number;
    success(rval: Css.Val, shorthandValidator: ShorthandValidator): void;
}
export declare class ShorthandSyntaxProperty extends ShorthandSyntaxNode {
    readonly name: string;
    validator: PropertyValidator;
    constructor(validatorSet: ValidatorSet, name: string);
    tryParse(values: Css.Val[], index: number, shorthandValidator: ShorthandValidator): number;
    success(rval: Css.Val, shorthandValidator: ShorthandValidator): void;
}
export declare class ShorthandSyntaxPropertyN extends ShorthandSyntaxProperty {
    readonly names: string[];
    constructor(validatorSet: ValidatorSet, names: string[]);
    success(rval: Css.Val, shorthandValidator: ShorthandValidator): void;
}
export declare class ShorthandSyntaxCompound extends ShorthandSyntaxNode {
    readonly nodes: ShorthandSyntaxNode[];
    readonly slash: boolean;
    constructor(nodes: ShorthandSyntaxNode[], slash: boolean);
    tryParse(values: Css.Val[], index: number, shorthandValidator: ShorthandValidator): number;
}
export declare class ShorthandValidator extends Css.Visitor {
    validatorSet: ValidatorSet;
    syntax: ShorthandSyntaxNode[];
    propList: string[];
    error: boolean;
    values: ValueMap;
    protected constructor(validatorSet: ValidatorSet, syntax: ShorthandSyntaxNode[], propList: string[]);
    static create(validatorSet: ValidatorSet, syntax: ShorthandSyntaxNode[], propList: string[]): ShorthandValidator;
    clone(scope: Exprs.LexicalScope): ShorthandValidator;
    finish(important: boolean, receiver: PropertyReceiver): boolean;
    propagateDefaultingValue(value: Css.Val, important: boolean, receiver: PropertyReceiver): void;
    validateList(list: Css.Val[]): number;
    validateSingle(val: Css.Val): Css.Val | null;
    visitEmpty(empty: Css.Val): Css.Val | null;
    visitStr(str: Css.Str): Css.Val | null;
    visitIdent(ident: Css.Ident): Css.Val | null;
    visitNumeric(numeric: Css.Numeric): Css.Val | null;
    visitNum(num: Css.Num): Css.Val | null;
    visitInt(num: Css.Int): Css.Val | null;
    visitHexColor(color: Css.HexColor): Css.Val | null;
    visitURL(url: Css.URL): Css.Val | null;
    visitSpaceList(list: Css.SpaceList): Css.Val | null;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    visitFunc(func: Css.Func): Css.Val | null;
    visitExpr(expr: Css.Expr): Css.Val | null;
}
export declare class SimpleShorthandValidator extends ShorthandValidator {
    validateList(list: Css.Val[]): number;
}
export declare class InsetsShorthandValidator extends ShorthandValidator {
    validateList(list: Css.Val[]): number;
    createSyntaxNode(): ShorthandSyntaxPropertyN;
}
export declare class InsetsSlashShorthandValidator extends ShorthandValidator {
    validateList(list: Css.Val[]): number;
}
export declare class CommaShorthandValidator extends SimpleShorthandValidator {
    mergeIn(acc: {
        [key: string]: Css.Val[];
    }, values: ValueMap): void;
    visitCommaList(list: Css.CommaList): Css.Val | null;
}
export declare class FontShorthandValidator extends SimpleShorthandValidator {
    static create(validatorSet: ValidatorSet, syntax: ShorthandSyntaxNode[], propList: string[]): FontShorthandValidator;
    validateList(list: Css.Val[]): number;
    visitCommaList(list: Css.CommaList): Css.Val | null;
    visitIdent(ident: Css.Ident): Css.Val | null;
}
export declare class TextSpacingShorthandValidator extends SimpleShorthandValidator {
    validateList(list: Css.Val[]): number;
}
export declare class BrowserShorthandValidator extends ShorthandValidator {
    readonly name: string;
    constructor(validatorSet: ValidatorSet, name: string, propList?: string[]);
    clone(scope: Exprs.LexicalScope): ShorthandValidator;
}
export declare class ScopedBrowserShorthandValidator extends BrowserShorthandValidator {
    readonly scope: Exprs.LexicalScope;
    constructor(validatorSet: ValidatorSet, name: string, propList: string[], scope: Exprs.LexicalScope);
    private validateValueText;
    validateList(list: Css.Val[]): number;
    visitCommaList(list: Css.CommaList): Css.Val | null;
}
export declare class AllShorthandValidator extends SimpleShorthandValidator {
    refreshPropList(): void;
    validateList(list: Css.Val[]): number;
}
export declare const shorthandValidators: {
    [key: string]: typeof ShorthandValidator;
};
/**
 * Object that validates simple and shorthand properties, breaking up shorthand
 * properties into corresponding simple ones, also stripping property prefixes.
 */
export declare class ValidatorSet {
    validators: Map<string, PropertyValidator>;
    prefixes: Map<string, Set<string>>;
    defaultValues: Map<string, Css.Val>;
    namedValidators: Map<string, ValidatingGroup>;
    systemFonts: Map<string, ValueMap>;
    shorthands: Map<string, ShorthandValidator>;
    layoutProps: Map<string, Css.Val>;
    backgroundProps: Map<string, Css.Val>;
    private browserShorthandStyle;
    private browserShorthandMisses;
    private browserPropertyNamesForAll;
    private allPropertyNames;
    private invalidateAllPropertyNames;
    private getBrowserPropertyNamesForAll;
    getPropertiesForAll(): string[];
    private getBrowserShorthandStyle;
    expandBrowserShorthand(name: string, valueText: string): {
        propList: string[];
        values: {
            [key: string]: string;
        };
    } | null;
    getShorthand(name: string, value?: Css.Val | string): ShorthandValidator | null;
    private addReplacement;
    private newGroup;
    private addCounts;
    private primitive;
    private newFunc;
    initBuiltInValidators(): void;
    private isBuiltIn;
    private readNameAndPrefixes;
    private parseValidators;
    private parseDefaults;
    private parseShorthands;
    parse(text: string): void;
    makePropSet(propList: string[]): Map<string, Css.Val>;
    validatePropertyAndHandleShorthand(name: string, value: Css.Val, important: boolean, scope: Exprs.LexicalScope, receiver: PropertyReceiver): void;
}
export declare function baseValidatorSet(): ValidatorSet;
export declare function containsVar(val: Css.Val): boolean;
