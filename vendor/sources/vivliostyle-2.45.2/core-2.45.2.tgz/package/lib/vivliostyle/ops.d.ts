/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Ops - Render EPUB content files by applying page masters,
 * styling and layout.
 */
import "./footnotes";
import "./table";
import * as Base from "./base";
import * as CmykStore from "./cmyk-store";
import * as Constants from "./constants";
import * as Counters from "./counters";
import * as CounterStyle from "./counter-style";
import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as CssParser from "./css-parser";
import * as CssStyler from "./css-styler";
import * as CssValidator from "./css-validator";
import * as Exprs from "./exprs";
import * as Font from "./font";
import * as GeometryUtil from "./geometry-util";
import * as Net from "./net";
import * as PageFloats from "./page-floats";
import * as CssPage from "./css-page";
import * as PageMaster from "./page-master";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
import * as Vgen from "./vgen";
import * as Vtree from "./vtree";
import * as XmlDoc from "./xml-doc";
import { Layout as LayoutType, PageFloats as PageFloatsType } from "./types";
/**
 * A `@font-face` rule. `priority` and `layer` are what the cascade sorts the
 * rule by when several rules define the same font (css-cascade-5 §6.4).
 */
export type FontFace = {
    properties: CssCascade.ElementStyle;
    condition: Exprs.Val | null;
    priority: number;
    layer: CssCascade.CascadeLayer | null;
};
/**
 * Sorts `@font-face` rules by cascade origin and layer, keeping the document
 * order within a layer (`Array.prototype.sort` is stable). The browser lets the
 * last matching rule win, so the winner of the cascade must be emitted last.
 */
export declare function sortFontFaces(fontFaces: FontFace[]): FontFace[];
export declare class Style {
    readonly store: OPSDocStore;
    readonly rootScope: Exprs.LexicalScope;
    readonly pageScope: Exprs.LexicalScope;
    readonly cascade: CssCascade.Cascade;
    readonly rootBox: PageMaster.RootPageBox;
    readonly fontFaces: FontFace[];
    readonly footnoteProps: CssCascade.ElementStyle;
    readonly flowProps: {
        [key: string]: CssCascade.ElementStyle;
    };
    readonly viewportProps: CssCascade.ElementStyle[];
    readonly pageProps: {
        [key: string]: CssCascade.ElementStyle;
    };
    readonly counterStyleStore: CounterStyle.CounterStyleStore;
    fontDeobfuscator: ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null;
    validatorSet: CssValidator.ValidatorSet;
    constructor(store: OPSDocStore, rootScope: Exprs.LexicalScope, pageScope: Exprs.LexicalScope, cascade: CssCascade.Cascade, rootBox: PageMaster.RootPageBox, fontFaces: FontFace[], footnoteProps: CssCascade.ElementStyle, flowProps: {
        [key: string]: CssCascade.ElementStyle;
    }, viewportProps: CssCascade.ElementStyle[], pageProps: {
        [key: string]: CssCascade.ElementStyle;
    }, counterStyleStore: CounterStyle.CounterStyleStore);
    sizeViewport(viewportWidth: number, viewportHeight: number, fontSize: number, pref?: Exprs.Preferences): {
        width: number;
        height: number;
        fontSize: number;
    };
}
export declare class StyleInstance extends Exprs.Context implements CssStyler.FlowListener, PageMaster.InstanceHolder, Vgen.StylerProducer {
    readonly style: Style;
    readonly xmldoc: XmlDoc.XMLDocHolder;
    readonly viewport: Vgen.Viewport;
    readonly clientLayout: Vtree.ClientLayout;
    readonly fontMapper: Font.Mapper;
    readonly customRenderer: Vgen.CustomRenderer;
    readonly fallbackMap: {
        [key: string]: string;
    };
    readonly pageNumberOffset: number;
    readonly documentURLTransformer: Base.DocumentURLTransformer;
    readonly counterStore: Counters.CounterStore;
    readonly cmykStore: CmykStore.CmykStore;
    lang: string | null;
    primaryFlows: {
        [key: string]: boolean;
    };
    rootPageBoxInstance: PageMaster.RootPageBoxInstance;
    styler: CssStyler.Styler;
    stylerMap: {
        [key: string]: CssStyler.Styler;
    };
    currentLayoutPosition: Vtree.LayoutPosition | null;
    layoutPositionAtPageStart: Vtree.LayoutPosition | null;
    currentCascadedPageStyle: CssCascade.ElementStyle | null;
    lookupOffset: number;
    faces: Font.DocumentFaces;
    pageBoxInstances: {
        [key: string]: PageMaster.PageBoxInstance;
    };
    pageManager: CssPage.PageManager;
    private pageNumberContextStack;
    private rootPageFloatLayoutContext;
    pageBreaks: {
        [key: string]: boolean;
    };
    pageProgression: Constants.PageProgression | null;
    isVersoFirstPage: boolean;
    blankPageAtStart: boolean;
    pageSheetSize: {
        [key: string]: {
            width: number;
            height: number;
        };
    };
    pageSheetHeight: number;
    pageSheetWidth: number;
    private invalidPageAreaOnCurrentPage;
    private repeatedInvalidPageAreaLayoutPosition;
    private semanticFootnoteFirstRefOffsets;
    private semanticFootnoteFirstRefOffsetsInitialized;
    pageGroupPageCounts: {
        [pageType: string]: Map<Element, number>;
    };
    currentPageGroupDocument: Document | null;
    private constructor();
    static create(style: Style, xmldoc: XmlDoc.XMLDocHolder, defaultLang: string | null, viewport: Vgen.Viewport, clientLayout: Vtree.ClientLayout, fontMapper: Font.Mapper, customRenderer: Vgen.CustomRenderer, fallbackMap: {
        [key: string]: string;
    }, pageNumberOffset: number, documentURLTransformer: Base.DocumentURLTransformer, counterStore: Counters.CounterStore, cmykStore: CmykStore.CmykStore, pref: Exprs.Preferences, pubTitle: string | null, docTitle: string | null, pageProgression?: Constants.PageProgression | null, isVersoFirstPage?: boolean): Task.Result<StyleInstance>;
    private loadFontsAndScripts;
    private matchStartPageSide;
    /** @override */
    getStylerForDoc(xmldoc: XmlDoc.XMLDocHolder): CssStyler.AbstractStyler;
    /** @override */
    registerInstance(key: string, instance: PageMaster.PageBoxInstance): void;
    /** @override */
    lookupInstance(key: string): PageMaster.PageBoxInstance;
    /** @override */
    encounteredFlowChunk(flowChunk: Vtree.FlowChunk, flow: Vtree.Flow): void;
    evalSupportsTest(name: string, value: string, isFunc: boolean): boolean;
    getCurrentPageNumberForPageScope(): number;
    getPageNumberContextDepth(): number;
    pushPageNumberContext(pageNumber: number): void;
    restorePageNumberContextDepth(depth: number): void;
    /**
     * @param selectorText
     * @returns true if selectorText is supported selector
     */
    private evalSupportsSelector;
    getConsumedOffset(flowPosition: Vtree.FlowPosition): number;
    private getNodePositionOffset;
    private getPageStartOffset;
    private getPageStartCounterOffsets;
    private getPageStartElement;
    private isForcedPageBreakValue;
    private hasForcedPageBreakBefore;
    private getExplicitPageType;
    private getPageGroupPageType;
    getPageStartPageType(layoutPosition: Vtree.LayoutPosition | null): string | null | undefined;
    getPageStartPageTypeOverride(layoutPosition: Vtree.LayoutPosition | null): string | null | undefined;
    private getPreviousInFlowSibling;
    private getFirstDocumentFlowElement;
    private getEffectiveFirstPageType;
    private getEffectivePageGroupStartElement;
    /**
     * Resolve the page type for the first page by examining the first in-flow
     * element's CSS `page` property. This is needed because `currentPageType`
     * is only set during layout (in ViewFactory), but the first page's type
     * must be known before layout begins for correct @page rule matching.
     *
     * Note: This must NOT set `currentPageType` as a side effect. Setting it
     * early would cause intermediate wrapper elements (whose page type is
     * null/auto) to get unwanted `breakBefore: "page"` during view tree
     * construction, since their page type would differ from `currentPageType`.
     * The `currentPageType` will be set naturally when the content element
     * is processed during layout. (Issue #1869, #1870)
     */
    private resolveFirstPageType;
    private shouldStartPageGroup;
    private updatePageGroupPageIndices;
    preparePageGroupPageIndicesForRerender(layoutPositions: Array<Vtree.LayoutPosition | null>, pageIndexToRender: number): void;
    private getFirstInFlowElementAtOrAfter;
    private getDeepestFirstInFlowChildOffset;
    private getFirstInFlowChildElement;
    private isPageBoundaryCandidateElement;
    private isNormalFlowElement;
    private isInlineLevelElement;
    private getDisplayValue;
    /**
     * @param noLookAhead Do not look ahead elements that are not styled yet
     * @return document offset of the given layoutPosition
     */
    getPosition(layoutPosition?: Vtree.LayoutPosition | null, noLookAhead?: boolean): number;
    dumpLocation(position: any): void;
    matchPageSide(side: string | null): boolean;
    updateStartSide(layoutPosition: Vtree.LayoutPosition): void;
    /**
     * @param cascadedPageStyle Cascaded page style specified in page context
     */
    selectPageMaster(cascadedPageStyle: CssCascade.ElementStyle): PageMaster.PageMasterInstance | null;
    flowChunkIsAfterParentFlowForcedBreak(flowChunk: Vtree.FlowChunk): boolean;
    beginIsolatedRootPageFloatLayoutContext(previousPageFloatLayoutContext?: PageFloatsType.AttachedPageFloatLayoutContext | null): PageFloats.RootPageFloatLayoutContext;
    endIsolatedRootPageFloatLayoutContext(originalRootPageFloatLayoutContext: PageFloats.RootPageFloatLayoutContext): void;
    hasActiveRootPageFloatLayoutContext(): boolean;
    private hasOnlyDeferredPageFloats;
    layoutDeferredPageFloats(column: LayoutType.Column): Task.Result<boolean>;
    getLastAfterPositionIfDeferredFloatsExists(column: LayoutType.Column, newPosition: Vtree.ChunkPosition | null): Vtree.ChunkPosition | null;
    private flowRootFormattingContextFor;
    /**
     * @return holding true
     */
    layoutColumn(column: LayoutType.Column, flowName: string): Task.Result<boolean>;
    createLayoutConstraint(pageFloatLayoutContext: PageFloats.PageFloatLayoutContext): LayoutType.LayoutConstraint;
    private createAndLayoutColumn;
    getRegionPageFloatLayoutContext(pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext, boxInstance: PageMaster.PageBoxInstance, layoutContainer: Vtree.Container, flowName: string): PageFloats.AttachedPageFloatLayoutContext;
    layoutFlowColumnsWithBalancing(page: Vtree.Page, boxInstance: PageMaster.PageBoxInstance, offsetX: number, offsetY: number, exclusions: GeometryUtil.Shape[], pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext, layoutContainer: Vtree.Container, flowNameStr: string, columnCount: number): Task.Result<LayoutType.Column[] | null>;
    layoutFlowColumns(page: Vtree.Page, boxInstance: PageMaster.PageBoxInstance, offsetX: number, offsetY: number, exclusions: GeometryUtil.Shape[], pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext, regionPageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext, layoutContainer: Vtree.Container, flowNameStr: string, columnCount: number, forceNonFitting: boolean): Task.Result<LayoutType.Column[] | null>;
    private openPageBox;
    /** Takes no flow, the one part that can run before the context is attached. */
    private layoutGeneratedContent;
    private layoutPageBoxContent;
    /**
     * Pushes this box's exclusion shape, or removes it when it turned out empty.
     * @return whether the layout continues into the children
     */
    private excludeOrRemovePageBox;
    private layoutPageBoxChildren;
    /**
     * The context becomes attached at the page area. Boxes reached before that
     * point cannot take a flow, having no container for its floats.
     */
    private layoutPageAreaEstablishingContainer;
    /**
     * @return holding true
     */
    layoutContainer(page: Vtree.Page, boxInstance: PageMaster.PageBoxInstance, parentContainer: HTMLElement, offsetX: number, offsetY: number, exclusions: GeometryUtil.Shape[], pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext): Task.Result<boolean>;
    processLinger(): void;
    initLingering(): void;
    noMorePrimaryFlows(cp: Vtree.LayoutPosition): boolean;
    private hasSameFlowPositions;
    private checkRepeatedInvalidPageArea;
    layoutNextPage(page: Vtree.Page, cp?: Vtree.LayoutPosition | null): Task.Result<Vtree.LayoutPosition | null>;
    /**
     * Set actual page width, height and bleed from style specified in page
     * context.
     */
    private setPageSizeAndBleed;
}
export declare class BaseParserHandler extends CssCascade.CascadeParserHandler {
    masterHandler: StyleParserHandler;
    insideRegion: boolean;
    constructor(masterHandler: StyleParserHandler, owner: CssParser.DispatchParserHandler, scope: Exprs.LexicalScope, validatorSet: CssValidator.ValidatorSet, condition: Exprs.Val | null, parent: BaseParserHandler | null, regionId: string | null, delegation: CssParser.Delegation | null);
    startPageTemplateRule(): void;
    startPageMasterRule(name: string | null, pseudoName: string | null, classes: string[]): void;
    startWhenRule(expr: Css.Expr): void;
    startLayerRule(nameList: string[] | null): void;
    startDefineRule(): void;
    startFontFaceRule(): void;
    startCounterStyleRule(name: string): void;
    startFlowRule(flowName: string): void;
    startViewportRule(): void;
    startFootnoteRule(pseudoelem: string | null): void;
    startRegionRule(): void;
    startPageRule(): void;
    startRuleBody(): void;
}
export declare class StyleParserHandler extends CssParser.DispatchParserHandler<BaseParserHandler> {
    readonly validatorSet: CssValidator.ValidatorSet;
    readonly rootScope: Exprs.LexicalScope;
    readonly pageScope: Exprs.LexicalScope;
    readonly rootBox: PageMaster.RootPageBox;
    readonly cascadeParserHandler: BaseParserHandler;
    regionCount: number;
    fontFaces: FontFace[];
    counterStyles: CounterStyle.CounterStyleStore;
    footnoteProps: CssCascade.ElementStyle;
    flowProps: {
        [key: string]: CssCascade.ElementStyle;
    };
    viewportProps: CssCascade.ElementStyle[];
    pageProps: {
        [key: string]: CssCascade.ElementStyle;
    };
    constructor(validatorSet: CssValidator.ValidatorSet);
}
export type StyleSheetParam = {
    url: string;
    text?: null;
} | {
    url: string | null;
    text: string;
};
export type StyleSource = StyleSheetParam & {
    flavor: CssParser.StylesheetFlavor;
    classes: string | null;
    media: string | null;
};
export declare function parseOPSResource(response: Net.FetchResponse, store: XmlDoc.XMLDocStore): Task.Result<XmlDoc.XMLDocHolder | null>;
export declare class OPSDocStore extends Net.ResourceStore<XmlDoc.XMLDocHolder> {
    fontDeobfuscator: ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null;
    styleByKey: {
        [key: string]: Style;
    };
    styleFetcherByKey: {
        [key: string]: TaskUtil.Fetcher<Style>;
    };
    styleByDocURL: {
        [key: string]: Style;
    };
    triggersByDocURL: {
        [key: string]: Vtree.Trigger[];
    };
    validatorSet: CssValidator.ValidatorSet;
    private styleSheets;
    protected triggerSingleDocumentPreprocessing: boolean;
    protected constructor(fontDeobfuscator: ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null, authorStyleSheets?: StyleSheetParam[] | null, userStyleSheets?: StyleSheetParam[] | null);
    getStyleForDoc(xmldoc: XmlDoc.XMLDocHolder): Style;
    getTriggersForDoc(xmldoc: XmlDoc.XMLDocHolder): Vtree.Trigger[];
    /**
     * Set author stylesheets and user stylesheets. Existing style sheets are
     * removed.
     */
    private setStyleSheets;
    private clearStyleSheets;
    private addAuthorStyleSheet;
    private addUserStyleSheet;
    parseOPSResource(response: Net.FetchResponse): Task.Result<XmlDoc.XMLDocHolder | null>;
    processViewportMeta(meta: Element): string;
}
