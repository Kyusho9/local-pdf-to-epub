/**
 * Copyright 2016 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Break - Control fragmentation.
 */
import * as Css from "./css";
/**
 * Check if style="box-decoration-break: clone" is set
 */
export declare function isCloneBoxDecorationBreak(element: Element): boolean;
/**
 * data-viv-box-break attribute
 *
 * Value: [ [inline-start || inline-end] |
 *          [block-start text-start? || block-end text-end?] justify? ]
 *        clone?
 *
 * inline-start, inline-end, block-start, block-end: the side at which a box break occurs
 * text-start: the fragment starts with text or inline box
 * text-end: the fragment ends with text or inline box
 * justify: the computed value of `text-align` property is `justify`
 * clone: the computed value of `box-decoration-break` property is `clone`
 */
type BoxBreakFlag = "inline-start" | "inline-end" | "block-start" | "block-end" | "text-start" | "text-end" | "justify" | "clone";
export declare function getBoxBreakFlags(element: Element): BoxBreakFlag[];
export declare function setBoxBreakFlags(element: Element, boxBreakFlags: BoxBreakFlag[]): void;
export declare function setBoxBreakFlag(element: Element, boxBreakFlag: BoxBreakFlag): void;
/**
 * data-viv-margin-discard attribute
 *
 * Value: block-start || block-end || inline-start || inline-end
 *
 * block-start: the block-start margin is discarded
 * block-end: the block-end margin is discarded
 * inline-start: the inline-start margin is discarded
 * inline-end: the inline-end margin is discarded
 */
type MarginDiscardFlag = "block-start" | "block-end" | "inline-start" | "inline-end";
export declare function getMarginDiscardFlags(element: Element): MarginDiscardFlag[];
export declare function setMarginDiscardFlags(element: Element, marginDiscardFlags: MarginDiscardFlag[]): void;
export declare function setMarginDiscardFlag(element: Element, marginDiscardFlag: MarginDiscardFlag): void;
/**
 * Convert old page-break-* properties to break-* properties with appropriate
 * values as specified by CSS Fragmentation module:
 * https://drafts.csswg.org/css-break/#page-break-properties
 */
export declare function convertPageBreakAliases(original: {
    name: string;
    value: Css.Val;
    important: boolean;
}): {
    name: string;
    value: Css.Val;
    important: boolean;
};
export declare const forcedBreakValues: {
    [key: string]: boolean | null;
};
/**
 * Returns if the value is one of the forced break values.
 * @param value The break value to be judged. Treats null as 'auto'.
 */
export declare function isForcedBreakValue(value: string | null): boolean;
export declare const spreadBreakValues: {
    [key: string]: boolean | null;
};
/**
 * Returns if the value is one of left/right/recto/verso values.
 * @param value The break value to be judged. Treats null as 'auto'.
 */
export declare function isSpreadBreakValue(value: string | null): boolean;
/**
 * Returns if the value is a page-level forced break value.
 * That is, one of page/left/right/recto/verso, excluding column/region.
 * @param value The break value to be judged. Treats null as 'auto'.
 */
export declare function isPageLevelForcedBreak(value: string | null): boolean;
export declare const avoidBreakValues: {
    [key: string]: boolean | null;
};
/**
 * Returns if the value is one of the avoid break values.
 * @param value The break value to be judged. Treats null as 'auto'.
 */
export declare function isAvoidBreakValue(value: string | null): boolean;
/**
 * Resolves the effective break value given two break values at a single break
 * point. The order of the arguments are relevant, since a value specified on
 * the latter element takes precedence over one on the former. A forced break
 * value is chosen if present. Otherwise, an avoid break value is chosen if
 * present. See CSS Fragmentation Module for the rule:
 *  https://drafts.csswg.org/css-break/#forced-breaks
 *  https://drafts.csswg.org/css-break/#unforced-breaks
 * Note that though the spec requires to honor multiple break values at a single
 * break point, the current implementation choose one of them and discard the
 * others.
 * @param first The break value specified on the former element. null means
 *     'auto' (not specified)
 * @param second The break value specified on the latter element. null means
 *     'auto' (not specified)
 */
export declare function resolveEffectiveBreakValue(first: string | null, second: string | null): string | null;
export declare function breakValueToStartBreakType(breakValue: string | null): string;
export {};
