/**
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Types - Type definiions.
 */
import * as Base from "./base";
import * as Css from "./css";
import * as Diff from "./diff";
import * as Exprs from "./exprs";
import * as GeometryUtil from "./geometry-util";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
export type FormattingContextType = "Block" | "RepetitiveElementsOwner" | "Table";
export type FragmentLayoutConstraintType = "AfterIfContinue" | "EntireTable" | "RepetitiveElementsOwner" | "TableRow";
export declare namespace CssCascade {
    type ElementStyle = {
        [key: string]: any;
    };
    interface CascadeValue {
        readonly value: Css.Val;
        readonly priority: number;
        getBaseValue(): CascadeValue;
        filterValue(visitor: Css.Visitor): CascadeValue;
        increaseSpecificity(specificity: number): CascadeValue;
        evaluate(context: Exprs.Context, propName?: string, percentRef?: number, vertical?: boolean): Css.Val;
        isEnabled(context: Exprs.Context): boolean;
    }
}
export declare namespace CssStyler {
    interface AbstractStyler {
        getStyle(element: Element, deep: boolean): CssCascade.ElementStyle;
        processContent(element: Element, styles: {
            [key: string]: Css.Val;
        }, nodeContext: Vtree.NodeContext): any;
    }
}
export declare namespace Layout {
    /**
     * Represents a constraint on layout
     */
    interface LayoutConstraint {
        /**
         * Returns if this constraint allows the node context to be laid out at the
         * current position.
         */
        allowLayout(nodeContext: Vtree.NodeContext): boolean;
        /**
         * Returns if this constraint allows the node context immediately after a
         * page-level break has already been satisfied.
         */
        allowLayoutAfterPageBreak?(nodeContext: Vtree.NodeContext): boolean;
    }
    /**
     * Represents constraints on laying out fragments
     */
    interface FragmentLayoutConstraint {
        flagmentLayoutConstraintType: FragmentLayoutConstraintType;
        allowLayout(nodeContext: Vtree.NodeContext | null, overflownNodeContext: Vtree.NodeContext | null, column: Column): boolean;
        nextCandidate(nodeContext: Vtree.NodeContext | null): boolean;
        postLayout(allowed: boolean, positionAfter: Vtree.NodeContext | null, initialPosition: Vtree.NodeContext | null, column: Column): any;
        finishBreak(nodeContext: Vtree.NodeContext | null, column: Column): Task.Result<boolean>;
        equalsTo(constraint: FragmentLayoutConstraint): boolean;
        getPriorityOfFinishBreak(): number;
    }
    /**
     * Potential breaking position.
     */
    interface BreakPosition {
        /**
         * @return break position, if found
         */
        findAcceptableBreak(column: Column, penalty: number): Vtree.NodeContext | null;
        /**
         * @return penalty for this break position
         */
        getMinBreakPenalty(): number;
        calculateOffset(column: Column): {
            current: number;
            minimum: number;
        };
        breakPositionChosen(column: Column): void;
    }
    interface AbstractBreakPosition extends BreakPosition {
        getNodeContext(): Vtree.NodeContext | null;
    }
    type BreakPositionAndNodeContext = {
        breakPosition: BreakPosition;
        nodeContext: Vtree.NodeContext;
    };
    /**
     * Potential breaking position inside CSS box (between lines).
     * @param checkPoints array of breaking points for
     *    breakable block
     */
    interface BoxBreakPosition extends AbstractBreakPosition {
        breakNodeContext: Vtree.NodeContext | null;
        readonly checkPoints: Vtree.RenderedNodeContext[];
        readonly penalty: number;
    }
    /**
     * Potential edge breaking position.
     */
    interface EdgeBreakPosition extends AbstractBreakPosition {
        overflowIfRepetitiveElementsDropped: boolean;
        readonly position: Vtree.NodeContext;
        readonly breakOnEdge: string | null;
        overflows: boolean;
        readonly computedBlockSize: number;
    }
    interface Column extends Vtree.Container {
        last: Node | null;
        viewDocument: Document;
        flowRootFormattingContext: Vtree.FormattingContext;
        isNonFirstColumn: boolean;
        isFloat: boolean;
        isFootnote: boolean;
        startEdge: number;
        endEdge: number;
        beforeEdge: number;
        afterEdge: number;
        footnoteEdge: number;
        chunkPositions: Vtree.ChunkPosition[];
        bands: GeometryUtil.Band[];
        overflown: boolean;
        breakPositions: BreakPosition[];
        pageBreakType: string | null;
        forceNonfitting: boolean;
        leftFloatEdge: number;
        /**
         * bottom of the bottommost left float
         */
        rightFloatEdge: number;
        /**
         * bottom of the bottommost right float
         */
        bottommostFloatTop: number;
        /**
         * Top of the bottommost float
         */
        stopAtOverflow: boolean;
        lastAfterPosition: Vtree.NodePosition | null;
        fragmentLayoutConstraints: FragmentLayoutConstraint[];
        pseudoParent: Column | null;
        nodeContextOverflowingDueToRepetitiveElements: Vtree.NodeContext | null;
        blockDistanceToBlockEndFloats: number;
        lastLineStride: number;
        computedBlockSize: number;
        layoutContext: Vtree.LayoutContext;
        clientLayout: Vtree.ClientLayout;
        readonly layoutConstraint: LayoutConstraint;
        readonly pageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext;
        getTopEdge(): number;
        getBottomEdge(): number;
        getLeftEdge(): number;
        getRightEdge(): number;
        asFloatNodeContext(nodeContext: Vtree.NodeContext): Vtree.FloatNodeContext | null;
        stopByOverflow(nodeContext: Vtree.NodeContext): boolean;
        isOverflown(edge: number): boolean;
        getExclusions(): GeometryUtil.Shape[];
        openAllViews(position: Vtree.NodePosition): Task.Result<Vtree.NodeContext>;
        calculateOffsetInNodeForNodeContext(position: Vtree.NodePosition): number;
        /**
         * @param count first-XXX nesting identifier
         */
        maybePeelOff(position: Vtree.NodeContext, count: number): Task.Result<Vtree.NodeContext>;
        /**
         * Builds the view until a CSS box edge is reached.
         * @param position start source position.
         * @param checkPoints array to append possible breaking points.
         * @return holding box edge position reached or null if the source is exhausted.
         */
        buildViewToNextBlockEdge(position: Vtree.NodeContext | null, checkPoints: Vtree.RenderedNodeContext[]): Task.Result<Vtree.NodeContext | null>;
        nextInTree(position: Vtree.NodeContext, atUnforcedBreak?: boolean): Task.Result<Vtree.NodeContext | null>;
        /**
         * Builds the view for a single unbreakable element.
         * @param position start source position.
         * @return holding box edge position reached or null if the source is exhausted.
         */
        buildDeepElementView(position: Vtree.NodeContext | null): Task.Result<Vtree.NodeContext | null>;
        /**
         * Create a single floating element (for exclusion areas).
         * @param ref container's child to insert float before (can be null).
         * @param side float side ("left" or "right").
         * @param width float inline dimension.
         * @param height float box progression dimension.
         * @return newly created float element.
         */
        createFloat(ref: Node | null, side: string, width: number, height: number): Element;
        /**
         * Remove all the exclusion floats.
         */
        killFloats(): void;
        /**
         * Create exclusion floats for a column.
         */
        createFloats(): void;
        /**
         * @param nodeContext position after the block
         * @param checkPoints array of possible breaking points.
         * @param index index of the breaking point
         * @param boxOffset box offset
         * @return edge position
         */
        calculateEdge(nodeContext: Vtree.NodeContext | null, checkPoints: Vtree.RenderedNodeContext[], index: number, boxOffset: number): number;
        /**
         * Parse CSS computed length (in pixels)
         * @param val CSS length in "px"
         * @return parsed and adjusted length value in pixels or 0 if not parsable
         */
        parseComputedLength(val: string): number;
        /**
         * Reads element's computed CSS margin.
         */
        getComputedMargin(element: Element): GeometryUtil.Insets;
        /**
         * Reads element's computed padding + borders.
         */
        getComputedPaddingBorder(element: Element): GeometryUtil.Insets;
        /**
         * Reads element's computed CSS insets(margins + border + padding or margins :
         * depends on box-sizing)
         */
        getComputedInsets(element: Element): GeometryUtil.Insets;
        /**
         * Set element's computed CSS insets to Column Container
         */
        setComputedInsets(element: Element, container: Column): void;
        /**
         * Set element's computed width and height to Column Container
         */
        setComputedWidthAndHeight(element: Element, container: Column): void;
        /**
         * Layout a single unbreakable element.
         */
        layoutUnbreakable(nodeContextIn: Vtree.NodeContext): Task.Result<Vtree.NodeContext | null>;
        /**
         * Layout a single float element.
         */
        layoutFloat(nodeContext: Vtree.RenderedNodeContext): Task.Result<Vtree.NodeContext | null>;
        setupFloatArea(area: PageFloatArea, floatReference: PageFloats.FloatReference, floatSide: string, anchorEdge: number | null, strategy: PageFloats.PageFloatLayoutStrategy, condition: PageFloats.PageFloatPlacementCondition): Task.Result<boolean>;
        createPageFloatArea(float: PageFloats.PageFloat, floatSide: string, anchorEdge: number | null, strategy: PageFloats.PageFloatLayoutStrategy, condition: PageFloats.PageFloatPlacementCondition): Task.Result<PageFloatArea | null>;
        layoutSinglePageFloatFragment(continuations: PageFloats.PageFloatContinuation[], floatSide: string, clearSide: string | null, allowFragmented: boolean, strategy: PageFloats.PageFloatLayoutStrategy, anchorEdge: number | null, pageFloatFragment?: PageFloats.PageFloatFragment | null): Task.Result<SinglePageFloatLayoutResult>;
        layoutPageFloatInner(continuation: PageFloats.PageFloatContinuation, strategy: PageFloats.PageFloatLayoutStrategy, anchorEdge: number | null, pageFloatFragment?: PageFloats.PageFloatFragment | null): Task.Result<boolean>;
        setFloatAnchorViewNode(nodeContext: Vtree.RenderedNodeContext): Vtree.RenderedNodeContext;
        resolveFloatReferenceFromColumnSpan(floatReference: PageFloats.FloatReference, columnSpan: Css.Val | null, nodeContext: Vtree.NodeContext): Task.Result<PageFloats.FloatReference>;
        layoutPageFloat(nodeContext: Vtree.FloatNodeContext): Task.Result<Vtree.NodeContext | null>;
        processLineStyling(nodeContext: Vtree.NodeContext, resNodeContext: Vtree.NodeContext | null, checkPoints: Vtree.RenderedNodeContext[]): Task.Result<Vtree.NodeContext | null>;
        isLoneImage(checkPoints: Vtree.RenderedNodeContext[]): boolean;
        getTrailingMarginEdgeAdjustment(trailingEdgeContexts: Vtree.NodeContext[]): number;
        /**
         * Layout a single CSS box.
         */
        layoutBreakableBlock(nodeContext: Vtree.NodeContext): Task.Result<Vtree.NodeContext | null>;
        postLayoutBlock(nodeContext: Vtree.NodeContext | null, checkPoints: Vtree.RenderedNodeContext[]): void;
        findEndOfLine(linePosition: number, checkPoints: Vtree.RenderedNodeContext[], isUpdateMaxReachedAfterEdge: boolean): {
            nodeContext: Vtree.RenderedNodeContext;
            index: number;
            checkPointIndex: number;
        };
        findAcceptableBreakInside(checkPoints: Vtree.RenderedNodeContext[], edgePosition: number, force: boolean): Vtree.NodeContext | null;
        resolveTextNodeBreaker(nodeContext: Vtree.NodeContext): TextNodeBreaker;
        /**
         * Read ranges skipping special elments
         */
        getRangeBoxes(start: Element | Text, end: Element | Text): Vtree.ClientRect[];
        /**
         * Give block's initial and final nodes, find positions of the line bottoms.
         * This is, of course, somewhat hacky implementation.
         * @return position of line breaks
         */
        findLinePositions(checkPoints: Vtree.RenderedNodeContext[]): number[];
        calculateClonedPaddingBorder(nodeContext: Vtree.NodeContext): number;
        findBoxBreakPosition(bp: BoxBreakPosition, force: boolean): Vtree.NodeContext | null;
        getAfterEdgeOfBlockContainer(nodeContext: Vtree.NodeContext): number;
        findFirstOverflowingEdgeAndCheckPoint(checkPoints: Vtree.RenderedNodeContext[]): {
            edge: number;
            checkPoint: Vtree.RenderedNodeContext | null;
        };
        findEdgeBreakPosition(bp: EdgeBreakPosition): Vtree.NodeContext;
        /**
         * Finalize a line break.
         * @return holing true
         */
        finishBreak(nodeContext: Vtree.NodeContext, forceRemoveSelf: boolean, endOfColumn: boolean): Task.Result<boolean>;
        findAcceptableBreakPosition(): BreakPositionAndNodeContext | null;
        doFinishBreak(nodeContext: Vtree.NodeContext | null, overflownNodeContext: Vtree.NodeContext | null, initialNodeContext: Vtree.NodeContext | null, initialComputedBlockSize: number): Task.Result<Vtree.NodeContext | null>;
        /**
         * Determines if a page break is acceptable at this position
         */
        isBreakable(flowPosition: Vtree.NodeContext): boolean;
        /**
         * @return true if overflows
         */
        checkOverflowAndSaveEdge(nodeContext: Vtree.NodeContext | null, trailingEdgeContexts: Vtree.NodeContext[] | null): boolean;
        /**
         * Save a possible page break position on a CSS block edge. Check if it
         * overflows.
         * @return true if overflows
         */
        checkOverflowAndSaveEdgeAndBreakPosition(nodeContext: Vtree.NodeContext | null, trailingEdgeContexts: Vtree.NodeContext[] | null, saveEvenOverflown: boolean, breakAtTheEdge: string | null): boolean;
        applyClearance(nodeContext: Vtree.RenderedNodeContext): boolean;
        isBFC(formattingContext: Vtree.FormattingContext): boolean;
        /**
         * Skips positions until either the start of unbreakable block or inline
         * content. Also sets breakBefore on the result combining break-before and
         * break-after properties from all elements that meet at the edge.
         */
        skipEdges(nodeContext: Vtree.NodeContext, leadingEdge: boolean, forcedBreakValue: string | null): Task.Result<Vtree.NodeContext | null>;
        /**
         * Skips non-renderable positions until it hits the end of the flow or some
         * renderable content. Returns the nodeContext that was passed in if some
         * content remains and null if all content could be skipped.
         */
        skipTailEdges(nodeContext: Vtree.NodeContext): Task.Result<Vtree.NodeContext | null>;
        layoutFloatOrFootnote(nodeContext: Vtree.FloatNodeContext): Task.Result<Vtree.NodeContext | null>;
        /**
         * Layout next portion of the source.
         */
        layoutNext(nodeContext: Vtree.NodeContext, leadingEdge: boolean, forcedBreakValue?: string | null): Task.Result<Vtree.NodeContext>;
        clearOverflownViewNodes(nodeContext: Vtree.NodeContext | null, removeSelf: boolean): void;
        /**
         * Save the potential breaking position at the edge. Should, in general, save
         * "after" position but only after skipping all of the "before" ones and
         * getting to the non-empty content (to get breakAtEdge right).
         */
        saveEdgeBreakPosition(position: Vtree.NodeContext, breakAtEdge: string | null, overflows: boolean): void;
        /**
         * @param checkPoints array of breaking points for breakable block
         */
        saveBoxBreakPosition(checkPoints: Vtree.RenderedNodeContext[]): void;
        updateMaxReachedAfterEdge(afterEdge: number): void;
        /**
         * @param chunkPosition starting position.
         * @return holding end position.
         */
        layout(chunkPosition: Vtree.ChunkPosition, leadingEdge: boolean, breakAfter?: string | null): Task.Result<Vtree.ChunkPosition | null>;
        isFullWithPageFloats(): boolean;
        getMaxBlockSizeOfPageFloats(): number;
        doFinishBreakOfFragmentLayoutConstraints(nodeContext: Vtree.NodeContext): Task.Result<boolean>;
        /**
         * @param nodeContext starting position.
         * @return holding end position.
         */
        doLayout(nodeContext: Vtree.NodeContext | null, leadingEdge: boolean, breakAfter?: string | null): Task.Result<{
            nodeContext: Vtree.NodeContext | null;
            overflownNodeContext: Vtree.NodeContext | null;
        }>;
        saveDistanceToBlockEndFloats(): void;
        collectElementsOffset(): RepetitiveElement.ElementsOffset[];
    }
    type SinglePageFloatLayoutResult = {
        floatArea: PageFloatArea | null;
        pageFloatFragment: PageFloats.PageFloatFragment | null;
        newPosition: Vtree.ChunkPosition | null;
    };
    /**
     * breaking point resolver for Text Node.
     */
    interface TextNodeBreaker {
        breakTextNode(textNode: Text, nodeContext: Vtree.NodeContext, low: number, checkPoints: Vtree.RenderedNodeContext[], checkpointIndex: number, force: boolean): Vtree.NodeContext;
        breakAfterSoftHyphen(textNode: Text, text: string, viewIndex: number, nodeContext: Vtree.NodeContext): number;
        breakAfterOtherCharacter(textNode: Text, text: string, viewIndex: number, nodeContext: Vtree.NodeContext): number;
        updateNodeContext(nodeContext: Vtree.NodeContext, viewIndex: number, textNode: Text): Vtree.NodeContext;
    }
    interface LayoutMode {
        doLayout(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<Vtree.NodeContext | null>;
        accept(nodeContext: Vtree.NodeContext | null, column: Layout.Column): boolean;
        postLayout(positionAfter: Vtree.NodeContext | null, initialPosition: Vtree.NodeContext, column: Layout.Column, accepted: boolean): boolean;
    }
    interface PageFloatArea extends Column {
        adjustContentRelativeSize: boolean;
        readonly floatSide: string;
        readonly parentContainer: Vtree.Container;
        readonly parentElement: Element | null;
        applyCompactFootnoteDisplay(): void;
        convertPercentageSizesToPx(target: Element): void;
        fixFloatSizeAndPosition(nodeContext: Vtree.NodeContext): void;
        getRootViewNodeCount(): number;
        hasNonPseudoTextContentAfter(rootViewNodeIndex: number): boolean;
        appendContentFrom(other: PageFloatArea): void;
        getContentBlockMarginAfter(): number;
        getContentInlineSize(): number;
    }
}
export declare namespace LayoutProcessor {
    interface BlockFormattingContext extends Vtree.FormattingContext {
    }
    function isInstanceOfBlockFormattingContext(object: Vtree.FormattingContext): object is BlockFormattingContext;
}
export declare namespace Net {
    type FetchResponse = {
        status: number;
        statusText: string | null;
        url: string;
        contentType: string | null;
        responseText: string | null;
        responseXML: Document | null;
        responseBlob: Blob | null;
    };
    interface ResourceStore<Resource> {
        resources: {
            [key: string]: Resource | null;
        };
        fetchers: {
            [key: string]: TaskUtil.Fetcher<Resource | null>;
        };
        readonly parser: (p1: FetchResponse, p2: ResourceStore<Resource>) => Task.Result<Resource | null>;
        readonly type: XMLHttpRequestResponseType;
        /**
         * @return resource for the given URL
         */
        load(url: string, opt_required?: boolean, opt_message?: string): Task.Result<Resource | null>;
        /**
         * @return fetcher for the resource for the given URL
         */
        fetch(url: string, opt_required?: boolean, opt_message?: string): TaskUtil.Fetcher<Resource | null> | null;
        get(url: string): XmlDoc.XMLDocHolder;
        delete(url: string): void;
    }
}
export declare namespace PageFloats {
    /**
     * @enum {string}
     */
    enum FloatReference {
        INLINE = "inline",
        COLUMN = "column",
        REGION = "region",
        PAGE = "page"
    }
    type PageFloatID = string;
    interface PageFloat {
        order: number | null;
        id: PageFloatID | null;
        insidePageFloatArea: boolean;
        parentPageFloat: PageFloat | null;
        readonly nodePosition: Vtree.NodePosition;
        readonly floatReference: FloatReference;
        readonly floatSide: string;
        readonly clearSide: string | null;
        readonly flowName: string;
        readonly floatMinWrapBlock: Css.Numeric | null;
        getOrder(): number;
        getId(): PageFloatID;
        isAllowedOnContext(pageFloatLayoutContext: AttachedPageFloatLayoutContext): boolean;
        isAllowedToPrecede(other: PageFloat): boolean;
    }
    interface PageFloatFragment {
        readonly floatReference: FloatReference;
        readonly floatSide: string;
        readonly clearSide: string | null;
        readonly continuations: PageFloatContinuation[];
        readonly area: Vtree.Container;
        readonly continues: boolean;
        hasFloat(float: PageFloat): boolean;
        findNotAllowedFloat(context: AttachedPageFloatLayoutContext): PageFloat | null;
        getOuterShape(): GeometryUtil.Shape;
        getOuterRect(): GeometryUtil.Rect;
        getOrder(): number;
        shouldBeStashedBefore(float: PageFloat): boolean;
        addContinuations(continuations: PageFloatContinuation[]): void;
        getFlowName(): string;
    }
    interface PageFloatContinuation {
        readonly float: PageFloat;
        readonly nodePosition: Vtree.NodePosition;
        equals(other: PageFloatContinuation | null): boolean;
    }
    type PageFloatPlacementCondition = {
        [key: string]: boolean;
    };
    interface PageFloatLayoutContext {
        direction: Css.Val;
        floatFragments: PageFloatFragment[];
        ignoreFootnoteAreaMaxHeight: boolean;
        readonly parent: PageFloatLayoutContext | null;
        readonly effectiveParent: PageFloatLayoutContext | null;
        readonly flowName: string | null;
        readonly generatingNodePosition: Vtree.NodePosition | null;
        addPageFloat(float: PageFloat): void;
        getPageFloatLayoutContext(floatReference: FloatReference): PageFloatLayoutContext;
        findPageFloatByNodePosition(nodePosition: Vtree.NodePosition): PageFloat | null;
        isForbidden(float: PageFloat): boolean;
        findPageFloatFragment(float: PageFloat): PageFloatFragment | null;
        hasFloatFragments(condition?: (p1: PageFloatFragment) => boolean): boolean;
        hasContinuingFloatFragmentsInFlow(flowName: string): boolean;
        markPageFloatAnchorSeen(float: PageFloat): void;
        registerPageFloatAnchor(float: PageFloat, anchorViewNode: Node): void;
        deferPageFloat(continuation: PageFloatContinuation): void;
        removeFloatDeferredToNext(float: PageFloat): void;
        hasPrecedingFloatsDeferredToNext(float: PageFloat, ignoreReference?: boolean): boolean;
        getDeferredPageFloatContinuations(flowName?: string | null): PageFloatContinuation[];
        getPageFloatContinuationsDeferredToNext(flowName?: string | null): PageFloatContinuation[];
        isInvalidated(): boolean;
        validate(): void;
        discardStashedFragments(floatReference: FloatReference): void;
        getStashedFloatFragments(floatReference: FloatReference): PageFloatFragment[];
        getFloatFragmentExclusions(): GeometryUtil.Shape[];
        getLayoutConstraints(): Layout.LayoutConstraint[];
        addLayoutConstraint(layoutConstraint: Layout.LayoutConstraint, floatReference: FloatReference): void;
        lock(): void;
        unlock(): void;
        isLocked(): boolean;
    }
    /** Only the root and an attached context can be one, and only these hold children. */
    interface ParentPageFloatLayoutContext extends PageFloatLayoutContext {
        readonly children: readonly AttachedPageFloatLayoutContext[];
        collectPageFloatAnchors(): any;
        getFloatsDeferredToNextInChildContexts(): PageFloat[];
        detachChildren(): AttachedPageFloatLayoutContext[];
        attachChildren(children: AttachedPageFloatLayoutContext[]): void;
    }
    /** Where a float goes can only be asked of a context bound to a container. */
    interface AttachedPageFloatLayoutContext extends ParentPageFloatLayoutContext {
        readonly container: Vtree.Container;
        getPageFloatLayoutContext(floatReference: FloatReference): AttachedPageFloatLayoutContext;
        restoreStashedFragments(floatReference: FloatReference): void;
        addPageFloatFragment(floatFragment: PageFloatFragment, dontInvalidate?: boolean): void;
        removePageFloatFragment(floatFragment: PageFloatFragment, dontInvalidate?: boolean): void;
        initFootnoteRetryFromEmptyFragment(float: PageFloat, area: Layout.PageFloatArea): boolean;
        finish(): void;
        hasSameContainerAs(other: AttachedPageFloatLayoutContext): boolean;
        invalidate(): void;
        stashEndFloatFragments(float: PageFloat): void;
        /**
         * @param anchorEdge Null indicates that the anchor is not in the current
         *     container.
         * @return Logical float side (snap-block is resolved when init=false). Null
         *     indicates that the float area does not fit inside the container
         */
        setFloatAreaDimensions(area: Layout.PageFloatArea, floatReference: FloatReference, floatSide: string, anchorEdge: number | null, init: boolean, force: boolean, condition: PageFloatPlacementCondition): string | null;
        getMaxReachedAfterEdge(): number;
        getBlockEndEdgeOfBlockStartFloats(inlinePos?: number): number;
        getBlockStartEdgeOfBlockEndFloats(inlinePos?: number): number;
        getPageFloatClearEdge(clear: string, column: Layout.Column): number;
        getPageFloatPlacementCondition(float: PageFloat, floatSide: string, clearSide: string | null): PageFloatPlacementCondition;
        getMaxBlockSizeOfPageFloats(): number;
    }
    interface PageFloatLayoutStrategy {
        appliesToNodeContext(nodeContext: Vtree.NodeContext): boolean;
        appliesToFloat(float: PageFloat): boolean;
        createPageFloat(nodeContext: Vtree.FloatNodeContext, pageFloatLayoutContext: AttachedPageFloatLayoutContext, column: Layout.Column): Task.Result<PageFloat>;
        createPageFloatFragment(continuations: PageFloatContinuation[], floatSide: string, clearSide: string | null, floatArea: Layout.PageFloatArea, continues: boolean): PageFloatFragment;
        findPageFloatFragment(float: PageFloat, pageFloatLayoutContext: AttachedPageFloatLayoutContext): PageFloatFragment | null;
        adjustPageFloatArea(floatArea: Layout.PageFloatArea, floatContainer: Vtree.Container, column: Layout.Column): Task.Result<void>;
        forbid(float: PageFloat, pageFloatLayoutContext: AttachedPageFloatLayoutContext): any;
    }
}
export declare namespace Selectors {
    interface AfterIfContinues {
        readonly sourceNode: Element;
        readonly styler: PseudoElement.PseudoelementStyler;
        createElement(column: Layout.Column, parentNodeContext: Vtree.ElementNodeContext): Task.Result<Element>;
    }
    interface AfterIfContinuesLayoutConstraint extends Layout.FragmentLayoutConstraint {
        nodeContext: Vtree.ElementNodeContext;
        afterIfContinues: AfterIfContinues;
        pseudoElementHeight: number;
        getRepetitiveElements(): AfterIfContinuesElementsOffset;
    }
    function isInstanceOfAfterIfContinuesLayoutConstraint(object: Layout.FragmentLayoutConstraint): object is AfterIfContinuesLayoutConstraint;
    interface AfterIfContinuesElementsOffset extends RepetitiveElement.ElementsOffset {
        nodeContext: Vtree.NodeContext;
        pseudoElementHeight: number;
        affectTo(nodeContext: Vtree.NodeContext): boolean;
    }
}
export declare namespace PseudoElement {
    interface PseudoelementStyler extends CssStyler.AbstractStyler {
        contentProcessed: {
            [key: string]: boolean;
        };
        readonly element: Element;
        style: CssCascade.ElementStyle;
        readonly styler: CssStyler.AbstractStyler;
        readonly context: Exprs.Context;
        readonly exprContentListener: Vtree.ExprContentListener;
    }
}
export declare namespace RepetitiveElement {
    interface RepetitiveElementsOwnerFormattingContext extends Vtree.FormattingContext {
        repetitiveElements: RepetitiveElements | null;
        readonly parent: Vtree.FormattingContext | null;
        readonly rootSourceNode: Element;
        getRepetitiveElements(): RepetitiveElements | null;
        getRootViewNode(position: Vtree.NodeContext): Element | null;
        getRootNodeContext(nodeContext: Vtree.NodeContext): Vtree.NodeContext | null;
        initializeRepetitiveElements(vertical: boolean): void;
    }
    function isInstanceOfRepetitiveElementsOwnerFormattingContext(object: Vtree.FormattingContext): object is RepetitiveElementsOwnerFormattingContext;
    interface ElementsOffset {
        calculateOffset(nodeContext: Vtree.NodeContext | null): number;
        calculateMinimumOffset(nodeContext: Vtree.NodeContext | null): number;
    }
    interface RepetitiveElements extends ElementsOffset {
        isSkipHeader: boolean;
        isSkipFooter: boolean;
        enableSkippingFooter: boolean;
        enableSkippingHeader: boolean;
        doneInitialLayout: boolean;
        firstContentSourceNode: Element | null;
        lastContentSourceNode: Element | null;
        allowInsertRepeatitiveElements: boolean;
        ownerSourceNode: Element;
        setHeaderNodeContext(nodeContext: Vtree.NodeContext): void;
        setFooterNodeContext(nodeContext: Vtree.NodeContext): void;
        updateHeight(column: Layout.Column): void;
        prepareLayoutFragment(): void;
        appendHeaderToFragment(rootNodeContext: Vtree.ElementNodeContext, firstChild: Node | null, column: Layout.Column): Task.Result<boolean>;
        appendFooterToFragment(rootNodeContext: Vtree.ElementNodeContext, firstChild: Node | null, column: Layout.Column): Task.Result<boolean>;
        appendElementToFragment(nodePosition: Vtree.NodePosition, rootNodeContext: Vtree.ElementNodeContext, firstChild: Node | null, column: Layout.Column): Task.Result<boolean>;
        moveChildren(from: Element, to: Element, firstChild: Node | null): void;
        isAfterLastContent(nodeContext: Vtree.NodeContext): boolean;
        isFirstContentNode(nodeContext: Vtree.NodeContext): boolean;
        isEnableToUpdateState(): boolean;
        updateState(): void;
        preventSkippingHeader(): void;
        preventSkippingFooter(): void;
        isHeaderRegistered(): boolean;
        isFooterRegistered(): boolean;
        isHeaderSourceNode(node: Node): boolean;
        isFooterSourceNode(node: Node): boolean;
    }
    interface RepetitiveElementsOwnerLayoutConstraint extends Layout.FragmentLayoutConstraint {
        getRepetitiveElements(): RepetitiveElements | null;
    }
    function isInstanceOfRepetitiveElementsOwnerLayoutConstraint(object: Layout.FragmentLayoutConstraint): object is RepetitiveElementsOwnerLayoutConstraint;
}
export declare namespace Table {
    interface TableFormattingContext extends RepetitiveElement.RepetitiveElementsOwnerFormattingContext {
    }
    function isInstanceOfTableFormattingContext(object: Vtree.FormattingContext): object is TableFormattingContext;
    interface TableRowLayoutConstraint extends RepetitiveElement.RepetitiveElementsOwnerLayoutConstraint {
        cellFragmentLayoutConstraints: {
            constraints: Layout.FragmentLayoutConstraint[];
            breakPosition: Vtree.NodeContext | null;
        }[];
        removeDummyRowNodes(nodeContext: Vtree.NodeContext): void;
        getElementsOffsetsForTableCell(column: Layout.Column | null): RepetitiveElement.ElementsOffset[];
    }
    function isInstanceOfTableRowLayoutConstraint(object: Layout.FragmentLayoutConstraint): object is TableRowLayoutConstraint;
}
export declare namespace Vtree {
    type ClientRect = {
        left: number;
        top: number;
        right: number;
        bottom: number;
        width: number;
        height: number;
    };
    /**
     * Interface to read the position assigned to the elements and ranges by the
     * browser.
     */
    interface ClientLayout {
        layoutBox: Element;
        window: Window;
        pixelRatio: number;
        scaleRatio: number;
        layoutUnitPerPixel: number;
        /**
         * @param range range to measure. The caller may share it with later
         *     measurements and reset it to a collapsed range at the start of its
         *     document once this call returns.
         * @return client rects of the range relative to the layout box.
         */
        getRangeClientRects(range: Range): ClientRect[];
        getElementClientRect(element: Element): ClientRect;
        /**
         * @return element's computed style
         */
        getElementComputedStyle(element: Element): CSSStyleDeclaration;
        /**
         * Adjust length value with rendering precision.
         * @param value Length value to adjust
         * @return Adjusted length value
         */
        adjustLengthValue(value: number): number;
    }
    /**
     * Styling, creating a single node's view, etc.
     */
    interface LayoutContext {
        /**
         * Creates a functionally equivalent, but uninitialized layout context,
         * suitable for building a separate column.
         */
        clone(): LayoutContext;
        /**
         * Set the current source node and create a view. Parameter firstTime
         * is true (and possibly offsetInNode > 0) if node was broken on
         * the previous page.
         * @return true if children should be processed as well
         */
        setCurrent(nodeContext: NodeContext, firstTime: boolean, atUnforcedBreak?: boolean): Task.Result<boolean>;
        /**
         * Set the container element that holds view elements produced from the
         * source.
         */
        setViewRoot(viewRoot: Element, isFootnote: boolean): any;
        /**
         * Moves to the next view node, creating it and appending it to the view tree
         * if needed.
         * @return that corresponds to the next view node
         */
        nextInTree(nodeContext: NodeContext, atUnforcedBreak?: boolean): Task.Result<NodeContext | null>;
        /**
         * Apply pseudo-element styles (if any).
         * @param target element to apply styles to
         */
        applyPseudoelementStyle(nodeContext: NodeContext, pseudoName: string, target: Element): void;
        /**
         * Apply styles to footnote container.
         * @param target element to apply styles to
         * @return vertical
         */
        applyFootnoteStyle(vertical: boolean, rtl: boolean, target: Element): Task.Result<boolean>;
        /**
         * Peel off innermost first-XXX pseudoelement, create and create view nodes
         * after the end of that pseudoelement.
         */
        peelOff(nodeContext: ChildNodeContext, nodeOffset: number): Task.Result<NodeContext>;
        /**
         * Process a block-end edge of a fragmented block.
         */
        processFragmentedBlockEdge(nodeContext: NodeContext): any;
        convertLengthToPx(numeric: Css.Numeric, viewNode: Node, clientLayout: ClientLayout): number | Css.Numeric;
        /**
         * Returns if two NodePositions represents the same position in the document.
         */
        isSameNodePosition(nodePosition1: NodePosition, nodePosition2: NodePosition): boolean;
        addEventListener(type: string, listener: Base.EventListener, capture?: boolean): void;
        removeEventListener(type: string, listener: Base.EventListener, capture?: boolean): void;
        dispatchEvent(evt: Base.Event): void;
    }
    /**
     * Formatting context.
     */
    interface FormattingContext {
        formattingContextType: FormattingContextType;
        getName(): string;
        isFirstTime(nodeContext: NodeContext, firstTime: boolean): boolean;
        getParent(): FormattingContext | null;
        saveState(): any;
        restoreState(state: any): any;
    }
    type NodePositionStep = {
        node: Node;
        shadowType: ShadowType;
        shadowContext: ShadowContext | null;
        nodeShadow: ShadowContext | null;
        shadowSibling: NodePositionStep | null;
        formattingContext: FormattingContext | null;
        fragmentIndex: number;
    };
    type RootNodePositionStep = NodePositionStep & {
        shadowSibling: null;
    };
    type NodePosition = {
        steps: [...NodePositionStep[], RootNodePositionStep];
        offsetInNode: number;
        after: boolean;
        preprocessedTextContent: Diff.Change[] | null;
    };
    /**
     * Handling of purely whitespace sequences between blocks
     * @enum {number}
     */
    enum Whitespace {
        /**
         * Whitespace sequence between blocks is ignored
         */
        IGNORE = 0,
        /**
         * Whitespace sequence between blocks is ignored unless it containes newline
         */
        NEWLINE = 1,
        /**
         * Whitespace sequence between blocks is preserved
         */
        PRESERVE = 2
    }
    interface ContainerGeometry {
        left: number;
        top: number;
        marginLeft: number;
        marginRight: number;
        marginTop: number;
        marginBottom: number;
        borderLeft: number;
        borderRight: number;
        borderTop: number;
        borderBottom: number;
        paddingLeft: number;
        paddingRight: number;
        paddingTop: number;
        paddingBottom: number;
        width: number;
        height: number;
        originX: number;
        originY: number;
        snapWidth: number;
        snapHeight: number;
        vertical: boolean;
        rtl: boolean;
        borderBoxSizing: boolean;
    }
    interface Container extends ContainerGeometry {
        exclusions: GeometryUtil.Shape[] | null;
        innerShape: GeometryUtil.Shape | null;
        computedBlockSize: number;
        snapOffsetX: number;
        snapOffsetY: number;
        element: HTMLElement;
        getInsetTop(): number;
        getInsetBottom(): number;
        getInsetLeft(): number;
        getInsetRight(): number;
        getInsetBefore(): number;
        getInsetAfter(): number;
        getInsetStart(): number;
        getInsetEnd(): number;
        getBeforeEdge(box: ClientRect): number;
        getAfterEdge(box: ClientRect): number;
        getStartEdge(box: ClientRect): number;
        getEndEdge(box: ClientRect): number;
        getInlineSize(box: ClientRect): number;
        getBoxSize(box: ClientRect): number;
        getBoxDir(): number;
        getInlineDir(): number;
        copyFrom(other: Container): void;
        setVerticalPosition(top: number, height: number): void;
        setHorizontalPosition(left: number, width: number): void;
        setBlockPosition(start: number, extent: number): void;
        setInlinePosition(start: number, extent: number): void;
        clear(): void;
        getInnerShape(): GeometryUtil.Shape;
        getInnerRect(): GeometryUtil.Rect;
        getPaddingRect(): GeometryUtil.Rect;
        getOuterShape(outerShapeProp: Css.Val | null, context: Exprs.Context | null): GeometryUtil.Shape | null;
        getOuterRect(): GeometryUtil.Rect;
    }
    /**
     * @enum {number}
     */
    enum ShadowType {
        NONE = 0,
        CONTENT = 1,
        ROOTLESS = 2,
        ROOTED = 3
    }
    /**
     * Data about shadow tree instance.
     */
    interface ShadowContext {
        readonly owner: Element;
        readonly root: Element;
        readonly xmldoc: XmlDoc.XMLDocHolder | null;
        readonly parentShadow: ShadowContext | null;
        subShadow: ShadowContext | null;
        readonly type: Vtree.ShadowType;
        readonly styler: CssStyler.AbstractStyler;
        equals(other: ShadowContext): boolean;
    }
    /**
     * Information about :first-letter or :first-line pseudoelements
     * @param count 0 - first-letter, 1 or more - first line(s)
     */
    interface FirstPseudo {
        readonly outer: FirstPseudo | null;
        readonly count: number;
    }
    /**
     * NodeContext represents a position in the document + layout-related
     * information attached to it. When after=false and offsetInNode=0, the
     * position is inside the element (node), but just before its first child.
     * When offsetInNode>0 it represents offset in the textual content of the
     * node. When after=true it represents position right after the last child
     * of the node. boxOffset is incremented by 1 for any valid node position.
     */
    interface NodeContext {
        offsetInNode: number;
        after: boolean;
        shadowType: ShadowType;
        shadowContext: Vtree.ShadowContext | null;
        nodeShadow: Vtree.ShadowContext | null;
        shadowSibling: NodeContext | null;
        shared: boolean;
        inline: boolean;
        overflow: boolean;
        breakPenalty: number;
        display: string | null;
        floatReference: PageFloats.FloatReference;
        floatSide: string | null;
        clearSide: string | null;
        floatMinWrapBlock: Css.Numeric | null;
        columnSpan: Css.Val | null;
        captionSide: string;
        inlineBorderSpacing: number;
        blockBorderSpacing: number;
        flexContainer: boolean;
        whitespace: Whitespace;
        hyphenateCharacter: string | null;
        breakWord: boolean;
        establishesBFC: boolean;
        containingBlockForAbsolute: boolean;
        breakBefore: string | null;
        breakAfter: string | null;
        viewNode: Element | Text | null;
        clearSpacer: Element | null;
        inheritedProps: {
            [key: string]: number | string | Css.Val | undefined;
        };
        vertical: boolean;
        direction: string;
        firstPseudo: FirstPseudo | null;
        lang: string | null;
        preprocessedTextContent: Diff.Change[] | null;
        formattingContext: FormattingContext;
        repeatOnBreak: string | null;
        pluginProps: {
            [key: string]: string | number | undefined | null | (number | null)[];
        };
        fragmentIndex: number;
        afterIfContinues: Selectors.AfterIfContinues | null;
        footnotePolicy: Css.Ident | null;
        pageType: string | null;
        sourceNode: Node;
        parent: NodeContext | null;
        blockContainer: ElementNodeContext | null;
        boxOffset: number;
        resetView(): void;
        modify(): this;
        copy(): this;
        clone(): this;
        toNodePositionStep(): NodePositionStep;
        toNodePosition(): NodePosition;
        isInsideBFC(): boolean;
        getContainingBlockForAbsolute(): ElementNodeContext | null;
        belongsTo(formattingContext: FormattingContext): boolean;
    }
    interface ChildNodeContext extends NodeContext {
        parent: NodeContext;
    }
    interface RootNodeContext extends NodeContext {
        parent: null;
        shadowSibling: null;
    }
    interface TextNodeContext extends ChildNodeContext {
        viewNode: Text;
    }
    interface ElementNodeContext extends NodeContext {
        viewNode: Element;
    }
    type RenderedNodeContext = ElementNodeContext | TextNodeContext;
    interface ContainedElementNodeContext extends ElementNodeContext {
        blockContainer: ElementNodeContext;
    }
    interface FloatNodeContext extends ElementNodeContext {
        floatSide: string;
    }
    interface ClearNodeContext extends ElementNodeContext {
        clearSide: string;
    }
    interface AfterIfContinuesNodeContext extends ElementNodeContext {
        afterIfContinues: Selectors.AfterIfContinues;
    }
    interface ChunkPosition {
        floats: NodePosition[] | null;
        primary: NodePosition;
        clone(): ChunkPosition;
        isSamePosition(other: ChunkPosition): boolean;
    }
    type ExprContentListener = (p1: Exprs.Val, p2: string, p3: Document) => Node | null;
}
export declare namespace XmlDoc {
    interface XMLDocHolder {
        lang: string | null;
        totalOffset: number;
        root: Base.ChildElement;
        body: Element;
        head: Element;
        last: Element;
        lastOffset: number;
        idMap: {
            [key: string]: Element;
        } | null;
        readonly store: XMLDocStore | null;
        readonly url: string;
        readonly document: Document;
        doc(): NodeList;
        getElementOffset(element: Element): number;
        getNodeOffset(srcNode: Node, offsetInNode: number, after: boolean): number;
        getTotalOffset(): number;
        /**
         * @return last node such that its offset is less or equal to the given
         */
        getNodeByOffset(offset: number): Node;
        /**
         * Get element by URL in the source document(s). URL must be in either '#id'
         * or 'url#id' form.
         */
        getElement(url: string): Element | null;
    }
    interface Predicate {
        readonly fn: (p1: Node) => boolean;
        check(node: Node): boolean;
        withAttribute(name: string, value: string): Predicate;
        withChild(name: string, opt_childPredicate?: Predicate): Predicate;
    }
    interface NodeList {
        readonly nodes: Node[];
        asArray(): Node[];
        size(): number;
        /**
         * Filter with predicate
         */
        predicate(pr: Predicate): NodeList;
        forEachNode(fn: (p1: Node, p2: (p1: Node) => void) => void): NodeList;
        forEach<T>(fn: (p1: Node) => T): T[];
        forEachNonNull<T>(fn: (p1: Node) => T | null): T[];
        child(tag: string): NodeList;
        childElements(): NodeList;
        attribute(name: string): (string | null)[];
        textContent(): (string | null)[];
    }
    type XMLDocStore = Net.ResourceStore<XMLDocHolder>;
}
