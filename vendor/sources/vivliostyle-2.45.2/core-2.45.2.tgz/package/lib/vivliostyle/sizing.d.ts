/**
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Sizing - CSS Intrinsic & Extrinsic Sizing
 */
import "./base";
import * as Vtree from "./vtree";
/**
 * Box sizes defined in css-sizing.
 * @enum {string}
 */
export declare enum Size {
    MAX_CONTENT_INLINE_SIZE = "max-content inline size",
    MAX_CONTENT_BLOCK_SIZE = "max-content block size",
    MAX_CONTENT_WIDTH = "max-content width",
    MAX_CONTENT_HEIGHT = "max-content height",
    MIN_CONTENT_INLINE_SIZE = "min-content inline size",
    MIN_CONTENT_BLOCK_SIZE = "min-content block size",
    MIN_CONTENT_WIDTH = "min-content width",
    MIN_CONTENT_HEIGHT = "min-content height",
    FIT_CONTENT_INLINE_SIZE = "fit-content inline size",
    FIT_CONTENT_BLOCK_SIZE = "fit-content block size",
    FIT_CONTENT_WIDTH = "fit-content width",
    FIT_CONTENT_HEIGHT = "fit-content height"
}
/**
 * Get specified sizes for the element.
 */
export declare function getSize(clientLayout: Vtree.ClientLayout, element: Element, sizes: Size[]): {
    [key in Size]: number;
};
