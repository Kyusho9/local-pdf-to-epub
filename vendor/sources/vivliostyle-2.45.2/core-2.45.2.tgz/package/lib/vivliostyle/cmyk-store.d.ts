/**
 * Copyright 2025 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 */
/**
 * The Vivliostyle CMYK implementation primarily in this file is not "true"
 * CMYK support in the sense that the web browser outputs CMYK, but rather a
 * feature that enables post-processing to replace RGB with CMYK using RGB as
 * a key.
 *
 * This processing leverages the fact that Chromium can transparently reflect
 * `color(srgb ...)` into PDF. Each RGB component has 4 decimal places (the
 * 5th digit is half-up rounded). Specifically, this is based on reading the
 * source code at the following commits.
 *
 * | Repository              | Commit Hash                              |
 * | ----------------------- | ---------------------------------------- |
 * | Chromium                | a2652c6fc5817d5cc643c3935e1363ddc48abb6e |
 * | Skia (third_party/skia) | 3544942c9d424d37d82d756d6dbbbc04327e8dbb |
 *
 * This implementation has several inherent limitations.
 *
 * - The RGB display shown in the browser is merely a key and does not
 *   necessarily reproduce the color appearance after output. Also, it is not
 *   possible to use more than ((10^4)+1)^3 CMYK colors.
 * - Only Chromium is supported. Similar replacement may be possible by
 *   analyzing other web browser implementations, but this is currently
 *   outside the scope of this module.
 * - This implementation is not designed to create PDFs with mixed RGB and
 *   CMYK. If you use this feature, you should specify CMYK colors for all
 *   rendered objects.
 *   There is no way to distinguish between "colors converted from CMYK to
 *   RGB" and "colors originally specified as RGB" in the post-processing
 *   stage. If these colors collide, the post-processing stage has no choice
 *   but to replace both with CMYK.
 * - Raster images are not handled at all. In the first place, there is no
 *   raster image format (at the time of implementation) that can handle CMYK
 *   and be displayed in a web browser. The possibility of replacement in the
 *   post-processing stage is not ruled out.
 */
import * as Css from "./css";
declare class SRGBValue {
    #private;
    static readonly MAX = 10000;
    private constructor();
    static fromInt(r: number, g: number, b: number): SRGBValue;
    offset(dr: number, dg: number, db: number): SRGBValue;
    toKey(): string;
    toColorFunc(alpha: number | null): Css.Func;
}
export interface CMYKValueJSON {
    c: number;
    m: number;
    y: number;
    k: number;
}
export interface RGBValueJSON {
    r: number;
    g: number;
    b: number;
}
export type CmykReserveMapEntry = [RGBValueJSON, CMYKValueJSON];
export declare function isValidCmykReserveMap(data: unknown): data is CmykReserveMapEntry[];
declare class CMYKValue {
    #private;
    static readonly MAX = 10000;
    private constructor();
    static fromInt(c: number, m: number, y: number, k: number): CMYKValue;
    static fromNumber(c: number, m: number, y: number, k: number): CMYKValue;
    /**
     * CSS Color Level 5 naive conversion.
     * https://www.w3.org/TR/css-color-5/#cmyk-rgb
     */
    toSRGB(): SRGBValue;
    equals(other: CMYKValue): boolean;
    toJSON(): CMYKValueJSON;
}
export declare function parseDeviceCmyk(func: Css.Func): {
    cmyk: CMYKValue;
    alpha: number | null;
} | null;
export declare class CmykStore {
    #private;
    registerDeviceCmyk(func: Css.Func): Css.Func | null;
    registerCmykReserveMap(entries: CmykReserveMapEntry[]): void;
    toJSON(): Record<string, CMYKValueJSON>;
}
export declare class CmykFilterVisitor extends Css.FilterVisitor {
    #private;
    constructor(store?: CmykStore);
    reset(): void;
    hadDeviceCmyk(): boolean;
    recordConversion(propertyName: string, originalValue: string): void;
    getConversions(): Record<string, string> | null;
    visitFunc(func: Css.Func): Css.Val;
}
export {};
