import { Layout, Vtree } from "./types";
/**
 * Enable page/column breaking using the browser's multi-column feature.
 * This function sets CSS properties on the column element to create a
 * single-column (column-count: 1) that splits into multiple columns
 * when content overflows the column's size. The large column gap
 * (column-gap) ensures that the browser creates new columns
 * apart from the original column position, and it helps determine
 * page/column breaking positions in our layout processing.
 */
export declare function setBrowserColumnBreaking(column: Vtree.Container): void;
/**
 * Disable the browser's multi-column feature for page/column breaking.
 * This function resets the CSS properties set by `setBrowserColumnBreaking`.
 */
export declare function unsetBrowserColumnBreaking(columnOrElement: Vtree.Container | HTMLElement): void;
/**
 * Check if the browser's multi-column feature is being used for page/column breaking.
 */
export declare function isUsingBrowserColumnBreaking(column: Vtree.Container): boolean;
/**
 * Mark the column as a root column for Vivliostyle layout processing.
 */
export declare function setAsRootColumn(column: Vtree.Container): void;
/**
 * Check if the client rectangle of an element or range is located
 * in a column beyond the current one due to the browser's column breaking.
 *
 * @param rect - The client rectangle to check.
 * @param vertical - Whether the layout is vertical.
 * @return the number of columns the end edge of the rectangle is after the current column.
 */
export declare function checkIfBeyondColumnBreaks(rect: Vtree.ClientRect, vertical: boolean): number;
/**
 * Adjust the client rectangle of an element or range to account for
 * the browser's column breaking.
 * This function modifies the rectangle's coordinates to ensure that
 * if the rectangle is located in a column beyond the current one,
 * its position in the block-progression direction is moved accordingly
 * so that overflow checks can be performed based solely on the
 * block-progression position.
 *
 * @param rect - The client rectangle to check.
 * @param vertical - Whether the layout is vertical.
 * @return the number of columns the start edge of the rectangle is after the current column.
 */
export declare function adjustRectForColumnBreaking(rect: Vtree.ClientRect, vertical: boolean): number;
/**
 * Adjust multiple client rectangles for column breaking.
 */
export declare function adjustRectsForColumnBreaking(rects: Vtree.ClientRect[], vertical: boolean): void;
/**
 * Get the client rectangle of an element, adjusted for column breaking.
 */
export declare function getElementClientRectAdjusted(clientLayout: Vtree.ClientLayout, element: Element, vertical: boolean): Vtree.ClientRect;
/**
 * Clear forced column breaks between two nodes.
 * This is used to prevent unnecessary blank pages.
 */
export declare function clearForcedColumnBreaks(prevNode: Node, currNode: Node): void;
/**
 * Check if an element has non-root multi-column styles (column-count or
 * column-width) set on its inline style.
 *
 * NOTE: Do not use `instanceof HTMLElement` for the check because it does
 * not work when the node is inside an iframe. (Issue #1000)
 */
export declare function hasNonRootMultiColumnStyle(element: Element): boolean;
/**
 * Check if the given element or any of its descendants establishes a
 * non-root multi-column layout (via inline style).
 */
export declare function containsNonRootMultiColumn(element: Element): boolean;
/**
 * Find the nearest ancestor element that establishes a multi-column
 * layout but is not the root column element.
 */
export declare function findAncestorNonRootMultiColumn(node: Node): Element | null;
/**
 * Fix overflow caused by forced column breaks in non-root multi-column elements.
 */
export declare function fixOverflowAtForcedColumnBreak(node: Node): void;
/**
 * Check if the root column's content overflows.
 *
 * Note: This check is based on the root column's trailing content
 * (lastElementChild), not only on a specific target element.
 */
export declare function checkRootColumnOverflow(column: Layout.Column): number;
/**
 * Fix multi-column box with `column-fill: auto` that was changed to `column-fill: balance`
 * for layout processing, by restoring `column-fill: auto` and setting block-size to prevent overflow.
 */
export declare function fixAutoFillMultiColumnBox(element: HTMLElement, column: Layout.Column): void;
export declare function fixAutoFillMultiColumnBoxes(column: Layout.Column): void;
/**
 * Calculate the position of the "after" edge in the block-progression.
 * Returns the edge position in pixels if it was determined successfully,
 * and returns NaN if the position could not be determined and the node
 * should be considered zero-height.
 */
export declare function calculateEdge(nodeContext: Vtree.NodeContext, clientLayout: Vtree.ClientLayout, extraOffset: number, vertical: boolean): number;
export declare function getElementHeight(element: Element, column: Layout.Column, vertical: boolean): number;
export declare function isOrphan(node: Node | null): boolean;
export declare function removeFollowingSiblings(parentNode: Node | null, viewNode: Node): void;
/**
 * Marks an element as "special". It should not be used in bbox calculations.
 */
export declare const SPECIAL_ATTR = "data-adapt-spec";
export declare function isSpecial(e: Element): boolean;
export declare function isOutOfFlow(node: Node | null): boolean;
/**
 * Check if element is out-of-flow due to CSS positioning or float.
 * Unlike isOutOfFlow(), this does not check for special marker elements.
 */
export declare function isCssOutOfFlow(node: Node): boolean;
/**
 * Check if element has position:fixed. Used to identify running elements
 * (position:running() rendered as position:fixed) without matching
 * position:absolute elements. (Issue #1833, #1869, #1870)
 */
export declare function isFixedPositioned(node: Node | null): boolean;
export declare function isSpecialNodeContext(nodeContext: Vtree.NodeContext): boolean;
export declare function isSpecialInlineDisplay(display: string): boolean;
export declare function findAncestorSpecialInlineNodeContext(nodeContext: Vtree.NodeContext): Vtree.ElementNodeContext | null;
export declare function textSpacingWrapperOf(node: Element | Text): Element | null;
export declare function findLastTextNodeInElement(element: Node): Node | null;
