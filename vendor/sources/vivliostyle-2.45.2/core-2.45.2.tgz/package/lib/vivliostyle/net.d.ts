/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Net - Fetch resource from a URL.
 */
import * as Base from "./base";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
import { Net, XmlDoc } from "./types";
/**
 * @enum {string}
 */
export declare enum FetchResponseType {
    ARRAYBUFFER = "arraybuffer",
    BLOB = "blob",
    DOCUMENT = "document",
    JSON = "json",
    TEXT = "text"
}
export type FetchResponse = Net.FetchResponse;
export declare function fetchFromURL(url: string, opt_type?: FetchResponseType, opt_method?: string): Task.Result<FetchResponse>;
export declare function makeBlob(parts: BlobPart[], opt_type?: string): Blob;
export declare function readBlob(blob: Blob): Task.Result<ArrayBuffer>;
/**
 * @return url
 */
export declare function createObjectURL(blob: Blob): string;
/**
 * @template Resource
 */
export declare class ResourceStore<Resource> implements Net.ResourceStore<Resource> {
    readonly parser: (p1: FetchResponse, p2: ResourceStore<Resource>) => Task.Result<Resource | null>;
    readonly type: FetchResponseType;
    resources: {
        [key: string]: Resource | null;
    };
    fetchers: {
        [key: string]: TaskUtil.Fetcher<Resource | null>;
    };
    constructor(parser: (p1: FetchResponse, p2: ResourceStore<Resource>) => Task.Result<Resource | null>, type: FetchResponseType);
    /**
     * @return resource for the given URL
     */
    load(url: string, opt_required?: boolean, opt_message?: string): Task.Result<Resource | null>;
    private fetchInner;
    /**
     * @return fetcher for the resource for the given URL
     */
    fetch(url: string, opt_required?: boolean, opt_message?: string): TaskUtil.Fetcher<Resource | null> | null;
    get(url: string): XmlDoc.XMLDocHolder;
    delete(url: string): void;
}
export type JSONStore = ResourceStore<Base.JSON>;
export declare function parseJSONResource(response: FetchResponse, store: JSONStore): Task.Result<Base.JSON>;
export declare function newJSONStore(): JSONStore;
/**
 * @return holding event type (load/error/abort)
 */
export declare function loadElement(elem: Element, src?: string, alt?: string | null): TaskUtil.Fetcher<string>;
