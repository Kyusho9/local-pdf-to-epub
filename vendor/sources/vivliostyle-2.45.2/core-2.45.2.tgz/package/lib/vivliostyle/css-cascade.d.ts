import * as Base from "./base";
import * as CmykStore from "./cmyk-store";
import * as CounterStyle from "./counter-style";
import * as Css from "./css";
import * as CssParser from "./css-parser";
import * as CssTokenizer from "./css-tokenizer";
import * as CssValidator from "./css-validator";
import * as Exprs from "./exprs";
import * as Matchers from "./matchers";
import * as Vtree from "./vtree";
import { CssCascade, CssStyler } from "./types";
import { TokenType } from "./css-tokenizer";
export type ElementStyle = {
    [key: string]: CascadeValue | CascadeValue[] | ElementStyleMap | {
        matcher: Matchers.Matcher;
        styles: ElementStyle;
    }[];
};
export declare const inheritedProps: {
    "border-collapse": boolean;
    "border-spacing": boolean;
    "caption-side": boolean;
    "clip-rule": boolean;
    color: boolean;
    "color-interpolation": boolean;
    "color-rendering": boolean;
    cursor: boolean;
    direction: boolean;
    "empty-cells": boolean;
    fill: boolean;
    "fill-opacity": boolean;
    "fill-rule": boolean;
    "font-kerning": boolean;
    "font-size": boolean;
    "font-size-adjust": boolean;
    "font-family": boolean;
    "font-feature-settings": boolean;
    "font-style": boolean;
    "font-stretch": boolean;
    "font-variant-ligatures": boolean;
    "font-variant-caps": boolean;
    "font-variant-numeric": boolean;
    "font-variant-east-asian": boolean;
    "font-weight": boolean;
    "glyph-orientation-vertical": boolean;
    "hanging-punctuation": boolean;
    hyphens: boolean;
    "hyphenate-character": boolean;
    "hyphenate-limit-chars": boolean;
    "hyphenate-limit-last": boolean;
    "image-rendering": boolean;
    "image-resolution": boolean;
    "letter-spacing": boolean;
    "line-break": boolean;
    "line-height": boolean;
    "list-style-image": boolean;
    "list-style-position": boolean;
    "list-style-type": boolean;
    marker: boolean;
    "marker-end": boolean;
    "marker-mid": boolean;
    "marker-start": boolean;
    orphans: boolean;
    "overflow-wrap": boolean;
    "paint-order": boolean;
    "pointer-events": boolean;
    quotes: boolean;
    "ruby-align": boolean;
    "ruby-position": boolean;
    "shape-rendering": boolean;
    stroke: boolean;
    "stroke-dasharray": boolean;
    "stroke-dashoffset": boolean;
    "stroke-linecap": boolean;
    "stroke-linejoin": boolean;
    "stroke-miterlimit": boolean;
    "stroke-opacity": boolean;
    "stroke-width": boolean;
    "tab-size": boolean;
    "text-align": boolean;
    "text-align-last": boolean;
    "text-anchor": boolean;
    "text-autospace": boolean;
    "text-decoration-skip": boolean;
    "text-decoration-skip-ink": boolean;
    "text-emphasis-color": boolean;
    "text-emphasis-position": boolean;
    "text-emphasis-style": boolean;
    "text-fill-color": boolean;
    "text-combine-upright": boolean;
    "text-indent": boolean;
    "text-justify": boolean;
    "text-orientation": boolean;
    "text-rendering": boolean;
    "text-shadow": boolean;
    "text-size-adjust": boolean;
    "text-spacing-trim": boolean;
    "text-stroke-color": boolean;
    "text-stroke-width": boolean;
    "text-transform": boolean;
    "text-underline-offset": boolean;
    "text-underline-position": boolean;
    "text-wrap": boolean;
    "text-wrap-mode": boolean;
    "text-wrap-style": boolean;
    visibility: boolean;
    "white-space": boolean;
    widows: boolean;
    "word-break": boolean;
    "word-spacing": boolean;
    "writing-mode": boolean;
};
export declare const polyfilledInheritedProps: string[];
export declare function getPolyfilledInheritedProps(): string[];
export declare const supportedNamespaces: {
    "http://www.idpf.org/2007/ops": boolean;
    "http://www.w3.org/1999/xhtml": boolean;
    "http://www.w3.org/2000/svg": boolean;
    "http://www.w3.org/1998/Math/MathML": boolean;
};
export declare const coupledPatterns: string[];
export declare const coupledExtentPatterns: string[];
export declare const geomNames: {
    [key: string]: boolean;
};
export declare function buildCouplingMap(sideMap: {
    [key: string]: string;
}, extentMap: {
    [key: string]: string;
}): {
    [key: string]: string;
};
export declare const couplingMapVert: {
    [key: string]: string;
};
export declare const couplingMapHor: {
    [key: string]: string;
};
export declare const couplingMapVertRtl: {
    [key: string]: string;
};
export declare const couplingMapHorRtl: {
    [key: string]: string;
};
/**
 * A cascade layer (CSS `@layer`, css-cascade-5 §6.4).
 *
 * `order` is (re)assigned by {@link CascadeLayerTree} whenever a layer is added
 * so that it always reflects the current layer ordering; a larger value means
 * a higher precedence for normal declarations.
 */
export declare class CascadeLayer {
    readonly name: string | null;
    readonly parent: CascadeLayer | null;
    order: number;
    readonly children: CascadeLayer[];
    constructor(name: string | null, parent: CascadeLayer | null);
}
/**
 * The layer tree of one cascade origin. Layers are ordered by a post-order
 * traversal, because the declarations directly contained in a layer form an
 * implicit final sub-layer of it.
 */
export declare class CascadeLayerTree {
    readonly root: CascadeLayer;
    /**
     * @param nameList `null` for an anonymous layer, otherwise the dot-separated
     *     `<layer-name>` split into its parts.
     */
    register(parent: CascadeLayer | null, nameList: string[] | null): CascadeLayer;
    private renumber;
}
/**
 * A fresh identity for one declaration block, so that `revert-rule` can tell
 * the declarations of its own rule from the rest of the cascade. Zero is
 * reserved for values the engine synthesizes outside of any rule.
 */
export declare function nextRuleId(): number;
/**
 * What the cascade sorts by, apart from the document order. Cascaded values
 * are the usual case, but the name-defining at-rules (`@font-face`,
 * `@counter-style`, `@-epubx-page-master`) are sorted the same way
 * (css-cascade-5 §6.4).
 */
export interface CascadePriority {
    readonly priority: number;
    readonly layer: CascadeLayer | null;
}
/**
 * Compares two cascaded values (or two name-defining at-rules). Cascade layers
 * are sorted between the origin and the selector specificity, and unlayered
 * declarations act as a final layer (css-cascade-5 §6.4.2).
 */
export declare function comparePriority(a: CascadePriority, b: CascadePriority): number;
export declare class CascadeValue implements CssCascade.CascadeValue {
    readonly value: Css.Val;
    readonly priority: number;
    readonly layer: CascadeLayer | null;
    readonly ruleId: number;
    constructor(value: Css.Val, priority: number, layer?: CascadeLayer | null, ruleId?: number);
    getBaseValue(): CascadeValue;
    /**
     * A copy of this cascaded value carrying another CSS value, keeping
     * everything the cascade sorts by (priority, layer and rule identity).
     */
    withValue(value: Css.Val): CascadeValue;
    filterValue(visitor: Css.Visitor): CascadeValue;
    increaseSpecificity(specificity: number): CascadeValue;
    evaluate(context: Exprs.Context, propName?: string, percentRef?: number, vertical?: boolean): Css.Val;
    isEnabled(context: Exprs.Context): boolean;
}
/**
 * Internal subclass of CascadeValue. Should never be seen outside of the
 * cascade engine.
 */
export declare class ConditionalCascadeValue extends CascadeValue {
    readonly condition: Exprs.Val;
    constructor(value: Css.Val, priority: number, condition: Exprs.Val, layer?: CascadeLayer | null, ruleId?: number);
    getBaseValue(): CascadeValue;
    withValue(value: Css.Val): CascadeValue;
    increaseSpecificity(specificity: number): CascadeValue;
    isEnabled(context: Exprs.Context): boolean;
}
/**
 * @param tv current value (cannot be conditional)
 * @param av cascaded value (can be conditional)
 */
export declare function cascadeValues(context: Exprs.Context, tv: CascadeValue, av: CascadeValue): CascadeValue;
/**
 * setProp with priority checking.
 * If context is given it is same as
 * setProp(style, name, cascadeValues(context, getProp(style, name), value))
 */
export declare function setPropCascadeValue(style: ElementStyle, name: string, value: CascadeValue, context?: Exprs.Context): void;
/**
 * Called for every declaration as it is parsed, to note the properties whose
 * cascade history has to be retained.
 */
export declare function noteRollbackDeclaration(name: string, value: Css.Val, validatorSet?: CssValidator.ValidatorSet): void;
/**
 * Replace every rollback keyword that won the cascade with the declaration it
 * rolls back to, so that the layout engine sees a real value instead of the
 * keyword. When Vivliostyle's own cascade has nothing left to roll back to,
 * the keyword survives on purpose and is handed to the browser through the
 * `style` attribute of the generated element (see `resolveRollbackValue`).
 *
 * This runs twice: once as soon as the cascade is settled, because the value
 * rolled back to may itself be a shorthand or contain var(), and once more
 * after var() substitution, because a keyword written in a var() fallback
 * only becomes the whole value there.
 *
 * @param afterVarSubstitution whether this is the second pass. Custom
 *     properties are left alone then: a custom property whose *substituted*
 *     value happens to spell a rollback keyword is not a rollback, it is just
 *     a token stream that no property can use (WPT-matching browser
 *     behavior). This pass also discards the retained cascade history.
 * @returns whether a value was rolled back to one that still contains var()
 */
export declare function resolveRollbackValues(style: ElementStyle, afterVarSubstitution?: boolean): boolean;
export type ElementStyleMap = {
    [key: string]: ElementStyle;
};
export declare const SPECIALS: {
    "region-id": boolean;
    "fragment-selector-id": boolean;
};
export declare const FOOTNOTE_COUNTER_ATTR = "data-viv-footnote-counter";
export declare function isSpecialName(name: string): boolean;
export declare function isMapName(name: string): boolean;
export declare function isPropName(name: string): boolean;
export declare function isInherited(name: string): boolean;
export declare function getProp(style: ElementStyle, name: string): CascadeValue;
export declare function setProp(style: ElementStyle, name: string, value: CascadeValue): void;
export declare function getStyleMap(style: ElementStyle, name: string): ElementStyleMap;
export declare function getMutableStyleMap(style: ElementStyle, name: string): ElementStyleMap;
export declare const getViewConditionalStyleMap: (style: ElementStyle) => {
    matcher: Matchers.Matcher;
    styles: ElementStyle;
}[];
export declare function getSpecial(style: ElementStyle, name: string): CascadeValue[];
export declare function getMutableSpecial(style: ElementStyle, name: string): CascadeValue[];
export declare function mergeIn(context: Exprs.Context, target: ElementStyle, style: ElementStyle, specificity: number, pseudoelement: string | null, regionId: string | null, viewConditionMatcher: Matchers.Matcher | null, validatorSet: CssValidator.ValidatorSet | null): void;
export declare function mergeAll(context: Exprs.Context, styles: ElementStyle[]): ElementStyle;
export declare function chainActions(chain: ChainedAction[], action: CascadeAction): CascadeAction;
export declare class InheritanceVisitor extends Css.FilterVisitor {
    readonly props: ElementStyle;
    readonly context: Exprs.Context;
    propName: string;
    constructor(props: ElementStyle, context: Exprs.Context);
    setPropName(name: string): void;
    private getFontSize;
    visitNumeric(numeric: Css.Numeric): Css.Val;
    visitExpr(expr: Css.Expr): Css.Val;
}
export declare function convertFontRelativeLengthToPx(numeric: Css.Numeric, baseFontSize: number, context: Exprs.Context): Css.Numeric;
export declare function convertFontSizeToPx(numeric: Css.Numeric, parentFontSize: number | null, context: Exprs.Context): Css.Numeric;
export type ActionTable = Map<string, CascadeAction>;
export declare class StyledCascadeInstance {
    readonly instance: CascadeInstance;
    readonly currentStyle: ElementStyle;
    readonly currentClassNames: string[];
    readonly currentEpubTypes: string[];
    constructor(instance: CascadeInstance, currentStyle: ElementStyle, currentClassNames: string[], currentEpubTypes: string[]);
}
export declare class ElementCascadeInstance extends StyledCascadeInstance {
    readonly currentElement: Base.ChildElement;
    constructor(instance: CascadeInstance, currentStyle: ElementStyle, currentClassNames: string[], currentEpubTypes: string[], currentElement: Base.ChildElement);
}
export declare class CascadeAction {
    apply(cascadeInstance: StyledCascadeInstance): void;
    mergeWith(other: CascadeAction): CascadeAction;
}
export declare class ConditionItemAction extends CascadeAction {
    readonly conditionItem: ConditionItem;
    constructor(conditionItem: ConditionItem);
    apply(cascadeInstance: StyledCascadeInstance): void;
}
export declare class CompoundAction extends CascadeAction {
    readonly list: CascadeAction[];
    constructor(list: CascadeAction[]);
    apply(cascadeInstance: StyledCascadeInstance): void;
    mergeWith(other: CascadeAction): CascadeAction;
}
export declare class ApplyRuleAction extends CascadeAction {
    readonly style: ElementStyle;
    readonly specificity: number;
    readonly pseudoelement: string | null;
    readonly regionId: string | null;
    readonly viewConditionId: string | null;
    constructor(style: ElementStyle, specificity: number, pseudoelement: string | null, regionId: string | null, viewConditionId: string | null);
    apply(cascadeInstance: StyledCascadeInstance): void;
}
export type PrimarySlot = {
    table: ActionTable;
    key: string;
};
export declare abstract class ChainedAction {
    abstract matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
    wire(chained: CascadeAction): WiredAction;
}
export declare abstract class WiredAction<T extends ChainedAction = ChainedAction> extends CascadeAction {
    protected readonly condition: T;
    protected readonly chained: CascadeAction;
    constructor(condition: T, chained: CascadeAction);
    abstract apply(cascadeInstance: StyledCascadeInstance): void;
    makePrimary(cascade: Cascade): boolean;
}
export declare class WiredGuard extends WiredAction {
    apply(cascadeInstance: StyledCascadeInstance): void;
}
export declare class WiredConditionScope extends WiredAction<CheckConditionAction> {
    apply(cascadeInstance: StyledCascadeInstance): void;
}
export declare class CheckClassAction extends ChainedAction {
    readonly className: string;
    constructor(className: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckIdAction extends ChainedAction {
    readonly id: string;
    constructor(id: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckLocalNameAction extends ChainedAction {
    readonly localName: string;
    constructor(localName: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckNSTagAction extends ChainedAction {
    readonly ns: string;
    readonly localName: string;
    constructor(ns: string, localName: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckTargetEpubTypeAction extends ChainedAction {
    readonly epubTypePatt: RegExp;
    readonly targetLocalName?: string;
    readonly useRoleAttr: boolean;
    constructor(epubTypePatt: RegExp, targetLocalName?: string, useRoleAttr?: boolean);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
}
export declare class CheckNamespaceAction extends ChainedAction {
    readonly ns: string;
    constructor(ns: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
}
export declare class CheckAttributePresentAction extends ChainedAction {
    readonly ns: string | null;
    readonly name: string;
    constructor(ns: string | null, name: string);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
}
export declare class CheckAttributeEqAction extends ChainedAction {
    readonly ns: string | null;
    readonly name: string;
    readonly value: string;
    readonly caseSensitivity: CssParser.AttributeSelectorCaseSensitivity;
    constructor(ns: string | null, name: string, value: string, caseSensitivity?: CssParser.AttributeSelectorCaseSensitivity);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckNamespaceSupportedAction extends ChainedAction {
    readonly ns: string | null;
    readonly name: string;
    constructor(ns: string | null, name: string);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
    primarySlot(cascade: Cascade): PrimarySlot | null;
}
export declare class CheckAttributeRegExpAction extends ChainedAction {
    readonly ns: string | null;
    readonly name: string;
    readonly regexp: RegExp;
    readonly caseSensitivity: CssParser.AttributeSelectorCaseSensitivity;
    constructor(ns: string | null, name: string, regexp: RegExp, caseSensitivity?: CssParser.AttributeSelectorCaseSensitivity);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
}
export declare class CheckLangAction extends ChainedAction {
    readonly langRegExp: RegExp;
    constructor(langRegExp: RegExp);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
}
export declare class IsFirstAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsRootAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
}
export declare abstract class IsNthAction extends ChainedAction {
    readonly a: number;
    readonly b: number;
    constructor(a: number, b: number);
    /**
     * Checkes whether given order can be represented as an+b with a non-negative
     * interger n
     */
    protected matchANPlusB(order: number): boolean;
}
export declare class IsNthSiblingAction extends IsNthAction {
    constructor(a: number, b: number);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
}
export type SiblingTypeCounts = {
    byNamespace: {
        [ns: string]: {
            [localName: string]: number;
        };
    };
    noNamespace: {
        [localName: string]: number;
    } | null;
};
export declare class IsNthSiblingOfTypeAction extends IsNthAction {
    constructor(a: number, b: number);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsNthLastSiblingAction extends IsNthAction {
    constructor(a: number, b: number);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsNthLastSiblingOfTypeAction extends IsNthAction {
    constructor(a: number, b: number);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsEmptyAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsEnabledAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsDisabledAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class IsCheckedAction extends ChainedAction {
    constructor();
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
export declare class MatchesNativeSelectorAction extends ChainedAction {
    readonly selector: string;
    constructor(selector: string);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
}
export declare class CheckConditionAction extends ChainedAction {
    readonly condition: string;
    constructor(condition: string);
    matches(cascadeInstance: StyledCascadeInstance): boolean;
    wire(chained: CascadeAction): WiredAction;
    getPriority(): number;
}
export declare class CheckAppliedAction extends CascadeAction {
    applied: boolean;
    constructor();
    apply(cascadeInstance: StyledCascadeInstance): void;
}
/**
 * Cascade Action for :is() and similar pseudo-classes
 */
export declare class MatchesAction extends ChainedAction {
    checkAppliedAction: CheckAppliedAction;
    firstActions: CascadeAction[];
    readonly priority: number;
    constructor(chains: ChainedAction[][]);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
    positive(): boolean;
}
/**
 * Cascade Action for :not() pseudo-class
 */
export declare class MatchesNoneAction extends MatchesAction {
    positive(): boolean;
}
/**
 * Cascade Action for :has() pseudo-class
 */
export declare class MatchesRelationalAction extends MatchesAction {
    selectorTexts: string[];
    constructor(selectorTexts: string[]);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
}
/**
 * Cascade Action for :nth-child(An+B of S) pseudo-class
 */
export declare class IsNthSiblingOfSelectorAction extends IsNthAction {
    checkAppliedAction: CheckAppliedAction;
    firstActions: CascadeAction[];
    constructor(a: number, b: number, chains: ChainedAction[][]);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    protected matchesSelector(element: Base.ChildElement, cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
/**
 * Cascade Action for :nth-last-child(An+B of S) pseudo-class
 */
export declare class IsNthLastSiblingOfSelectorAction extends IsNthSiblingOfSelectorAction {
    constructor(a: number, b: number, chains: ChainedAction[][]);
    matches(cascadeInstance: ElementCascadeInstance): boolean;
    getPriority(): number;
}
/**
 * An object that is notified as elements are pushed and popped and typically
 * controls a "named condition" (which is a count associated with a name).
 */
export interface ConditionItem {
    /**
     * Returns a "fresh" copy of this item. May be this if immutable.
     */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /**
     * Depth is 0 for element itself and its siblings, 1 for direct children and
     * -1 for the parent.
     */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /**
     * @return return true if no more notifications are desired
     */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
export declare class AbstractConditionItem {
    readonly condition: string;
    readonly viewConditionId: string | null;
    readonly viewCondition: Matchers.Matcher | null;
    constructor(condition: string, viewConditionId: string | null, viewCondition: Matchers.Matcher | null);
    increment(cascadeInstance: CascadeInstance): void;
    decrement(cascadeInstance: CascadeInstance): void;
    buildViewConditionMatcher(cascadeInstance: CascadeInstance): Matchers.Matcher | null;
}
export declare class DescendantConditionItem extends AbstractConditionItem implements ConditionItem {
    constructor(condition: string, viewConditionId: string | null, viewCondition: Matchers.Matcher | null);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
export declare class ChildConditionItem extends AbstractConditionItem implements ConditionItem {
    constructor(condition: string, viewConditionId: string | null, viewCondition: Matchers.Matcher | null);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
export declare class AdjacentSiblingConditionItem extends AbstractConditionItem implements ConditionItem {
    fired: boolean;
    constructor(condition: string, viewConditionId: string | null, viewCondition: Matchers.Matcher | null);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
export declare class FollowingSiblingConditionItem extends AbstractConditionItem implements ConditionItem {
    fired: boolean;
    constructor(condition: string, viewConditionId: string | null, viewCondition: Matchers.Matcher | null);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
/**
 * Not a true condition item, this class manages proper handling of "after"
 * pseudoelement.
 */
export declare class AfterPseudoelementItem implements ConditionItem {
    readonly afterprop: ElementStyle;
    readonly element: Element;
    readonly elementStyle: ElementStyle;
    constructor(afterprop: ElementStyle, element: Element, elementStyle: ElementStyle);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
/**
 * Not a true condition item, this class restores current language.
 */
export declare class RestoreLangItem implements ConditionItem {
    readonly lang: string;
    constructor(lang: string);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
/**
 * Not a true condition item, this class manages inheritance of quotes property
 */
export declare class QuotesScopeItem implements ConditionItem {
    readonly oldQuotes: Css.Str[];
    constructor(oldQuotes: Css.Str[]);
    /** @override */
    fresh(cascadeInstance: CascadeInstance): ConditionItem;
    /** @override */
    push(cascadeInstance: CascadeInstance, depth: number): boolean;
    /** @override */
    pop(cascadeInstance: CascadeInstance, depth: number): boolean;
}
export type CounterValues = {
    [key: string]: number[];
};
export interface CounterListener {
    countersOfId(id: string, counters: CounterValues): any;
    getExprContentListener(): Vtree.ExprContentListener;
}
export interface CounterResolver {
    readonly rootScope: Exprs.LexicalScope;
    readonly pageScope: Exprs.LexicalScope;
    setStyler(styler: CssStyler.AbstractStyler): void;
    /**
     * Returns an Exprs.Val, whose value is calculated at the layout time by
     * retrieving the innermost page-based counter (null if it does not exist) by
     * its name and formatting the value into a string.
     * @param name Name of the page-based counter to be retrieved
     * @param format A function that formats the counter value into a string
     */
    getPageCounterVal(name: string, format: (p1: number | null) => string): Exprs.Val;
    /**
     * Returns an Exprs.Val, whose value is calculated at the layout time by
     * retrieving the page-based counters by its name and formatting the values
     * into a string.
     * @param name Name of the page-based counters to be retrieved
     * @param format A function that formats the counter values (passed as an
     *     array ordered by the nesting depth with the outermost counter first and
     *     the innermost last) into a string
     */
    getPageCountersVal(name: string, format: (p1: number[]) => string): Exprs.Val;
    getTargetCounterVal(url: string, name: string, format: (p1: number | null) => string): Exprs.Val;
    getTargetCountersVal(url: string, name: string, format: (p1: number[]) => string): Exprs.Val;
    /**
     * Get value of the CSS target-text() function
     * https://drafts.csswg.org/css-content-3/#target-text
     * @param url Target URL (with fragment identifier)
     * @param pseudoElement Pseudo-element selector ('content', 'before', 'after', 'first-letter', 'marker')
     */
    getTargetTextVal(url: string, pseudoElement: string): Exprs.Val;
    /**
     * Get value of the CSS string() function
     * https://drafts.csswg.org/css-gcpm-3/#using-named-strings
     */
    getNamedStringVal(name: string, retrievePosition: string): Exprs.Val;
    /**
     * Set named string for the CSS string-set property
     * https://drafts.csswg.org/css-gcpm-3/#setting-named-strings-the-string-set-pro
     */
    setNamedString(name: string, stringValue: string | Css.Val, elementOffset: number): void;
    /**
     * Get value of the CSS element() function
     * https://drafts.csswg.org/css-gcpm-3/#running-elements
     */
    getRunningElementVal(name: string, retrievePosition: string): Exprs.Val;
    /**
     * Set running element
     * https://drafts.csswg.org/css-gcpm-3/#running-elements
     */
    setRunningElement(name: string, elementOffset: number): void;
}
export declare class AttrValueFilterVisitor extends Css.FilterVisitor {
    element: Element;
    private readonly scope;
    private readonly propName;
    private readonly validatorSet;
    hadAttrFunction: boolean;
    constructor(element: Element, scope: Exprs.LexicalScope, propName: string, validatorSet: CssValidator.ValidatorSet);
    validatePropertyValue(value: Css.Val): Css.Val;
    visitFunc(func: Css.Func): Css.Val;
}
export declare class ContentPropVisitor extends Css.FilterVisitor {
    cascade: CascadeInstance;
    element: Element | null;
    readonly counterResolver: CounterResolver;
    private readonly elementStyle;
    private readonly pseudoName?;
    constructor(cascade: CascadeInstance, element: Element | null, counterResolver: CounterResolver, elementStyle: ElementStyle, pseudoName?: string);
    private getCounterStore;
    private hasLocalCounterResetOrSet;
    private hasLocalCounterIncrement;
    private hasLocalCounter;
    /**
     * Helper method to evaluate CSS values containing counter() and other functions,
     * then convert to string.
     */
    private evaluateAndGetString;
    visitIdent(ident: Css.Ident): Css.Val;
    private format;
    private formatCounterList;
    private formatLastValue;
    private buildCounterText;
    visitFuncCounter(values: Css.Val[]): Css.Val;
    visitFuncCounters(values: Css.Val[]): Css.Val;
    visitFuncTargetCounter(values: Css.Val[]): Css.Val;
    visitFuncTargetCounters(values: Css.Val[]): Css.Val;
    /**
     * CSS `target-text()` function
     * https://drafts.csswg.org/css-content-3/#target-text
     */
    visitFuncTargetText(values: Css.Val[]): Css.Val;
    /**
     * CSS `string()` function
     * https://drafts.csswg.org/css-gcpm-3/#using-named-strings
     */
    visitFuncString(values: Css.Val[]): Css.Val;
    /**
     * CSS `element()` function
     * https://drafts.csswg.org/css-gcpm-3/#running-elements
     */
    visitFuncElement(values: Css.Val[]): Css.Val;
    /**
     * CSS `content()` function
     * https://drafts.csswg.org/css-gcpm-3/#content-function-header
     */
    visitFuncContent(values: Css.Val[]): Css.Val;
    /**
     * CSS `leader()` function
     * https://www.w3.org/TR/css-content-3/#leaders
     */
    visitFuncLeader(values: Css.Val[]): Css.Val;
    visitFunc(func: Css.Func): Css.Val;
}
/**
 * Fitting order and specificity in the same number. Order is recorded in the
 * fractional part. Select value so that
 *
 *   0x7FFFFFFF != 0x7FFFFFFF + ORDER_INCREMENT
 *
 */
export declare const ORDER_INCREMENT: number;
export declare class Cascade {
    nsCount: number;
    nsPrefix: Map<string, string>;
    tags: ActionTable;
    nstags: ActionTable;
    epubtypes: ActionTable;
    classes: ActionTable;
    ids: ActionTable;
    pagetypes: ActionTable;
    order: number;
    readonly layerTrees: Map<string, CascadeLayerTree>;
    /**
     * Returns the cascade layer for a `@layer` rule of the given origin.
     * @param nameList `null` for an anonymous layer.
     */
    registerLayer(flavor: string, parent: CascadeLayer | null, nameList: string[] | null): CascadeLayer;
    insertInTable(table: ActionTable, key: string, action: CascadeAction): void;
    createInstance(context: Exprs.Context, counterListener: CounterListener, counterResolver: CounterResolver, counterStyleStore: CounterStyle.CounterStyleStore, cmykStore: CmykStore.CmykStore, root: Element, scope: Exprs.LexicalScope, validatorSet: CssValidator.ValidatorSet, styles: StyleReader, mergeValidatorSet: CssValidator.ValidatorSet | null): CascadeInstance;
    nextOrder(): number;
}
export interface StyleReader {
    styleOf(element: Element): ElementStyle;
}
export declare class CascadeInstance {
    readonly context: Exprs.Context;
    readonly counterListener: CounterListener;
    readonly counterResolver: CounterResolver;
    readonly counterStyleStore: CounterStyle.CounterStyleStore;
    readonly cmykStore: CmykStore.CmykStore;
    readonly root: Element;
    readonly scope: Exprs.LexicalScope;
    readonly validatorSet: CssValidator.ValidatorSet;
    readonly styles: StyleReader;
    readonly mergeValidatorSet: CssValidator.ValidatorSet | null;
    code: Cascade;
    stack: ConditionItem[][];
    conditions: Map<string, number>;
    currentElement: Element | null;
    currentElementOffset: number | null;
    currentLocalName: string;
    currentNamespace: string | null;
    currentId: string | null;
    currentXmlId: string | null;
    currentNSTag: string;
    currentPageType: string | null;
    previousPageType: string | null;
    firstPageType: string | null;
    pageTypePageIndices: {
        [pageType: string]: number[];
    };
    isFirst: boolean;
    isRoot: boolean;
    counters: CounterValues;
    lastCounterChanges: string[];
    lastCounterChangeTypes: {
        [key: string]: "reset" | "set" | "increment";
    };
    counterScoping: ({
        [key: string]: boolean;
    } | null)[];
    quotes: Css.Str[];
    quoteDepth: number;
    lang: string;
    siblingOrderStack: number[];
    currentSiblingOrder: number;
    siblingTypeCountsStack: SiblingTypeCounts[];
    currentSiblingTypeCounts: SiblingTypeCounts;
    currentFollowingSiblingOrder: number | null;
    followingSiblingOrderStack: (number | null)[];
    followingSiblingTypeCountsStack: SiblingTypeCounts[];
    currentFollowingSiblingTypeCounts: SiblingTypeCounts;
    viewConditions: Map<string, Matchers.Matcher[]>;
    dependentConditions: string[];
    elementStack: Element[];
    constructor(cascade: Cascade, context: Exprs.Context, counterListener: CounterListener, counterResolver: CounterResolver, counterStyleStore: CounterStyle.CounterStyleStore, cmykStore: CmykStore.CmykStore, root: Element, scope: Exprs.LexicalScope, validatorSet: CssValidator.ValidatorSet, styles: StyleReader, mergeValidatorSet: CssValidator.ValidatorSet | null);
    pushConditionItem(item: ConditionItem): void;
    increment(condition: string, viewCondition: Matchers.Matcher | null): void;
    decrement(condition: string, viewCondition: Matchers.Matcher | null): void;
    buildViewConditionMatcher(viewConditionId: string | null): Matchers.Matcher | null;
    applyAction(cascadeInstance: StyledCascadeInstance, table: ActionTable, key: string): void;
    pushRule(classes: string[], pageType: string | null, baseStyle: ElementStyle): void;
    defineCounter(counterName: string, value: number): void;
    pushCounters(props: ElementStyle, elementStyle: ElementStyle): void;
    popCounters(): void;
    /**
     * Process CSS string-set property
     * https://drafts.csswg.org/css-gcpm-3/#setting-named-strings-the-string-set-pro
     */
    setNamedStrings(props: ElementStyle, element: Element, elementOffset: number): void;
    /**
     * Process CSS running elements
     * https://drafts.csswg.org/css-gcpm-3/#running-elements
     */
    setRunningElement(props: ElementStyle, elementOffset: number): void;
    processPseudoelementProps(pseudoprops: ElementStyle, element: Element, elementStyle: ElementStyle, pseudoName?: string): void;
    private dropPseudoelement;
    pushElement(element: Base.ChildElement, baseStyle: ElementStyle, elementOffset: number): ElementCascadeInstance;
    private hasNonTrivialViewConditionalPseudoContent;
    /**
     * Properties that are valid on ::marker and should be extracted
     * to CSS custom properties on the parent element.
     */
    static readonly markerAllowedProps: string[];
    /**
     * Extract ::marker or ::footnote-marker properties into CSS custom
     * properties (--viv-marker-*) on the parent element's style,
     * so that the browser's native ::marker can be controlled via polyfill CSS.
     *
     * For ::marker: the content is resolved from list-style-type/list-style-image
     * if not explicitly set.  For ::footnote-marker: the content comes from
     * ::footnote-marker { content: ... } declarations.
     */
    processMarkerPseudoelementProps(pseudoProps: ElementStyle, element: Element, elementStyle: ElementStyle): void;
    /**
     * Resolve Css.Expr nodes in marker content to static values.
     * counter() functions are evaluated to strings; URLs are kept as-is.
     */
    private resolveMarkerContentVal;
    /**
     * Get inherited property value
     * @param propName
     * @param element
     * @param elementStyle style being cascaded for `element`, which the style
     *     store cannot serve until the cascade for it finishes
     * @returns the inherited property value, or the initial value (or null) if not found
     */
    getInheritedPropertyValue(propName: string, element: Element, elementStyle: ElementStyle): Css.Val | null;
    resolvePseudoelementInheritedPropertyValue(pseudoProps: ElementStyle, propName: string, element: Element, elementStyle: ElementStyle): Css.Val | null;
    private applyAttrFilterInner;
    private applyAttrFilter;
    /**
     * Substitute all variables in property values in elementStyle
     */
    applyVarFilter(elementStyles: ElementStyle[], element: Element | null): void;
    /**
     * Calculate all calc() in property values in elementStyle
     */
    applyCalcFilter(elementStyle: ElementStyle, context: Exprs.Context): void;
    applyCmykFilter(elementStyle: ElementStyle, element?: Element): void;
    private applyCmykFilterInternal;
    private applyActions;
    private pop;
    popRule(): void;
    popElement(element: Element): void;
}
export declare const EMPTY: string[];
/**
 * Pseudoelement names in the order they should be processed, empty string is
 * the place where the element's DOM children are processed.
 */
export declare const pseudoNames: string[];
/**
 * @enum {number}
 */
export declare enum ParseState {
    TOP = 0,
    SELECTOR = 1
}
export interface SelectorChain {
    push(action: ChainedAction): void;
    restartWith(action: ChainedAction): SelectorChain;
    emit(action: CascadeAction, handler: CascadeParserHandler): void;
    contributeTo(list: MatchesParameterParserHandler): void;
    recordTextIn(texts: string[], text: string): void;
    finishIn(handler: CascadeParserHandler): void;
}
export declare class CascadeParserHandler extends CssParser.SlaveParserHandler implements CssValidator.PropertyReceiver {
    readonly condition: Exprs.Val | null;
    readonly regionId: string | null;
    readonly validatorSet: CssValidator.ValidatorSet;
    chain: SelectorChain;
    selectorListVoided: boolean;
    private pendingChained;
    specificity: number;
    elementStyle: ElementStyle;
    /** Identity of the declaration block being parsed, for `revert-rule`. */
    ruleId: number;
    pseudoelement: string | null;
    footnoteContent: boolean;
    cascade: Cascade;
    layer: CascadeLayer | null;
    state: ParseState;
    viewConditionId: string | null;
    invalid: boolean;
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, condition: Exprs.Val | null, parent: CascadeParserHandler | null, regionId: string | null, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation | null);
    layerStatementRule(nameLists: string[][]): void;
    protected insertNonPrimary(action: CascadeAction): void;
    processChain(action: CascadeAction): void;
    insertChained(chained: CascadeAction): void;
    private takePendingChained;
    private invalidContinuationAfterPseudoelement;
    isInsideSelectorRule(mnemonics: string): boolean;
    tagSelector(ns: string | null, name: string | null): void;
    invalidSelector(message: string): void;
    setInvalid(): void;
    classSelector(name: string): void;
    pseudoclassSelector(name: string, params: (number | string)[] | null): void;
    private unsupportedPseudoclassSelector;
    pseudoelementSelector(name: string, params: (number | string)[] | null): void;
    private unsupportedPseudoelementSelector;
    idSelector(id: string): void;
    attributeSelector(ns: string | null, name: string, op: TokenType, value: string | null, modifier?: CssParser.AttributeSelectorCaseSensitivity): void;
    descendantSelector(): void;
    childSelector(): void;
    adjacentSiblingSelector(): void;
    followingSiblingSelector(): void;
    nextSelector(): void;
    startSelectorRule(): void;
    error(mnemonics: string, token: CssTokenizer.Token): void;
    startStylesheet(flavor: CssParser.StylesheetFlavor): void;
    startRuleBody(): void;
    finishChain(): void;
    voidSelector(): void;
    voidSelectorList(): void;
    applyRuleForSelector(): void;
    protected makeApplyRuleAction(specificity: number): ApplyRuleAction;
    special(name: string, value: Css.Val): void;
    property(name: string, value: Css.Val, important: boolean): void;
    /** @override */
    invalidPropertyValue(name: string, value: Css.Val): void;
    /** @override */
    unknownProperty(name: string, value: Css.Val): void;
    /** @override */
    simpleProperty(name: string, value: Css.Val, important: any): void;
    finish(): Cascade;
    startFuncWithSelector(funcName: string, params?: (number | string)[]): void;
}
export declare const nthSelectorActionClasses: {
    [key: string]: new (a: number, b: number) => IsNthAction;
};
export declare let conditionCount: number;
/**
 * Cascade Parser Handler for :is() and similar pseudo-classes parameter
 */
export declare class MatchesParameterParserHandler extends CascadeParserHandler {
    readonly parent: CascadeParserHandler;
    parentChain: SelectorChain;
    chains: ChainedAction[][];
    maxSpecificity: number;
    selectorTexts: string[];
    constructor(parent: CascadeParserHandler, delegation: CssParser.Delegation);
    insertChained(chained: CascadeAction): void;
    takeAlternative(actions: ChainedAction[]): void;
    nextSelector(): void;
    endFuncWithSelector(): void;
    startRuleBody(): void;
    error(mnemonics: string, token: CssTokenizer.Token): void;
    pseudoelementSelector(name: string, params: (number | string)[] | null): void;
    invalidSelector(message: string): void;
    private voidAlternative;
    pushSelectorText(selectorText: string): void;
    /**
     * @returns true unless this is `:not()`
     */
    positive(): boolean;
    /**
     * @returns true unless this is `:where()`
     */
    increasingSpecificity(): boolean;
    /**
     * @returns true if this takes a forgiving selector list (:is/where)
     */
    forgiving(): boolean;
    /**
     * @returns true if this is `:has()`
     */
    relational(): boolean;
}
/**
 * Cascade Parser Handler for :not() pseudo-class parameter
 */
export declare class NotParameterParserHandler extends MatchesParameterParserHandler {
    positive(): boolean;
    forgiving(): boolean;
}
/**
 * Cascade Parser Handler for :where() pseudo-class parameter
 */
export declare class WhereParameterParserHandler extends MatchesParameterParserHandler {
    increasingSpecificity(): boolean;
}
/**
 * Cascade Parser Handler for :has() pseudo-class parameter
 */
export declare class HasParameterParserHandler extends MatchesParameterParserHandler {
    relational(): boolean;
    forgiving(): boolean;
}
/**
 * Cascade Parser Handler for :nth-child(An+B of S) pseudo-class parameter
 */
export declare class NthChildOfSelectorParameterParserHandler extends MatchesParameterParserHandler {
    readonly a: number;
    readonly b: number;
    constructor(parent: CascadeParserHandler, delegation: CssParser.Delegation, a: number, b: number);
    endFuncWithSelector(): void;
    forgiving(): boolean;
}
/**
 * Cascade Parser Handler for :nth-last-child(An+B of S) pseudo-class parameter
 */
export declare class NthLastChildOfSelectorParameterParserHandler extends NthChildOfSelectorParameterParserHandler {
    endFuncWithSelector(): void;
}
export declare class DefineParserHandler extends CssParser.SlaveParserHandler {
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, delegation: CssParser.Delegation);
    property(name: string, value: Css.Val, important: boolean): void;
}
export declare class PropSetParserHandler extends CssParser.SlaveParserHandler implements CssValidator.PropertyReceiver {
    readonly condition: Exprs.Val | null;
    readonly elementStyle: ElementStyle;
    readonly validatorSet: CssValidator.ValidatorSet;
    readonly ruleType?: string;
    readonly layer: CascadeLayer | null;
    order: number;
    readonly ruleId: number;
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, condition: Exprs.Val | null, elementStyle: ElementStyle, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation, ruleType?: string, layer?: CascadeLayer | null);
    property(name: string, value: Css.Val, important: boolean): void;
    /** @override */
    invalidPropertyValue(name: string, value: Css.Val): void;
    /** @override */
    unknownProperty(name: string, value: Css.Val): void;
    /** @override */
    simpleProperty(name: string, value: Css.Val, important: any): void;
}
export declare class PropertyParserHandler extends CssParser.ErrorHandler implements CssValidator.PropertyReceiver {
    readonly validatorSet: CssValidator.ValidatorSet;
    elementStyle: ElementStyle;
    order: number;
    readonly ruleId: number;
    constructor(scope: Exprs.LexicalScope, validatorSet: CssValidator.ValidatorSet);
    property(name: string, value: Css.Val, important: boolean): void;
    /** @override */
    invalidPropertyValue(name: string, value: Css.Val): void;
    /** @override */
    unknownProperty(name: string, value: Css.Val): void;
    /** @override */
    simpleProperty(name: string, value: Css.Val, important: any): void;
}
export declare function forEachViewConditionalStyles(style: ElementStyle, callback: (p1: ElementStyle) => any): void;
export declare function mergeViewConditionalStyles(cascMap: {
    [key: string]: CascadeValue;
}, context: Exprs.Context, style: ElementStyle): void;
export declare function parseStyleAttribute(scope: Exprs.LexicalScope, validatorSet: CssValidator.ValidatorSet, baseURL: string, styleAttrValue: string): ElementStyle;
export declare function isVertical(cascaded: {
    [key: string]: CascadeValue;
}, context: Exprs.Context, vertical: boolean): boolean;
export declare function isRtl(cascaded: {
    [key: string]: CascadeValue;
}, context: Exprs.Context, rtl: boolean): boolean;
export declare function flattenCascadedStyle(style: ElementStyle, context: Exprs.Context, regionIds: string[] | null, isFootnote: boolean): {
    [key: string]: CascadeValue;
};
export declare function forEachStylesInRegion(style: ElementStyle, regionIds: string[] | null, isFootnote: boolean, callback: (p1: string, p2: ElementStyle) => any): void;
export declare function mergeStyle(to: {
    [key: string]: CascadeValue;
}, from: ElementStyle, context: Exprs.Context): void;
/**
 * Convert logical properties to physical ones, taking specificity into account.
 * @param src Source properties map
 * @param dest Destination map
 * @param transform If supplied, property values are transformed by this
 *     function before inserted into the destination map. The first parameter is
 *     the property name and the second one is the property value.
 * @template T
 */
export declare const convertToPhysical: <T>(src: {
    [key: string]: CascadeValue;
}, dest: {
    [key: string]: T;
}, vertical: boolean, rtl: boolean, leftPageSide: boolean, transform: (p1: string, p2: CascadeValue) => T) => void;
/**
 * Convert var() to its value
 */
export declare class VarFilterVisitor extends Css.FilterVisitor {
    elementStyles: ElementStyle[];
    readonly styles: StyleReader;
    readonly root: Element;
    element: Element | null;
    private readonly currentCustomPropertyName;
    private resolvingCustomProperties;
    private varResolutionState;
    constructor(elementStyles: ElementStyle[], styles: StyleReader, root: Element, element: Element | null, currentCustomPropertyName?: string | null);
    private getRawCustomPropertyLookup;
    private collectReferencedCustomProperties;
    private findReferencedCycleStart;
    getFallbackCycleMembers(val: Css.Val, elementStyles: ElementStyle[], element: Element | null): Set<string> | null;
    private resolveCustomProperty;
    private resolveReferencedCustomProperty;
    private getVarValue;
    visitFunc(func: Css.Func): Css.Val;
    visitSpaceList(list: Css.SpaceList): Css.Val;
    visitCommaList(list: Css.CommaList): Css.Val;
}
/**
 * Convert calc() to its value
 */
export declare class CalcFilterVisitor extends Css.FilterVisitor {
    context: Exprs.Context;
    resolveViewportUnit?: boolean;
    percentRef?: number;
    vertical?: boolean;
    constructor(context: Exprs.Context, resolveViewportUnit?: boolean, percentRef?: number, vertical?: boolean);
    visitFunc(func: Css.Func): Css.Val;
    protected hasUnresolvableUnit(exprText: string): boolean;
    protected isLengthExpr(exprText: string): boolean;
    visitNumeric(numeric: Css.Numeric): Css.Val;
}
export declare class RootSizingCalcFilterVisitor extends CalcFilterVisitor {
    protected hasUnresolvableUnit(exprText: string): boolean;
    protected isLengthExpr(exprText: string): boolean;
}
export declare function evaluateCSSToCSS(context: Exprs.Context, val: Css.Val, propName?: string, percentRef?: number, vertical?: boolean): Css.Val;
