import * as Css from "./css";
export declare function preprocessForTextSpacing(element: Element): void;
export declare function processGeneratedContent(element: HTMLElement, textAutospace: Css.Val, textSpacingTrim: Css.Val, hangingPunctuation: Css.Val, lang: string | null, vertical: boolean): void;
