import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as Exprs from "./exprs";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
export declare function makeFontTraitKey(properties: {
    [key: string]: Css.Val;
}): string;
export declare function prepareProperties(properties: CssCascade.ElementStyle, context: Exprs.Context): {
    [key: string]: Css.Val;
};
/**
 * A font declared in a font-face rule.
 */
export declare class Face {
    readonly properties: {
        [key: string]: Css.Val;
    };
    fontTraitKey: string;
    src: string | null;
    blobURLs: string[];
    blobs: Blob[];
    family: string | null;
    /**
     * The `<style>` element carrying this face's `@font-face` rule in the view
     * document. Only the view faces made by {@link Mapper.initFont} have one.
     */
    styleElement: HTMLStyleElement | null;
    constructor(properties: {
        [key: string]: Css.Val;
    });
    /**
     * Create "at" font-face rule.
     */
    makeAtRule(src: string, fontBytes: Blob | null): string;
}
/**
 * Set of the fonts declared in all stylesheets of a document.
 * @param deobfuscator function
 *     that takes url and returns data deobfuscator
 */
export declare class DocumentFaces {
    readonly deobfuscator: ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null;
    /**
     * Maps source font family names to the family names used in the HTML view.
     */
    familyMap: {
        [key: string]: string;
    };
    constructor(deobfuscator: ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null);
    registerFamily(srcFace: Face, viewFace: Face): void;
    filterFontFamily(val: Css.Val): Css.Val;
}
/**
 * Object that loads fonts in a document and allocates font families for them
 * in the view document
 * @param head where to add styles in the view document (normally head element)
 * @param body where to probe text in the view document (normally body element)
 */
export declare class Mapper {
    readonly head: Element;
    readonly body: Element;
    /**
     * Maps Face.src to an entry for an already-loaded font.
     */
    srcURLMap: {
        [key: string]: TaskUtil.Fetcher<Face | null>;
    };
    familyPrefix: string;
    familyCounter: number;
    constructor(head: Element, body: Element, opt_familyPrefix?: string);
    getViewFontFamily(srcFace: Face, documentFaces: DocumentFaces): string;
    /**
     * @param fontBytes deobfuscated font bytes (if deobfuscation is needed)
     */
    private initFont;
    loadFont(srcFace: Face, documentFaces: DocumentFaces): TaskUtil.Fetcher<Face | null>;
    findOrLoadFonts(srcFaces: Face[], documentFaces: DocumentFaces): Task.Result<boolean>;
    /**
     * Puts the `@font-face` rules of the view document back in the order of the
     * rules they came from, which the cascade has already sorted. A font that
     * needs deobfuscation is added when its fetch completes, so the order the
     * rules were added in is not the order they were declared in, and the
     * browser lets the last of the matching rules win.
     */
    private reorderFontFaceRules;
    waitFontLoading(): Task.Result<boolean>;
}
