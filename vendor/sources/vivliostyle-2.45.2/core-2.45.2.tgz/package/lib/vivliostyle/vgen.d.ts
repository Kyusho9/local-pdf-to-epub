import * as Base from "./base";
import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as CssStyler from "./css-styler";
import * as Exprs from "./exprs";
import * as Font from "./font";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
import * as Vtree from "./vtree";
import { XmlDoc } from "./types";
export type CustomRenderer = (p1: Element, p2: Element, p3: {
    [key: string]: Css.Val;
}) => Task.Result<Element | null>;
export interface CustomRendererFactory {
    makeCustomRenderer(xmldoc: XmlDoc.XMLDocHolder): CustomRenderer;
}
/**
 * Creates an epubReadingSystem object in the iframe.contentWindow.navigator
 * when load event fires.
 */
export declare function initIFrame(iframe: HTMLIFrameElement): void;
export interface StylerProducer {
    getStylerForDoc(xmldoc: XmlDoc.XMLDocHolder): CssStyler.AbstractStyler;
}
export declare class ViewFactory extends Base.SimpleEventTarget implements Vtree.LayoutContext {
    readonly flowName: string;
    readonly context: Exprs.Context;
    readonly viewport: Viewport;
    readonly styler: CssStyler.Styler;
    readonly regionIds: string[] | null;
    readonly xmldoc: XmlDoc.XMLDocHolder;
    readonly docFaces: Font.DocumentFaces;
    readonly footnoteStyle: CssCascade.ElementStyle;
    readonly stylerProducer: StylerProducer;
    readonly page: Vtree.Page;
    readonly customRenderer: CustomRenderer;
    readonly fallbackMap: {
        [key: string]: string;
    };
    readonly documentURLTransformer: Base.DocumentURLTransformer;
    readonly pageProps?: {
        [key: string]: CssCascade.ElementStyle;
    };
    readonly cascadedPageStyle?: CssCascade.ElementStyle | null;
    private readonly semanticFootnoteFirstRefOffsets;
    private readonly semanticFootnoteFirstRefOffsetsInitialized;
    private static SVG_URL_ATTRIBUTES;
    private static FOOTNOTE_CALL_OWNER_ATTR;
    document: Document;
    exprContentListener: Vtree.ExprContentListener;
    private computedStyleParentFontSizeOverride;
    private computedStyleParentLineHeightOverride;
    nodeContext: Vtree.NodeContext | null;
    viewRoot: Element | null;
    isFootnote: boolean;
    sourceNode: Node | null;
    offsetInNode: number;
    viewNode: Element | Text | null;
    constructor(flowName: string, context: Exprs.Context, viewport: Viewport, styler: CssStyler.Styler, regionIds: string[] | null, xmldoc: XmlDoc.XMLDocHolder, docFaces: Font.DocumentFaces, footnoteStyle: CssCascade.ElementStyle, stylerProducer: StylerProducer, page: Vtree.Page, customRenderer: CustomRenderer, fallbackMap: {
        [key: string]: string;
    }, documentURLTransformer: Base.DocumentURLTransformer, pageProps?: {
        [key: string]: CssCascade.ElementStyle;
    }, cascadedPageStyle?: CssCascade.ElementStyle | null, semanticFootnoteFirstRefOffsets?: Map<string, number>, semanticFootnoteFirstRefOffsetsInitialized?: {
        value: boolean;
    });
    /** @override */
    clone(): Vtree.LayoutContext;
    private getExplicitPageType;
    private isNormalFlowElement;
    private getFirstInFlowChildElement;
    private getEffectiveStartPageType;
    private syncTextNodePageTypeBoundary;
    private syncSemanticFootnoteCounterToTarget;
    createPseudoelementShadow(nodeContext: Vtree.NodeContext, element: Element, isRoot: boolean, cascStyle: CssCascade.ElementStyle, computedStyle: {
        [key: string]: Css.Val;
    }, styler: CssStyler.AbstractStyler, context: Exprs.Context, parentShadow: Vtree.ShadowContext | null, subShadow: Vtree.ShadowContext | null): Vtree.ShadowContext | null;
    getPseudoMap(cascStyle: CssCascade.ElementStyle, regionIds: string[] | null, isFootnote: boolean, nodeContext: Vtree.NodeContext, context: Exprs.Context): CssCascade.ElementStyleMap | null;
    createRefShadow(href: string, type: Vtree.ShadowType, element: Element, parentShadow: Vtree.ShadowContext | null, subShadow: Vtree.ShadowContext | null): Task.Result<Vtree.ShadowContext | null>;
    createShadows(nodeContext: Vtree.NodeContext, element: Element, isRoot: boolean, cascStyle: CssCascade.ElementStyle, computedStyle: {
        [key: string]: Css.Val;
    }, styler: CssStyler.AbstractStyler, context: Exprs.Context, shadowContext: Vtree.ShadowContext | null): Task.Result<Vtree.ShadowContext | null>;
    /** @override */
    setViewRoot(viewRoot: Element, isFootnote: boolean): void;
    /**
     * @return vertical
     */
    computeStyle(vertical: boolean, rtl: boolean, style: CssCascade.ElementStyle, computedStyle: {
        [key: string]: Css.Val;
    }): boolean;
    private inheritFromSourceParent;
    resolveURL(url: string): string;
    inheritLangAttribute(nodeContext: Vtree.NodeContext): void;
    transferPolyfilledInheritedProps(nodeContext: Vtree.NodeContext, computedStyle: {
        [key: string]: Css.Val;
    }): void;
    resolveFormattingContext(nodeContext: Vtree.NodeContext, firstTime: boolean, display: Css.Val | null | undefined, position: Css.Ident | null | undefined, float: Css.Val | null | undefined, isRoot: boolean): void;
    /**
     * @return holding true if children should be processed
     */
    private createElementView;
    /**
     * Check if the current position is at the start of a page.
     * This is used to determine whether a forced break should be ignored.
     * (Issue #1608)
     */
    private isAtStartOfPage;
    /**
     * Check if the current element is inside multi-column element
     * that is not root or body element in the source tree.
     *
     * Note: vivliostyle handles multi-column on the root and body element on its own,
     * but leaves it to the browser to handle other multi-column.
     * This check is for such non-root/body multi-column.
     */
    private isInsideNonRootMultiColumn;
    /**
     * Check if the current position is at a forced or unforced break
     * (Fix for Issue #690)
     *
     * @param nodeContext
     * @returns forced break type, or "auto" for unforced break, or null for not break
     */
    private getBreakTypeAt;
    private isInsideTable;
    private processAfterIfcontinues;
    isSVGUrlAttribute(attributeName: string): boolean;
    modifyElemDimensionWithImageResolution(images: {
        image: HTMLElement;
        element: HTMLElement;
        fetcher: TaskUtil.Fetcher<string>;
    }[], imageResolution: number, computedStyle: {
        [key: string]: Css.Val;
    }, isVertical: boolean): void;
    private preprocessElementStyle;
    private findAndProcessRepeatingElements;
    private processRepeatOnBreak;
    private createTextNodeView;
    private preprocessTextContent;
    /**
     * @return holding true if children should be processed
     */
    createNodeView(nodeContext: Vtree.NodeContext, firstTime: boolean): Task.Result<boolean>;
    /** @override */
    setCurrent(nodeContext: Vtree.NodeContext, firstTime: boolean, atUnforcedBreak?: boolean): Task.Result<boolean>;
    processShadowContent(pos: Vtree.ChildNodeContext): Vtree.NodeContext;
    private nextPositionInTree;
    /**
     * Find a footnote-call element immediately before the given view node.
     */
    private findImmediateFootnoteCallSibling;
    /**
     * True for semantic footnotes that already provide a noteref call in source
     * (EPUB or DPUB-ARIA pattern), so an extra ::footnote-call must not be inserted.
     */
    private isSemanticFootnoteElement;
    /**
     * Insert a footnote-call NodeContext before the footnote element.
     * The footnote-call will be processed as a normal inline element,
     * then shadowSibling will lead to the footnote element.
     * (Issue #868)
     */
    private insertFootnoteCall;
    /** @override */
    nextInTree(position: Vtree.NodeContext, atUnforcedBreak?: boolean): Task.Result<Vtree.NodeContext | null>;
    private nextInTreeWithPreprocessedText;
    addImageFetchers(bg: Css.Val): void;
    applyComputedStyles(target: Element, computedStyle: {
        [key: string]: Css.Val;
    }): void;
    /**
     * Parse a CSS value with "px" unit plus layoutUnitAdj.
     * This is to get accurate font-size and line-height values from computed style
     * that have been set with minus layoutUnitAdj.
     * @param val CSS value string
     * @returns parsed and adjusted value in px, or null if cannot parse as "px" unit, e.g. "normal"
     */
    private parsePlusLayoutUnitAdj;
    private getFootnoteAreaInheritedMetrics;
    private getComputedFontMetrics;
    private getParentViewStyle;
    private getParentComputedMetrics;
    /**
     * Get "lh" unit size in px
     * @return line-height in px, or null if cannot be determined
     */
    private getLineHeightUnitSize;
    /**
     * Get "em" unit size in px
     * @return font-size in px, or null if cannot be determined
     */
    private getEmUnitSize;
    /** @override */
    applyPseudoelementStyle(nodeContext: Vtree.NodeContext, pseudoName: string, target: Element): void;
    /** @override */
    peelOff(nodeContext: Vtree.ChildNodeContext, nodeOffset: number): Task.Result<Vtree.NodeContext>;
    createElement(ns: string | null, tag: string): Element;
    /** @override */
    applyFootnoteStyle(vertical: boolean, rtl: boolean, target: Element): Task.Result<boolean>;
    /** @override */
    processFragmentedBlockEdge(nodeContext: Vtree.NodeContext): void;
    private fixClonedBoxDecorationOverflow;
    private createChildAnonymousBlockIfNeeded;
    /** @override */
    convertLengthToPx(numeric: Css.Numeric, viewNode: Node, clientLayout: Vtree.ClientLayout): number | Css.Numeric;
    /**
     * Returns if two NodePositionStep are equivalent.
     */
    isSameNodePositionStep(step1: Vtree.NodePositionStep, step2: Vtree.NodePositionStep): boolean;
    /** @override */
    isSameNodePosition(nodePosition1: Vtree.NodePosition, nodePosition2: Vtree.NodePosition): boolean;
}
export declare const propertiesNotPassedToDOM: {
    "float-min-wrap-block": boolean;
    "float-reference": boolean;
    "flow-into": boolean;
    "flow-linger": boolean;
    "flow-options": boolean;
    "flow-priority": boolean;
    "footnote-display": boolean;
    "footnote-policy": boolean;
    "margin-break": boolean;
    page: boolean;
};
export declare class DefaultClientLayout implements Vtree.ClientLayout {
    layoutBox: Element;
    window: Window;
    pixelRatio: number;
    scaleRatio: number;
    layoutUnitPerPixel: number;
    constructor(viewport: Viewport);
    private subtractOffsets;
    /** @override */
    getRangeClientRects(range: Range): Vtree.ClientRect[];
    /** @override */
    getElementClientRect(element: Element): Vtree.ClientRect;
    /** @override */
    getElementComputedStyle(element: Element): CSSStyleDeclaration;
    /**
     * Adjust length value with rendering precision.
     * @param value Length value to adjust
     * @return Adjusted length value
     * @override
     */
    adjustLengthValue(value: number): number;
}
export declare class Viewport {
    readonly window: Window;
    readonly fontSize: number;
    readonly pixelRatio: number;
    document: Document;
    root: HTMLElement;
    private outerZoomBox;
    contentContainer: HTMLElement;
    layoutBox: HTMLElement;
    width: number;
    height: number;
    scaleRatio: number;
    layoutUnitPerPixel: number;
    layoutUnitAdj: number;
    constructor(window: Window, fontSize: number, pixelRatio: number, opt_root?: HTMLElement, opt_width?: number, opt_height?: number);
    /**
     * Reset zoom.
     */
    resetZoom(): void;
    /**
     * Zoom viewport.
     * @param width Overall width of contents before scaling (px)
     * @param height Overall height of contents before scaling (px)
     * @param scale Factor to which the viewport will be scaled.
     */
    zoom(width: number, height: number, scale: number): void;
    /**
     * Remove all pages inside the viewport.
     */
    clear(): void;
}
/**
 * Recursively walk a CSS value tree and push image-load fetchers for any
 * URL values found. Used to preload images referenced by background-image,
 * border-image-source, filter, etc.
 */
export declare function addImageFetchersToPage(val: Css.Val, page: Vtree.Page): void;
