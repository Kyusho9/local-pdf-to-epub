import * as BreakPosition from "./break-position";
import * as LayoutProcessor from "./layout-processor";
import * as LayoutRetryers from "./layout-retryers";
import * as LayoutUtil from "./layout-util";
import * as RepetitiveElementImpl from "./repetitive-element";
import * as Task from "./task";
import * as Layout from "./layout";
import { FormattingContextType, FragmentLayoutConstraintType, Layout as LayoutType, RepetitiveElement, Table, Vtree } from "./types";
export declare class TableRow {
    readonly rowIndex: number;
    readonly sourceNode: Node | null;
    cells: TableCell[];
    breakBefore: string | null;
    breakAfter: string | null;
    constructor(rowIndex: number, sourceNode: Node | null);
    addCell(cell: TableCell): void;
}
export declare class TableCell {
    readonly rowIndex: number;
    readonly columnIndex: number;
    readonly anchorColumnIndex: number;
    colSpan: number;
    rowSpan: number;
    constructor(rowIndex: number, columnIndex: number, anchorColumnIndex: number, viewElement: Element);
}
export declare class TableSlot {
    readonly rowIndex: number;
    readonly columnIndex: number;
    readonly cell: TableCell;
    constructor(rowIndex: number, columnIndex: number, cell: TableCell);
}
export declare class TableCellFragment {
    readonly column: Layout.Column;
    readonly cellNodeContext: Vtree.NodeContext;
    pseudoColumn: Layout.PseudoColumn;
    empty: boolean;
    constructor(column: Layout.Column, pseudoColumnContainer: HTMLElement, cellNodeContext: Vtree.NodeContext);
    findAcceptableBreakPosition(): Layout.BreakPositionAndNodeContext;
}
export declare class TableCaptionView {
    readonly viewNode: Element;
    readonly side: string;
    constructor(viewNode: Element, side: string);
}
export declare class BetweenTableRowBreakPosition extends BreakPosition.EdgeBreakPosition {
    private formattingContext;
    acceptableCellBreakPositions: Layout.BreakPositionAndNodeContext[] | null;
    private rowIndex;
    constructor(position: Vtree.NodeContext, breakOnEdge: string | null, overflows: boolean, columnBlockSize: number);
    findAcceptableBreak(column: Layout.Column, penalty: number): Vtree.NodeContext | null;
    /**
     * Check if any non-spanning cell in the row has content that wasn't fully
     * rendered. This happens when page floats (footnotes) reduce available space
     * during a retry, causing cell content to overflow within the row even though
     * the row boundary appears acceptable. (Issue #1663)
     */
    private hasUnfinishedCells;
    getMinBreakPenalty(): number;
    getAcceptableCellBreakPositions(): Layout.BreakPositionAndNodeContext[];
    private getRowIndex;
    private getCellFragments;
}
export declare class InsideTableRowBreakPosition extends BreakPosition.AbstractBreakPosition {
    readonly rowIndex: number;
    readonly beforeNodeContext: Vtree.NodeContext;
    readonly formattingContext: TableFormattingContext;
    acceptableCellBreakPositions: Layout.BreakPositionAndNodeContext[] | null;
    constructor(rowIndex: number, beforeNodeContext: Vtree.NodeContext, formattingContext: TableFormattingContext);
    findAcceptableBreak(column: Layout.Column, penalty: number): Vtree.NodeContext | null;
    getMinBreakPenalty(): number;
    getAcceptableCellBreakPositions(): Layout.BreakPositionAndNodeContext[];
    private getCellFragments;
}
export type BrokenTableCellPosition = {
    cellNodePosition: Vtree.NodePosition;
    breakChunkPosition: Vtree.ChunkPosition;
    cell: TableCell;
};
/**
 * @param tableSourceNode Source node of the table
 */
export declare class TableFormattingContext extends RepetitiveElementImpl.RepetitiveElementsOwnerFormattingContext implements Table.TableFormattingContext {
    readonly tableSourceNode: Element;
    formattingContextType: FormattingContextType;
    vertical: boolean;
    columnCount: number;
    tableWidth: number;
    captions: (TableCaptionView | null)[];
    colGroups: DocumentFragment | null;
    colWidths: number[] | null;
    inlineBorderSpacing: number;
    rows: TableRow[];
    slots: TableSlot[][];
    cellFragments: TableCellFragment[][];
    lastRowViewNode: Element | null;
    cellBreakPositions: BrokenTableCellPosition[];
    repetitiveElements: RepetitiveElement.RepetitiveElements | null;
    constructor(parent: Vtree.FormattingContext | null, tableSourceNode: Element);
    getName(): string;
    isFirstTime(nodeContext: Vtree.NodeContext, firstTime: boolean): boolean;
    getParent(): Vtree.FormattingContext | null;
    finishFragment(): void;
    addRow(rowIndex: number, row: TableRow): void;
    getRowSlots(rowIndex: number): TableSlot[];
    addCell(rowIndex: number, columnIndex: number, viewElement: Element): void;
    getRowByIndex(index: number): TableRow;
    findRowIndexBySourceNode(sourceNode: Node): number;
    private isPreviousFragmentRowSpanningCellBreakPosition;
    addCellFragment(rowIndex: number, columnIndex: number, cellFragment: TableCellFragment): void;
    getCellsFallingOnRow(rowIndex: number): TableCell[];
    getRowSpanningCellsOverflowingTheRow(rowIndex: number): TableCell[];
    getCellFragmentOfCell(cell: TableCell): TableCellFragment;
    getColumnCount(): number;
    /**
     * @return position
     */
    findCellFromColumn(column: Layout.Column | null): {
        rowIndex: number;
        columnIndex: number;
    } | null;
    collectElementsOffsetOfUpperCells(position: {
        rowIndex: number;
        columnIndex: number;
    }): RepetitiveElement.ElementsOffset[];
    collectElementsOffsetOfHighestColumn(): RepetitiveElement.ElementsOffset[];
    private collectElementsOffsetFromColumn;
    saveState(): any;
    restoreState(state: any): void;
}
export declare class ElementsOffsetOfTableCell implements RepetitiveElement.ElementsOffset {
    readonly repeatitiveElementsInColumns: RepetitiveElement.ElementsOffset[][];
    constructor(repeatitiveElementsInColumns: RepetitiveElement.ElementsOffset[][]);
    /** @override */
    calculateOffset(nodeContext: Vtree.NodeContext): number;
    /** @override */
    calculateMinimumOffset(nodeContext: Vtree.NodeContext): number;
    private calculateMaxOffsetOfColumn;
}
export declare class EntireTableLayoutStrategy extends LayoutUtil.EdgeSkipper {
    readonly formattingContext: TableFormattingContext;
    readonly column: Layout.Column;
    rowIndex: number;
    columnIndex: number;
    inRow: boolean;
    checkPoints: Vtree.RenderedNodeContext[];
    inHeaderOrFooter: boolean;
    constructor(formattingContext: TableFormattingContext, column: Layout.Column);
    startNonInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startNonElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    registerCheckPoint(state: LayoutUtil.RenderedActiveLayoutIteratorState): void;
    postLayoutBlockContents(state: LayoutUtil.RenderedActiveLayoutIteratorState): void;
}
export declare class TableLayoutStrategy extends LayoutUtil.EdgeSkipper {
    readonly formattingContext: TableFormattingContext;
    readonly column: Layout.Column;
    private static ignoreList;
    inRow: boolean;
    currentRowIndex: number;
    currentColumnIndex: number;
    originalStopAtOverflow: boolean;
    inHeader: boolean;
    inFooter: boolean;
    private didExtractRowSpanningCellBreakPositions;
    constructor(formattingContext: TableFormattingContext, column: Layout.Column);
    startNonInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    resetColumn(): void;
    getColSpanningCellWidth(cell: TableCell): number;
    layoutCell(cell: TableCell, cellNodeContext: Vtree.NodeContext, startChunkPosition: Vtree.ChunkPosition): Task.Result<boolean>;
    /**
     * Find the break position for the cell at the given slot index.
     * Returns the break position and its index in cellBreakPositions, or null if not found.
     * Uses sourceNode matching instead of sequential index to support layout retry (issue #1663).
     */
    findBrokenCellAtSlot(slotIndex: number, sourceNode: Node): {
        position: BrokenTableCellPosition;
        index: number;
    } | null;
    private extractRowSpanningCellBreakPositions;
    layoutRowSpanningCellsFromPreviousFragment(state: LayoutUtil.RenderedActiveLayoutIteratorState): Task.Result<boolean>;
    startTableRow(state: LayoutUtil.RenderedActiveLayoutIteratorState): Task.Result<boolean>;
    private registerCellFragmentIndex;
    startTableCell(state: LayoutUtil.RenderedActiveLayoutIteratorState): Task.Result<boolean>;
    startNonInlineBox(state: LayoutUtil.RenderedActiveLayoutIteratorState): Task.Result<boolean>;
    endNonInlineBox(state: LayoutUtil.RenderedActiveLayoutIteratorState): Task.Result<boolean>;
    afterNonInlineElementNode(state: LayoutUtil.RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
}
export declare class TableLayoutProcessor implements LayoutProcessor.LayoutProcessor {
    private layoutEntireTable;
    private getColumnWidths;
    private getColGroupElements;
    private normalizeAndGetColElements;
    private addMissingColElements;
    /**
     * Measure width of columns and normalize colgroup and col elements so that
     * each column has a corresponding col element with the width specified.
     */
    normalizeColGroups(formattingContext: TableFormattingContext, tableElement: Element, column: Layout.Column): void;
    doInitialLayout(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<Vtree.NodeContext | null>;
    /**
     * Check if any row inside the table has a forced break value
     * (propagated from cells or set on the row itself).
     */
    private hasForcedBreakInRows;
    /**
     * Check if there is any in-flow content before the given view node.
     * Walks previous siblings at each ancestor level (up to the column root)
     * to determine whether the table is at the leading edge of the
     * page/column.
     */
    private hasInFlowContentBefore;
    addCaptions(formattingContext: TableFormattingContext, rootViewNode: Element, firstChild: Node | null): void;
    addColGroups(formattingContext: TableFormattingContext, rootViewNode: Element, firstChild: Node | null): void;
    removeColGroups(formattingContext: TableFormattingContext, rootViewNode: Element | null): void;
    doLayout(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<Vtree.NodeContext | null>;
    /** @override */
    layout(nodeContext: Vtree.NodeContext, column: Layout.Column, leadingEdge: boolean): Task.Result<Vtree.NodeContext | null>;
    /** @override */
    createEdgeBreakPosition(position: Vtree.NodeContext, breakOnEdge: string | null, overflows: boolean, columnBlockSize: number): LayoutType.BreakPosition;
    /** @override */
    startNonInlineElementNode(nodeContext: Vtree.NodeContext): boolean;
    /** @override */
    afterNonInlineElementNode(nodeContext: Vtree.NodeContext, stopAtOverflow: boolean): boolean;
    /** @override */
    finishBreak(column: Layout.Column, nodeContext: Vtree.NodeContext, forceRemoveSelf: boolean, endOfColumn: boolean): Task.Result<boolean>;
    /** @override */
    clearOverflownViewNodes(column: Layout.Column, parentNodeContext: Vtree.NodeContext, nodeContext: Vtree.NodeContext, removeSelf: boolean): void;
}
export declare class LayoutRetryer extends LayoutRetryers.AbstractLayoutRetryer {
    private tableFormattingContext;
    private readonly processor;
    constructor(tableFormattingContext: TableFormattingContext, processor: TableLayoutProcessor);
    resolveLayoutMode(nodeContext: Vtree.NodeContext): LayoutType.LayoutMode;
    clearNodes(initialPosition: Vtree.NodeContext): void;
    restoreState(nodeContext: Vtree.NodeContext, column: Layout.Column): void;
}
export declare class LayoutEntireTable extends RepetitiveElementImpl.LayoutEntireBlock {
    readonly processor: TableLayoutProcessor;
    constructor(formattingContext: TableFormattingContext, processor: TableLayoutProcessor);
    doLayout(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<Vtree.NodeContext | null>;
}
export declare class EntireTableBreakPosition extends BreakPosition.EdgeBreakPosition {
    constructor(tableNodeContext: Vtree.NodeContext);
    getMinBreakPenalty(): number;
    breakPositionChosen(column: Layout.Column): void;
}
export declare class EntireTableLayoutConstraint implements Layout.FragmentLayoutConstraint {
    tableRootNode: Node;
    flagmentLayoutConstraintType: FragmentLayoutConstraintType;
    constructor(tableRootNode: Node);
    /** @override */
    allowLayout(nodeContext: Vtree.NodeContext, overflownNodeContext: Vtree.NodeContext, column: Layout.Column): boolean;
    /** @override */
    nextCandidate(nodeContext: Vtree.NodeContext): boolean;
    /** @override */
    postLayout(allowed: boolean, positionAfter: Vtree.NodeContext, initialPosition: Vtree.NodeContext, column: Layout.Column): void;
    /** @override */
    finishBreak(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<boolean>;
    /** @override */
    equalsTo(constraint: Layout.FragmentLayoutConstraint): boolean;
    /** @override */
    getPriorityOfFinishBreak(): number;
}
export declare class LayoutFragmentedTable extends RepetitiveElementImpl.LayoutFragmentedBlock {
    readonly processor: TableLayoutProcessor;
    constructor(formattingContext: TableFormattingContext, processor: TableLayoutProcessor);
    doLayout(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<Vtree.NodeContext | null>;
}
export declare class TableRowLayoutConstraint extends RepetitiveElementImpl.RepetitiveElementsOwnerLayoutConstraint implements Table.TableRowLayoutConstraint {
    flagmentLayoutConstraintType: FragmentLayoutConstraintType;
    cellFragmentLayoutConstraints: {
        constraints: Layout.FragmentLayoutConstraint[];
        breakPosition: Vtree.NodeContext | null;
    }[];
    constructor(nodeContext: Vtree.NodeContext);
    allowLayout(nodeContext: Vtree.NodeContext, overflownNodeContext: Vtree.NodeContext, column: Layout.Column): boolean;
    nextCandidate(nodeContext: Vtree.NodeContext): boolean;
    postLayout(allowed: boolean, positionAfter: Vtree.NodeContext, initialPosition: Vtree.NodeContext, column: Layout.Column): void;
    finishBreak(nodeContext: Vtree.NodeContext, column: Layout.Column): Task.Result<boolean>;
    removeDummyRowNodes(nodeContext: Vtree.NodeContext): void;
    private collectCellFragmentLayoutConstraints;
    private getCellFragemnts;
    getElementsOffsetsForTableCell(column: Layout.Column | null): RepetitiveElement.ElementsOffset[];
    equalsTo(constraint: Layout.FragmentLayoutConstraint): boolean;
}
