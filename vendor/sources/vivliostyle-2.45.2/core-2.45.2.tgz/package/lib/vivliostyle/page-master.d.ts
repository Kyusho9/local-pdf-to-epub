import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as CssParser from "./css-parser";
import * as CssValidator from "./css-validator";
import * as Exprs from "./exprs";
import * as Font from "./font";
import * as Vtree from "./vtree";
export declare let keyCount: number;
/**
 * Represent an at-rule which creates a page-level CSS box (page-master,
 * partition, and partition-group).
 */
export declare abstract class PageBox<I extends PageBoxInstance = PageBoxInstance<any>> {
    readonly name: string | null;
    readonly pseudoName: string | null;
    readonly classes: string[];
    readonly parent: PageBox | null;
    specified: CssCascade.ElementStyle;
    children: PageBox[];
    pageMaster: PageMaster | null;
    index: number;
    key: string;
    protected _scope: Exprs.LexicalScope;
    get scope(): Exprs.LexicalScope;
    constructor(scope: Exprs.LexicalScope, name: string | null, pseudoName: string | null, classes: string[], parent: PageBox | null);
    createInstance(parentInstance: PageBoxInstance, context: Exprs.Context, docElementStyle: CssCascade.ElementStyle): PageBoxInstance;
    /**
     * Clone the PageBox.
     * @param param parent: The parent of the cloned PageBox.
     *     pseudoName: Assign this value as the pseudoName of the cloned PageBox.
     */
    clone(param: {
        parent?: PageBox;
        pseudoName?: string;
    }): PageBox<I>;
    /**
     * Copy 'specified' properties to another instance.
     * @param dest The PageBox into which 'specified' properties are copied
     */
    protected copySpecified(dest: PageBox): void;
    /**
     * Clone children with the specified PageBox as their parent.
     */
    protected cloneChildren(parent: PageBox): void;
}
/**
 * Parent of all page masters
 */
export declare class RootPageBox extends PageBox<RootPageBoxInstance> {
    constructor(scope: Exprs.LexicalScope);
}
export declare class PageMasterScope extends Exprs.LexicalScope {
    pageMaster: PageMaster;
    constructor(scope: Exprs.LexicalScope, pageMaster: PageMaster);
}
/**
 * Represent a page-master rule
 */
export declare class PageMaster<I extends PageMasterInstance = PageMasterInstance<any>> extends PageBox<I> {
    readonly condition: Exprs.Val | null;
    readonly specificity: number;
    readonly layer: CssCascade.CascadeLayer | null;
    keyMap: {
        [key: string]: string;
    };
    constructor(scope: Exprs.LexicalScope, name: string | null, pseudoName: string | null, classes: string[], parent: RootPageBox, condition: Exprs.Val | null, specificity: number, layer?: CssCascade.CascadeLayer | null);
    createInstance(parentInstance: PageBoxInstance, context: Exprs.Context, docElementStyle: CssCascade.ElementStyle): PageBoxInstance;
    clone(param: any): PageMaster;
    /**
     * Point the pageMaster reference in the PageMasterScope to the current page
     * master. This is needed when a page master is cloned and shares a common
     * scope with the original page master. Since every Exprs.Val which the
     * page master holds has a reference to the scope and uses it for variable
     * resolution, this reference must be updated properly before the page master
     * instance is used.
     */
    resetScope(): void;
}
/**
 * Represent a partition-group rule
 */
export declare class PartitionGroup extends PageBox<PartitionGroupInstance> {
    constructor(scope: Exprs.LexicalScope, name: string | null, pseudoName: string | null, classes: string[], parent: PageBox);
    createInstance(parentInstance: PageBoxInstance, context: Exprs.Context, docElementStyle: CssCascade.ElementStyle): PageBoxInstance;
    clone(param: any): PartitionGroup;
}
/**
 * Represent a partition rule
 */
export declare class Partition<I extends PartitionInstance = PartitionInstance> extends PageBox<I> {
    constructor(scope: Exprs.LexicalScope, name: string | null, pseudoName: string | null, classes: string[], parent: PageBox);
    createInstance(parentInstance: PageBoxInstance, context: Exprs.Context, docElementStyle: CssCascade.ElementStyle): PageBoxInstance;
    clone(param: any): Partition;
}
/**
 * @param def default value
 */
export declare function toExprIdent(scope: Exprs.LexicalScope, val: Css.Val, def: string): Exprs.Val;
export declare function toExprAuto(scope: Exprs.LexicalScope, val: Css.Val, ref: Exprs.Val | null): Exprs.Val | null;
export declare function toExprNormal(scope: Exprs.LexicalScope, val: Css.Val, ref: Exprs.Val | null): Exprs.Val | null;
export declare function toExprZero(scope: Exprs.LexicalScope, val: Css.Val, ref: Exprs.Val | null): Exprs.Val;
/**
 * If the value is not specified (null), returns zero.
 * If the value is 'auto', returns null.
 * Otherwise, return the value itself.
 */
export declare function toExprZeroAuto(scope: Exprs.LexicalScope, val: Css.Val, ref: Exprs.Val | null): Exprs.Val | null;
export declare function toExprZeroBorder(scope: Exprs.LexicalScope, val: Css.Val, styleVal: Css.Val, ref: Exprs.Val | null): Exprs.Val;
export declare function toExprBool(scope: Exprs.LexicalScope, val: Css.Val, def: Exprs.Val): Exprs.Val;
export interface InstanceHolder extends Exprs.Context {
    registerInstance(key: string, instance: PageBoxInstance): void;
    /**
     * @return instance
     */
    lookupInstance(key: string): PageBoxInstance;
}
/**
 * A page box whose subtree establishes the page float area of a page. Which box
 * becomes the area's container is fixed by the page box tree: the page master
 * itself for -epubx-page-master, the page area partition for `@page` rules.
 */
export interface PageAreaEstablishing {
    /**
     * The child whose subtree establishes the area, or null when this box is the
     * container itself.
     */
    readonly pageAreaEstablishingChild: (PageBoxInstance & PageAreaEstablishing) | null;
}
export declare class PageBoxInstance<P extends PageBox = PageBox<any>> {
    readonly parentInstance: PageBoxInstance | null;
    readonly pageBox: P;
    /**
     * cascaded styles, geometric ones converted to Css.Expr
     */
    protected cascaded: CssCascade.ElementStyle;
    style: {
        [key: string]: Css.Val;
    };
    private autoWidth;
    private autoHeight;
    children: PageBoxInstance[];
    isAutoWidth: boolean;
    isAutoHeight: boolean;
    isTopDependentOnAutoHeight: boolean;
    isRightDependentOnAutoWidth: boolean;
    private calculatedWidth;
    private calculatedHeight;
    pageMasterInstance: PageMasterInstance | null;
    namedValues: {
        [key: string]: Exprs.Val;
    };
    namedFuncs: {
        [key: string]: Exprs.Val;
    };
    vertical: boolean;
    rtl: boolean;
    suppressEmptyBoxGeneration: boolean;
    borderBoxSizing: boolean;
    constructor(parentInstance: PageBoxInstance | null, pageBox: P);
    /**
     * Reset information related to layout.
     */
    reset(): void;
    private addNamedValues;
    resolveName(name: string): Exprs.Val;
    resolveFunc(name: any): Exprs.Val;
    protected initEnabled(): void;
    protected boxSpecificEnabled(enabled: Exprs.Val): Exprs.Val;
    protected initHorizontal(): void;
    protected initVertical(): void;
    protected initColumns(): void;
    private depends;
    protected resolveStyle(context: Exprs.Context): void;
    protected init(context: Exprs.Context): void;
    protected register(context: Exprs.Context): void;
    getProp(context: Exprs.Context, name: string): Css.Val;
    getPropAsNumber(context: Exprs.Context, name: string): number;
    getSpecial(context: Exprs.Context, name: string): Css.Val[] | null;
    getActiveRegions(context: Exprs.Context): string[] | null;
    propagateProperty(context: Exprs.Context, container: Vtree.Container, name: string, docFaces: Font.DocumentFaces): void;
    propagatePropertyToElement(context: Exprs.Context, element: Element, name: string, docFaces: Font.DocumentFaces): void;
    propagateDelayedProperty(context: Exprs.Context, container: Vtree.Container, name: string, delayedItems: Vtree.DelayedItem[]): void;
    assignLeftPosition(context: Exprs.Context, container: Vtree.Container): void;
    assignRightPosition(context: Exprs.Context, container: Vtree.Container): void;
    assignTopPosition(context: Exprs.Context, container: Vtree.Container): void;
    assignBottomPosition(context: Exprs.Context, container: Vtree.Container): void;
    assignBeforePosition(context: Exprs.Context, container: Vtree.Container): void;
    assignAfterPosition(context: Exprs.Context, container: Vtree.Container): void;
    assignStartEndPosition(context: Exprs.Context, container: Vtree.Container): void;
    sizeWithMaxHeight(context: Exprs.Context, container: Vtree.Container): void;
    sizeWithMaxWidth(context: Exprs.Context, container: Vtree.Container): void;
    prepareContainer(context: Exprs.Context, container: Vtree.Container, page: Vtree.Page, docFaces: Font.DocumentFaces, clientLayout: Vtree.ClientLayout): void;
    transferContentProps(context: Exprs.Context, container: Vtree.Container, page: Vtree.Page, docFaces: Font.DocumentFaces): void;
    transferSingleUriContentProps(context: Exprs.Context, element: Element, docFaces: Font.DocumentFaces): void;
    /**
     * @param column (null when content comes from the content property)
     */
    finishContainer(context: Exprs.Context, container: Vtree.Container, page: Vtree.Page, column: Vtree.Container | null, columnCount: number, clientLayout: Vtree.ClientLayout, docFaces: Font.DocumentFaces): void;
    protected buildCascadedStyle(docElementStyle: CssCascade.ElementStyle): void;
    protected resolveContent(cascade: CssCascade.CascadeInstance): void;
    applyCascadeAndInit(cascade: CssCascade.CascadeInstance, docElementStyle: CssCascade.ElementStyle): void;
    resolveAutoSizing(context: Exprs.Context): void;
}
/**
 * Properties that are passed through before the layout.
 */
export declare const passPreProperties: string[];
/**
 * Properties that are passed through after the layout.
 */
export declare const passPostProperties: string[];
/**
 * Only passed when there is content assigned by the content property.
 *
 * This list is for properties that need to be propagated to the generated DOM
 * element as browser CSS properties. Keep browser-expanded longhands here
 * rather than their shorthand forms (for example, text-box-trim/text-box-edge
 * instead of text-box).
 *
 * text-autospace and text-spacing-trim are intentionally omitted for now:
 * generated content handles them via TextPolyfill.processGeneratedContent()
 * with explicit values from boxInstance.getProp(), not by inheriting browser
 * CSS properties. If generated content switches to browser-native handling for
 * those properties in the future, add them back here.
 */
export declare const passContentProperties: string[];
export declare const passSingleUriContentProperties: string[];
export declare const delayedProperties: string[];
export declare const userAgentPageMasterPseudo = "background-host";
export declare class RootPageBoxInstance extends PageBoxInstance<RootPageBox> {
    constructor(pageBox: RootPageBox);
    applyCascadeAndInit(cascade: CssCascade.CascadeInstance, docElementStyle: CssCascade.ElementStyle): void;
}
export declare class PageMasterInstance<P extends PageMaster = PageMaster<PageMasterInstance<any>>> extends PageBoxInstance<P> implements PageAreaEstablishing {
    constructor(parentInstance: PageBoxInstance, pageBox: P);
    /** `@page` rules put the area on the page area partition instead. */
    get pageAreaEstablishingChild(): (PageBoxInstance & PageAreaEstablishing) | null;
    boxSpecificEnabled(enabled: Exprs.Val): Exprs.Val;
    /**
     * Called after layout of contents of the page has done to adjust the overall
     * page layout. Override in subclasses.
     */
    adjustPageLayout(context: Exprs.Context, page: Vtree.Page, clientLayout: Vtree.ClientLayout): void;
}
export declare class PartitionGroupInstance extends PageBoxInstance<PartitionGroup> {
    constructor(parentInstance: PageBoxInstance, pageBox: PageBox);
}
export declare class PartitionInstance<P extends Partition = Partition<PartitionInstance<any>>> extends PageBoxInstance<P> {
    constructor(parentInstance: PageBoxInstance, pageBox: P);
    processPartitionList(enabled: Exprs.Val, listVal: Css.Val, conflicting: boolean): Exprs.Val;
    boxSpecificEnabled(enabled: Exprs.Val): Exprs.Val;
    prepareContainer(context: Exprs.Context, container: Vtree.Container, page: Vtree.Page, docFaces: Font.DocumentFaces, clientLayout: Vtree.ClientLayout): void;
}
export declare class PageBoxParserHandler extends CssParser.SlaveParserHandler implements CssValidator.PropertyReceiver {
    readonly target: PageBox;
    readonly validatorSet: CssValidator.ValidatorSet;
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, target: PageBox, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation);
    property(name: string, value: Css.Val, important: boolean): void;
    /** @override */
    unknownProperty(name: string, value: Css.Val): void;
    /** @override */
    invalidPropertyValue(name: string, value: Css.Val): void;
    /** @override */
    simpleProperty(name: string, value: Css.Val, important: any): void;
}
export declare class PartitionParserHandler extends PageBoxParserHandler {
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, target: Partition, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation);
}
export declare class PartitionGroupParserHandler extends PageBoxParserHandler {
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, target: PartitionGroup, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation);
    startPartitionRule(name: string | null, pseudoName: string | null, classes: string[]): void;
    startPartitionGroupRule(name: string | null, pseudoName: string | null, classes: string[]): void;
}
export declare class PageMasterParserHandler extends PageBoxParserHandler {
    constructor(scope: Exprs.LexicalScope, owner: CssParser.DispatchParserHandler, target: PageMaster, validatorSet: CssValidator.ValidatorSet, delegation: CssParser.Delegation);
    startPartitionRule(name: string | null, pseudoName: string | null, classes: string[]): void;
    startPartitionGroupRule(name: string | null, pseudoName: string | null, classes: string[]): void;
}
