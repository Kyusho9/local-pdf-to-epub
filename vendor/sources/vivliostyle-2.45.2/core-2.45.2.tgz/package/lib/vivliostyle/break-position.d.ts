import { Layout, RepetitiveElement, Vtree } from "./types";
/**
 * Potential breaking position.
 */
export type BreakPosition = Layout.BreakPosition;
export declare abstract class AbstractBreakPosition implements Layout.AbstractBreakPosition {
    abstract findAcceptableBreak(column: Layout.Column, penalty: number): Vtree.NodeContext | null;
    abstract getMinBreakPenalty(): number;
    calculateOffset(column: any): {
        current: number;
        minimum: number;
    };
    /** @override */
    breakPositionChosen(column: Layout.Column): void;
    getNodeContext(): Vtree.NodeContext | null;
}
export declare function calculateOffset(nodeContext: Vtree.NodeContext | null, elementsOffsets: RepetitiveElement.ElementsOffset[]): {
    current: number;
    minimum: number;
};
/**
 * Potential edge breaking position.
 */
export declare class EdgeBreakPosition extends AbstractBreakPosition implements Layout.EdgeBreakPosition {
    readonly position: Vtree.NodeContext;
    readonly breakOnEdge: string | null;
    overflows: boolean;
    readonly computedBlockSize: number;
    overflowIfRepetitiveElementsDropped: boolean;
    protected isEdgeUpdated: boolean;
    private edge;
    constructor(position: Vtree.NodeContext, breakOnEdge: string | null, overflows: boolean, computedBlockSize: number);
    findAcceptableBreak(column: Layout.Column, penalty: number): Vtree.NodeContext | null;
    getMinBreakPenalty(): number;
    private updateEdge;
    private updateOverflows;
    getNodeContext(): Vtree.NodeContext;
    private isFirstContentOfRepetitiveElementsOwner;
}
