/**
 * Copyright 2026 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Semantic footnote helper utilities.
 *
 * This module owns semantic-footnote-specific rules that are independent from
 * the main view-generation flow: element/reference detection, shared marker
 * attributes, first-reference bookkeeping, and style-merging helpers that can
 * be driven by injected style accessors.
 *
 * Keep view-tree sequencing and DOM construction in vgen.ts. Extend this
 * module when new DPUB/EPUB semantic footnote behavior can be expressed as
 * pure reference/style helpers that do not need direct access to ViewFactory
 * state.
 */
import * as Css from "./css";
import * as Exprs from "./exprs";
import * as Vtree from "./vtree";
import { CssCascade } from "./types";
export declare const SEMANTIC_FOOTNOTE_FIRST_REF_ATTR = "data-vivliostyle-footnote-first-ref";
export declare const SEMANTIC_FOOTNOTE_REFERENCED_ATTR = "data-vivliostyle-footnote-referenced";
type ElementStyleMap = {
    [key: string]: CssCascade.ElementStyle;
};
export type SemanticFootnoteStyleAccess = {
    getStyle: (element: Element) => CssCascade.ElementStyle | null;
    getProp: (style: CssCascade.ElementStyle | null | undefined, propName: string) => CssCascade.CascadeValue | null | undefined;
    getStyleMap: (style: CssCascade.ElementStyle, mapName: string) => ElementStyleMap | null | undefined;
    getMutableStyleMap: (style: CssCascade.ElementStyle, mapName: string) => ElementStyleMap;
    createCascadeValue: (value: Css.Val, priority: number) => CssCascade.CascadeValue;
    filterFootnoteMarkerContent: (content: CssCascade.CascadeValue, element: Element) => Css.Val;
};
export type SemanticFootnoteStyleState = {
    sourceStyle: CssCascade.ElementStyle | null;
    footnoteDisplay: Css.Val | null;
    footnotePolicy: Css.Ident | null;
};
export declare function isSemanticFootnoteElement(element: Element): boolean;
export declare function isSemanticFootnoteNoterefElement(element: Element): boolean;
export declare function resolveSemanticFootnoteReference(element: Element, baseURL: string): string | null;
export declare function resolveSemanticFootnoteTarget(element: Element, baseURL: string, resolveElement: (reference: string) => Element | null): Element | null;
export declare function initializeFirstSemanticFootnoteReferenceOffsets(ownerDocument: Document, baseURL: string, getElementOffset: (element: Element) => number, firstRefOffsets: Map<string, number>, initialized: {
    value: boolean;
}): void;
export declare function shouldGenerateSemanticFootnote(element: Element, baseURL: string, getElementOffset: (element: Element) => number, firstRefOffsets: Map<string, number>, initialized: {
    value: boolean;
}): boolean;
export declare function mergeSemanticFootnoteIncludeStyle(element: Element, elementStyle: CssCascade.ElementStyle, shadowContext: Vtree.ShadowContext | null, baseURL: string, resolveElement: (reference: string) => Element | null, footnoteCounterAttr: string, styleAccess: SemanticFootnoteStyleAccess): CssCascade.ElementStyle;
export declare function mergeSemanticFootnoteRootStyle(element: Element, elementStyle: CssCascade.ElementStyle, shadowContext: Vtree.ShadowContext | null, context: Exprs.Context, styleAccess: SemanticFootnoteStyleAccess): CssCascade.ElementStyle;
export declare function getSemanticFootnoteStyleState(element: Element, shadowContext: Vtree.ShadowContext | null, styleAccess: SemanticFootnoteStyleAccess): SemanticFootnoteStyleState;
export declare function resolveMarkerContentValue(val: Css.Val, context: Exprs.Context): Css.Val;
export declare function refreshSemanticFootnoteMarkerContent(sourceStyle: CssCascade.ElementStyle | null, computedStyle: {
    [key: string]: Css.Val;
}, context: Exprs.Context): void;
export {};
