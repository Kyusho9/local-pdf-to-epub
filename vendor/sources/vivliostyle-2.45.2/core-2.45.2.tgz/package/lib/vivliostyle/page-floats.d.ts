import * as Css from "./css";
import * as Constants from "./constants";
import * as GeometryUtil from "./geometry-util";
import * as Task from "./task";
import { Layout as LayoutType, PageFloats, Vtree } from "./types";
export declare const FloatReference: typeof PageFloats.FloatReference;
export type FloatReference = PageFloats.FloatReference;
type PageFloatID = PageFloats.PageFloatID;
export declare function floatReferenceOf(str: string): FloatReference;
export declare function isPageFloat(floatReference: FloatReference): boolean;
/**
 * Interpret a float value with the writing-mode and direction assuming the
 * float-reference is inline and returns "left" or "right".
 */
export declare function resolveInlineFloatDirection(floatSide: string, vertical: boolean, direction: string, pageSide: Constants.PageSide | null): string;
export declare class PageFloat implements PageFloats.PageFloat {
    readonly nodePosition: Vtree.NodePosition;
    readonly floatReference: FloatReference;
    readonly floatSide: string;
    readonly clearSide: string | null;
    readonly flowName: string;
    readonly floatMinWrapBlock: Css.Numeric | null;
    order: number | null;
    id: PageFloatID | null;
    /**
     * Set to true when this float is created inside a page float area.
     * Used to bypass the normal anchor check in isAllowedOnContext because
     * the anchor node is lost after page-level invalidation. (Issue #1675)
     */
    insidePageFloatArea: boolean;
    /**
     * Reference to the parent page float that contains this float.
     * Set when this float is created inside a page float area, allowing
     * isAllowedOnContext to check whether the parent is still present.
     * (Issue #1675)
     */
    parentPageFloat: PageFloat | null;
    constructor(nodePosition: Vtree.NodePosition, floatReference: FloatReference, floatSide: string, clearSide: string | null, flowName: string, floatMinWrapBlock: Css.Numeric | null);
    getOrder(): number;
    getId(): PageFloatID;
    isAllowedOnContext(pageFloatLayoutContext: AttachedPageFloatLayoutContext): boolean;
    isAllowedToPrecede(other: PageFloat): boolean;
}
export declare class PageFloatStore {
    private floats;
    private nextPageFloatIndex;
    private nextOrder;
    private createPageFloatId;
    addPageFloat(float: PageFloat): void;
    findPageFloatByNodePosition(nodePosition: Vtree.NodePosition): PageFloat | null;
}
/**
 * @param continues Represents whether the float is fragmented and continues
 *     after this fragment
 */
export declare class PageFloatFragment implements PageFloats.PageFloatFragment {
    readonly floatReference: FloatReference;
    readonly floatSide: string;
    readonly clearSide: string | null;
    readonly continuations: PageFloatContinuation[];
    readonly area: Vtree.Container;
    readonly continues: boolean;
    constructor(floatReference: FloatReference, floatSide: string, clearSide: string | null, continuations: PageFloatContinuation[], area: Vtree.Container, continues: boolean);
    hasFloat(float: PageFloat): boolean;
    findNotAllowedFloat(context: AttachedPageFloatLayoutContext): PageFloat | null;
    getOuterShape(): GeometryUtil.Shape;
    getOuterRect(): GeometryUtil.Rect;
    getOrder(): number;
    shouldBeStashedBefore(float: PageFloat): boolean;
    addContinuations(continuations: PageFloatContinuation[]): void;
    getFlowName(): string;
}
export declare class PageFloatContinuation implements PageFloats.PageFloatContinuation {
    readonly float: PageFloat;
    readonly nodePosition: Vtree.NodePosition;
    constructor(float: PageFloat, nodePosition: Vtree.NodePosition);
    equals(other: PageFloatContinuation | null): boolean;
}
export type PageFloatPlacementCondition = PageFloats.PageFloatPlacementCondition;
/**
 * What a context accumulates while a page is laid out. Halving a footnote until
 * it fits (Issue #1879) and invalidating a line-policy footnote at most once
 * (Issue #2024, #2026) terminate only because this record outlives the
 * containers a retry rebuilds.
 */
type PageFloatContextState = {
    invalidated: boolean;
    locked: boolean;
    readonly children: AttachedPageFloatLayoutContext[];
    readonly floatAnchors: {
        [key in PageFloatID]: Node;
    };
    readonly forbiddenFloats: PageFloatID[];
    readonly floatFragments: PageFloatFragment[];
    readonly stashedFloatFragments: PageFloatFragment[];
    readonly floatsDeferredToNext: PageFloatContinuation[];
    readonly floatsDeferredFromPrevious: PageFloatContinuation[];
    readonly layoutConstraints: LayoutType.LayoutConstraint[];
    /**
     * Maximum outer block size for footnotes on this page.
     * Set when a footnote is placed but then found to be not-allowed (anchor
     * not reachable in multi-column). Each retry halves this value until
     * the footnote fits or is too small to display. (Issue #1879)
     */
    footnoteMaxBlockSize: number | null;
    /**
     * When true, max-height on @footnote areas should be ignored.
     * Set when a page contains only footnote continuation(s) and no body
     * content. Per CSS GCPM §2.4.2, max-height should not apply in this
     * case. (Issue #1878)
     */
    ignoreFootnoteAreaMaxHeight: boolean;
    /**
     * Tracks footnote IDs whose anchors have been registered at least once
     * during this page's layout cycle. Unlike floatAnchors, this set
     * survives invalidate() calls, so we can detect feedback loops where
     * a footnote's own size pushes its anchor off the page. (Issue #1879)
     */
    readonly footnoteAnchorsSeen: Set<PageFloatID>;
    /**
     * Tracks the footnoteMaxBlockSize value used when a `footnote-policy: line`
     * footnote triggered invalidation (body reflow) on the current page. Like
     * footnoteAnchorsSeen, this map survives invalidate() calls. Placing such a
     * footnote shrinks the body area and invalidates the page to reflow the
     * body; without this guard the same footnote is re-placed and re-invalidated
     * on every page-layout retry, which never converges and hangs the renderer.
     * Allowing exactly one invalidation per line-policy footnote per retry size
     * bounds the retries while still reflowing body after footnoteMaxBlockSize
     * changes.
     * (Issue #2024, #2026)
     */
    readonly lineFootnoteInvalidationMaxBlockSize: Map<PageFloatID, number | null>;
    /**
     * Tracks `footnote-policy: line` footnote IDs for which finish() has already
     * forbidden the float and invalidated the page once. Without this guard,
     * finish() forbids and invalidates on every page-layout retry (the float is
     * re-deferred each pass), which never converges and hangs the renderer.
     * Like footnoteAnchorsSeen, this set survives invalidate(). (Issue #2024)
     */
    readonly lineFootnoteFinishInvalidatedOnce: Set<PageFloatID>;
};
/** Unchanged by attachment, which is why identity-keyed walks ignore it. */
type PageFloatContextIdentity = {
    readonly parent: ParentPageFloatLayoutContext | null;
    readonly floatReference: FloatReference | null;
    readonly flowName: string | null;
    readonly generatingNodePosition: Vtree.NodePosition | null;
    readonly writingMode: Css.Val;
    readonly direction: Css.Val;
    readonly pageSide: Constants.PageSide | null;
    readonly outerContext: AttachedPageFloatLayoutContext | null;
    readonly floatStore: PageFloatStore;
};
/**
 * @param generatingNodePosition Source NodePosition generating the context.
 *     Specify when a column context is generated by a non-root element (for
 *     example page floats)
 */
export declare abstract class PageFloatLayoutContext implements PageFloats.PageFloatLayoutContext {
    readonly parent: ParentPageFloatLayoutContext | null;
    protected readonly floatReference: FloatReference | null;
    readonly flowName: string | null;
    readonly generatingNodePosition: Vtree.NodePosition | null;
    readonly writingMode: Css.Val;
    readonly direction: Css.Val;
    /** Null on the root context and on a TOC box, which has no page side. */
    readonly pageSide: Constants.PageSide | null;
    /**
     * Reference to the outer column's context for page float area contexts.
     * Used only for getParent() navigation to propagate nested page floats
     * and footnotes to region/page level. Unlike `parent`, this does NOT
     * affect children registration, isInvalidated() propagation, or
     * getFloatFragmentExclusions(). (Issue #1675)
     */
    protected readonly outerContext: AttachedPageFloatLayoutContext | null;
    protected readonly floatStore: PageFloatStore;
    protected readonly state: PageFloatContextState;
    protected constructor(identity: PageFloatContextIdentity, state?: PageFloatContextState);
    protected static buildIdentity(parent: ParentPageFloatLayoutContext | null, floatReference: FloatReference | null, flowName: string | null, generatingNodePosition: Vtree.NodePosition | null, writingMode: Css.Val | null, direction: Css.Val | null, outerContext: AttachedPageFloatLayoutContext | null, pageSide: Constants.PageSide | null): PageFloatContextIdentity;
    private newState;
    /**
     * A page float area takes no part in invalidation or exclusions, and reaches
     * its surroundings through its column instead. (Issue #1675)
     */
    static createDetached(outerContext: AttachedPageFloatLayoutContext, floatReference: FloatReference | null, flowName: string | null, generatingNodePosition: Vtree.NodePosition | null): UnattachedPageFloatLayoutContext;
    static create(parent: ParentPageFloatLayoutContext, floatReference: FloatReference | null, flowName: string | null, generatingNodePosition: Vtree.NodePosition | null, writingMode: Css.Val | null, direction: Css.Val | null, outerContext?: AttachedPageFloatLayoutContext | null, pageSide?: Constants.PageSide | null): UnattachedPageFloatLayoutContext;
    static createWithContainer(container: Vtree.Container, parent: ParentPageFloatLayoutContext, floatReference: FloatReference | null, flowName: string | null, generatingNodePosition: Vtree.NodePosition | null, writingMode: Css.Val | null, direction: Css.Val | null, outerContext?: AttachedPageFloatLayoutContext | null, pageSide?: Constants.PageSide | null): AttachedPageFloatLayoutContext;
    protected static register(parent: ParentPageFloatLayoutContext | null, next: AttachedPageFloatLayoutContext): void;
    protected identity(): PageFloatContextIdentity;
    get floatFragments(): PageFloatFragment[];
    get footnoteMaxBlockSize(): number | null;
    set footnoteMaxBlockSize(value: number | null);
    get ignoreFootnoteAreaMaxHeight(): boolean;
    set ignoreFootnoteAreaMaxHeight(value: boolean);
    /**
     * Returns the effective parent context for hierarchy traversal.
     * For normal contexts, returns `parent`. For page float area contexts
     * (where `parent` is null), falls back to `outerContext`. (Issue #1675)
     */
    get effectiveParent(): PageFloatLayoutContext | null;
    protected getParent(floatReference: FloatReference): PageFloatLayoutContext;
    protected getPreviousSibling(): AttachedPageFloatLayoutContext | null;
    addPageFloat(float: PageFloat): void;
    getPageFloatLayoutContext(floatReference: FloatReference): PageFloatLayoutContext;
    findPageFloatByNodePosition(nodePosition: Vtree.NodePosition): PageFloat | null;
    isForbidden(float: PageFloat): boolean;
    findPageFloatFragment(float: PageFloat): PageFloatFragment | null;
    hasFloatFragments(condition?: (p1: PageFloatFragment) => boolean): boolean;
    hasContinuingFloatFragmentsInFlow(flowName: string): boolean;
    markPageFloatAnchorSeen(float: PageFloat): void;
    registerPageFloatAnchor(float: PageFloat, anchorViewNode: Node): void;
    /**
     * Whether this `footnote-policy: line` footnote has already triggered
     * invalidation (body reflow) at the current retry size. (Issue #2024, #2026)
     */
    hasInvalidatedForLineFootnote(float: PageFloat): boolean;
    /**
     * Mark that this `footnote-policy: line` footnote has triggered invalidation
     * at the current retry size, so subsequent placements suppress redundant
     * invalidation. (Issue #2024, #2026)
     */
    markInvalidatedForLineFootnote(float: PageFloat): void;
    deferPageFloat(continuation: PageFloatContinuation): void;
    removeFloatDeferredToNext(float: PageFloat): void;
    hasPrecedingFloatsDeferredToNext(float: PageFloat, ignoreReference?: boolean): boolean;
    getLastFollowingFloatInFragments(float: PageFloat): PageFloat | null;
    getDeferredPageFloatContinuations(flowName?: string | null): PageFloatContinuation[];
    getPageFloatContinuationsDeferredToNext(flowName?: string | null): PageFloatContinuation[];
    protected trySetFootnoteRetryMaxBlockSize(currentOuter: number): boolean;
    isInvalidated(): any;
    validate(): void;
    protected toLogical(side: string): string;
    protected toPhysical(side: string): string;
    protected toLogicalFloatSides(floatSide: string): string[];
    discardStashedFragments(floatReference: FloatReference): void;
    getStashedFloatFragments(floatReference: FloatReference): PageFloatFragment[];
    getFloatFragmentExclusions(): GeometryUtil.Shape[];
    getLayoutConstraints(): LayoutType.LayoutConstraint[];
    addLayoutConstraint(layoutConstraint: LayoutType.LayoutConstraint, floatReference: FloatReference): void;
    lock(): void;
    unlock(): void;
    isLocked(): boolean;
}
/** The only class that can be attached, which is what limits it to once. */
export declare class UnattachedPageFloatLayoutContext extends PageFloatLayoutContext {
    /**
     * A new context rather than a mutated one, which is what keeps a discarded
     * attempt's container out of the next one.
     */
    withContainer(container: Vtree.Container): AttachedPageFloatLayoutContext;
}
/** A context enters the tree when it is attached; an unattached one is never a parent. */
export declare abstract class ParentPageFloatLayoutContext extends PageFloatLayoutContext implements PageFloats.ParentPageFloatLayoutContext {
    get children(): readonly AttachedPageFloatLayoutContext[];
    abstract asAttached(): AttachedPageFloatLayoutContext | null;
    attachChildren(children: AttachedPageFloatLayoutContext[]): void;
    detachChildren(): AttachedPageFloatLayoutContext[];
    collectPageFloatAnchors(): any;
    getFloatsDeferredToNextInChildContexts(): PageFloat[];
    protected findPageFloatAnchor(floatId: PageFloatID): Node | null;
    protected hasRootMultiColumnFootnoteContext(): boolean;
    getPreviousSiblingOf(child: PageFloatLayoutContext | null, floatReference: FloatReference | null, flowName: string | null, generatingNodePosition: Vtree.NodePosition | null): AttachedPageFloatLayoutContext | null;
}
export declare class RootPageFloatLayoutContext extends ParentPageFloatLayoutContext {
    asAttached(): null;
    /**
     * Expose a previous rendered page's context to a temporary isolated root.
     * The context is stored as a pseudo-child so normal previous-sibling lookup
     * can seed deferred floats without making it this context's real parent.
     * (Issue #2026)
     */
    addPageFloatLayoutContextAsPreviousSibling(context: PageFloats.AttachedPageFloatLayoutContext): void;
    static createRoot(): RootPageFloatLayoutContext;
}
export declare class AttachedPageFloatLayoutContext extends ParentPageFloatLayoutContext implements PageFloats.AttachedPageFloatLayoutContext {
    readonly container: Vtree.Container;
    asAttached(): AttachedPageFloatLayoutContext;
    /**
     * Null at the page level, whose parent is the container-less root, and in a
     * page float area, which has no parent at all.
     */
    protected readonly attachedParent: AttachedPageFloatLayoutContext | null;
    /** How a page float area's context reaches its column. (Issue #1675) */
    private readonly attachedOuter;
    constructor(identity: PageFloatContextIdentity, container: Vtree.Container, state?: PageFloatContextState);
    protected getParent(floatReference: FloatReference): AttachedPageFloatLayoutContext;
    getPageFloatLayoutContext(floatReference: FloatReference): AttachedPageFloatLayoutContext;
    private forbid;
    addPageFloatFragment(floatFragment: PageFloatFragment, dontInvalidate?: boolean): void;
    removePageFloatFragment(floatFragment: PageFloatFragment, dontInvalidate?: boolean): void;
    hasCurrentAnchor(floatId: PageFloatID): boolean;
    isAnchorAlreadyAppeared(floatId: PageFloatID): boolean;
    private hasNonRootMultiColumnFootnoteContext;
    private hasMultiColumnFootnoteContext;
    initFootnoteRetryFromEmptyFragment(float: PageFloat, area: LayoutType.PageFloatArea): boolean;
    checkAndForbidNotAllowedFloat(): boolean;
    checkAndForbidFloatFollowingDeferredFloat(): boolean;
    finish(): void;
    restoreStashedFragments(floatReference: FloatReference): void;
    hasSameContainerAs(other: AttachedPageFloatLayoutContext): boolean;
    invalidate(): void;
    removeEndFloatFragments(floatSide: string): void;
    private isFragmentInCurrentContainer;
    stashEndFloatFragments(float: PageFloat): void;
    private getLimitValue;
    private getLimitValueInner;
    private getLimitValuesInner;
    /**
     * @param anchorEdge Null indicates that the anchor is not in the current
     *     container.
     * @return Logical float side (snap-block is resolved when init=false). Null
     *     indicates that the float area does not fit inside the container
     */
    setFloatAreaDimensions(area: LayoutType.PageFloatArea, floatReference: FloatReference, floatSide: string, anchorEdge: number | null, init: boolean, force: boolean, condition: PageFloatPlacementCondition): string | null;
    reattachFloatFragments(): void;
    getMaxReachedAfterEdge(): number;
    getBlockEndEdgeOfBlockStartFloats(inlinePos?: number): number;
    getBlockStartEdgeOfBlockEndFloats(inlinePos?: number): number;
    getPageFloatClearEdge(clear: string, column: LayoutType.Column): number;
    getPageFloatPlacementCondition(float: PageFloat, floatSide: string, clearSide: string | null): PageFloatPlacementCondition;
    isColumnFullWithPageFloats(column: LayoutType.Column): boolean;
    getMaxBlockSizeOfPageFloats(): number;
}
export interface PageFloatLayoutStrategy extends PageFloats.PageFloatLayoutStrategy {
}
export declare class PageFloatLayoutStrategyResolver {
    static register(strategy: PageFloatLayoutStrategy): void;
    findByNodeContext(nodeContext: Vtree.NodeContext): PageFloatLayoutStrategy;
    findByFloat(float: PageFloat): PageFloatLayoutStrategy;
}
export declare class NormalPageFloatLayoutStrategy implements PageFloatLayoutStrategy {
    /** @override */
    appliesToNodeContext(nodeContext: Vtree.NodeContext): boolean;
    /** @override */
    appliesToFloat(float: PageFloat): boolean;
    /** @override */
    createPageFloat(nodeContext: Vtree.FloatNodeContext, pageFloatLayoutContext: AttachedPageFloatLayoutContext, column: LayoutType.Column): Task.Result<PageFloat>;
    /** @override */
    createPageFloatFragment(continuations: PageFloatContinuation[], floatSide: string, clearSide: string | null, floatArea: LayoutType.PageFloatArea, continues: boolean): PageFloatFragment;
    /** @override */
    findPageFloatFragment(float: PageFloat, pageFloatLayoutContext: AttachedPageFloatLayoutContext): PageFloatFragment | null;
    /** @override */
    adjustPageFloatArea(floatArea: LayoutType.PageFloatArea, floatContainer: Vtree.Container, column: LayoutType.Column): Task.Result<void>;
    /** @override */
    forbid(float: PageFloat, pageFloatLayoutContext: AttachedPageFloatLayoutContext): void;
}
export {};
