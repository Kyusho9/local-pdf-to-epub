import * as Base from "./base";
import * as CssCascade from "./css-cascade";
import * as Exprs from "./exprs";
import * as Vgen from "./vgen";
import * as Vtree from "./vtree";
import { Layout } from "./types";
/**
 * Class representing a reference by target-counter(s).
 * @param targetId ID of the referenced element (transformed by
 *     DocumentURLTransformer to handle a reference across multiple source
 *     documents)
 * @param resolved If the reference is already resolved or not
 */
export declare class TargetCounterReference {
    readonly targetId: string;
    resolved: boolean;
    pageCounters: CssCascade.CounterValues | null;
    spineIndex: number;
    pageIndex: number;
    constructor(targetId: string, resolved: boolean);
    equals(other: TargetCounterReference): boolean;
    /**
     * Returns if the reference is resolved or not.
     */
    isResolved(): boolean;
    /**
     * Marks that this reference is resolved.
     */
    resolve(): void;
    /**
     * Marks that this reference is unresolved.
     */
    unresolve(): void;
}
export declare class CounterStore {
    readonly documentURLTransformer: Base.DocumentURLTransformer;
    countersById: {
        [key: string]: CssCascade.CounterValues;
    };
    pageCountersById: {
        [key: string]: CssCascade.CounterValues;
    };
    pageDocCountersById: {
        [key: string]: CssCascade.CounterValues;
    };
    pageTextById: {
        [key: string]: {
            [pseudoElement: string]: string;
        };
    };
    currentPageDocCounters: CssCascade.CounterValues | null;
    previousPageDocCounters: CssCascade.CounterValues | null;
    currentPageDocCounterChanges: {
        [key: string]: boolean;
    };
    currentPageDocCounterChangeTypes: {
        [key: string]: "reset" | "set" | "increment";
    };
    currentPageCounters: CssCascade.CounterValues;
    previousPageCounters: CssCascade.CounterValues;
    pageCountersBeforeOverride: CssCascade.CounterValues;
    hasDeferredNamedStrings: boolean;
    namedStringPageSnapshots: {
        [startOffset: number]: {
            lastOffset: number;
            spineIndex: number;
            counters: CssCascade.CounterValues;
        };
    };
    namedStringPageCounterExprMap: {
        [exprKey: string]: {
            expr: Exprs.Val;
            offset: number;
            counterName: string;
            format: (p1: number[]) => string;
        };
    };
    currentPageCountersStack: CssCascade.CounterValues[];
    pageIndicesById: {
        [key: string]: {
            spineIndex: number;
            pageIndex: number;
        };
    };
    currentPage: Vtree.Page | null;
    newReferencesOfCurrentPage: TargetCounterReference[];
    referencesToSolve: TargetCounterReference[];
    referencesToSolveStack: TargetCounterReference[][];
    unresolvedReferences: {
        [key: string]: TargetCounterReference[];
    };
    resolvedReferences: {
        [key: string]: TargetCounterReference[];
    };
    private referenceTargetIdsBySourcePage;
    private targetsMovedEarlierAfterPageBreak;
    pageControlledCounterNames: {
        [key: string]: boolean;
    };
    private pagesCounterExprs;
    private pageCounterExprs;
    private targetCounterExprs;
    private targetTextExprs;
    constructor(documentURLTransformer: Base.DocumentURLTransformer);
    createCounterListener(baseURL: string): CssCascade.CounterListener;
    createCounterResolver(baseURL: string, rootScope: Exprs.LexicalScope, pageScope: Exprs.LexicalScope): CssCascade.CounterResolver;
    setCurrentPage(page: Vtree.Page): void;
    setCurrentPageDocCounters(counters: CssCascade.CounterValues | null, changes: string[] | null, changeTypes?: {
        [key: string]: "reset" | "set" | "increment";
    }): void;
    setPageControlledCounterNames(names: string[]): void;
    isPageControlledCounter(name: string): boolean;
    private definePageCounter;
    /**
     * Forcefully set the `page` page-based counter to the specified value.
     */
    forceSetPageCounter(pageNumber: number): void;
    /**
     * Update the page-based counters with 'counter-reset' and 'counter-increment'
     * properties within the page context. Call before starting layout of the
     * page.
     */
    updatePageCounters(cascadedPageStyle: CssCascade.ElementStyle, context: Exprs.Context): void;
    /**
     * Save current page-based counters values and set them to the values passed
     * in. The saved counter values can be restored by popPageCounters method.
     */
    pushPageCounters(counters: CssCascade.CounterValues): void;
    /**
     * Restore previously saved page-based counter values.
     */
    popPageCounters(): void;
    /**
     * Resolve a reference with the specified ID.
     */
    resolveReference(id: string): void;
    /**
     * Save a reference appeared in the current page.
     * @param resolved If the reference is already resolved or not.
     */
    saveReferenceOfCurrentPage(id: string, resolved: boolean): void;
    /**
     * Finish the current page; elements with ID are collected and saved with
     * current page-based counter values internally.
     * @param spineIndex Index of the currently laid out spine item
     * @param pageIndex Index of the currently laid out page in its spine item
     */
    finishPage(spineIndex: number, pageIndex: number): void;
    discardReferencesFromPage(spineIndex: number, pageIndex: number): void;
    /**
     * Keep only the resolved/unresolved references of the target that satisfy
     * the given predicate, removing the arrays entirely when they become empty.
     */
    private retainReferences;
    isReferenceTracked(ref: TargetCounterReference): boolean;
    /**
     * Record a snapshot of the current page counters keyed by the page's element
     * offset range, so page-based counters in named strings (string-set) can be
     * resolved against the page that contains the assignment element (Issue
     * #1997). Re-finishing a page (relayout) overwrites the previous snapshot.
     * The spine index is stored so the snapshot can be shifted together with
     * pageCountersById when a preceding spine's page count changes (see
     * adjustPageCountersOfLaterSpines).
     */
    private recordNamedStringPageSnapshot;
    /**
     * Return the page counters captured for the finished page whose element
     * offset range contains the given offset, or null when no such page has been
     * finished yet (Issue #1997).
     */
    getPageCountersForOffset(offset: number): CssCascade.CounterValues | null;
    /**
     * Adjust page counter snapshots for elements in spines after the specified
     * spine. Called when a preceding spine's page count changes (e.g. TOC
     * expands after target-text resolution), shifting all subsequent pages.
     */
    adjustPageCountersOfLaterSpines(expandedSpineIndex: number, pageDelta: number): void;
    /**
     * Drop references whose source page belongs to spine items that are about to
     * be rebuilt, and invalidate target snapshots owned by that suffix. Retain
     * pageIndicesById so unresolved forward references can still locate and
     * render their targets while the suffix is reconstructed.
     */
    discardReferencesFromSpine(firstSpineIndex: number): void;
    /**
     * Walk through target-counter DOM nodes in the given page containers and
     * update their text content from the current pageCountersById snapshots.
     */
    updateTargetCounterNodesInPages(pages: Vtree.Page[], changedTargetIds?: Set<string>): Set<Vtree.Page>;
    /**
     * Update target-text() nodes retained outside a rebuilt spine suffix.
     */
    updateTargetTextNodesInPages(pages: Vtree.Page[], changedTargetIds?: Set<string>): Set<Vtree.Page>;
    /**
     * Shared walker for patching generated-content nodes (target-counter/
     * target-text) in retained pages from the current target snapshots.
     */
    private updateGeneratedContentNodesInPages;
    /**
     * Resolve page-level counter values for a page.
     *
     * Prefer an explicit per-page snapshot when one is supplied. Otherwise fall
     * back to looking up tracked element IDs on the page via pageCountersById.
     *
     * Note: explicitCounters are pageCounterStarts (pre-increment snapshots),
     * while pageCountersById stores post-increment values. When using
     * explicitCounters as a fallback, the caller should be aware of this
     * distinction. For the "page" counter the difference is +1, but this
     * method returns whichever snapshot it finds without adjustment.
     */
    private getPageCountersForPage;
    /**
     * Walk through page-counter DOM nodes in the given page containers and
     * update their text content from the adjusted pageCountersById snapshots.
     * Called after adjustPageCountersOfLaterSpines has shifted the counters.
     *
     * When available, pass explicit per-page counter snapshots aligned with the
     * given pages so pages without tracked element IDs are also updated.
     */
    updatePageCounterNodesInPages(pages: Vtree.Page[], pageCountersByPage?: Array<CssCascade.CounterValues | null>): void;
    /**
     * Returns unresolved references pointing to the specified page.
     */
    getUnresolvedRefsToPage(page: Vtree.Page): {
        spineIndex: number;
        pageIndex: number;
        pageCounters: CssCascade.CounterValues | null;
        refs: TargetCounterReference[];
    }[];
    /**
     * Save current references to solve and set them to the values passed in.
     * The saved references can be restored by popReferencesToSolve method.
     */
    pushReferencesToSolve(refs: TargetCounterReference[]): void;
    /**
     * Restore previously saved references to solve.
     */
    popReferencesToSolve(): void;
    registerPageCounterExpr(name: string, format: (p1: number[]) => string, expr: Exprs.Val): void;
    /**
     * Return the format function registered for a page-counter expression, or
     * null if it is not a registered page counter (Issue #1997).
     */
    getPageCounterFormat(expr: Exprs.Val): ((p1: number[]) => string) | null;
    /**
     * Get (or lazily create) a patchable expression for a counter(page) used
     * inside a named string assigned at the given element offset. The expression
     * reads its value from the assignment-page snapshot so it stays correct after
     * cross-spine repagination shifts page numbers (Issue #1997). The same
     * (offset, counterName) pair always reuses the same expression to avoid
     * unbounded growth across margin-box re-renders.
     */
    getOrCreateNamedStringPageCounterExpr(pageScope: Exprs.LexicalScope, offset: number, counterName: string, format: (p1: number[]) => string): Exprs.Val;
    registerTargetCounterExpr(name: string, format: (p1: number) => string, expr: Exprs.Val, transformedId: string): void;
    registerTargetTextExpr(pseudoElement: string, expr: Exprs.Val, transformedId: string): void;
    getExprContentListener(): Vtree.ExprContentListener;
    private exprContentListener;
    private fixPageCounterInRunningElement;
    finishLastPage(viewport: Vgen.Viewport): void;
    createLayoutConstraint(pageIndex: number): Layout.LayoutConstraint;
    moveTargetEarlierAfterPageBreak(id: string, pageIndex: number): boolean;
    unresolveReferencesForTargets(targetIds: Iterable<string>): void;
    private unresolveReferences;
}
export declare const PAGES_COUNTER_ATTR = "data-vivliostyle-pages-counter";
export declare const PAGE_COUNTER_ATTR = "data-vivliostyle-page-counter";
export declare const NAMED_STRING_PAGE_COUNTER_ATTR = "data-vivliostyle-named-string-page-counter";
export declare const TARGET_COUNTER_ATTR = "data-vivliostyle-target-counter";
export declare const TARGET_TEXT_ATTR = "data-vivliostyle-target-text";
export declare const TARGET_COUNTER_IN_RUNNING_ATTR = "data-vivliostyle-target-counter-in-running";
export declare const TARGET_TEXT_IN_RUNNING_ATTR = "data-vivliostyle-target-text-in-running";
