export interface PrintConfig {
    title: string;
    printCallback: (iframeWin: Window) => void;
    errorCallback: ((message: string) => void) | null;
    hideIframe: boolean;
    removeIframe: boolean;
}
export declare function printHTML(htmlDoc: string, config: PrintConfig): void;
