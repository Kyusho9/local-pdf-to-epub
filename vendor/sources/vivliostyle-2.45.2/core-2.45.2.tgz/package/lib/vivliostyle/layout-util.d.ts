import * as Task from "./task";
import { Vtree } from "./types";
export type LayoutIteratorState = {
    nodeContext: Vtree.NodeContext | null;
    atUnforcedBreak: boolean;
    break: boolean;
    leadingEdge?: boolean;
    breakAtTheEdge?: string | null;
    onStartEdges?: boolean;
    leadingEdgeContexts?: Vtree.RenderedNodeContext[];
    lastAfterNodeContext?: Vtree.NodeContext | null;
};
export interface ActiveLayoutIteratorState extends LayoutIteratorState {
    get nodeContext(): Vtree.NodeContext;
    set nodeContext(nodeContext: Vtree.NodeContext | null);
}
export declare function asActiveState(state: LayoutIteratorState): ActiveLayoutIteratorState | null;
export interface RenderedActiveLayoutIteratorState extends ActiveLayoutIteratorState {
    get nodeContext(): Vtree.RenderedNodeContext;
    set nodeContext(nodeContext: Vtree.NodeContext | null);
}
export declare function asRenderedActiveState(state: ActiveLayoutIteratorState): RenderedActiveLayoutIteratorState | null;
export declare class LayoutIteratorStrategy {
    initialState(initialNodeContext: Vtree.NodeContext): LayoutIteratorState;
    startNonDisplayableNode(state: ActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonDisplayableNode(state: ActiveLayoutIteratorState): void | Task.Result<boolean>;
    startIgnoredTextNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterIgnoredTextNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startNonElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startNonInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    finish(state: LayoutIteratorState): void | Task.Result<boolean>;
}
export declare class LayoutIterator {
    private readonly strategy;
    private readonly layoutContext;
    constructor(strategy: LayoutIteratorStrategy, layoutContext: Vtree.LayoutContext);
    iterate(initialNodeContext: Vtree.NodeContext): Task.Result<Vtree.NodeContext | null>;
    private step;
}
export declare class EdgeSkipper extends LayoutIteratorStrategy {
    protected readonly leadingEdge?: boolean;
    constructor(leadingEdge?: boolean);
    startNonInlineBox(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    endEmptyNonInlineBox(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    endNonInlineBox(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    initialState(initialNodeContext: Vtree.NodeContext): LayoutIteratorState;
    startNonElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    startNonInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
    afterNonInlineElementNode(state: RenderedActiveLayoutIteratorState): void | Task.Result<boolean>;
}
