/**
 * Copyright 2026 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Client rects of DOM ranges, measured through one Range per
 * document.
 *
 * A live Range stays registered with its document until it is
 * garbage-collected, and mutating the document costs time in proportion to the
 * number of registered Ranges. Range.detach() does nothing, so a Range created
 * for a single measurement keeps adding that cost until an unpredictable
 * garbage collection.
 */
import { Vtree } from "./types";
export type RangeBoundary = {
    readonly position: "at";
    readonly node: Node;
    readonly offset: number;
} | {
    readonly position: "before" | "after";
    readonly node: Node;
};
export declare function at(node: Node, offset: number): RangeBoundary;
export declare function before(node: Node): RangeBoundary;
export declare function after(node: Node): RangeBoundary;
export declare function getClientRectsBetween(start: RangeBoundary, end: RangeBoundary): DOMRectList;
export declare function getClientRectsOfNode(node: Node): DOMRectList;
export declare function getLayoutClientRectsBetween(clientLayout: Vtree.ClientLayout, start: RangeBoundary, end: RangeBoundary): Vtree.ClientRect[];
export declare function getLayoutClientRectsOfNodeContents(clientLayout: Vtree.ClientLayout, node: Node): Vtree.ClientRect[];
