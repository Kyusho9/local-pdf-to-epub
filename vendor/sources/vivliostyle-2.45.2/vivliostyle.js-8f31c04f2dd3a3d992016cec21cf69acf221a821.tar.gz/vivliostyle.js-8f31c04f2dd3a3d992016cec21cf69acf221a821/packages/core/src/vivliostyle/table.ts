/**
 * Copyright 2016 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Table - Table formatting context and layout.
 */
import * as Asserts from "./asserts";
import * as Base from "./base";
import * as Break from "./break";
import * as BreakPosition from "./break-position";
import * as Css from "./css";
import * as LayoutHelper from "./layout-helper";
import * as LayoutProcessor from "./layout-processor";
import * as LayoutRetryers from "./layout-retryers";
import * as LayoutUtil from "./layout-util";
import * as PageFloats from "./page-floats";
import * as Plugin from "./plugin";
import * as RepetitiveElementImpl from "./repetitive-element";
import * as Task from "./task";
import * as Vgen from "./vgen";
import * as VtreeImpl from "./vtree";
import * as Layout from "./layout";
import {
  FormattingContextType,
  FragmentLayoutConstraintType,
  Layout as LayoutType,
  RepetitiveElement,
  Table,
  Vtree,
} from "./types";

export class TableRow {
  cells: TableCell[] = [];
  breakBefore: string | null = null;
  breakAfter: string | null = null;

  constructor(
    public readonly rowIndex: number,
    public readonly sourceNode: Node | null,
  ) {}

  addCell(cell: TableCell) {
    this.cells.push(cell);
  }
}

export class TableCell {
  colSpan: number;
  rowSpan: number;

  constructor(
    public readonly rowIndex: number,
    public readonly columnIndex: number,
    // Differs from columnIndex where cells above span rows and keep their
    // slots in this row taken.
    public readonly anchorColumnIndex: number,
    viewElement: Element,
  ) {
    this.colSpan = (viewElement as HTMLTableCellElement).colSpan || 1;
    this.rowSpan = (viewElement as HTMLTableCellElement).rowSpan || 1;
  }
}

export class TableSlot {
  constructor(
    public readonly rowIndex: number,
    public readonly columnIndex: number,
    public readonly cell: TableCell,
  ) {}
}

export class TableCellFragment {
  pseudoColumn: Layout.PseudoColumn;
  empty: boolean = false;

  constructor(
    public readonly column: Layout.Column,
    pseudoColumnContainer: HTMLElement,
    public readonly cellNodeContext: Vtree.NodeContext,
  ) {
    this.pseudoColumn = new Layout.PseudoColumn(
      column,
      pseudoColumnContainer,
      cellNodeContext,
    );
  }

  findAcceptableBreakPosition(): Layout.BreakPositionAndNodeContext {
    const element = this.cellNodeContext.viewNode as HTMLElement;
    const { verticalAlign, alignContent } = element.style;
    if (verticalAlign !== "top" && verticalAlign !== "baseline") {
      Base.setCSSProperty(element, "vertical-align", "top");
    }
    if (alignContent && alignContent !== "normal") {
      Base.setCSSProperty(element, "align-content", "normal");
    }
    const bp = this.pseudoColumn.findAcceptableBreakPosition();
    Base.setCSSProperty(element, "vertical-align", verticalAlign);
    if (alignContent && alignContent !== "normal") {
      Base.setCSSProperty(element, "align-content", alignContent);
    }
    return bp;
  }
}

export class TableCaptionView {
  constructor(
    public readonly viewNode: Element,
    public readonly side: string,
  ) {}
}

export class BetweenTableRowBreakPosition
  extends BreakPosition.EdgeBreakPosition
{
  private formattingContext: TableFormattingContext;

  acceptableCellBreakPositions: Layout.BreakPositionAndNodeContext[] | null =
    null;
  private rowIndex: number | null = null;

  constructor(
    position: Vtree.NodeContext,
    breakOnEdge: string | null,
    overflows: boolean,
    columnBlockSize: number,
  ) {
    super(position, breakOnEdge, overflows, columnBlockSize);
    this.formattingContext =
      position.formattingContext as TableFormattingContext;
  }

  override findAcceptableBreak(
    column: Layout.Column,
    penalty: number,
  ): Vtree.NodeContext | null {
    const breakNodeContext = super.findAcceptableBreak(column, penalty);
    if (penalty < this.getMinBreakPenalty()) {
      return null;
    }
    // If any cell has remaining content, this between-row break would lose it
    // because finishBreak for between-row breaks only saves break positions
    // for row-spanning cells. An InsideTableRowBreakPosition should be used
    // instead. (Issue #1663)
    if (this.hasUnfinishedCells()) {
      return null;
    }
    return breakNodeContext;
  }

  /**
   * Check if any non-spanning cell in the row has content that wasn't fully
   * rendered. This happens when page floats (footnotes) reduce available space
   * during a retry, causing cell content to overflow within the row even though
   * the row boundary appears acceptable. (Issue #1663)
   */
  private hasUnfinishedCells(): boolean {
    const rowIndex = this.getRowIndex();
    const allCells = this.formattingContext.getCellsFallingOnRow(rowIndex);
    for (const cell of allCells) {
      // Skip row-spanning cells (handled by getAcceptableCellBreakPositions)
      if (cell.rowIndex + cell.rowSpan - 1 > rowIndex) {
        continue;
      }
      const cellFragment = this.formattingContext.getCellFragmentOfCell(cell);
      if (cellFragment) {
        const bp = cellFragment.findAcceptableBreakPosition();
        if (!cellFragment.pseudoColumn.isLastAfterNodeContext(bp.nodeContext)) {
          return true;
        }
      }
    }
    return false;
  }

  override getMinBreakPenalty(): number {
    let penalty = super.getMinBreakPenalty();
    this.getAcceptableCellBreakPositions().forEach((bp) => {
      penalty += bp.breakPosition.getMinBreakPenalty();
    });
    const cellFragments = this.getCellFragments();
    penalty += Math.max(
      0,
      ...cellFragments.map((cf) => cf.cellNodeContext.breakPenalty),
    );
    return penalty;
  }

  getAcceptableCellBreakPositions(): Layout.BreakPositionAndNodeContext[] {
    if (!this.acceptableCellBreakPositions) {
      const formattingContext = this.formattingContext;
      const cellFragments = this.getCellFragments();
      this.acceptableCellBreakPositions = cellFragments.map((cellFragment) =>
        cellFragment.findAcceptableBreakPosition(),
      );
    }
    return this.acceptableCellBreakPositions;
  }

  private getRowIndex(): number {
    if (this.rowIndex != null) {
      return this.rowIndex;
    }
    return (this.rowIndex = this.formattingContext.findRowIndexBySourceNode(
      this.position.sourceNode,
    ));
  }

  private getCellFragments() {
    return this.formattingContext
      .getRowSpanningCellsOverflowingTheRow(this.getRowIndex())
      .map(
        this.formattingContext.getCellFragmentOfCell,
        this.formattingContext,
      );
  }
}

export class InsideTableRowBreakPosition
  extends BreakPosition.AbstractBreakPosition
{
  acceptableCellBreakPositions: Layout.BreakPositionAndNodeContext[] | null =
    null;

  constructor(
    public readonly rowIndex: number,
    public readonly beforeNodeContext: Vtree.NodeContext,
    public readonly formattingContext: TableFormattingContext,
  ) {
    super();
  }

  override findAcceptableBreak(
    column: Layout.Column,
    penalty: number,
  ): Vtree.NodeContext | null {
    if (
      this !== column.breakPositions[0] && // Fix for issue #1458, case 2
      penalty < this.getMinBreakPenalty()
    ) {
      return null;
    }
    const cellFragments = this.getCellFragments();
    const acceptableCellBreakPositions = this.getAcceptableCellBreakPositions();
    const foundBreakInsideCell = acceptableCellBreakPositions.some(
      (bp, index) => {
        const pseudoColumn = cellFragments[index].pseudoColumn;
        const nodeContext = bp.nodeContext;
        return (
          !pseudoColumn.isStartNodeContext(nodeContext) &&
          !pseudoColumn.isLastAfterNodeContext(nodeContext)
        );
      },
    );
    this.beforeNodeContext.overflow = acceptableCellBreakPositions.some(
      (bp) => bp.nodeContext.overflow,
    );
    if (foundBreakInsideCell) {
      return this.beforeNodeContext;
    } else {
      return null;
    }
  }

  override getMinBreakPenalty(): number {
    const formattingContext = this.formattingContext;
    formattingContext.getRowByIndex(this.rowIndex);
    let penalty = this.beforeNodeContext.breakPenalty;

    const breakPositions = this.getAcceptableCellBreakPositions();
    const cellFragments = this.getCellFragments();
    penalty += Math.max(
      0,
      ...cellFragments.map((cf) => cf.cellNodeContext.breakPenalty),
    );

    // If there is a box break in a row-spanning cell, do not add penalty.
    // This is to prevent the cell content from disappearing due to the situation
    // that a box break occurs in a row-spanning cell but the row break fails.
    // (Issue #1403)
    const foundBoxBreakInRowSpanningCell = breakPositions.some(
      (bp, i) =>
        bp.breakPosition instanceof Layout.BoxBreakPosition &&
        (cellFragments[i].cellNodeContext.sourceNode as HTMLTableCellElement)
          .rowSpan > 1,
    );

    breakPositions.forEach((bp, i) => {
      let penalty1 = bp.breakPosition.getMinBreakPenalty();
      if (
        foundBoxBreakInRowSpanningCell &&
        bp.breakPosition instanceof BreakPosition.EdgeBreakPosition &&
        bp.breakPosition.overflows &&
        penalty1 >= 3
      ) {
        // When a box break occurs in a row-spanning cell, the height of the row group decreases,
        // and the overflows flag that was set before the box break may be no longer valid.
        // So,check the overflow again, and if the cell does not overflow, reduce the penalty.
        // (Issue #1403)
        const overflows = cellFragments[i].column.checkOverflowAndSaveEdge(
          bp.nodeContext,
          null,
        );
        if (!overflows) {
          penalty1 -= 3;
        }
      }
      penalty += penalty1;
    });
    return penalty;
  }

  getAcceptableCellBreakPositions(): Layout.BreakPositionAndNodeContext[] {
    if (!this.acceptableCellBreakPositions) {
      const cellFragments = this.getCellFragments();
      this.acceptableCellBreakPositions = cellFragments.map((cellFragment) =>
        cellFragment.findAcceptableBreakPosition(),
      );
    }
    return this.acceptableCellBreakPositions;
  }

  private getCellFragments() {
    return this.formattingContext
      .getCellsFallingOnRow(this.rowIndex)
      .map(
        this.formattingContext.getCellFragmentOfCell,
        this.formattingContext,
      );
  }
}

export type BrokenTableCellPosition = {
  cellNodePosition: Vtree.NodePosition;
  breakChunkPosition: Vtree.ChunkPosition;
  cell: TableCell;
};

/**
 * @param tableSourceNode Source node of the table
 */
export class TableFormattingContext
  extends RepetitiveElementImpl.RepetitiveElementsOwnerFormattingContext
  implements Table.TableFormattingContext
{
  formattingContextType: FormattingContextType = "Table";
  vertical: boolean = false;
  columnCount: number = -1;
  tableWidth: number = 0;
  captions: (TableCaptionView | null)[] = [];
  colGroups: DocumentFragment | null = null;
  colWidths: number[] | null = null;
  inlineBorderSpacing: number = 0;
  rows: TableRow[] = [];
  slots: TableSlot[][] = [];
  cellFragments: TableCellFragment[][] = [];
  lastRowViewNode: Element | null = null;
  cellBreakPositions: BrokenTableCellPosition[] = [];
  repetitiveElements: RepetitiveElement.RepetitiveElements | null = null;

  constructor(
    parent: Vtree.FormattingContext | null,
    public readonly tableSourceNode: Element,
  ) {
    super(parent, tableSourceNode);
  }

  override getName(): string {
    return "Table formatting context (Table.TableFormattingContext)";
  }

  override isFirstTime(
    nodeContext: Vtree.NodeContext,
    firstTime: boolean,
  ): boolean {
    if (!firstTime) {
      return firstTime;
    }
    switch (nodeContext.display) {
      case "table-row": {
        // Check both cellBreakPositions and fragmentIndex to determine if this
        // is the first time laying out this row (issue #1663).
        // Previous-fragment row-spanning cells are laid out separately before
        // the current row; they should not make the row itself a continuation.
        const rowIndex = this.findRowIndexBySourceNode(nodeContext.sourceNode);
        return (
          this.cellBreakPositions.every((p) =>
            this.isPreviousFragmentRowSpanningCellBreakPosition(p, rowIndex),
          ) && nodeContext.fragmentIndex <= 1
        );
      }
      case "table-cell": {
        // For cells, check if this cell's source node is in cellBreakPositions
        // or if fragmentIndex indicates this is a continuation (issue #1663).
        // A table-cell directly under the table participates in an anonymous
        // row, so a continued table fragment must not make a fresh cell look
        // like a continuation fragment.
        if (nodeContext.fragmentIndex > 1) {
          return false;
        }
        if (
          nodeContext.parent?.display === "table-row" &&
          nodeContext.parent.fragmentIndex > 1
        ) {
          return false;
        }
        // Check if this cell's sourceNode is in cellBreakPositions
        return !this.cellBreakPositions.some(
          (p) => p.cellNodePosition.steps[0].node === nodeContext.sourceNode,
        );
      }
      default:
        return firstTime;
    }
  }

  override getParent(): Vtree.FormattingContext | null {
    return this.parent;
  }

  finishFragment() {
    this.cellFragments = [];
  }

  addRow(rowIndex: number, row: TableRow) {
    this.rows[rowIndex] = row;
  }

  getRowSlots(rowIndex: number): TableSlot[] {
    let rowSlots = this.slots[rowIndex];
    if (!rowSlots) {
      rowSlots = this.slots[rowIndex] = [];
    }
    return rowSlots;
  }

  addCell(rowIndex: number, columnIndex: number, viewElement: Element) {
    let row = this.rows[rowIndex];
    if (!row) {
      this.addRow(rowIndex, new TableRow(rowIndex, null));
      row = this.rows[rowIndex];
    }
    const rowSlots = this.getRowSlots(rowIndex);
    let anchorColumnIndex = 0;
    while (rowSlots[anchorColumnIndex]) {
      anchorColumnIndex++;
    }
    const cell = new TableCell(
      rowIndex,
      columnIndex,
      anchorColumnIndex,
      viewElement,
    );
    row.addCell(cell);
    const rowUpper = rowIndex + cell.rowSpan;
    const columnUpper = anchorColumnIndex + cell.colSpan;
    for (let r = rowIndex; r < rowUpper; r++) {
      const slots = this.getRowSlots(r);
      for (let i = anchorColumnIndex; i < columnUpper; i++) {
        slots[i] = new TableSlot(r, i, cell);
      }
    }
  }

  getRowByIndex(index: number): TableRow {
    const row = this.rows[index];
    Asserts.assert(row);
    return row;
  }

  findRowIndexBySourceNode(sourceNode: Node): number {
    return this.rows.findIndex((row) => sourceNode === row.sourceNode);
  }

  private isPreviousFragmentRowSpanningCellBreakPosition(
    cellBreakPosition: BrokenTableCellPosition,
    rowIndex: number,
  ): boolean {
    const cell = cellBreakPosition.cell;
    return (
      rowIndex >= 0 &&
      cell.rowIndex < rowIndex &&
      cell.rowIndex + cell.rowSpan > rowIndex
    );
  }

  addCellFragment(
    rowIndex: number,
    columnIndex: number,
    cellFragment: TableCellFragment,
  ) {
    let list = this.cellFragments[rowIndex];
    if (!list) {
      list = this.cellFragments[rowIndex] = [];
    }
    list[columnIndex] = cellFragment;
  }

  getCellsFallingOnRow(rowIndex: number): TableCell[] {
    const rowSlots = this.getRowSlots(rowIndex);
    return rowSlots.reduce((uniqueCells, slot) => {
      if (slot.cell !== uniqueCells.at(-1)) {
        return uniqueCells.concat(slot.cell);
      } else {
        return uniqueCells;
      }
    }, [] as TableCell[]);
  }

  getRowSpanningCellsOverflowingTheRow(rowIndex: number): TableCell[] {
    return this.getCellsFallingOnRow(rowIndex).filter(
      (cell) => cell.rowIndex + cell.rowSpan - 1 > rowIndex,
    );
  }

  getCellFragmentOfCell(cell: TableCell): TableCellFragment {
    return (
      this.cellFragments[cell.rowIndex] &&
      this.cellFragments[cell.rowIndex][cell.columnIndex]
    );
  }

  getColumnCount(): number {
    if (this.columnCount < 0) {
      this.columnCount = Math.max(
        ...this.rows.map((row) =>
          row.cells.reduce((sum, c) => sum + c.colSpan, 0),
        ),
      );
    }
    return this.columnCount;
  }

  /**
   * @return position
   */
  findCellFromColumn(
    column: Layout.Column | null,
  ): { rowIndex: number; columnIndex: number } | null {
    if (!column) {
      return null;
    }
    let tableCell: TableCell | null = null;
    let row = 0;
    let col = 0;
    loop: for (row = 0; row < this.cellFragments.length; row++) {
      if (!this.cellFragments[row]) {
        continue;
      }
      for (col = 0; col < this.cellFragments[row].length; col++) {
        if (!this.cellFragments[row][col]) {
          continue;
        }
        if (column === this.cellFragments[row][col].pseudoColumn.getColumn()) {
          tableCell = this.rows[row].cells[col];
          break loop;
        }
      }
    }
    if (!tableCell) {
      return null;
    }
    for (; row < this.slots.length; row++) {
      for (; col < this.slots[row].length; col++) {
        const slot = this.slots[row][col];
        if (slot.cell === tableCell) {
          return { rowIndex: slot.rowIndex, columnIndex: slot.columnIndex };
        }
      }
    }
    return null;
  }

  collectElementsOffsetOfUpperCells(position: {
    rowIndex: number;
    columnIndex: number;
  }): RepetitiveElement.ElementsOffset[] {
    const collected: TableCellFragment[] = [];
    return this.slots.reduce((repetitiveElements, row, index) => {
      if (index >= position.rowIndex) {
        return repetitiveElements;
      }
      const cellFragment =
        row[position.columnIndex] &&
        this.getCellFragmentOfCell(row[position.columnIndex].cell);
      if (!cellFragment || collected.includes(cellFragment)) {
        return repetitiveElements;
      }
      this.collectElementsOffsetFromColumn(
        cellFragment.pseudoColumn.getColumn(),
        repetitiveElements,
      );
      collected.push(cellFragment);
      return repetitiveElements;
    }, [] as RepetitiveElement.ElementsOffset[]);
  }

  collectElementsOffsetOfHighestColumn(): RepetitiveElement.ElementsOffset[] {
    const elementsInColumn: {
      collected: TableCellFragment[];
      elements: RepetitiveElement.ElementsOffset[];
    }[] = [];
    this.rows.forEach((row) => {
      row.cells.forEach((cell, index) => {
        if (!elementsInColumn[index]) {
          elementsInColumn[index] = { collected: [], elements: [] };
        }
        const state = elementsInColumn[index];
        const cellFragment = this.getCellFragmentOfCell(cell);
        if (!cellFragment || state.collected.includes(cellFragment)) {
          return;
        }
        this.collectElementsOffsetFromColumn(
          cellFragment.pseudoColumn.getColumn(),
          state.elements,
        );
        state.collected.push(cellFragment);
      });
    });
    return [
      new ElementsOffsetOfTableCell(
        elementsInColumn.map((entry) => entry.elements),
      ),
    ];
  }

  private collectElementsOffsetFromColumn(
    column: LayoutType.Column,
    repetitiveElements: RepetitiveElement.ElementsOffset[],
  ) {
    column.fragmentLayoutConstraints.forEach((constraint) => {
      if (
        RepetitiveElement.isInstanceOfRepetitiveElementsOwnerLayoutConstraint(
          constraint,
        )
      ) {
        const repetitiveElement = constraint.getRepetitiveElements();
        repetitiveElements.push(repetitiveElement);
      }
      if (Table.isInstanceOfTableRowLayoutConstraint(constraint)) {
        constraint
          .getElementsOffsetsForTableCell(null)
          .forEach((repetitiveElement) => {
            repetitiveElements.push(repetitiveElement);
          });
      }
    });
  }

  override saveState(): any {
    return [...this.cellBreakPositions];
  }

  override restoreState(state: any) {
    // Create a fresh copy to prevent the saved state from being mutated
    // during subsequent layout attempts (issue #1667).
    this.cellBreakPositions = [...(state as BrokenTableCellPosition[])];
  }
}

export class ElementsOffsetOfTableCell
  implements RepetitiveElement.ElementsOffset
{
  constructor(
    public readonly repeatitiveElementsInColumns: RepetitiveElement.ElementsOffset[][],
  ) {}

  /** @override */
  calculateOffset(nodeContext: Vtree.NodeContext): number {
    return this.calculateMaxOffsetOfColumn(
      nodeContext,
      (offsets) => offsets.current,
    );
  }

  /** @override */
  calculateMinimumOffset(nodeContext: Vtree.NodeContext): number {
    return this.calculateMaxOffsetOfColumn(
      nodeContext,
      (offsets) => offsets.minimum,
    );
  }

  private calculateMaxOffsetOfColumn(nodeContext, resolver) {
    let maxOffset = 0;
    this.repeatitiveElementsInColumns.forEach((repetitiveElements) => {
      const offsets = BreakPosition.calculateOffset(
        nodeContext,
        repetitiveElements,
      );
      maxOffset = Math.max(maxOffset, resolver(offsets));
    });
    return maxOffset;
  }
}

function getTableFormattingContext(
  formattingContext: Vtree.FormattingContext | null,
): TableFormattingContext {
  Asserts.assert(formattingContext instanceof TableFormattingContext);
  return formattingContext as TableFormattingContext;
}

function isTableRowGrouping(display: string | null): boolean {
  return (
    display === "table-row-group" ||
    display === "table-header-group" ||
    display === "table-footer-group"
  );
}

function isTableRoot(display: string | null): boolean {
  return display === "table" || display === "inline-table";
}

function isValidParentOfTableRow(display: string | null): boolean {
  return isTableRowGrouping(display) || isTableRoot(display);
}

function skipNestedTable(
  state: LayoutUtil.RenderedActiveLayoutIteratorState,
  formattingContext: TableFormattingContext,
  column: Layout.Column,
): Task.Result<boolean> | null {
  const nodeContext = state.nodeContext;
  const display = nodeContext.display;
  const parentDisplay = nodeContext.parent ? nodeContext.parent.display : null;

  // Is inline-table nested in another table?
  let isNestedInlineTable = false;
  if (
    parentDisplay === "inline-table" &&
    !(nodeContext.formattingContext instanceof TableFormattingContext)
  ) {
    for (let nc = nodeContext.parent; nc; nc = nc.parent) {
      if (nc.formattingContext instanceof TableFormattingContext) {
        isNestedInlineTable = nc.formattingContext === formattingContext;
        break;
      }
    }
  }
  const isNestedTable =
    isNestedInlineTable ||
    (display === "table-row" && !isValidParentOfTableRow(parentDisplay)) ||
    (display === "table-cell" &&
      parentDisplay !== "table-row" &&
      !isValidParentOfTableRow(parentDisplay)) ||
    (nodeContext.formattingContext instanceof TableFormattingContext &&
      nodeContext.formattingContext !== formattingContext);
  if (isNestedTable) {
    return column
      .buildDeepElementView(nodeContext)
      .thenAsync((nodeContextAfter) => {
        state.nodeContext = nodeContextAfter;
        return Task.newResult(true);
      });
  } else {
    return null;
  }
}

function layoutFloatOrFootnoteIfNeeded(
  column: Layout.Column,
  state: LayoutUtil.RenderedActiveLayoutIteratorState,
): Task.Result<boolean> | null {
  // Column.asFloatNodeContext drops the float that opened a page float area.
  // This edge asks about that float too.
  const nodeContext = VtreeImpl.asFloatNodeContext(state.nodeContext);
  if (
    !nodeContext ||
    !(
      PageFloats.isPageFloat(nodeContext.floatReference) ||
      nodeContext.floatSide === "footnote"
    )
  ) {
    return null;
  }
  return column
    .layoutFloatOrFootnote(nodeContext)
    .thenAsync((nextNodeContext) => {
      if (nextNodeContext) {
        state.nodeContext = nextNodeContext;
      }
      return Task.newResult(true);
    });
}

export class EntireTableLayoutStrategy extends LayoutUtil.EdgeSkipper {
  rowIndex: number = -1;
  columnIndex: number = 0;
  inRow: boolean = false;
  checkPoints: Vtree.RenderedNodeContext[] = [];
  inHeaderOrFooter: boolean = false;

  constructor(
    public readonly formattingContext: TableFormattingContext,
    public readonly column: Layout.Column,
  ) {
    super();
  }

  override startNonInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    const formattingContext = this.formattingContext;
    const r = skipNestedTable(state, formattingContext, this.column);
    if (r) {
      return r;
    }
    this.postLayoutBlockContents(state);
    const floatResult = layoutFloatOrFootnoteIfNeeded(this.column, state);
    if (floatResult) {
      return floatResult;
    }
    const nodeContext = state.nodeContext;
    const display = nodeContext.display;
    const repetitiveElements = formattingContext.getRepetitiveElements();
    switch (display) {
      case "table":
        formattingContext.inlineBorderSpacing = nodeContext.inlineBorderSpacing;
        break;
      case "table-caption": {
        const captionView = new TableCaptionView(
          nodeContext.viewNode as Element,
          nodeContext.captionSide,
        );
        formattingContext.captions.push(captionView);
        break;
      }
      case "table-header-group":
        if (!repetitiveElements.isHeaderRegistered()) {
          this.inHeaderOrFooter = true;
          repetitiveElements.setHeaderNodeContext(nodeContext);
        }
        return Task.newResult(true);
      case "table-footer-group":
        if (!repetitiveElements.isFooterRegistered()) {
          this.inHeaderOrFooter = true;
          repetitiveElements.setFooterNodeContext(nodeContext);
        }
        return Task.newResult(true);
      case "table-row":
        if (!this.inHeaderOrFooter) {
          this.inRow = true;
          this.rowIndex++;
          this.columnIndex = 0;
          formattingContext.addRow(
            this.rowIndex,
            new TableRow(this.rowIndex, nodeContext.sourceNode),
          );
          // Capture row's own breakBefore for forced break detection
          if (nodeContext.breakBefore) {
            formattingContext.rows[this.rowIndex].breakBefore =
              nodeContext.breakBefore;
          }
          if (!repetitiveElements.firstContentSourceNode) {
            repetitiveElements.firstContentSourceNode =
              nodeContext.sourceNode as Element;
          }
        }
        break;
    }
    return super.startNonInlineElementNode(state);
  }

  override afterNonInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    const formattingContext = this.formattingContext;
    const nodeContext = state.nodeContext;
    const display = nodeContext.display;
    const clientLayout = this.column.clientLayout;
    this.postLayoutBlockContents(state);
    if (nodeContext.sourceNode === formattingContext.tableSourceNode) {
      const computedStyle = clientLayout.getElementComputedStyle(
        formattingContext.getRootViewNode(nodeContext) as Element,
      );
      formattingContext.tableWidth = parseFloat(
        computedStyle[formattingContext.vertical ? "height" : "width"],
      );
      formattingContext.getRepetitiveElements().lastContentSourceNode =
        state.lastAfterNodeContext &&
        (state.lastAfterNodeContext.sourceNode as Element);
      state.break = true;
    } else {
      switch (display) {
        case "table-header-group":
        case "table-footer-group":
          if (this.inHeaderOrFooter) {
            this.inHeaderOrFooter = false;
            return Task.newResult(true);
          }
          break;
        case "table-row":
          if (!this.inHeaderOrFooter) {
            formattingContext.lastRowViewNode = nodeContext.viewNode as Element;
            this.inRow = false;
            // Capture row's own breakAfter for forced break detection
            const row = formattingContext.rows[this.rowIndex];
            if (row && nodeContext.breakAfter) {
              row.breakAfter = Break.resolveEffectiveBreakValue(
                row.breakAfter,
                nodeContext.breakAfter,
              );
            }
          }
          break;
        case "table-cell":
          if (!this.inHeaderOrFooter) {
            if (!this.inRow) {
              this.rowIndex++;
              this.columnIndex = 0;
              this.inRow = true;
            }
            const elem = nodeContext.viewNode as Element;
            formattingContext.addCell(this.rowIndex, this.columnIndex, elem);
            this.columnIndex++;
            fixTableCellWrapperForBaseline(elem);
            // Propagate cell break values to the row for forced break detection
            const cellRow = formattingContext.rows[this.rowIndex];
            if (cellRow) {
              if (nodeContext.breakBefore) {
                cellRow.breakBefore = Break.resolveEffectiveBreakValue(
                  cellRow.breakBefore,
                  nodeContext.breakBefore,
                );
              }
              if (nodeContext.breakAfter) {
                cellRow.breakAfter = Break.resolveEffectiveBreakValue(
                  cellRow.breakAfter,
                  nodeContext.breakAfter,
                );
              }
            }
          }
          break;
      }
    }
    return super.afterNonInlineElementNode(state);
  }

  override startNonElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    this.registerCheckPoint(state);
  }

  override afterNonElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    this.registerCheckPoint(state);
  }

  override startInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    this.registerCheckPoint(state);
  }

  override afterInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    this.registerCheckPoint(state);
  }

  registerCheckPoint(state: LayoutUtil.RenderedActiveLayoutIteratorState) {
    const nodeContext = state.nodeContext;
    if (!LayoutHelper.isSpecialNodeContext(nodeContext)) {
      this.checkPoints.push(nodeContext.clone());
    }
  }

  postLayoutBlockContents(state: LayoutUtil.RenderedActiveLayoutIteratorState) {
    if (this.checkPoints.length > 0) {
      this.column.postLayoutBlock(state.nodeContext, this.checkPoints);
    }
    this.checkPoints = [];
  }
}

export class TableLayoutStrategy extends LayoutUtil.EdgeSkipper {
  private static ignoreList: { [key: string]: boolean } = {
    "table-caption": true,
    "table-column-group": true,
    "table-column": true,
  };
  inRow: boolean = false;
  currentRowIndex: number = -1;
  currentColumnIndex: number = 0;
  originalStopAtOverflow: boolean;
  inHeader: boolean = false;
  inFooter: boolean = false;
  private didExtractRowSpanningCellBreakPositions: boolean = false;

  constructor(
    public readonly formattingContext: TableFormattingContext,
    public readonly column: Layout.Column,
  ) {
    super(true);
    this.originalStopAtOverflow = column.stopAtOverflow;
    column.stopAtOverflow = false;
  }

  override startNonInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    const floatResult = layoutFloatOrFootnoteIfNeeded(this.column, state);
    if (floatResult) {
      return floatResult;
    }
    return super.startNonInlineElementNode(state);
  }

  resetColumn() {
    this.column.stopAtOverflow = this.originalStopAtOverflow;
  }

  getColSpanningCellWidth(cell: TableCell): number {
    const colWidths = this.formattingContext.colWidths;
    Asserts.assert(colWidths);
    let width = 0;
    for (let i = 0; i < cell.colSpan; i++) {
      width += colWidths[cell.anchorColumnIndex + i];
    }
    width += this.formattingContext.inlineBorderSpacing * (cell.colSpan - 1);
    return width;
  }

  layoutCell(
    cell: TableCell,
    cellNodeContext: Vtree.NodeContext,
    startChunkPosition: Vtree.ChunkPosition,
  ): Task.Result<boolean> {
    const rowIndex = cell.rowIndex;
    const columnIndex = cell.columnIndex;
    const colSpan = cell.colSpan;
    const cellViewNode = cellNodeContext.viewNode as Element;
    if (colSpan > 1) {
      Base.setCSSProperty(cellViewNode, "box-sizing", "border-box");
      Base.setCSSProperty(
        cellViewNode,
        this.formattingContext.vertical ? "height" : "width",
        `${this.getColSpanningCellWidth(cell)}px`,
      );
    }
    const pseudoColumnContainer =
      cellViewNode.ownerDocument.createElement("div");
    cellViewNode.appendChild(pseudoColumnContainer);
    const cellFragment = new TableCellFragment(
      this.column,
      pseudoColumnContainer,
      cellNodeContext,
    );
    this.formattingContext.addCellFragment(rowIndex, columnIndex, cellFragment);
    if (
      startChunkPosition.primary.steps.length === 1 &&
      startChunkPosition.primary.after
    ) {
      // Contents of the cell have ended in the previous fragment
      cellFragment.empty = true;
    }
    return cellFragment.pseudoColumn
      .layout(startChunkPosition, true)
      .thenAsync(() => {
        fixTableCellWrapperForBaseline(cellViewNode);
        return Task.newResult(true);
      });
  }

  /**
   * Find the break position for the cell at the given slot index.
   * Returns the break position and its index in cellBreakPositions, or null if not found.
   * Uses sourceNode matching instead of sequential index to support layout retry (issue #1663).
   */
  findBrokenCellAtSlot(
    slotIndex: number,
    sourceNode: Node,
  ): { position: BrokenTableCellPosition; index: number } | null {
    const cellBreakPositions = this.formattingContext.cellBreakPositions;
    for (let i = 0; i < cellBreakPositions.length; i++) {
      const p = cellBreakPositions[i];
      if (
        p.cell.anchorColumnIndex === slotIndex &&
        p.cellNodePosition.steps[0].node === sourceNode
      ) {
        return { position: p, index: i };
      }
    }
    return null;
  }

  private extractRowSpanningCellBreakPositions(): BrokenTableCellPosition[][] {
    if (this.didExtractRowSpanningCellBreakPositions) {
      return [];
    }
    const cellBreakPositions = this.formattingContext.cellBreakPositions;
    if (cellBreakPositions.length === 0) {
      return [];
    }
    const rowSpanningCellBreakPositions: BrokenTableCellPosition[][] = [];
    cellBreakPositions.forEach((p) => {
      const cell = p.cell;
      const rowIndex = cell.rowIndex;
      // Only extract cells that actually span into the current row
      // (i.e., rowIndex < currentRowIndex AND rowIndex + rowSpan > currentRowIndex)
      // Fix for issue #1663: Don't extract cells that are entirely in previous rows
      if (
        rowIndex < this.currentRowIndex &&
        rowIndex + cell.rowSpan > this.currentRowIndex
      ) {
        let arr = rowSpanningCellBreakPositions[rowIndex];
        if (!arr) {
          arr = rowSpanningCellBreakPositions[rowIndex] = [];
        }
        arr.push(p);
      }
    });
    this.didExtractRowSpanningCellBreakPositions =
      rowSpanningCellBreakPositions.length > 0;
    return rowSpanningCellBreakPositions;
  }

  layoutRowSpanningCellsFromPreviousFragment(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): Task.Result<boolean> {
    const formattingContext = this.formattingContext;
    const rowSpanningCellBreakPositions =
      this.extractRowSpanningCellBreakPositions();
    const rowCount = rowSpanningCellBreakPositions.reduce((s) => s + 1, 0);
    if (rowCount === 0) {
      return Task.newResult(true);
    }
    const layoutContext = this.column.layoutContext;
    const currentRow = state.nodeContext;
    currentRow.viewNode.remove();
    const frame = Task.newFrame<boolean>(
      "layoutRowSpanningCellsFromPreviousFragment",
    );
    let cont = Task.newResult(true);
    let spanningCellRowIndex = 0;
    const occupiedSlotIndices: number[] = [];
    rowSpanningCellBreakPositions.forEach((rowCellBreakPositions) => {
      cont = cont.thenAsync(() => {
        // Is it always correct to assume steps[1] to be the row?
        // A table row under layout always sits below its table element context.
        const rowNodeContext = VtreeImpl.makeNodeContextFromNodePositionStep(
          rowCellBreakPositions[0].cellNodePosition.steps[1],
          (currentRow as Vtree.ChildNodeContext).parent,
        );
        return layoutContext.setCurrent(rowNodeContext, false).thenAsync(() => {
          // the row was rendered in the previous fragment and re-renders here
          const rowElementContext =
            VtreeImpl.asElementNodeContext(rowNodeContext);
          Asserts.assert(rowElementContext);
          const rowViewNode = rowElementContext.viewNode;
          let cont1 = Task.newResult(true);
          let columnIndex = 0;

          function addDummyCellUntil(upperColumnIndex) {
            while (columnIndex < upperColumnIndex) {
              if (!occupiedSlotIndices.includes(columnIndex)) {
                const dummy = rowViewNode.ownerDocument.createElement("td");
                Base.setCSSProperty(dummy, "padding", "0");
                rowViewNode.appendChild(dummy);
              }
              columnIndex++;
            }
          }
          rowCellBreakPositions.forEach((cellBreakPosition) => {
            cont1 = cont1.thenAsync(() => {
              const cell = cellBreakPosition.cell;
              addDummyCellUntil(cell.anchorColumnIndex);
              const cellNodePosition = cellBreakPosition.cellNodePosition;
              const cellNodeContext =
                VtreeImpl.makeNodeContextFromNodePositionStep(
                  cellNodePosition.steps[0],
                  rowNodeContext,
                );
              cellNodeContext.offsetInNode = cellNodePosition.offsetInNode;
              cellNodeContext.after = cellNodePosition.after;
              cellNodeContext.fragmentIndex =
                cellNodePosition.steps[0].fragmentIndex + 1;
              return layoutContext
                .setCurrent(cellNodeContext, false)
                .thenAsync(() => {
                  const breakChunkPosition =
                    cellBreakPosition.breakChunkPosition;
                  for (let i = 0; i < cell.colSpan; i++) {
                    occupiedSlotIndices.push(columnIndex + i);
                  }
                  columnIndex += cell.colSpan;
                  return this.layoutCell(
                    cell,
                    cellNodeContext,
                    breakChunkPosition,
                  ).thenAsync(() => {
                    (cellNodeContext.viewNode as HTMLTableCellElement).rowSpan =
                      cell.rowIndex +
                      cell.rowSpan -
                      this.currentRowIndex +
                      rowCount -
                      spanningCellRowIndex;
                    return Task.newResult(true);
                  });
                });
            });
          });
          return cont1.thenAsync(() => {
            addDummyCellUntil(formattingContext.getColumnCount());
            spanningCellRowIndex++;
            return Task.newResult(true);
          });
        });
      });
    });
    cont.then(() => {
      layoutContext
        .setCurrent(currentRow, true, state.atUnforcedBreak)
        .then(() => {
          frame.finish(true);
        });
    });
    return frame.result();
  }

  startTableRow(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): Task.Result<boolean> {
    if (this.inHeader || this.inFooter) {
      return Task.newResult(true);
    }
    const nodeContext = state.nodeContext;
    const formattingContext = this.formattingContext;
    if (this.currentRowIndex < 0) {
      this.currentRowIndex = formattingContext.findRowIndexBySourceNode(
        nodeContext.sourceNode,
      );
    } else {
      this.currentRowIndex++;
    }
    this.currentColumnIndex = 0;
    this.inRow = true;
    return this.layoutRowSpanningCellsFromPreviousFragment(state).thenAsync(
      () => {
        this.registerCellFragmentIndex();

        // Merge pre-collected cell/row break values with state.breakAtTheEdge
        let breakAtEdge = state.breakAtTheEdge;
        if (this.currentRowIndex > 0) {
          const prevRow = formattingContext.rows[this.currentRowIndex - 1];
          if (prevRow?.breakAfter) {
            breakAtEdge = Break.resolveEffectiveBreakValue(
              breakAtEdge,
              prevRow.breakAfter,
            );
          }
        }
        const currentRow = formattingContext.rows[this.currentRowIndex];
        if (currentRow?.breakBefore) {
          breakAtEdge = Break.resolveEffectiveBreakValue(
            breakAtEdge,
            currentRow.breakBefore,
          );
        }

        // Check for forced break before this row
        if (!state.leadingEdge && Break.isForcedBreakValue(breakAtEdge)) {
          this.column.checkOverflowAndSaveEdgeAndBreakPosition(
            state.lastAfterNodeContext,
            null,
            true,
            breakAtEdge,
          );
          nodeContext.viewNode?.remove();
          // Set block-end box-break flags on the table and its ancestors
          // since doFinishBreak skips finishBreak when pageBreakType is set
          if (state.lastAfterNodeContext) {
            this.column.layoutContext.processFragmentedBlockEdge(
              state.lastAfterNodeContext,
            );
          }
          this.column.pageBreakType = breakAtEdge;
          this.resetColumn();
          state.break = true;
          return Task.newResult(true);
        }

        const overflown = this.column.checkOverflowAndSaveEdgeAndBreakPosition(
          state.lastAfterNodeContext,
          null,
          true,
          breakAtEdge,
        );
        if (
          overflown &&
          formattingContext.getRowSpanningCellsOverflowingTheRow(
            this.currentRowIndex - 1,
          ).length === 0
        ) {
          this.resetColumn();
          nodeContext.overflow = true;
          state.break = true;
        }
        return Task.newResult(true);
      },
    );
  }

  private registerCellFragmentIndex() {
    const cells = this.formattingContext.getRowByIndex(
      this.currentRowIndex,
    ).cells;
    cells.forEach((cell) => {
      // Use proper lookup by cell reference instead of array index,
      // since cellBreakPositions may contain entries from multiple rows
      // after the fix for issue #1663.
      const cellBreakPosition = this.formattingContext.cellBreakPositions.find(
        (p) => p.cell === cell,
      );
      if (cellBreakPosition) {
        const tdNodeStep = cellBreakPosition.cellNodePosition.steps[0];
        const offset = (
          this.column.layoutContext as Vgen.ViewFactory
        ).xmldoc.getElementOffset(tdNodeStep.node as Element);
        Layout.registerFragmentIndex(offset, tdNodeStep.fragmentIndex + 1, 1);
      }
    });
  }

  startTableCell(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): Task.Result<boolean> {
    if (this.inHeader || this.inFooter) {
      return Task.newResult(true);
    }
    const nodeContext = state.nodeContext;
    if (!this.inRow) {
      if (this.currentRowIndex < 0) {
        this.currentRowIndex = 0;
      } else {
        this.currentRowIndex++;
      }
      this.currentColumnIndex = 0;
      this.inRow = true;
    }
    const cell = this.formattingContext.getRowByIndex(this.currentRowIndex)
      .cells[this.currentColumnIndex];
    if (!cell) {
      // Fix for Issue #712
      state.break = true;
      return Task.newResult(true);
    }
    const afterNodeContext = nodeContext.copy().modify();
    afterNodeContext.after = true;
    state.nodeContext = afterNodeContext;
    const frame = Task.newFrame<boolean>("startTableCell");
    let cont: Task.Result<Vtree.ChunkPosition>;
    // Use sourceNode matching instead of sequential index to support layout retry (issue #1663)
    const brokenCell = this.findBrokenCellAtSlot(
      cell.anchorColumnIndex,
      nodeContext.sourceNode,
    );
    if (brokenCell) {
      const cellBreakPosition = brokenCell.position;
      // Remove the consumed entry from cellBreakPositions so that
      // subsequent rows are not affected by stale entries.
      // (Old code used cellBreakPositions.shift() which consumed entries.)
      this.formattingContext.cellBreakPositions.splice(brokenCell.index, 1);
      nodeContext.fragmentIndex =
        cellBreakPosition.cellNodePosition.steps[0].fragmentIndex + 1;
      cont = Task.newResult(cellBreakPosition.breakChunkPosition);
    } else {
      cont = this.column
        .nextInTree(nodeContext, state.atUnforcedBreak)
        .thenAsync((nextNodeContext) => {
          const nextViewNode = nextNodeContext.viewNode;
          if (nextViewNode) {
            nodeContext.viewNode.removeChild(nextViewNode);
          }
          const startNodePosition = VtreeImpl.newNodePositionFromNodeContext(
            nextNodeContext,
            0,
          );
          return Task.newResult(new VtreeImpl.ChunkPosition(startNodePosition));
        });
    }
    cont.then((startChunkPosition) => {
      Asserts.assert(nodeContext);
      this.layoutCell(cell, nodeContext, startChunkPosition).then(() => {
        this.afterNonInlineElementNode(state);
        this.currentColumnIndex++;
        frame.finish(true);
      });
    });
    return frame.result();
  }

  startNonInlineBox(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): Task.Result<boolean> {
    const r = skipNestedTable(
      state,
      getTableFormattingContext(this.formattingContext),
      this.column,
    );
    if (r) {
      return r;
    }
    const nodeContext = state.nodeContext;
    const repetitiveElements = this.formattingContext.getRepetitiveElements();
    const display = nodeContext.display;
    if (
      display === "table-header-group" &&
      repetitiveElements &&
      repetitiveElements.isHeaderSourceNode(nodeContext.sourceNode)
    ) {
      this.inHeader = true;
      return Task.newResult(true);
    } else if (
      display === "table-footer-group" &&
      repetitiveElements &&
      repetitiveElements.isFooterSourceNode(nodeContext.sourceNode)
    ) {
      this.inFooter = true;
      return Task.newResult(true);
    } else if (display === "table-row") {
      return this.startTableRow(state);
    } else if (display === "table-cell") {
      return this.startTableCell(state);
    } else {
      return Task.newResult(true);
    }
  }

  endNonInlineBox(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): Task.Result<boolean> {
    const nodeContext = state.nodeContext;
    const display = nodeContext.display;
    if (display === "table-row") {
      this.inRow = false;
      if (!this.inHeader && !this.inFooter) {
        const beforeNodeContext = nodeContext.copy().modify();
        beforeNodeContext.after = false;
        const bp = new InsideTableRowBreakPosition(
          this.currentRowIndex,
          beforeNodeContext,
          this.formattingContext,
        );
        this.column.breakPositions.push(bp);
      }
    }
    return Task.newResult(true);
  }

  afterNonInlineElementNode(
    state: LayoutUtil.RenderedActiveLayoutIteratorState,
  ): void | Task.Result<boolean> {
    const nodeContext = state.nodeContext;
    const repetitiveElements = this.formattingContext.getRepetitiveElements();
    const display = nodeContext.display;
    if (display === "table-header-group") {
      if (
        repetitiveElements &&
        !repetitiveElements.allowInsertRepeatitiveElements &&
        repetitiveElements.isHeaderSourceNode(nodeContext.sourceNode)
      ) {
        this.inHeader = false;
        nodeContext.viewNode.remove();
      } else {
        Base.setCSSProperty(
          nodeContext.viewNode as Element,
          "display",
          "table-row-group",
        );
      }
    } else if (display === "table-footer-group") {
      if (
        repetitiveElements &&
        !repetitiveElements.allowInsertRepeatitiveElements &&
        repetitiveElements.isFooterSourceNode(nodeContext.sourceNode)
      ) {
        this.inFooter = false;
        nodeContext.viewNode.remove();
      } else {
        Base.setCSSProperty(
          nodeContext.viewNode as Element,
          "display",
          "table-row-group",
        );
      }
    }
    if (display && TableLayoutStrategy.ignoreList[display]) {
      nodeContext.viewNode.remove();
    } else if (
      nodeContext.sourceNode === this.formattingContext.tableSourceNode
    ) {
      nodeContext.overflow = this.column.checkOverflowAndSaveEdge(
        nodeContext,
        null,
      );
      this.resetColumn();
      state.break = true;
    } else if (display === "table-row" && !this.inHeader && !this.inFooter) {
      const cont = super.afterNonInlineElementNode(state);
      const pending = cont && cont.isPending() ? cont : Task.newResult(true);
      return pending.thenAsync(() => {
        if (!state.break) {
          const overflown = this.column.checkOverflowAndSaveEdge(
            nodeContext,
            null,
          );
          const repetitiveElements =
            this.formattingContext.getRepetitiveElements();
          const overflownDueToRepetitiveElements =
            this.column.nodeContextOverflowingDueToRepetitiveElements ===
            nodeContext;
          // Keep this guard broad. During repetitive-element retry passes the
          // footer may already be marked skipped in the current state even
          // though footer dropping is still the mechanism that resolves the
          // overflow for this table fragment.
          const canResolveByDroppingFooter =
            !overflown &&
            overflownDueToRepetitiveElements &&
            !!repetitiveElements?.isFooterRegistered();
          if (overflown || overflownDueToRepetitiveElements) {
            // Catch row overflow as soon as the row finishes; otherwise the
            // next row start detects it one row too late and content can drift
            // into the page margin before the break is taken. (Issue #1902)
            if (
              !canResolveByDroppingFooter &&
              this.formattingContext.getRowSpanningCellsOverflowingTheRow(
                this.currentRowIndex,
              ).length === 0
            ) {
              this.resetColumn();
              nodeContext.overflow = true;
              state.break = true;
            }
          }
        }
        return Task.newResult(true);
      });
    } else {
      return super.afterNonInlineElementNode(state);
    }
    return Task.newResult(true);
  }
}

type TableLayoutOption = {
  calculateBreakPositionsInside: boolean;
};
const tableLayoutOptionCache: {
  root: Node;
  tableLayoutOption: TableLayoutOption;
}[] = [];

function getTableLayoutOption(
  tableRootSourceNode: Node,
): TableLayoutOption | null {
  const i = tableLayoutOptionCache.findIndex(
    (c) => c.root === tableRootSourceNode,
  );
  const pair = tableLayoutOptionCache[i];
  return pair ? pair.tableLayoutOption : null;
}

function clearTableLayoutOptionCache(tableRootSourceNode: Node): void {
  const i = tableLayoutOptionCache.findIndex(
    (c) => c.root === tableRootSourceNode,
  );
  if (i >= 0) {
    tableLayoutOptionCache.splice(i, 1);
  }
}

export class TableLayoutProcessor implements LayoutProcessor.LayoutProcessor {
  private layoutEntireTable(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    const formattingContext = getTableFormattingContext(
      nodeContext.formattingContext,
    );
    const strategy = new EntireTableLayoutStrategy(formattingContext, column);
    const iterator = new LayoutUtil.LayoutIterator(
      strategy,
      column.layoutContext,
    );
    return iterator.iterate(nodeContext);
  }

  private getColumnWidths(
    lastRow: Element,
    columnCount: number,
    vertical: boolean,
    clientLayout: Vtree.ClientLayout,
  ): number[] {
    const doc = lastRow.ownerDocument;
    const dummyRow = doc.createElement("tr");
    const dummyCells: HTMLTableCellElement[] = [];
    for (let i = 0; i < columnCount; i++) {
      const cell = doc.createElement("td");
      dummyRow.appendChild(cell);
      dummyCells.push(cell);
    }
    lastRow.after(dummyRow);
    const colWidths = dummyCells.map((cell) => {
      const rect = LayoutHelper.getElementClientRectAdjusted(
        clientLayout,
        cell,
        vertical,
      );
      const width = vertical ? rect["height"] : rect["width"];
      // Workaround for issue #958
      // Non-integer width causes problem, so return rounded-up value.
      return Math.ceil(width);
    });
    dummyRow.remove();
    return colWidths;
  }

  private getColGroupElements(tableElement: Element): Element[] {
    const colGroups: Element[] = [];
    let child = tableElement.firstElementChild;
    while (child) {
      if (child.localName === "colgroup") {
        colGroups.push(child);
      }
      child = child.nextElementSibling;
    }
    return colGroups;
  }

  private normalizeAndGetColElements(colGroups: Element[]): Element[] {
    const cols: Element[] = [];
    colGroups.forEach((colGroup) => {
      // Replace colgroup[span=n] with colgroup with n col elements
      let span = (colGroup as any).span;
      colGroup.removeAttribute("span");
      let col = colGroup.firstElementChild;
      while (col) {
        if (col.localName === "col") {
          // Replace col[span=n] with n col elements
          let s = (col as any).span;
          col.removeAttribute("span");
          span -= s;
          while (s-- > 1) {
            const cloned = col.cloneNode(true) as Element;
            colGroup.insertBefore(cloned, col);
            cols.push(cloned);
          }
          cols.push(col);
        }
        col = col.nextElementSibling;
      }
      while (span-- > 0) {
        col = colGroup.ownerDocument.createElement("col");
        colGroup.appendChild(col);
        cols.push(col);
      }
    });
    return cols;
  }

  private addMissingColElements(
    cols: Element[],
    colGroups: Element[],
    columnCount: number,
    tableElement: Element,
  ) {
    if (cols.length < columnCount) {
      const colGroup = tableElement.ownerDocument.createElement("colgroup");
      colGroups.push(colGroup);
      for (let i = cols.length; i < columnCount; i++) {
        const col = tableElement.ownerDocument.createElement("col");
        colGroup.appendChild(col);
        cols.push(col);
      }
    }
  }

  /**
   * Measure width of columns and normalize colgroup and col elements so that
   * each column has a corresponding col element with the width specified.
   */
  normalizeColGroups(
    formattingContext: TableFormattingContext,
    tableElement: Element,
    column: Layout.Column,
  ) {
    const vertical = formattingContext.vertical;
    const lastRow = formattingContext.lastRowViewNode;
    if (!lastRow) {
      return;
    }
    formattingContext.lastRowViewNode = null;
    const doc = lastRow.ownerDocument;
    const fragment = doc.createDocumentFragment();

    // Count columns
    const columnCount = formattingContext.getColumnCount();
    if (!(columnCount > 0)) {
      formattingContext.colGroups = fragment;
      return;
    }

    // Measure column widths
    const colWidths = (formattingContext.colWidths = this.getColumnWidths(
      lastRow,
      columnCount,
      vertical,
      column.clientLayout,
    ));

    // Normalize colgroup and col elements
    const colGroups = this.getColGroupElements(tableElement);
    const cols = this.normalizeAndGetColElements(colGroups);

    // Add missing col elements for remaining columns
    this.addMissingColElements(cols, colGroups, columnCount, tableElement);

    // Assign width to col elements
    cols.forEach((col, i) => {
      Base.setCSSProperty(
        col,
        vertical ? "height" : "width",
        `${colWidths[i]}px`,
      );
    });
    colGroups.forEach((colGroup) => {
      fragment.appendChild(colGroup.cloneNode(true));
    });
    formattingContext.colGroups = fragment;
  }

  doInitialLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    const formattingContext = getTableFormattingContext(
      nodeContext.formattingContext,
    );
    formattingContext.vertical = nodeContext.vertical;
    formattingContext.initializeRepetitiveElements(nodeContext.vertical);
    const tableLayoutOption = getTableLayoutOption(nodeContext.sourceNode);
    clearTableLayoutOptionCache(nodeContext.sourceNode);
    const frame = Task.newFrame<Vtree.NodeContext | null>(
      "TableLayoutProcessor.doInitialLayout",
    );
    const initialNodeContext = nodeContext.copy();
    this.layoutEntireTable(nodeContext, column).then((nodeContextAfter) => {
      const tableElement = nodeContextAfter.viewNode as Element;

      // CSS 2.1 §13.3.3: The first row's break-before propagates to the
      // table.  If the first row has a forced break-before and the table is
      // not at the leading edge of the page/column, trigger a page break
      // before the table so it moves to the next page.
      const firstRow = formattingContext.rows[0];
      if (
        firstRow &&
        Break.isForcedBreakValue(firstRow.breakBefore) &&
        this.hasInFlowContentBefore(tableElement, column)
      ) {
        tableElement.parentNode?.removeChild(tableElement);
        column.pageBreakType = firstRow.breakBefore;
        frame.finish(initialNodeContext);
        return;
      }

      const tableBBox = LayoutHelper.getElementClientRectAdjusted(
        column.clientLayout,
        tableElement,
        column.vertical,
      );
      let edge = column.vertical ? tableBBox.left : tableBBox.bottom;
      edge +=
        (column.vertical ? -1 : 1) *
        BreakPosition.calculateOffset(
          nodeContext,
          column.collectElementsOffset(),
        ).current;
      if (
        !column.isOverflown(edge) &&
        (!tableLayoutOption ||
          !tableLayoutOption.calculateBreakPositionsInside) &&
        !this.hasForcedBreakInRows(formattingContext)
      ) {
        column.breakPositions.push(
          new EntireTableBreakPosition(initialNodeContext),
        );
        frame.finish(nodeContextAfter);
        return;
      }
      this.normalizeColGroups(formattingContext, tableElement, column);
      frame.finish(null);
    });
    return frame.result();
  }

  /**
   * Check if any row inside the table has a forced break value
   * (propagated from cells or set on the row itself).
   */
  private hasForcedBreakInRows(
    formattingContext: TableFormattingContext,
  ): boolean {
    for (let i = 0; i < formattingContext.rows.length; i++) {
      const row = formattingContext.rows[i];
      if (!row) continue;
      // Skip the first row's breakBefore (break before the table, not inside)
      if (i > 0 && Break.isForcedBreakValue(row.breakBefore)) {
        return true;
      }
      // Skip the last row's breakAfter (break after the table, not inside)
      if (
        i < formattingContext.rows.length - 1 &&
        Break.isForcedBreakValue(row.breakAfter)
      ) {
        return true;
      }
    }
    return false;
  }

  /**
   * Check if there is any in-flow content before the given view node.
   * Walks previous siblings at each ancestor level (up to the column root)
   * to determine whether the table is at the leading edge of the
   * page/column.
   */
  private hasInFlowContentBefore(
    viewNode: Node,
    column: Layout.Column,
  ): boolean {
    let node: Node | null = viewNode;
    while (node && node !== column.element) {
      let sibling = node.previousSibling;
      while (sibling) {
        if (sibling.nodeType === 1 && !LayoutHelper.isOutOfFlow(sibling)) {
          return true;
        }
        if (sibling.nodeType === 3 && !VtreeImpl.canIgnore(sibling)) {
          return true;
        }
        sibling = sibling.previousSibling;
      }
      node = node.parentNode;
    }
    return false;
  }

  addCaptions(
    formattingContext: TableFormattingContext,
    rootViewNode: Element,
    firstChild: Node | null,
  ) {
    const captions = formattingContext.captions;
    captions.forEach((caption, i) => {
      if (caption) {
        rootViewNode.insertBefore(caption.viewNode, firstChild);
        if (caption.side === "top") {
          captions[i] = null;
        }
      }
    });
  }

  addColGroups(
    formattingContext: TableFormattingContext,
    rootViewNode: Element,
    firstChild: Node | null,
  ) {
    if (
      formattingContext.colGroups &&
      this.getColGroupElements(rootViewNode).length === 0
    ) {
      rootViewNode.insertBefore(
        formattingContext.colGroups.cloneNode(true),
        firstChild,
      );
      // Set table-layout to fixed so that the widths of the columns
      // are respected. (Fix for issue #1475)
      Base.setCSSProperty(rootViewNode, "table-layout", "fixed");
      Base.setCSSProperty(
        rootViewNode,
        formattingContext.vertical ? "height" : "width",
        `${formattingContext.tableWidth}px`,
      );
    }
  }

  removeColGroups(
    formattingContext: TableFormattingContext,
    rootViewNode: Element | null,
  ) {
    if (formattingContext.colGroups && rootViewNode) {
      const colGroups = this.getColGroupElements(rootViewNode);
      if (colGroups) {
        colGroups.forEach((colGroup) => {
          rootViewNode.removeChild(colGroup);
        });
      }
    }
  }

  doLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    const formattingContext = getTableFormattingContext(
      nodeContext.formattingContext,
    );
    const rootViewNode = formattingContext.getRootViewNode(
      nodeContext,
    ) as Element;
    const firstChild = rootViewNode.firstChild;
    this.addCaptions(formattingContext, rootViewNode, firstChild);
    this.addColGroups(formattingContext, rootViewNode, firstChild);
    const strategy = new TableLayoutStrategy(formattingContext, column);
    const iterator = new LayoutUtil.LayoutIterator(
      strategy,
      column.layoutContext,
    );
    const frame = Task.newFrame<Vtree.NodeContext | null>(
      "TableFormattingContext.doLayout",
    );
    iterator.iterate(nodeContext).thenFinish(frame);
    return frame.result();
  }

  /** @override */
  layout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
    leadingEdge: boolean,
  ): Task.Result<Vtree.NodeContext | null> {
    const formattingContext = getTableFormattingContext(
      nodeContext.formattingContext,
    );
    const rootViewNode = formattingContext.getRootViewNode(nodeContext);
    if (!rootViewNode) {
      return column.buildDeepElementView(nodeContext);
    } else {
      if (leadingEdge) {
        const repetitiveElements = formattingContext.getRepetitiveElements();
        // Issue #1980: a table can resume at a new page/column from the middle
        // of its body, so it never passes through the table-root retry path
        // below. Header-only tables would then drop their repeated thead on the
        // first continuation page unless we preserve the header here. Keep
        // footer-bearing tables on the normal skip logic, because existing
        // fixtures intentionally drop header/footer when space is too tight.
        if (
          repetitiveElements &&
          nodeContext.sourceNode !== formattingContext.tableSourceNode &&
          !nodeContext.after &&
          !repetitiveElements.isFooterRegistered()
        ) {
          repetitiveElements.preventSkippingHeader();
        }
        RepetitiveElementImpl.appendHeaderToAncestors(
          nodeContext.parent,
          column,
        );
      }
      return new LayoutRetryer(formattingContext, this).layout(
        nodeContext,
        column,
      );
    }
  }

  /** @override */
  createEdgeBreakPosition(
    position: Vtree.NodeContext,
    breakOnEdge: string | null,
    overflows: boolean,
    columnBlockSize: number,
  ): LayoutType.BreakPosition {
    return new BetweenTableRowBreakPosition(
      position,
      breakOnEdge,
      overflows,
      columnBlockSize,
    );
  }

  /** @override */
  startNonInlineElementNode(nodeContext: Vtree.NodeContext): boolean {
    return false;
  }

  /** @override */
  afterNonInlineElementNode(
    nodeContext: Vtree.NodeContext,
    stopAtOverflow: boolean,
  ): boolean {
    adjustRowHeight(nodeContext);
    return false;
  }

  /** @override */
  finishBreak(
    column: Layout.Column,
    nodeContext: Vtree.NodeContext,
    forceRemoveSelf: boolean,
    endOfColumn: boolean,
  ): Task.Result<boolean> {
    const formattingContext = getTableFormattingContext(
      nodeContext.formattingContext,
    );
    if (nodeContext.display === "table-row") {
      const rowIndex = formattingContext.findRowIndexBySourceNode(
        nodeContext.sourceNode,
      );
      let cells: TableCell[];
      if (!nodeContext.after) {
        cells = formattingContext.getCellsFallingOnRow(rowIndex);
      } else {
        cells =
          formattingContext.getRowSpanningCellsOverflowingTheRow(rowIndex);
      }
      // Only remove entries for cells that are about to be re-broken,
      // preserving break positions from other rows (e.g., from previous pages).
      // Fix for issue #1663: unconditional reset lost previous-page break info
      // during layout retry.
      formattingContext.cellBreakPositions =
        formattingContext.cellBreakPositions.filter(
          (p) => !cells.includes(p.cell),
        );
      if (cells.length) {
        const frame = Task.newFrame<boolean>(
          "TableLayoutProcessor.finishBreak",
        );
        let i = 0;
        frame
          .loopWithFrame((loopFrame) => {
            if (i === cells.length) {
              loopFrame.breakLoop();
              return;
            }
            const cell = cells[i++];
            const cellFragment = formattingContext.getCellFragmentOfCell(cell);
            const breakNodeContext =
              cellFragment.findAcceptableBreakPosition().nodeContext;
            const cellNodeContext = cellFragment.cellNodeContext;
            const cellNodePosition = cellNodeContext.toNodePosition();
            const breakChunkPosition = new VtreeImpl.ChunkPosition(
              breakNodeContext.toNodePosition(),
            );
            formattingContext.cellBreakPositions.push({
              cellNodePosition,
              breakChunkPosition,
              cell,
            } as BrokenTableCellPosition);
            const cellViewNode =
              cellNodeContext.viewNode as HTMLTableCellElement;
            cellFragment.column.layoutContext.processFragmentedBlockEdge(
              cellFragment.cellNodeContext,
            );
            if (rowIndex < cell.rowIndex + cell.rowSpan - 1) {
              cellViewNode.rowSpan = rowIndex - cell.rowIndex + 1;
            }
            if (!cellFragment.empty) {
              cellFragment.pseudoColumn
                .finishBreak(breakNodeContext, false, true)
                .then(() => {
                  adjustCellHeight(
                    cellFragment,
                    formattingContext,
                    breakNodeContext,
                  );
                  loopFrame.continueLoop();
                });
            } else {
              loopFrame.continueLoop();
            }
          })
          .then(() => {
            column.clearOverflownViewNodes(nodeContext, false);
            column.layoutContext.processFragmentedBlockEdge(nodeContext);
            adjustRowHeight(nodeContext);
            formattingContext.finishFragment();
            frame.finish(true);
          });
        return frame.result();
      }
    }
    adjustRowHeight(nodeContext);
    formattingContext.finishFragment();
    return LayoutProcessor.blockLayoutProcessor.finishBreak(
      column,
      nodeContext,
      forceRemoveSelf,
      endOfColumn,
    );
  }

  /** @override */
  clearOverflownViewNodes(
    column: Layout.Column,
    parentNodeContext: Vtree.NodeContext,
    nodeContext: Vtree.NodeContext,
    removeSelf: boolean,
  ) {
    LayoutProcessor.BlockLayoutProcessor.prototype.clearOverflownViewNodes(
      column,
      parentNodeContext,
      nodeContext,
      removeSelf,
    );
  }
}

function adjustCellHeight(
  cellFragment: TableCellFragment,
  formattingContext: TableFormattingContext,
  breakNodeContext: Vtree.NodeContext,
): void {
  const repetitiveElements = formattingContext.getRepetitiveElements();
  if (
    !repetitiveElements ||
    !(
      repetitiveElements.isHeaderRegistered() ||
      repetitiveElements.isFooterRegistered()
    ) // Fix for issue #1458, case 1
  ) {
    return;
  }
  const vertical = formattingContext.vertical;
  const column = cellFragment.column;
  const cellContentElement = cellFragment.pseudoColumn.getColumnElement();
  const cellElement = cellFragment.cellNodeContext.viewNode as Element;
  const cellElementRect = LayoutHelper.getElementClientRectAdjusted(
    column.clientLayout,
    cellElement,
    vertical,
  );
  const padding = column.getComputedPaddingBorder(cellElement);
  if (vertical) {
    const width =
      cellElementRect.right -
      column.footnoteEdge -
      repetitiveElements.calculateOffset(breakNodeContext) -
      padding.right;
    Base.setCSSProperty(cellContentElement, "max-width", `${width}px`);
  } else {
    const height =
      column.footnoteEdge -
      repetitiveElements.calculateOffset(breakNodeContext) -
      cellElementRect.top -
      padding.top;
    Base.setCSSProperty(cellContentElement, "max-height", `${height}px`);
  }
}

/**
 * When a table cell has vertical-align: baseline and its content wrapper
 * contains only out-of-flow children (position: absolute/fixed), the wrapper
 * generates a spurious baseline from whitespace text nodes. This causes the
 * browser's baseline alignment to incorrectly shift the absolutely positioned
 * elements' static positions. Fix by setting the wrapper to display: contents
 * so it becomes transparent to the box model and the browser can apply its
 * table-cell baseline static-position fix correctly.
 */
function fixTableCellWrapperForBaseline(cellViewNode: Element): void {
  // Find the table cell element (cellViewNode may be the wrapper div itself
  // due to the shadow/template model, not the <td>)
  const cellElement = cellViewNode.matches("td, th")
    ? cellViewNode
    : cellViewNode.closest("td, th");
  if (!cellElement) {
    return;
  }
  const cellStyle = (cellElement as HTMLElement).style;
  if (cellStyle.verticalAlign !== "baseline") {
    return;
  }
  const wrapper = cellElement.querySelector(
    ".-vivliostyle-table-cell-container",
  );
  if (!wrapper) {
    return;
  }
  const children = wrapper.children;
  if (children.length === 0) {
    return;
  }
  for (let i = 0; i < children.length; i++) {
    const pos = (children[i] as HTMLElement).style.position;
    if (pos !== "absolute" && pos !== "fixed") {
      return;
    }
  }
  Base.setCSSProperty(wrapper, "display", "contents");
}

/**
 * Adjusts the height of a table row to prevent another preceding row
 * containing fragmented rowspanning cells and dummy empty cells which
 * should have zero height from having non-zero height due to
 * Chromium's behavior when rowspanning cells exist.
 * (Fix for issue #1458, case 3)
 *
 * @param nodeContext - node context of table or table-row
 */
function adjustRowHeight(nodeContext: Vtree.NodeContext): void {
  const display = nodeContext.display;
  if (display !== "table-row" && display !== "table") {
    return;
  }
  const elementContext = VtreeImpl.asElementNodeContext(nodeContext);
  Asserts.assert(elementContext);
  const tbodyElement =
    display === "table-row"
      ? elementContext.viewNode.parentElement
      : elementContext.viewNode.querySelector("tbody");
  if (!tbodyElement) {
    return;
  }
  // Find row elements that only have rowspanning cells and empty cells.
  let spanStartRows: NodeListOf<HTMLTableRowElement>;
  try {
    spanStartRows = tbodyElement.querySelectorAll(
      ":scope>tr:has(>:empty):not(:has(>:not([rowspan]:not([rowspan='1']),:empty)))",
    );
  } catch {
    // Do nothing if the browser does not support `:has()` to avoid error.
    // (Workaround for issue #1509)
    return;
  }
  if (spanStartRows.length === 0) {
    return;
  }
  const spanStartRowHeight = Array.from(spanStartRows).reduce(
    (totalHeight, rowElement) => {
      const rect = rowElement.getBoundingClientRect();
      const height = nodeContext.vertical ? rect.width : rect.height;
      return totalHeight + height;
    },
    0,
  );
  const spanStartLastRow = spanStartRows[spanStartRows.length - 1];
  const spanStartLastRowIndex = Array.from(tbodyElement.children).indexOf(
    spanStartLastRow,
  );
  const rowSpan = Array.from(spanStartLastRow.children).reduce((r, cell) => {
    const span = (cell as HTMLTableCellElement).rowSpan;
    return span > 1 &&
      spanStartLastRowIndex + span < tbodyElement.childElementCount
      ? Math.max(r, span)
      : r;
  }, 0);
  // Find the row element that needs to be adjusted.
  let rowToBeAdjusted = rowSpan
    ? tbodyElement.children[spanStartLastRowIndex + rowSpan - 1]
    : tbodyElement.lastElementChild;
  if (
    rowToBeAdjusted != tbodyElement.lastElementChild &&
    rowToBeAdjusted.querySelector(":scope>*>div>div")
  ) {
    for (
      let row: Element | null = rowToBeAdjusted;
      row && row !== tbodyElement.lastElementChild;
      row = row.nextElementSibling
    ) {
      if (row.querySelector(":scope>[rowspan]:not([rowspan='1'])")) {
        rowToBeAdjusted = row;
        break;
      }
    }
  }
  const rowRect = rowToBeAdjusted.getBoundingClientRect();
  const rowHeight = nodeContext.vertical ? rowRect.width : rowRect.height;
  const newRowHeight = spanStartRowHeight + rowHeight;
  Base.setCSSProperty(
    rowToBeAdjusted,
    nodeContext.vertical ? "width" : "height",
    `${newRowHeight}px`,
  );
}

export class LayoutRetryer extends LayoutRetryers.AbstractLayoutRetryer {
  constructor(
    private tableFormattingContext: TableFormattingContext,
    private readonly processor: TableLayoutProcessor,
  ) {
    super();
  }

  override resolveLayoutMode(
    nodeContext: Vtree.NodeContext,
  ): LayoutType.LayoutMode {
    const repetitiveElements =
      this.tableFormattingContext.getRepetitiveElements();
    if (!repetitiveElements || !repetitiveElements.doneInitialLayout) {
      return new LayoutEntireTable(this.tableFormattingContext, this.processor);
    } else {
      // The unconditional preserve-header path stays limited to table-root
      // retries; mid-table continuations are handled at the leading edge above.
      if (
        nodeContext.sourceNode ===
          this.tableFormattingContext.tableSourceNode &&
        !nodeContext.after
      ) {
        if (repetitiveElements) {
          repetitiveElements.preventSkippingHeader();
        }
      }
      return new LayoutFragmentedTable(
        this.tableFormattingContext,
        this.processor,
      );
    }
  }

  override clearNodes(initialPosition: Vtree.NodeContext) {
    super.clearNodes(initialPosition);
    const rootViewNode =
      this.tableFormattingContext.getRootViewNode(initialPosition);
    this.processor.removeColGroups(this.tableFormattingContext, rootViewNode);
  }

  override restoreState(nodeContext: Vtree.NodeContext, column: Layout.Column) {
    super.restoreState(nodeContext, column);
    this.tableFormattingContext.finishFragment();
  }
}

export class LayoutEntireTable extends RepetitiveElementImpl.LayoutEntireBlock {
  constructor(
    formattingContext: TableFormattingContext,
    public readonly processor: TableLayoutProcessor,
  ) {
    super(formattingContext);
  }

  override doLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    return this.processor.doInitialLayout(nodeContext, column);
  }
}

export class EntireTableBreakPosition extends BreakPosition.EdgeBreakPosition {
  constructor(tableNodeContext: Vtree.NodeContext) {
    super(tableNodeContext, null, tableNodeContext.overflow, 0);
  }

  override getMinBreakPenalty(): number {
    if (!this.isEdgeUpdated) {
      throw new Error("EdgeBreakPosition.prototype.updateEdge not called");
    }
    return (
      (this.overflows ? 3 : 0) +
      (this.position.parent ? this.position.parent.breakPenalty : 0)
    );
  }

  override breakPositionChosen(column: Layout.Column): void {
    column.fragmentLayoutConstraints.push(
      new EntireTableLayoutConstraint(this.position.sourceNode),
    );
  }
}

export class EntireTableLayoutConstraint
  implements Layout.FragmentLayoutConstraint
{
  flagmentLayoutConstraintType: FragmentLayoutConstraintType = "EntireTable";

  constructor(public tableRootNode: Node) {}

  /** @override */
  allowLayout(
    nodeContext: Vtree.NodeContext,
    overflownNodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): boolean {
    // If the nodeContext overflows, any EntireTableLayoutConstraint should not
    // be registered in the first place. See
    // TableLayoutProcessor.prototype.doInitialLayout.

    Asserts.assert(!nodeContext.overflow);
    return false;
  }

  /** @override */
  nextCandidate(nodeContext: Vtree.NodeContext): boolean {
    return true;
  }

  /** @override */
  postLayout(
    allowed: boolean,
    positionAfter: Vtree.NodeContext,
    initialPosition: Vtree.NodeContext,
    column: Layout.Column,
  ) {
    tableLayoutOptionCache.push({
      root: positionAfter.sourceNode,
      tableLayoutOption: {
        calculateBreakPositionsInside: true,
      } as TableLayoutOption,
    });
  }

  /** @override */
  finishBreak(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<boolean> {
    return Task.newResult(true);
  }

  /** @override */
  equalsTo(constraint: Layout.FragmentLayoutConstraint): boolean {
    return (
      constraint instanceof EntireTableLayoutConstraint &&
      constraint.tableRootNode === this.tableRootNode
    );
  }

  /** @override */
  getPriorityOfFinishBreak(): number {
    return 0;
  }
}

export class LayoutFragmentedTable
  extends RepetitiveElementImpl.LayoutFragmentedBlock
{
  constructor(
    formattingContext: TableFormattingContext,
    public readonly processor: TableLayoutProcessor,
  ) {
    super(formattingContext);
  }

  override doLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    const repetitiveElements = this.formattingContext.getRepetitiveElements();
    if (
      repetitiveElements &&
      !repetitiveElements.isAfterLastContent(nodeContext)
    ) {
      const constraint = new TableRowLayoutConstraint(nodeContext);
      if (
        !column.fragmentLayoutConstraints.some((c) => constraint.equalsTo(c))
      ) {
        column.fragmentLayoutConstraints.unshift(constraint);
      }
    }
    return this.processor.doLayout(nodeContext, column);
  }
}

export class TableRowLayoutConstraint
  extends RepetitiveElementImpl.RepetitiveElementsOwnerLayoutConstraint
  implements Table.TableRowLayoutConstraint
{
  flagmentLayoutConstraintType: FragmentLayoutConstraintType = "TableRow";
  cellFragmentLayoutConstraints: {
    constraints: Layout.FragmentLayoutConstraint[];
    breakPosition: Vtree.NodeContext | null;
  }[] = [];

  constructor(nodeContext: Vtree.NodeContext) {
    super(nodeContext);
  }

  override allowLayout(
    nodeContext: Vtree.NodeContext,
    overflownNodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): boolean {
    const repetitiveElements = this.getRepetitiveElements();
    if (!repetitiveElements) {
      return true;
    }
    if (column.pseudoParent) {
      return true;
    }
    if (LayoutHelper.isOrphan(this.nodeContext.viewNode)) {
      return true;
    }
    if (!repetitiveElements.isEnableToUpdateState()) {
      return true;
    }
    if (
      (overflownNodeContext && !nodeContext) ||
      (nodeContext && nodeContext.overflow)
    ) {
      return !RepetitiveElementImpl.isOverflowInsideRepetitiveElementsOwner(
        nodeContext,
        overflownNodeContext,
        repetitiveElements,
      );
    } else {
      return true;
    }
  }

  override nextCandidate(nodeContext: Vtree.NodeContext): boolean {
    const formattingContext = getTableFormattingContext(
      this.nodeContext.formattingContext,
    );
    const cellFragmentConstraints = this.collectCellFragmentLayoutConstraints(
      nodeContext,
      formattingContext,
    );
    if (
      cellFragmentConstraints.some((entry) =>
        entry.constraints.some((constraint) =>
          constraint.nextCandidate(nodeContext),
        ),
      )
    ) {
      return true;
    }
    return super.nextCandidate(nodeContext);
  }

  override postLayout(
    allowed: boolean,
    positionAfter: Vtree.NodeContext,
    initialPosition: Vtree.NodeContext,
    column: Layout.Column,
  ) {
    const formattingContext = getTableFormattingContext(
      this.nodeContext.formattingContext,
    );
    this.cellFragmentLayoutConstraints =
      this.collectCellFragmentLayoutConstraints(
        positionAfter,
        formattingContext,
      );
    this.cellFragmentLayoutConstraints.forEach((entry) => {
      entry.constraints.forEach((constraint) => {
        constraint.postLayout(
          allowed,
          entry.breakPosition,
          initialPosition,
          column,
        );
      });
    });
    if (!allowed) {
      const rootViewNode = formattingContext.getRootViewNode(this.nodeContext);
      new TableLayoutProcessor().removeColGroups(
        formattingContext,
        rootViewNode as Element,
      );
      this.removeDummyRowNodes(initialPosition);
    }
    super.postLayout(allowed, positionAfter, initialPosition, column);
  }

  override finishBreak(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<boolean> {
    getTableFormattingContext(this.nodeContext.formattingContext);
    const frame: Task.Frame<boolean> = Task.newFrame("finishBreak");
    const constraints = this.cellFragmentLayoutConstraints.flatMap((entry) =>
      entry.constraints.map((constraint) => ({
        constraint,
        breakPosition: entry.breakPosition,
      })),
    );
    let i = 0;
    frame
      .loop(() => {
        if (i < constraints.length) {
          const entry = constraints[i++];
          return entry.constraint
            .finishBreak(entry.breakPosition, column)
            .thenReturn(true);
        } else {
          return Task.newResult(false);
        }
      })
      .then(() => {
        frame.finish(true);
      });
    return frame
      .result()
      .thenAsync(() => super.finishBreak(nodeContext, column));
  }

  removeDummyRowNodes(nodeContext: Vtree.NodeContext) {
    if (
      !nodeContext ||
      nodeContext.display !== "table-row" ||
      !nodeContext.viewNode
    ) {
      return;
    }
    while ((nodeContext.viewNode as Element).previousElementSibling) {
      const dummyNode = (nodeContext.viewNode as Element)
        .previousElementSibling;
      if (dummyNode.parentNode) {
        dummyNode.parentNode.removeChild(dummyNode);
      }
    }
  }

  private collectCellFragmentLayoutConstraints(
    nodeContext: Vtree.NodeContext,
    formattingContext: TableFormattingContext,
  ): {
    constraints: Layout.FragmentLayoutConstraint[];
    breakPosition: Vtree.NodeContext | null;
  }[] {
    return this.getCellFragemnts(nodeContext, formattingContext).map(
      (entry) => ({
        constraints:
          entry.fragment.pseudoColumn.getColumn().fragmentLayoutConstraints,
        breakPosition: entry.breakPosition,
      }),
    );
  }

  private getCellFragemnts(
    nodeContext: Vtree.NodeContext,
    formattingContext: TableFormattingContext,
  ): {
    fragment: TableCellFragment;
    breakPosition: Vtree.NodeContext | null;
  }[] {
    let rowIndex = Number.MAX_VALUE;
    if (nodeContext && nodeContext.display === "table-row") {
      rowIndex =
        formattingContext.findRowIndexBySourceNode(nodeContext.sourceNode) + 1;
    }
    rowIndex = Math.min(formattingContext.cellFragments.length, rowIndex);
    const cellFragments: {
      fragment: TableCellFragment;
      breakPosition: Vtree.NodeContext | null;
    }[] = [];
    for (let i = 0; i < rowIndex; i++) {
      if (!formattingContext.cellFragments[i]) {
        continue;
      }
      formattingContext.cellFragments[i].forEach((cellFragment) => {
        if (!cellFragment) {
          return;
        }
        cellFragments.push({
          fragment: cellFragment,
          breakPosition: cellFragment.findAcceptableBreakPosition().nodeContext,
        });
      });
    }
    return cellFragments;
  }

  getElementsOffsetsForTableCell(
    column: Layout.Column | null,
  ): RepetitiveElement.ElementsOffset[] {
    const formattingContext = getTableFormattingContext(
      this.nodeContext.formattingContext,
    );
    const position = formattingContext.findCellFromColumn(column);
    if (position) {
      return formattingContext.collectElementsOffsetOfUpperCells(position);
    } else {
      return formattingContext.collectElementsOffsetOfHighestColumn();
    }
  }

  override equalsTo(constraint: Layout.FragmentLayoutConstraint): boolean {
    if (!(constraint instanceof TableRowLayoutConstraint)) {
      return false;
    }
    return (
      getTableFormattingContext(this.nodeContext.formattingContext) ===
      getTableFormattingContext(constraint.nodeContext.formattingContext)
    );
  }
}

const tableLayoutProcessor = new TableLayoutProcessor();

function resolveFormattingContextHook(
  nodeContext: Vtree.NodeContext,
  firstTime: boolean,
  display: Css.Ident,
  position: Css.Ident,
  floatSide: Css.Val,
  isRoot: boolean,
): TableFormattingContext | null {
  if (!firstTime) {
    return null;
  }
  if (display === Css.ident.table) {
    const parent = nodeContext.parent;
    return new TableFormattingContext(
      parent ? parent.formattingContext : null,
      nodeContext.sourceNode as Element,
    );
  }
  return null;
}

function resolveLayoutProcessor(
  formattingContext,
): TableLayoutProcessor | null {
  if (formattingContext instanceof TableFormattingContext) {
    return tableLayoutProcessor;
  }
  return null;
}

Plugin.registerHook(
  Plugin.HOOKS.RESOLVE_FORMATTING_CONTEXT,
  resolveFormattingContextHook,
);

Plugin.registerHook(
  Plugin.HOOKS.RESOLVE_LAYOUT_PROCESSOR,
  resolveLayoutProcessor,
);
