/**
 * Copyright 2021 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview TextPolyfill - CSS text-spacing and hanging-punctuation support.
 */
import * as Asserts from "./asserts";
import * as Base from "./base";
import * as Css from "./css";
import * as LayoutHelper from "./layout-helper";
import * as Plugin from "./plugin";
import * as PseudoElement from "./pseudo-element";
import * as RangeClientRects from "./range-client-rects";
import * as Vtree from "./vtree";

type PropertyValue = string | number | Css.Val | undefined;

type HangingPunctuation = {
  first: boolean;
  forceEnd: boolean; // force-end
  allowEnd: boolean; // allow-end
  last: boolean;
};

const HANGING_PUNCTUATION_NONE: HangingPunctuation = {
  first: false,
  forceEnd: false,
  allowEnd: false,
  last: false,
};

function hangingPunctuationFromPropertyValue(
  value: PropertyValue,
): HangingPunctuation {
  const cssval =
    value instanceof Css.Val
      ? value
      : typeof value === "string"
        ? Css.getName(value)
        : Css.ident.none;

  if (cssval === Css.ident.none) {
    return HANGING_PUNCTUATION_NONE;
  }
  const values = cssval instanceof Css.SpaceList ? cssval.values : [cssval];
  const hangingPunctuation: HangingPunctuation = Object.create(
    HANGING_PUNCTUATION_NONE,
  );

  for (const val of values) {
    if (val instanceof Css.Ident) {
      switch (val.name) {
        case "first":
          hangingPunctuation.first = true;
          break;
        case "force-end":
          hangingPunctuation.forceEnd = true;
          hangingPunctuation.allowEnd = false;
          break;
        case "allow-end":
          hangingPunctuation.forceEnd = false;
          hangingPunctuation.allowEnd = true;
          break;
        case "last":
          hangingPunctuation.last = true;
          break;
      }
    }
  }
  return hangingPunctuation;
}

function isHangingPunctuationNone(
  hangingPunctuation: HangingPunctuation,
): boolean {
  return (
    !hangingPunctuation.first &&
    !hangingPunctuation.last &&
    !hangingPunctuation.forceEnd &&
    !hangingPunctuation.allowEnd
  );
}

type SpacingTrim = {
  trimStart: boolean; // trim-start
  spaceFirst: boolean; // space-first
  trimEnd: boolean; // trim-end
  allowEnd: boolean; // allow-end
  trimAdjacent: boolean; // trim-adjacent
  // TODO: add support for:
  //   trimAll: boolean; // trim-all
};

/**
 * text-spacing-trim: space-all
 * space-all = space-start space-end space-adjacent
 */
const SPACING_TRIM_NONE: SpacingTrim = {
  trimStart: false,
  spaceFirst: false,
  trimEnd: false,
  allowEnd: false,
  trimAdjacent: false,
};

/**
 * text-spacing-trim: normal
 * normal = space-start allow-end trim-adjacent
 */
const SPACING_TRIM_NORMAL: SpacingTrim = {
  trimStart: false,
  spaceFirst: false,
  trimEnd: false,
  allowEnd: true,
  trimAdjacent: true,
};

/**
 * text-spacing-trim: trim-both
 * trim-both = trim-start trim-end trim-adjacent
 *
 * NOTE: Values `trim-auto` (deprecated) and `auto` are treated as `trim-both`.
 */
const SPACING_TRIM_BOTH: SpacingTrim = {
  trimStart: true,
  spaceFirst: false,
  trimEnd: true,
  allowEnd: false,
  trimAdjacent: true,
};

function spacingTrimFromPropertyValue(value: PropertyValue): SpacingTrim {
  const cssval =
    value instanceof Css.Val
      ? value
      : typeof value === "string"
        ? Css.getName(value)
        : Css.ident.normal;

  if (cssval === Css.ident.normal) {
    return SPACING_TRIM_NORMAL;
  }
  if (cssval === Css.ident.auto) {
    return SPACING_TRIM_BOTH;
  }
  const values = cssval instanceof Css.SpaceList ? cssval.values : [cssval];
  const textSpacing: SpacingTrim = Object.create(SPACING_TRIM_NORMAL);

  for (const val of values) {
    if (val instanceof Css.Ident) {
      switch (val.name) {
        case "trim-both":
        case "trim-auto":
          return SPACING_TRIM_BOTH;
        case "space-all":
          return SPACING_TRIM_NONE;
        case "trim-start":
          textSpacing.trimStart = true;
          textSpacing.spaceFirst = false;
          break;
        case "space-start":
          textSpacing.trimStart = false;
          textSpacing.spaceFirst = false;
          break;
        case "space-first":
          textSpacing.trimStart = false;
          textSpacing.spaceFirst = true;
          break;
        case "trim-end":
          textSpacing.trimEnd = true;
          textSpacing.allowEnd = false;
          break;
        case "space-end":
          textSpacing.trimEnd = false;
          textSpacing.allowEnd = false;
          break;
        case "allow-end":
          textSpacing.trimEnd = false;
          textSpacing.allowEnd = true;
          break;
        case "trim-adjacent":
          textSpacing.trimAdjacent = true;
          break;
        case "space-adjacent":
          textSpacing.trimAdjacent = false;
          break;
      }
    }
  }

  return textSpacing;
}

type Autospace = {
  ideographAlpha: boolean;
  ideographNumeric: boolean;
  // TODO: add support for:
  //   punctuation: boolean;
  //   replace: boolean;
};

/**
 * text-autospace: no-autospace (none)
 */
const AUTOSPACE_NONE: Autospace = {
  ideographAlpha: false,
  ideographNumeric: false,
};

/**
 * text-autospace: normal
 */
const AUTOSPACE_NORMAL: Autospace = {
  ideographAlpha: true,
  ideographNumeric: true,
};

function autospaceFromPropertyValue(value: PropertyValue): Autospace {
  const cssval =
    value instanceof Css.Val
      ? value
      : typeof value === "string"
        ? Css.getName(value)
        : Css.ident.normal;

  if (cssval === Css.ident.normal || cssval === Css.ident.auto) {
    return AUTOSPACE_NORMAL;
  }
  if (cssval === Css.ident.none) {
    return AUTOSPACE_NONE;
  }

  const values = cssval instanceof Css.SpaceList ? cssval.values : [cssval];
  const autospace: Autospace = Object.create(AUTOSPACE_NONE);

  for (const val of values) {
    if (val instanceof Css.Ident) {
      switch (val.name) {
        case "no-autospace":
          return AUTOSPACE_NONE;
        case "ideograph-alpha":
          autospace.ideographAlpha = true;
          break;
        case "ideograph-numeric":
          autospace.ideographNumeric = true;
          break;
      }
    }
  }

  return autospace;
}

function isTextSpacingNone(
  autospace: Autospace,
  spacingTrim: SpacingTrim,
): boolean {
  return (
    !autospace.ideographAlpha &&
    !autospace.ideographNumeric &&
    !spacingTrim.trimStart &&
    !spacingTrim.spaceFirst &&
    !spacingTrim.trimEnd &&
    !spacingTrim.allowEnd &&
    !spacingTrim.trimAdjacent
  );
}

function normalizeLang(lang: string | null | undefined): string | null {
  if (lang) {
    // Normalize CJK lang
    lang = lang.toLowerCase();
    if (/^zh\b.*-(hant|tw|hk)\b/.test(lang)) {
      return "zh-hant";
    }
    if (/^zh\b/.test(lang)) {
      return "zh-hans";
    }
    if (/^ja\b/.test(lang)) {
      return "ja";
    }
    if (/^ko\b/.test(lang)) {
      return "ko";
    }
    return lang;
  }
  return null;
}

/**
 * Find the block container establishing the inline formatting context that
 * the node participates in.
 */
function findBlockContainer(node: Node): HTMLElement | null {
  const window = node.ownerDocument?.defaultView;
  if (!window) {
    return null;
  }
  for (let elem = node.parentElement; elem; elem = elem.parentElement) {
    if (elem.hasAttribute("data-vivliostyle-column")) {
      return elem;
    }
    const { display } = window.getComputedStyle(elem);
    if (
      display !== "inline" &&
      display !== "contents" &&
      !display.startsWith("ruby")
    ) {
      return elem;
    }
  }
  return null;
}

/**
 * Force the block to be laid out from scratch.
 *
 * After the `viv-ts-*` elements are inserted, the browser may reuse cached
 * shaping results and break lines differently than it does on a fresh layout,
 * so measuring the block as-is would paginate against a layout that changes
 * later. (Issue #2142)
 */
function reshapeBlockContainer(element: HTMLElement): void {
  const savedFontKerning = element.style.fontKerning;
  const { fontKerning } =
    element.ownerDocument.defaultView.getComputedStyle(element);
  element.style.fontKerning = fontKerning === "none" ? "normal" : "none";
  element.offsetHeight; // force layout so that restoring the value re-shapes
  element.style.fontKerning = savedFontKerning;
}

const CHROMIUM_VO_TR_FALLBACK_PATTERN = /^[‘’“”〰﹙﹚﹛﹜﹝﹞〚〛]\p{M}*$/u;
const CHROMIUM_VO_TR_FALLBACK_OPEN_PATTERN = /^[‘“﹙﹛﹝〚]\p{M}*$/u;

function isChromiumVoTrFallback(text: string, vertical: boolean): boolean {
  return (
    Base.browserType === "chromium" &&
    vertical &&
    CHROMIUM_VO_TR_FALLBACK_PATTERN.test(text)
  );
}

function getChromiumVoTrFallbackTagName(
  text: string,
): "viv-ts-open" | "viv-ts-close" {
  // Reuse the existing open/close wrapper tags only to isolate the character.
  // Fallback-only nodes return before text-spacing/hanging classes are assigned,
  // so this tag choice does not change spacing behavior.
  return CHROMIUM_VO_TR_FALLBACK_OPEN_PATTERN.test(text)
    ? "viv-ts-open"
    : "viv-ts-close";
}

class TextSpacingPolyfill {
  getPolyfilledInheritedProps() {
    return ["hanging-punctuation", "text-autospace", "text-spacing-trim"];
  }

  preprocessSingleDocument(document: Document): void {
    if (!document.body) {
      return;
    }
    this.preprocessForTextSpacing(document.body);
  }

  preprocessForTextSpacing(element: Element): void {
    // Split text nodes by punctuations and ideograph/non-ideograph boundary
    const walker = element.ownerDocument.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
    );
    for (
      let node = walker.nextNode() as Text | null;
      node;
      node = walker.nextNode() as Text | null
    ) {
      const parentElem = node.parentElement;
      if (
        !parentElem ||
        parentElem.namespaceURI !== Base.NS.XHTML ||
        parentElem.dataset?.["mathTypeset"] === "true"
      ) {
        continue;
      }
      const textArr = node.textContent
        .replace(
          /(?![()\[\]{}])[\p{Ps}\p{Pe}\p{Pf}\p{Pi}、。，．：；､｡\u3000\u3030]\p{M}*(?=\P{M})|.(?=(?![()\[\]{}])[\p{Ps}\p{Pe}\p{Pf}\p{Pi}、。，．：；､｡\u3000\u3030])|(?!\p{P})[\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF]\p{M}*(?=(?![\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF\uFF01-\uFF60])[\p{L}\p{Nd}])|(?![\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF\uFF01-\uFF60])[\p{L}\p{Nd}]\p{M}*(?=(?!\p{P})[\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF])/gsu,
          "$&\x00",
        )
        .split("\x00");

      if (textArr.length > 1) {
        const lastIndex = textArr.length - 1;
        for (let i = 0; i < lastIndex; i++) {
          node.before(document.createTextNode(textArr[i]));
        }
        node.textContent = textArr[lastIndex];
      }
    }
  }

  processGeneratedContent(
    element: HTMLElement,
    autospaceVal: Css.Val,
    spacingTrimVal: Css.Val,
    hangingPunctuationVal: Css.Val,
    lang: string | null,
    vertical: boolean,
  ): void {
    lang = normalizeLang(lang);
    const autospace = autospaceFromPropertyValue(autospaceVal);
    const spacingTrim = spacingTrimFromPropertyValue(spacingTrimVal);
    const hangingPunctuation = hangingPunctuationFromPropertyValue(
      hangingPunctuationVal,
    );

    if (
      isHangingPunctuationNone(hangingPunctuation) &&
      isTextSpacingNone(autospace, spacingTrim)
    ) {
      return;
    }

    this.preprocessForTextSpacing(element);

    const whiteSpaceSave = element.style.whiteSpace;
    if ((vertical ? element.offsetHeight : element.offsetWidth) === 0) {
      // Prevent wrong line wrapping
      element.style.whiteSpace = "pre";
    }

    const walker = element.ownerDocument.createTreeWalker(
      element,
      NodeFilter.SHOW_TEXT,
    );
    let prevNode: Text | null = null;
    let nextNode: Text | null = null;
    for (let node = walker.nextNode() as Text | null; node; node = nextNode) {
      nextNode = walker.nextNode() as Text | null;
      const isFirstInBlock = !prevNode;
      const isFirstAfterForcedLineBreak =
        !prevNode || prevNode.textContent.endsWith("\n");
      const isLastBeforeForcedLineBreak =
        !nextNode || nextNode.textContent.startsWith("\n");
      const isLastInBlock = !nextNode;
      this.processTextSpacing(
        node,
        isFirstInBlock || isFirstAfterForcedLineBreak,
        isFirstInBlock,
        isFirstAfterForcedLineBreak,
        isLastBeforeForcedLineBreak,
        isLastInBlock,
        prevNode,
        nextNode,
        autospace,
        spacingTrim,
        hangingPunctuation,
        lang,
        vertical,
      );
      prevNode = node;
    }

    element.style.whiteSpace = whiteSpaceSave;
  }

  postLayoutBlock(
    nodeContext: Vtree.NodeContext,
    checkPoints: Vtree.RenderedNodeContext[],
  ): void {
    const isFirstFragment =
      !nodeContext ||
      (nodeContext.fragmentIndex === 1 && checkIfFirstInBlock());
    const isAfterForcedLineBreak =
      isFirstFragment || checkIfAfterForcedLineBreak();

    function isOutOfLine(node: Node): boolean {
      if (node?.nodeType !== 1) {
        return false;
      }
      const elem = node as HTMLElement;
      if (elem.hasAttribute(LayoutHelper.SPECIAL_ATTR)) {
        return true;
      }
      const { position, float } = elem.style ?? {};
      return (
        position === "absolute" ||
        position === "fixed" ||
        !!(float && float !== "none")
      );
    }

    function checkIfFirstInBlock(): boolean {
      const p = checkPoints[0];
      for (let pp: Vtree.NodeContext | null = p; ; pp = pp.parent) {
        if (!pp || !pp.inline) {
          if (pp?.fragmentIndex !== 1) {
            // This block is not the first fragment
            return false;
          }
          break;
        }
      }
      if (!p.inline) {
        // This is at the start of the block
        return true;
      }
      for (
        let prev = p.viewNode.previousSibling;
        prev;
        prev = prev.previousSibling
      ) {
        if (Vtree.canIgnore(prev, p.whitespace)) {
          continue;
        }
        if (!isOutOfLine(prev)) {
          return false;
        }
      }
      return true;
    }

    function findPrevNodeAtFragmentStart(): {
      nodeContext: Vtree.NodeContext;
      prevNode: Node;
    } | null {
      for (
        let p: Vtree.NodeContext | null = checkPoints[0];
        p && p.inline;
        p = p.parent
      ) {
        const sibling = p.viewNode?.previousSibling;
        const prevNode =
          sibling &&
          sibling.nodeType === Node.TEXT_NODE &&
          /^[ \t\r\n\f]*$/.test(sibling.textContent) &&
          p.whitespace !== Vtree.Whitespace.PRESERVE
            ? sibling.previousSibling
            : sibling;
        if (prevNode) {
          return { nodeContext: p, prevNode };
        }
      }
      return null;
    }

    function checkIfAfterForcedLineBreak(): boolean {
      const found = findPrevNodeAtFragmentStart();
      if (!found) {
        return false;
      }
      const p = found.nodeContext;
      for (
        let prevNode: Node | null = found.prevNode;
        prevNode;
        prevNode = prevNode.lastChild
      ) {
        if (prevNode.nodeType === Node.ELEMENT_NODE) {
          if ((prevNode as Element).localName === "br") {
            return true;
          }
          const display = (prevNode as HTMLElement).style?.display;
          if (display && display !== "inline") {
            return !/^(inline|ruby)\b/.test(display);
          }
        } else if (prevNode.nodeType === Node.TEXT_NODE) {
          if (p.whitespace === Vtree.Whitespace.PRESERVE) {
            if (prevNode.textContent?.endsWith("\n")) {
              return true;
            }
          } else if (p.whitespace === Vtree.Whitespace.NEWLINE) {
            if (/\n[ \t\r\n\f]*$/.test(prevNode.textContent)) {
              return true;
            }
          }
        }
      }
      return false;
    }

    let iFirst = -1;
    const reshapeTargets = new Set<HTMLElement>();
    for (let i = 0; i < checkPoints.length; i++) {
      const p = checkPoints[i];
      const textP =
        !p.after && p.inline && !p.display ? Vtree.asTextNodeContext(p) : null;
      if (
        textP &&
        textP.viewNode.parentNode &&
        !Vtree.canIgnore(textP.viewNode, textP.whitespace)
      ) {
        if (iFirst < 0) {
          iFirst = i;
        }
        const lang = normalizeLang(
          textP.lang ??
            textP.parent.lang ??
            nodeContext?.lang ??
            nodeContext?.parent?.lang,
        );
        const autospace = autospaceFromPropertyValue(
          textP.inheritedProps["text-autospace"],
        );
        const spacingTrim = spacingTrimFromPropertyValue(
          textP.inheritedProps["text-spacing-trim"],
        );
        const hangingPunctuation = hangingPunctuationFromPropertyValue(
          textP.inheritedProps["hanging-punctuation"],
        );

        if (
          isHangingPunctuationNone(hangingPunctuation) &&
          isTextSpacingNone(autospace, spacingTrim)
        ) {
          continue;
        }
        if (/\b(flex|grid)\b/.test(textP.parent.display ?? "")) {
          // Cannot process if parent is flex or grid. (Issue #926)
          continue;
        }
        let prevNode: Node | null = null;
        let nextNode: Node | null = null;
        let isFirstAfterBreak = i === iFirst;
        let isFirstInBlock = i === iFirst && isFirstFragment;
        let isFirstAfterForcedLineBreak =
          i === iFirst && isAfterForcedLineBreak;
        let isLastBeforeForcedLineBreak = false;
        let isLastInBlock = false;

        function checkIfFirstAfterForcedLineBreak(
          prevP: Vtree.NodeContext,
        ): boolean {
          if (prevP.viewNode?.nodeType === Node.ELEMENT_NODE) {
            return (prevP.viewNode as Element).localName === "br";
          }
          if (prevP.viewNode?.nodeType === Node.TEXT_NODE) {
            const prevTextNode = prevP.viewNode as Text;
            if (prevP.whitespace === Vtree.Whitespace.PRESERVE) {
              if (prevTextNode.textContent?.endsWith("\n")) {
                return true;
              }
            } else if (prevP.whitespace === Vtree.Whitespace.NEWLINE) {
              if (/\n[ \t\r\n\f]*$/.test(prevTextNode.textContent)) {
                return true;
              }
            }
            if (prevTextNode.previousElementSibling?.localName === "br") {
              return Vtree.canIgnore(prevTextNode, prevP.whitespace);
            }
          }
          return false;
        }

        function checkIfLastBeforeForcedLineBreak(
          nextP: Vtree.NodeContext,
        ): boolean {
          if (nextP.viewNode?.nodeType === Node.ELEMENT_NODE) {
            return (nextP.viewNode as Element).localName === "br";
          }
          if (nextP.viewNode?.nodeType === Node.TEXT_NODE) {
            const nextTextNode = nextP.viewNode as Text;
            if (nextP.whitespace === Vtree.Whitespace.PRESERVE) {
              if (nextTextNode.textContent?.startsWith("\n")) {
                return true;
              }
            } else if (nextP.whitespace === Vtree.Whitespace.NEWLINE) {
              if (/^[ \t\r\n\f]*\n/.test(nextTextNode.textContent)) {
                return true;
              }
            }
            if (nextTextNode.nextElementSibling?.localName === "br") {
              return Vtree.canIgnore(nextTextNode, nextP.whitespace);
            }
          }
          return false;
        }

        for (let prev = i - 1; prev >= 0; prev--) {
          const prevP = checkPoints[prev];
          if (checkIfFirstAfterForcedLineBreak(prevP)) {
            isFirstAfterForcedLineBreak = true;
            break;
          }
          if (
            !prevP.display &&
            prevP.viewNode.nodeType === Node.TEXT_NODE &&
            prevP.viewNode.textContent.length > 0
          ) {
            prevNode = prevP.viewNode;
            break;
          }
          // Issue #868: Look inside footnote-call for the last text node.
          // BUT skip and look further back if we're inside that same footnote-call.
          if (
            prevP.viewNode?.nodeType === Node.ELEMENT_NODE &&
            PseudoElement.getPseudoName(prevP.viewNode as Element) ===
              "footnote-call"
          ) {
            if (prevP.viewNode.contains(textP.viewNode)) {
              continue;
            }
            const lastText = LayoutHelper.findLastTextNodeInElement(
              prevP.viewNode,
            );
            if (lastText) {
              prevNode = lastText;
              break;
            }
          }
          if (
            (prevP.display && !/^(inline|ruby)\b/.test(prevP.display)) ||
            (prevP.viewNode?.nodeType === Node.ELEMENT_NODE &&
              ((prevP.viewNode as Element).localName === "br" ||
                Base.mediaTags[(prevP.viewNode as Element).localName]))
          ) {
            break;
          }
          if (prev === 0) {
            isFirstAfterBreak = true;
            if (isFirstFragment) {
              isFirstInBlock = true;
              isFirstAfterForcedLineBreak = true;
            }
          }
        }
        for (let next = i + 1; next < checkPoints.length; next++) {
          const nextP = checkPoints[next];
          if (checkIfLastBeforeForcedLineBreak(nextP)) {
            isLastBeforeForcedLineBreak = true;
            break;
          }
          if (
            nextP.viewNode !== textP.viewNode &&
            !nextP.display &&
            nextP.viewNode.nodeType === Node.TEXT_NODE &&
            nextP.viewNode.textContent.length > 0
          ) {
            nextNode = nextP.viewNode;
            break;
          }
          if (
            (nextP.display && !/^(inline|ruby)\b/.test(nextP.display)) ||
            (nextP.viewNode?.nodeType === Node.ELEMENT_NODE &&
              ((nextP.viewNode as Element).localName === "br" ||
                Base.mediaTags[(nextP.viewNode as Element).localName]))
          ) {
            if (
              next === checkPoints.length - 1 &&
              isOutOfLine(nextP.viewNode)
            ) {
              isLastInBlock = true;
            }
            break;
          }
          if (next === checkPoints.length - 1) {
            isLastBeforeForcedLineBreak = true;
            isLastInBlock = true;
            for (
              let nextNext = nextP.viewNode.nextSibling;
              nextNext;
              nextNext = nextNext.nextSibling
            ) {
              if (!isOutOfLine(nextNext)) {
                isLastInBlock = false;
                break;
              }
            }
          }
        }
        if (textP.parent.display === "inline-block") {
          // an inline-block box enclosing rendered checkpoints has its
          // element view
          const inlineBlock = Vtree.asElementNodeContext(textP.parent);
          Asserts.assert(inlineBlock);
          if (!isFirstInBlock) {
            let firstInInlineBlock = inlineBlock.viewNode.firstChild;
            while (Vtree.canIgnore(firstInInlineBlock, textP.whitespace)) {
              firstInInlineBlock = firstInInlineBlock.nextSibling;
            }
            if (textP.viewNode === firstInInlineBlock) {
              isFirstInBlock = true;
            }
          }
          if (!isLastInBlock) {
            let lastInInlineBlock = inlineBlock.viewNode.lastChild;
            while (Vtree.canIgnore(lastInInlineBlock, textP.whitespace)) {
              lastInInlineBlock = lastInInlineBlock.previousSibling;
            }
            if (textP.viewNode === lastInInlineBlock) {
              isLastInBlock = true;
            }
          }
        }
        const columnOver = this.processTextSpacing(
          textP.viewNode,
          isFirstAfterBreak,
          isFirstInBlock,
          isFirstAfterForcedLineBreak,
          isLastBeforeForcedLineBreak,
          isLastInBlock,
          prevNode,
          nextNode,
          autospace,
          spacingTrim,
          hangingPunctuation,
          lang,
          textP.vertical,
        );
        const blockContainer = findBlockContainer(textP.viewNode);
        if (blockContainer) {
          reshapeTargets.add(blockContainer);
        }
        if (columnOver > 0) {
          // Stop processing if the node is moved to next column
          // because it will be processed again in the next column.
          // (Issue #1256)
          break;
        }
      }
    }
    for (const target of reshapeTargets) {
      if (target.querySelector("viv-ts-open, viv-ts-close, viv-ts-thin-sp")) {
        reshapeBlockContainer(target);
      }
    }
  }

  private processTextSpacing(
    textNode: Text,
    isFirstAfterBreak: boolean,
    isFirstInBlock: boolean,
    isFirstAfterForcedLineBreak: boolean,
    isLastBeforeForcedLineBreak: boolean,
    isLastInBlock: boolean,
    prevNode: Node | null,
    nextNode: Node | null,
    autospace: Autospace,
    spacingTrim: SpacingTrim,
    hangingPunctuation: HangingPunctuation,
    lang: string | null,
    vertical: boolean,
  ): number {
    const text = textNode.textContent;
    const document = textNode.ownerDocument;
    let columnOver = 0;

    function isAtStartOfLine(): boolean {
      if (isFirstAfterBreak) {
        return true;
      }
      if (!prevNode) {
        return false;
      }
      const rect = RangeClientRects.getClientRectsOfNode(textNode)[0];
      if (!rect) {
        return false;
      }
      const prevRects = RangeClientRects.getClientRectsOfNode(prevNode);
      const prevRect = prevRects[prevRects.length - 1];
      if (!prevRect) {
        return false;
      }
      columnOver ||= LayoutHelper.checkIfBeyondColumnBreaks(prevRect, vertical);
      return vertical
        ? rect.top < prevRect.top + prevRect.height - rect.width ||
            rect.left + rect.width < prevRect.left + rect.width / 10 ||
            rect.left > prevRect.left + prevRect.width - rect.width / 10
        : rect.left < prevRect.left + prevRect.width - rect.height ||
            rect.top > prevRect.top + prevRect.height - rect.height / 10 ||
            rect.top + rect.height < prevRect.top + rect.height / 10;
    }

    function isAtEndOfLine(): boolean {
      if (!nextNode) {
        return false;
      }
      const rect = RangeClientRects.getClientRectsOfNode(textNode)[0];
      if (!rect) {
        return false;
      }
      columnOver ||= LayoutHelper.checkIfBeyondColumnBreaks(rect, vertical);
      const nextRect = RangeClientRects.getClientRectsOfNode(nextNode)[0];
      if (!nextRect) {
        return false;
      }
      return vertical
        ? rect.top + rect.height > nextRect.top + rect.width ||
            rect.left > nextRect.left + nextRect.width - rect.width / 10 ||
            rect.left + rect.width < nextRect.left + rect.width / 10
        : rect.left + rect.width > nextRect.left + rect.height ||
            rect.top + rect.height < nextRect.top + rect.height / 10 ||
            rect.top > nextRect.top + nextRect.height - rect.height / 10;
    }

    let chromiumVoTrFallbackOnly = false;
    let hangingFirst = false;
    let hangingLast = false;
    let hangingEnd = false;
    let tagName: "viv-ts-open" | "viv-ts-close" | undefined;
    const needsChromiumVoTrFallback = isChromiumVoTrFallback(text, vertical);

    if (
      isFirstInBlock &&
      hangingPunctuation.first &&
      /^[\p{Ps}\p{Pf}\p{Pi}'"\u3000]\p{M}*$/u.test(text)
    ) {
      // hanging-punctuation: first
      tagName = "viv-ts-open";
      hangingFirst = true;
    } else if (
      isLastInBlock &&
      hangingPunctuation.last &&
      /^[\p{Pe}\p{Pf}\p{Pi}'"]\p{M}*$/u.test(text)
    ) {
      // hanging-punctuation: last
      tagName = "viv-ts-close";
      hangingLast = true;
    } else if (
      (hangingPunctuation.forceEnd || hangingPunctuation.allowEnd) &&
      /^[、。，．､｡]\p{M}*$/u.test(text)
    ) {
      // hanging-punctuation: force-end | allow-end
      tagName = "viv-ts-close";
      hangingEnd = true;
    } else if (
      (spacingTrim.trimStart ||
        spacingTrim.spaceFirst ||
        spacingTrim.trimAdjacent) &&
      /^[‘“〝（［｛｟〈〈《「『【〔〖〘〚]\p{M}*$/u.test(text)
    ) {
      // fullwidth opening punctuation
      tagName = "viv-ts-open";
    } else if (
      (spacingTrim.trimEnd ||
        spacingTrim.allowEnd ||
        spacingTrim.trimAdjacent) &&
      (/^[’”〞〟）］｝｠〉〉》」』】〕〗〙〛]\p{M}*$/u.test(text) ||
        (lang === "zh-hans" && /^[：；]\p{M}*$/u.test(text)) ||
        (lang !== "zh-hant" && /^[、。，．]\p{M}*$/u.test(text)))
    ) {
      // fullwidth closing punctuation
      tagName = "viv-ts-close";
    } else if (needsChromiumVoTrFallback) {
      tagName = getChromiumVoTrFallbackTagName(text);
      chromiumVoTrFallbackOnly = true;
    }

    if (tagName !== undefined) {
      if (textNode.parentElement?.localName === "viv-ts-inner") {
        // Already processed
        return 0;
      }
      // Wrap the textNode as `<{tagName}><viv-ts-inner>{text}<viv-ts-inner></{tagName}>`
      const outerElem = document.createElement(tagName);
      const innerElem = document.createElement("viv-ts-inner");
      outerElem.appendChild(innerElem);
      textNode.before(outerElem);
      innerElem.appendChild(textNode);

      if (needsChromiumVoTrFallback) {
        const textOrientation =
          document.defaultView.getComputedStyle(outerElem).textOrientation;
        if (textOrientation === "mixed") {
          innerElem.style.textOrientation = "sideways";
        }
      }

      if (chromiumVoTrFallbackOnly) {
        return 0;
      }

      // Check if the punctuation is almost full width
      function checkFullWidth(elem: HTMLElement): boolean {
        const fontSize = parseFloat(
          document.defaultView.getComputedStyle(elem).fontSize,
        );
        const fullWidthThreshold = fontSize * 0.7;
        return (
          (vertical ? elem.offsetHeight : elem.offsetWidth) > fullWidthThreshold
        );
      }
      const isFullWidth = checkFullWidth(innerElem);

      function linePosition(): number {
        return vertical ? outerElem.offsetLeft : outerElem.offsetTop;
      }

      if (isFullWidth || hangingFirst || hangingLast || hangingEnd) {
        if (tagName === "viv-ts-open") {
          if (hangingFirst) {
            outerElem.className = "viv-hang-first";
          } else if (isFirstInBlock || isFirstAfterForcedLineBreak) {
            if (spacingTrim.trimStart) {
              outerElem.className = "viv-ts-trim";
            } else {
              outerElem.className = "viv-ts-space";
            }
          } else if (
            !(spacingTrim.trimStart || spacingTrim.spaceFirst) &&
            isAtStartOfLine()
          ) {
            outerElem.className = "viv-ts-space";
          } else if (
            spacingTrim.trimAdjacent &&
            prevNode &&
            /[\p{Ps}\p{Pi}\p{Pe}\p{Pf}\u00B7\u2027\u30FB\u3000：；、。，．]\p{M}*$/u.test(
              prevNode.textContent,
            ) &&
            // exclude non-fullwidth closing punctuations (Issue #1003)
            (!/[\p{Pe}\p{Pf}]\p{M}*$/u.test(prevNode.textContent) ||
              (prevNode.parentElement?.localName === "viv-ts-inner" &&
                checkFullWidth(prevNode.parentElement)))
          ) {
            outerElem.className = "viv-ts-trim";
          } else if (
            (spacingTrim.trimStart || spacingTrim.spaceFirst) &&
            isAtStartOfLine()
          ) {
            const linePos = linePosition();
            outerElem.className = "viv-ts-auto";
            if (linePos === linePosition() && !isAtStartOfLine()) {
              // workaround for issues #1005 and #1010
              outerElem.className = "viv-ts-trim";
            }
          }
        } else if (tagName === "viv-ts-close") {
          if (hangingLast) {
            outerElem.className = isFullWidth
              ? "viv-hang-last"
              : "viv-hang-last viv-hang-hw";
          } else if (isLastInBlock || isLastBeforeForcedLineBreak) {
            const linePos = linePosition();
            if (hangingEnd) {
              outerElem.className = isFullWidth
                ? hangingPunctuation.allowEnd && spacingTrim.allowEnd
                  ? "viv-ts-auto"
                  : "viv-hang-end"
                : "viv-hang-end viv-hang-hw";
              if (hangingPunctuation.allowEnd && linePos === linePosition()) {
                if (spacingTrim.trimEnd) {
                  outerElem.className = "viv-ts-trim";
                } else if (spacingTrim.allowEnd) {
                  outerElem.className = "viv-hang-end";
                  if (linePos === linePosition()) {
                    outerElem.className = "";
                  }
                } else {
                  outerElem.className = "viv-ts-space";
                }
              }
            } else if (spacingTrim.trimEnd) {
              outerElem.className = "viv-ts-trim";
            } else if (spacingTrim.allowEnd) {
              outerElem.className = "viv-ts-auto";
              if (linePos === linePosition()) {
                outerElem.className = "";
              }
            } else {
              outerElem.className = "viv-ts-space";
            }
          } else if (
            nextNode &&
            /^[\p{Pe}\p{Pf}\u00B7\u2027\u30FB\u3000：；、。，．]/u.test(
              nextNode.textContent,
            )
          ) {
            if (isFullWidth && spacingTrim.trimAdjacent) {
              outerElem.className = "viv-ts-trim";
            }
          } else if (hangingEnd) {
            const atEnd = isAtEndOfLine();
            const atEndNoHang = atEnd && hangingPunctuation.allowEnd;
            if (!atEndNoHang) {
              outerElem.className = isFullWidth
                ? "viv-hang-end"
                : "viv-hang-end viv-hang-hw";
            }
            if (!isFullWidth) {
              if (!atEnd && !isAtEndOfLine()) {
                outerElem.className = "";
              }
            } else if (atEndNoHang && spacingTrim.trimEnd) {
              outerElem.className = "viv-ts-auto";
            } else if (!atEndNoHang && !isAtEndOfLine()) {
              outerElem.className = "";
            } else if (!atEnd && hangingPunctuation.allowEnd) {
              if (!spacingTrim.trimEnd) {
                outerElem.className = "viv-ts-space";
                if (!isAtEndOfLine()) {
                  if (spacingTrim.allowEnd) {
                    outerElem.className = "viv-ts-auto";
                    if (!isAtEndOfLine()) {
                      outerElem.className = "viv-hang-end";
                    }
                  } else {
                    outerElem.className = "viv-hang-end";
                  }
                }
              } else {
                outerElem.className = "viv-ts-auto";
                if (!isAtEndOfLine()) {
                  outerElem.className = "viv-hang-end";
                }
              }
            }
          } else if (spacingTrim.trimEnd || spacingTrim.allowEnd) {
            if (isAtEndOfLine()) {
              if (spacingTrim.allowEnd) {
                outerElem.className = "viv-ts-space";
              } else {
                outerElem.className = "viv-ts-auto";
              }
            } else {
              const linePos = linePosition();
              outerElem.className = "viv-ts-auto";
              if (linePos === linePosition()) {
                outerElem.className = "";
              }
            }
          }
        }
      }
    }

    function checkUpright(elem: Element): boolean {
      const style = elem?.ownerDocument.defaultView?.getComputedStyle(elem);
      return (
        !!style &&
        (style.textOrientation === "upright" ||
          style.textCombineUpright === "all" ||
          style["-webkit-text-combine"] === "horizontal")
      );
    }

    function checkNonZeroMarginBorderPadding(
      node1: Node,
      node2: Node,
    ): boolean {
      if (node1.nodeType === Node.ELEMENT_NODE) {
        const style = document.defaultView.getComputedStyle(node1 as Element);
        if (
          parseFloat(style.marginInlineEnd) ||
          parseFloat(style.borderInlineEndWidth) ||
          parseFloat(style.paddingInlineEnd)
        ) {
          return true;
        }
      }
      const parent1 = node1.parentElement;
      if (parent1 && !parent1.contains(node2)) {
        return checkNonZeroMarginBorderPadding(parent1, node2);
      }
      if (node2.nodeType === Node.ELEMENT_NODE) {
        const style = document.defaultView.getComputedStyle(node2 as Element);
        if (
          parseFloat(style.marginInlineStart) ||
          parseFloat(style.borderInlineStartWidth) ||
          parseFloat(style.paddingInlineStart)
        ) {
          return true;
        }
      }
      const parent2 = node2.parentElement;
      if (parent2 && !parent2.contains(node1)) {
        return checkNonZeroMarginBorderPadding(node1, parent2);
      }
      return false;
    }

    if (autospace.ideographAlpha || autospace.ideographNumeric) {
      if (
        prevNode &&
        /^(?!\p{P})[\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF]/u.test(text) &&
        ((autospace.ideographAlpha &&
          /(?![\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF\uFF01-\uFF60])\p{L}\p{M}*$/u.test(
            prevNode.textContent,
          )) ||
          (autospace.ideographNumeric &&
            /(?![\uFF01-\uFF60])\p{Nd}\p{M}*$/u.test(prevNode.textContent))) &&
        !(
          vertical &&
          prevNode.parentElement !== null &&
          checkUpright(prevNode.parentElement)
        ) &&
        !checkNonZeroMarginBorderPadding(prevNode, textNode)
      ) {
        textNode.before(document.createElement("viv-ts-thin-sp"));
      }
      if (
        nextNode &&
        /(?!\p{P})[\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF]\p{M}*$/u.test(text) &&
        ((autospace.ideographAlpha &&
          /^(?![\p{sc=Han}\u3041-\u30FF\u31C0-\u31FF\uFF01-\uFF60])\p{L}/u.test(
            nextNode.textContent,
          )) ||
          (autospace.ideographNumeric &&
            /^(?![\uFF01-\uFF60])\p{Nd}/u.test(nextNode.textContent))) &&
        !(
          vertical &&
          nextNode.parentElement !== null &&
          checkUpright(nextNode.parentElement)
        ) &&
        !checkNonZeroMarginBorderPadding(textNode, nextNode)
      ) {
        textNode.after(document.createElement("viv-ts-thin-sp"));
      }
    }
    return columnOver;
  }

  registerHooks() {
    Plugin.registerHook(
      Plugin.HOOKS.POLYFILLED_INHERITED_PROPS,
      this.getPolyfilledInheritedProps.bind(this),
    );
    Plugin.registerHook(
      Plugin.HOOKS.PREPROCESS_SINGLE_DOCUMENT,
      this.preprocessSingleDocument.bind(this),
    );
    Plugin.registerHook(
      Plugin.HOOKS.POST_LAYOUT_BLOCK,
      this.postLayoutBlock.bind(this),
      true, // text-spacing must be processed before others (Issue #1105)
    );
  }
}

const textPolyfill = new TextSpacingPolyfill();
textPolyfill.registerHooks();

export function preprocessForTextSpacing(element: Element): void {
  textPolyfill.preprocessForTextSpacing(element);
}

export function processGeneratedContent(
  element: HTMLElement,
  textAutospace: Css.Val,
  textSpacingTrim: Css.Val,
  hangingPunctuation: Css.Val,
  lang: string | null,
  vertical: boolean,
): void {
  textPolyfill.processGeneratedContent(
    element,
    textAutospace,
    textSpacingTrim,
    hangingPunctuation,
    lang,
    vertical,
  );
}
