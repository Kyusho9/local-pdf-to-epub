/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Ops - Render EPUB content files by applying page masters,
 * styling and layout.
 */
import "./footnotes";
import "./table";
import * as Asserts from "./asserts";
import * as Base from "./base";
import * as Break from "./break";
import * as CmykStore from "./cmyk-store";
import * as Columns from "./columns";
import * as Constants from "./constants";
import * as Counters from "./counters";
import * as CounterStyle from "./counter-style";
import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import { replaceScopeAmpersands } from "./css-nesting";
import * as CssParser from "./css-parser";
import * as CssProp from "./css-prop";
import * as CssStyler from "./css-styler";
import * as CssTokenizer from "./css-tokenizer";
import * as CssValidator from "./css-validator";
import * as Display from "./display";
import * as Exprs from "./exprs";
import * as Font from "./font";
import * as GeometryUtil from "./geometry-util";
import * as Layout from "./layout";
import * as LayoutProcessor from "./layout-processor";
import * as Logging from "./logging";
import * as Net from "./net";
import * as PageFloats from "./page-floats";
import * as CssPage from "./css-page";
import * as Plugin from "./plugin";
import * as PageMaster from "./page-master";
import * as Scripts from "./scripts";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
import * as TextPolyfill from "./text-polyfill";
import * as Vgen from "./vgen";
import * as Vtree from "./vtree";
import * as XmlDoc from "./xml-doc";
import { Layout as LayoutType, PageFloats as PageFloatsType } from "./types";
import {
  UserAgentBaseCss,
  UserAgentCounterStylesCss,
  UserAgentPageCss,
  UserAgentTocCss,
} from "./assets";

/**
 * A `@font-face` rule. `priority` and `layer` are what the cascade sorts the
 * rule by when several rules define the same font (css-cascade-5 §6.4).
 */
export type FontFace = {
  properties: CssCascade.ElementStyle;
  condition: Exprs.Val | null;
  priority: number;
  layer: CssCascade.CascadeLayer | null;
};

/**
 * Sorts `@font-face` rules by cascade origin and layer, keeping the document
 * order within a layer (`Array.prototype.sort` is stable). The browser lets the
 * last matching rule win, so the winner of the cascade must be emitted last.
 */
export function sortFontFaces(fontFaces: FontFace[]): FontFace[] {
  return [...fontFaces].sort(CssCascade.comparePriority);
}

class CounterStyleParserHandler extends CssCascade.PropSetParserHandler {
  constructor(
    scope: Exprs.LexicalScope,
    owner: CssParser.DispatchParserHandler,
    elementStyle: CssCascade.ElementStyle,
    validatorSet: CssValidator.ValidatorSet,
    private readonly counterStyleName: string,
    private readonly counterStyles: CounterStyle.CounterStyleStore,
    delegation: CssParser.Delegation,
    layer: CssCascade.CascadeLayer | null,
  ) {
    super(
      scope,
      owner,
      null,
      elementStyle,
      validatorSet,
      delegation,
      "counter-style",
      layer,
    );
  }

  override endRule(): void {
    super.endRule();
    if (
      !this.counterStyles.define(this.counterStyleName, this.elementStyle, {
        priority: this.getBaseSpecificity(),
        layer: this.layer,
      })
    ) {
      Logging.logger.warn(
        `E_CSS_COUNTER_STYLE_INVALID: @counter-style ${this.counterStyleName}`,
      );
    }
  }
}

export class Style {
  fontDeobfuscator:
    ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null;
  validatorSet: CssValidator.ValidatorSet;

  constructor(
    public readonly store: OPSDocStore,
    public readonly rootScope: Exprs.LexicalScope,
    public readonly pageScope: Exprs.LexicalScope,
    public readonly cascade: CssCascade.Cascade,
    public readonly rootBox: PageMaster.RootPageBox,
    public readonly fontFaces: FontFace[],
    public readonly footnoteProps: CssCascade.ElementStyle,
    public readonly flowProps: { [key: string]: CssCascade.ElementStyle },
    public readonly viewportProps: CssCascade.ElementStyle[],
    public readonly pageProps: { [key: string]: CssCascade.ElementStyle },
    public readonly counterStyleStore: CounterStyle.CounterStyleStore,
  ) {
    this.fontDeobfuscator = store.fontDeobfuscator;
    this.validatorSet = store.validatorSet;
    this.pageScope.defineBuiltIn("has-content", function (name) {
      name = name as string;
      const styleInstance = this as StyleInstance;
      const cp = styleInstance.currentLayoutPosition;
      const flowChunk = cp.firstFlowChunkOfFlow(name);
      return (
        styleInstance.matchPageSide(cp.startSideOfFlow(name as string)) &&
        cp.hasContent(name as string, styleInstance.lookupOffset) &&
        !!flowChunk &&
        !styleInstance.flowChunkIsAfterParentFlowForcedBreak(flowChunk)
      );
    });
    this.pageScope.defineName(
      "page-number",
      new Exprs.Native(
        this.pageScope,
        function () {
          const styleInstance = this as StyleInstance;
          return (
            styleInstance.pageNumberOffset +
            styleInstance.getCurrentPageNumberForPageScope()
          );
        },
        "page-number",
      ),
    );
    this.pageScope.defineName(
      "blank-page",
      new Exprs.Native(
        this.pageScope,
        function () {
          const styleInstance = this as StyleInstance;
          const cp = styleInstance.currentLayoutPosition;
          return cp?.isBlankPage;
        },
        "blank-page",
      ),
    );
  }

  sizeViewport(
    viewportWidth: number,
    viewportHeight: number,
    fontSize: number,
    pref?: Exprs.Preferences,
  ): { width: number; height: number; fontSize: number } {
    if (this.viewportProps.length) {
      const context = new Exprs.Context(
        this.rootScope,
        viewportWidth,
        viewportHeight,
        fontSize,
        fontSize * Exprs.defaultPreferencesInstance.lineHeight,
      );
      const viewportProps = CssCascade.mergeAll(context, this.viewportProps);
      const width = viewportProps["width"] as CssCascade.CascadeValue;
      const height = viewportProps["height"] as CssCascade.CascadeValue;
      const textZoom = viewportProps["text-zoom"] as CssCascade.CascadeValue;
      let scaleFactor = 1;
      if ((width && height) || textZoom) {
        const defaultFontSize = Exprs.defaultUnitSizes["em"];
        const zoomVal = textZoom
          ? textZoom.evaluate(context, "text-zoom")
          : null;
        if (zoomVal === Css.ident.scale) {
          scaleFactor = defaultFontSize / fontSize;
          fontSize = defaultFontSize;
          viewportWidth *= scaleFactor;
          viewportHeight *= scaleFactor;
        }
        if (width && height) {
          const widthVal = Css.toNumber(
            width.evaluate(context, "width"),
            context,
          );
          const heightVal = Css.toNumber(
            height.evaluate(context, "height"),
            context,
          );
          if (widthVal > 0 && heightVal > 0) {
            const spreadWidth =
              pref && pref.spreadView
                ? (widthVal + pref.pageBorder) * 2
                : widthVal;
            return { width: spreadWidth, height: heightVal, fontSize };
          }
        }
      }
    }
    return { width: viewportWidth, height: viewportHeight, fontSize };
  }
}

/**
 * Collect all unique formatting context states from a LayoutPosition.
 * Formatting contexts (e.g., TableFormattingContext) are stored in
 * NodePositionStep.formattingContext within flow chunk positions.
 * This walks the position tree to find them all and save their states,
 * including those reachable through shadowSibling chains (e.g.,
 * footnote-call → footnote element transitions). (Issue #1663)
 */
function collectFormattingContextStates(
  layoutPosition: Vtree.LayoutPosition,
): Map<Vtree.FormattingContext, any> {
  const states = new Map<Vtree.FormattingContext, any>();
  const collectFromStep = (step: Vtree.NodePositionStep): void => {
    if (step.formattingContext && !states.has(step.formattingContext)) {
      states.set(step.formattingContext, step.formattingContext.saveState());
    }
    if (step.shadowSibling) {
      collectFromStep(step.shadowSibling);
    }
  };
  for (const name in layoutPosition.flowPositions) {
    const flowPos = layoutPosition.flowPositions[name];
    for (const fcp of flowPos.positions) {
      const primary = fcp.chunkPosition.primary;
      for (const step of primary.steps) {
        collectFromStep(step);
      }
      if (fcp.chunkPosition.floats) {
        for (const floatPos of fcp.chunkPosition.floats) {
          for (const step of floatPos.steps) {
            collectFromStep(step);
          }
        }
      }
    }
  }
  return states;
}

/**
 * Restore all formatting context states previously saved by
 * collectFormattingContextStates(). (Issue #1663)
 */
function restoreFormattingContextStates(
  states: Map<Vtree.FormattingContext, any>,
): void {
  for (const [fc, state] of states) {
    if (state !== undefined) {
      fc.restoreState(state);
    }
  }
}

function releaseBreakPositions(
  context: PageFloats.AttachedPageFloatLayoutContext,
): void {
  if ("breakPositions" in context.container) {
    const column = context.container as LayoutType.Column;
    column.breakPositions = [];
    column.nodeContextOverflowingDueToRepetitiveElements = null;
  }
  for (const child of context.children) {
    releaseBreakPositions(child);
  }
  for (const fragment of context.floatFragments) {
    releaseBreakPositions(
      (fragment.area as Layout.PageFloatArea).pageFloatLayoutContext,
    );
  }
}

type OpenedPageBox = {
  readonly boxContainer: HTMLElement;
  /** Replaced by the column when this box holds the flow itself. */
  container: Vtree.Container;
  readonly offsetX: number;
  readonly offsetY: number;
  readonly flowName: Css.Val;
  readonly dontExclude: boolean;
  readonly forwardOrderInLayout: boolean;
  removed: boolean;
};

//-------------------------------------------------------------------------------
export class StyleInstance
  extends Exprs.Context
  implements
    CssStyler.FlowListener,
    PageMaster.InstanceHolder,
    Vgen.StylerProducer
{
  lang: string | null;
  primaryFlows = { body: true } as { [key: string]: boolean };
  rootPageBoxInstance: PageMaster.RootPageBoxInstance;
  styler: CssStyler.Styler;
  stylerMap: { [key: string]: CssStyler.Styler };
  currentLayoutPosition: Vtree.LayoutPosition | null = null;
  layoutPositionAtPageStart: Vtree.LayoutPosition | null = null;
  currentCascadedPageStyle: CssCascade.ElementStyle | null = null;
  lookupOffset: number = 0;
  faces: Font.DocumentFaces;
  pageBoxInstances: { [key: string]: PageMaster.PageBoxInstance } = {};
  pageManager: CssPage.PageManager;
  private pageNumberContextStack: number[] = [];
  private rootPageFloatLayoutContext: PageFloats.RootPageFloatLayoutContext;
  pageBreaks: { [key: string]: boolean } = {};
  pageProgression: Constants.PageProgression | null = null;
  isVersoFirstPage: boolean = false;
  blankPageAtStart: boolean = false;
  pageSheetSize: { [key: string]: { width: number; height: number } } = {};
  pageSheetHeight: number = 0;
  pageSheetWidth: number = 0;
  private invalidPageAreaOnCurrentPage: boolean = false;
  private repeatedInvalidPageAreaLayoutPosition: Vtree.LayoutPosition | null =
    null;
  private semanticFootnoteFirstRefOffsets: Map<string, number> = new Map();
  private semanticFootnoteFirstRefOffsetsInitialized = { value: false };
  pageGroupPageCounts: {
    [pageType: string]: Map<Element, number>;
  } = Object.create(null);
  currentPageGroupDocument: Document | null = null;

  private constructor(
    public readonly style: Style,
    public readonly xmldoc: XmlDoc.XMLDocHolder,
    defaultLang: string | null,
    public readonly viewport: Vgen.Viewport,
    public readonly clientLayout: Vtree.ClientLayout,
    public readonly fontMapper: Font.Mapper,
    public readonly customRenderer: Vgen.CustomRenderer,
    public readonly fallbackMap: { [key: string]: string },
    public readonly pageNumberOffset: number,
    public readonly documentURLTransformer: Base.DocumentURLTransformer,
    public readonly counterStore: Counters.CounterStore,
    public readonly cmykStore: CmykStore.CmykStore,
    pref: Exprs.Preferences,
    pubTitle: string | null,
    docTitle: string | null,
    pageProgression?: Constants.PageProgression | null,
    isVersoFirstPage?: boolean,
  ) {
    super(
      style.rootScope,
      viewport.width,
      viewport.height,
      viewport.fontSize,
      viewport.fontSize * pref.lineHeight,
    );
    this.lang = xmldoc.lang || defaultLang;
    this.faces = new Font.DocumentFaces(this.style.fontDeobfuscator);
    this.rootPageFloatLayoutContext =
      PageFloats.RootPageFloatLayoutContext.createRoot();
    this.pageProgression = pageProgression || null;
    this.isVersoFirstPage = !!isVersoFirstPage;
    for (const flowName in style.flowProps) {
      const flowStyle = style.flowProps[flowName];
      const consume = CssCascade.getProp(flowStyle, "flow-consume");
      if (consume) {
        const consumeVal = consume.evaluate(this, "flow-consume");
        if (consumeVal == Css.ident.all) {
          this.primaryFlows[flowName] = true;
        } else {
          delete this.primaryFlows[flowName];
        }
      }
    }

    // The flow-consume loop above must evaluate under the default pref. Only
    // the document subtree resolved below reads the real pref. Do not hoist
    // this assignment above the loop, or primaryFlows would change.
    this.pref = pref;
    this.pubTitle = pubTitle;
    this.docTitle = docTitle;

    const counterListener = this.counterStore.createCounterListener(
      this.xmldoc.url,
    );
    const counterResolver = this.counterStore.createCounterResolver(
      this.xmldoc.url,
      this.style.rootScope,
      this.style.pageScope,
    );
    this.styler = new CssStyler.Styler(
      this.xmldoc,
      this.style.cascade,
      this.style.rootScope,
      this,
      this.primaryFlows,
      this.style.validatorSet,
      counterListener,
      counterResolver,
      this.style.counterStyleStore,
      this.cmykStore,
      this.style.validatorSet,
    );
    counterResolver.setStyler(this.styler);
    this.styler.resetFlowChunkStream(this);
    this.stylerMap = {};
    this.stylerMap[this.xmldoc.url] = this.styler;
    const docElementStyle = this.styler.getTopContainerStyle();
    if (!this.pageProgression) {
      this.pageProgression = CssPage.resolvePageProgression(docElementStyle);
    }

    // Check the spread break at beginning of a document that may cause
    // the first page verso side or cause a blank page (issue #666)
    if (!this.matchStartPageSide(this.styler.breakBeforeValues.get(0))) {
      if (this.pageNumberOffset === 0) {
        this.isVersoFirstPage = true;
      } else {
        this.blankPageAtStart = true;
      }
    }

    const rootBox = this.style.rootBox;
    this.rootPageBoxInstance = new PageMaster.RootPageBoxInstance(rootBox);
    const cascadeInstance = this.style.cascade.createInstance(
      this,
      counterListener,
      counterResolver,
      this.style.counterStyleStore,
      this.cmykStore,
      this.xmldoc.root,
      this.style.rootScope,
      this.style.validatorSet,
      this.styler.styles,
      this.style.validatorSet,
    );

    // Named page type at first page
    this.styler.cascade.currentPageType = this.styler.cascade.firstPageType;

    this.rootPageBoxInstance.applyCascadeAndInit(
      cascadeInstance,
      docElementStyle,
    );
    this.rootPageBoxInstance.resolveAutoSizing(this);
    this.pageManager = new CssPage.PageManager(
      cascadeInstance,
      this.style.pageScope,
      this.rootPageBoxInstance,
      this,
      docElementStyle,
    );

    // Determine page sheet sizes corresponding to page selectors
    const pageProps = this.style.pageProps;
    if (!pageProps[""]) {
      pageProps[""] = {};
    }
    Object.keys(pageProps).forEach((selector) => {
      let pageStyle = pageProps[selector] as {
        [key: string]: CssCascade.CascadeValue;
      };

      // Substitute var() in @page
      this.styler.cascade.applyVarFilter([pageStyle], null);
      if (CssCascade.resolveRollbackValues(pageStyle, true)) {
        this.styler.cascade.applyVarFilter([pageStyle], null);
      }

      // Calculate calc()
      this.styler.cascade.applyCalcFilter(pageStyle, this.styler.context);

      // Convert device-cmyk() to color(srgb ...)
      this.styler.cascade.applyCmykFilter(pageStyle);

      const pageSizeAndBleed = CssPage.evaluatePageSizeAndBleed(
        CssPage.resolvePageSizeAndBleed(pageStyle),
        this,
      );
      this.pageSheetSize[selector] = {
        width: pageSizeAndBleed.pageWidth + pageSizeAndBleed.cropOffset * 2,
        height: pageSizeAndBleed.pageHeight + pageSizeAndBleed.cropOffset * 2,
      };
    });
  }

  static create(
    style: Style,
    xmldoc: XmlDoc.XMLDocHolder,
    defaultLang: string | null,
    viewport: Vgen.Viewport,
    clientLayout: Vtree.ClientLayout,
    fontMapper: Font.Mapper,
    customRenderer: Vgen.CustomRenderer,
    fallbackMap: { [key: string]: string },
    pageNumberOffset: number,
    documentURLTransformer: Base.DocumentURLTransformer,
    counterStore: Counters.CounterStore,
    cmykStore: CmykStore.CmykStore,
    pref: Exprs.Preferences,
    pubTitle: string | null,
    docTitle: string | null,
    pageProgression?: Constants.PageProgression | null,
    isVersoFirstPage?: boolean,
  ): Task.Result<StyleInstance> {
    const instance = new StyleInstance(
      style,
      xmldoc,
      defaultLang,
      viewport,
      clientLayout,
      fontMapper,
      customRenderer,
      fallbackMap,
      pageNumberOffset,
      documentURLTransformer,
      counterStore,
      cmykStore,
      pref,
      pubTitle,
      docTitle,
      pageProgression,
      isVersoFirstPage,
    );
    const frame: Task.Frame<StyleInstance> = Task.newFrame(
      "StyleInstance.create",
    );
    instance.loadFontsAndScripts().then(() => {
      frame.finish(instance);
    });
    return frame.result();
  }

  private loadFontsAndScripts(): Task.Result<boolean> {
    const frame: Task.Frame<boolean> = Task.newFrame(
      "StyleInstance.loadFontsAndScripts",
    );
    const srcFaces = [] as Font.Face[];
    for (const fontFace of this.style.fontFaces) {
      if (fontFace.condition && !fontFace.condition.evaluate(this)) {
        continue;
      }
      const properties = Font.prepareProperties(fontFace.properties, this);
      const srcFace = new Font.Face(properties);
      srcFaces.push(srcFace);
    }
    this.fontMapper.findOrLoadFonts(srcFaces, this.faces).then(() => {
      // JavaScript in HTML documents support
      Scripts.loadScriptsInHead(
        this.xmldoc.document,
        this.viewport.window,
        this.styler,
      ).thenFinish(frame);
    });
    return frame.result();
  }

  private matchStartPageSide(side: string | null): boolean {
    const isRectoStart =
      this.pageNumberOffset % 2 == (this.isVersoFirstPage ? 1 : 0);
    const isLTR = this.pageProgression == Constants.PageProgression.LTR;
    switch (side) {
      case "left":
        return isRectoStart !== isLTR;
      case "right":
        return isRectoStart === isLTR;
      case "recto":
        return isRectoStart;
      case "verso":
        return !isRectoStart;
      default:
        return true;
    }
  }

  /** @override */
  getStylerForDoc(xmldoc: XmlDoc.XMLDocHolder): CssStyler.AbstractStyler {
    let styler = this.stylerMap[xmldoc.url];
    if (!styler) {
      const style = this.style.store.getStyleForDoc(xmldoc);

      // We need a separate content, so that variables can get potentially
      // different values.
      const context = new Exprs.Context(
        style.rootScope,
        this.pageWidth(),
        this.pageHeight(),
        this.initialFontSize,
        this.initialFontSize * Exprs.defaultPreferencesInstance.lineHeight,
      );
      const counterListener = this.counterStore.createCounterListener(
        xmldoc.url,
      );
      const counterResolver = this.counterStore.createCounterResolver(
        xmldoc.url,
        style.rootScope,
        style.pageScope,
      );
      styler = new CssStyler.Styler(
        xmldoc,
        style.cascade,
        style.rootScope,
        context,
        this.primaryFlows,
        style.validatorSet,
        counterListener,
        counterResolver,
        style.counterStyleStore,
        this.cmykStore,
        null,
      );
      this.stylerMap[xmldoc.url] = styler;
    }
    return styler;
  }

  /** @override */
  registerInstance(key: string, instance: PageMaster.PageBoxInstance): void {
    this.pageBoxInstances[key] = instance;
  }

  /** @override */
  lookupInstance(key: string): PageMaster.PageBoxInstance {
    return this.pageBoxInstances[key];
  }

  /** @override */
  encounteredFlowChunk(flowChunk: Vtree.FlowChunk, flow: Vtree.Flow): void {
    const cp = this.currentLayoutPosition;
    if (cp) {
      if (!cp.flows[flowChunk.flowName]) {
        cp.flows[flowChunk.flowName] = flow;
      } else {
        flow = cp.flows[flowChunk.flowName];
      }
      let flowPosition = cp.flowPositions[flowChunk.flowName];
      if (!flowPosition) {
        flowPosition = new Vtree.FlowPosition();
        cp.flowPositions[flowChunk.flowName] = flowPosition;
      }
      const nodePosition = Vtree.newNodePositionFromNode(flowChunk.element);
      const chunkPosition = new Vtree.ChunkPosition(nodePosition);
      const flowChunkPosition = new Vtree.FlowChunkPosition(
        chunkPosition,
        flowChunk,
      );
      flowPosition.positions.push(flowChunkPosition);
    }
  }

  override evalSupportsTest(
    name: string,
    value: string,
    isFunc: boolean,
  ): boolean {
    if (isFunc) {
      if (name === "selector") {
        return this.evalSupportsSelector(value);
      }
      return false;
    }
    if (!name) {
      // `(...)` without `name:`
      return false;
    }

    if (Css.isCustomPropName(name)) {
      return typeof CSS !== "undefined" && CSS.supports(`(${name}:${value})`);
    }

    let supported = true;

    class SupportsReceiver implements CssValidator.PropertyReceiver {
      unknownProperty(name: string, value: Css.Val): void {
        supported = false;
      }
      invalidPropertyValue(name: string, value: Css.Val): void {
        supported = false;
      }
      simpleProperty(name: string, value: Css.Val, important): void {}
    }

    const supportsReceiver = new SupportsReceiver();
    const val = CssParser.parseValue(
      this.style.rootScope,
      new CssTokenizer.Tokenizer(value, null),
      "",
    );
    if (!val) {
      return false;
    }
    const validatorSet = (this.xmldoc.store as OPSDocStore).validatorSet;
    validatorSet.validatePropertyAndHandleShorthand(
      name,
      val,
      false,
      this.style.rootScope,
      supportsReceiver,
    );
    return supported;
  }

  getCurrentPageNumberForPageScope(): number {
    if (this.currentLayoutPosition) {
      return this.currentLayoutPosition.page;
    }
    // Issue #2013: target-counter() rerender can evaluate page-number after
    // currentLayoutPosition has been cleared, so fall back to the active
    // render-slot page number captured by OPFView.renderSinglePage().
    return this.pageNumberContextStack.at(-1) ?? 0;
  }

  getPageNumberContextDepth(): number {
    return this.pageNumberContextStack.length;
  }

  pushPageNumberContext(pageNumber: number): void {
    this.pageNumberContextStack.push(pageNumber);
  }

  restorePageNumberContextDepth(depth: number): void {
    this.pageNumberContextStack.length = depth;
  }

  /**
   * @param selectorText
   * @returns true if selectorText is supported selector
   */
  private evalSupportsSelector(selectorText: string): boolean {
    class SilentStyleParserHandler extends StyleParserHandler {
      override errorMsg(
        ..._args: Parameters<StyleParserHandler["errorMsg"]>
      ): void {}
    }

    const sph = new SilentStyleParserHandler(null);
    const normalizedSelectorText = replaceScopeAmpersands(selectorText);
    const tokenizer = new CssTokenizer.Tokenizer(
      normalizedSelectorText + "{}",
      sph,
    );
    const parser = new CssParser.Parser(
      CssParser.actionsBase,
      tokenizer,
      sph,
      "",
    );
    if (
      parser.runParser(Number.POSITIVE_INFINITY, false, false, false, false)
    ) {
      return !sph.cascadeParserHandler.invalid;
    }
    return false;
  }

  getConsumedOffset(flowPosition: Vtree.FlowPosition): number {
    let offset = Number.POSITIVE_INFINITY;
    for (let i = 0; i < flowPosition.positions.length; i++) {
      const pos = flowPosition.positions[i].chunkPosition.primary;
      let node = pos.steps[0].node;
      let offsetInNode = pos.offsetInNode;
      let after = pos.after;
      let k = 0;
      while (node.ownerDocument != this.xmldoc.document) {
        k++;
        node = pos.steps[k].node;
        after = false;
        offsetInNode = 0;
      }
      const chunkOffset = this.xmldoc.getNodeOffset(node, offsetInNode, after);
      if (chunkOffset < offset) {
        offset = chunkOffset;
      }
    }
    return offset;
  }

  private getNodePositionOffset(position: Vtree.NodePosition): number {
    let node = position.steps[0].node;
    let offsetInNode = position.offsetInNode;
    let after = position.after;
    let k = 0;
    while (node.ownerDocument != this.xmldoc.document) {
      k++;
      node = position.steps[k].node;
      after = false;
      offsetInNode = 0;
    }
    return this.xmldoc.getNodeOffset(node, offsetInNode, after);
  }

  private getPageStartOffset(
    layoutPosition?: Vtree.LayoutPosition | null,
    noLookAhead?: boolean,
  ): number {
    if (!layoutPosition) {
      return 0;
    }
    let currentOffset = Number.POSITIVE_INFINITY;
    for (const flowName in this.primaryFlows) {
      let flowPosition = layoutPosition.flowPositions[flowName];
      if (
        !noLookAhead &&
        (!flowPosition || flowPosition.positions.length == 0) &&
        this.currentLayoutPosition
      ) {
        this.styler.styleUntilFlowIsReached(flowName);
        flowPosition = this.currentLayoutPosition.flowPositions[flowName];
        if (layoutPosition != this.currentLayoutPosition) {
          if (flowPosition) {
            flowPosition = flowPosition.clone();
            layoutPosition.flowPositions[flowName] = flowPosition;
          }
        }
      }
      if (flowPosition) {
        for (let i = 0; i < flowPosition.positions.length; i++) {
          const pos = flowPosition.positions[i].chunkPosition.primary;
          const offset = this.getNodePositionOffset(pos);
          if (offset < currentOffset) {
            currentOffset = offset;
          }
        }
      }
    }
    return currentOffset;
  }

  private getPageStartCounterOffsets(layoutPosition: Vtree.LayoutPosition): {
    counterOffset: number;
    changeOffset: number;
  } {
    const pageStartOffset = this.getPageStartOffset(layoutPosition);
    if (!isFinite(pageStartOffset)) {
      return { counterOffset: pageStartOffset, changeOffset: pageStartOffset };
    }
    const searchRoot = this.xmldoc.body || this.xmldoc.root;
    const startElement = searchRoot
      ? this.getFirstInFlowElementAtOrAfter(searchRoot, pageStartOffset)
      : null;
    const searchRootOffset = searchRoot
      ? this.xmldoc.getElementOffset(searchRoot)
      : pageStartOffset;
    // Issue #1999: on the first page, @page counters must start from the
    // body/root snapshot instead of treating document start as a synthetic
    // page-boundary counter change.
    const isDocumentStart = pageStartOffset <= searchRootOffset;
    const resolvedStartElement =
      startElement === searchRoot && isDocumentStart
        ? (this.getFirstInFlowChildElement(searchRoot) ?? startElement)
        : startElement;
    if (!resolvedStartElement) {
      if (isDocumentStart) {
        return {
          counterOffset: searchRootOffset,
          changeOffset: searchRootOffset,
        };
      }
      return { counterOffset: pageStartOffset, changeOffset: pageStartOffset };
    }
    const changeOffset = this.xmldoc.getElementOffset(resolvedStartElement);
    let counterOffset = pageStartOffset;
    if (isDocumentStart && changeOffset !== pageStartOffset) {
      counterOffset = changeOffset;
    }
    // When the page starts exactly at an element boundary, adjust for inline
    // starts so margin-box counters reflect the pre-consumed state.
    if (changeOffset === pageStartOffset) {
      if (this.isInlineLevelElement(resolvedStartElement)) {
        counterOffset = Math.max(0, pageStartOffset - 1);
      } else {
        counterOffset =
          this.getDeepestFirstInFlowChildOffset(resolvedStartElement);
      }
    }
    return { counterOffset, changeOffset };
  }

  private getPageStartElement(
    layoutPosition: Vtree.LayoutPosition | null,
    pageStartOffset: number = this.getPageStartOffset(layoutPosition),
  ): Element | null {
    if (!isFinite(pageStartOffset)) {
      return null;
    }
    const searchRoot = this.xmldoc.body || this.xmldoc.root;
    if (!searchRoot) {
      return null;
    }
    const startElement = this.getFirstInFlowElementAtOrAfter(
      searchRoot,
      pageStartOffset,
    );
    const searchRootOffset = this.xmldoc.getElementOffset(searchRoot);
    const isDocumentStart = pageStartOffset <= searchRootOffset;
    if (startElement === searchRoot && isDocumentStart) {
      return this.getFirstInFlowChildElement(searchRoot) ?? startElement;
    }

    const startElementOffset = startElement
      ? this.xmldoc.getElementOffset(startElement)
      : Number.POSITIVE_INFINITY;
    if (startElementOffset > pageStartOffset) {
      // Issue #1991: a continuation page can start in deferred text before any
      // new in-flow element begins, so recover the containing normal-flow
      // element from the raw offset instead of jumping to the next element.
      const nodeAtOffset = this.xmldoc.getNodeByOffset(pageStartOffset);
      if (!Vtree.canIgnore(nodeAtOffset)) {
        let currentElement =
          nodeAtOffset.nodeType === Node.ELEMENT_NODE
            ? (nodeAtOffset as Element)
            : nodeAtOffset.parentElement;
        while (currentElement) {
          if (
            this.xmldoc.getElementOffset(currentElement) <= pageStartOffset &&
            this.isPageBoundaryCandidateElement(currentElement)
          ) {
            return currentElement;
          }
          currentElement = currentElement.parentElement;
        }
      }
    }

    return startElement;
  }

  private isForcedPageBreakValue(value: string | null): boolean {
    return (
      Break.isForcedBreakValue(value) &&
      value !== "column" &&
      value !== "region"
    );
  }

  private hasForcedPageBreakBefore(style: CssCascade.ElementStyle): boolean {
    const breakValue = CssCascade.getProp(style, "break-before");
    if (!breakValue) {
      return false;
    }
    const resolvedBreakValue = breakValue
      .evaluate(this, "break-before")
      .toString();
    return this.isForcedPageBreakValue(resolvedBreakValue);
  }

  private getExplicitPageType(style: CssCascade.ElementStyle): string | null {
    const pageValue = CssCascade.getProp(style, "page");
    // `page` is non-inherited; defaulting values and `auto` do not establish a
    // named page group and must not keep a stale named page alive.
    if (!pageValue || Css.isDefaultingValue(pageValue.value)) {
      return null;
    }
    const pageType = pageValue.evaluate(this, "page").toString();
    if (!pageType || pageType.toLowerCase() === "auto") {
      return null;
    }
    return pageType;
  }

  private getPageGroupPageType(element: Element): string | null {
    if (this.isInlineLevelElement(element)) {
      return null;
    }
    const style = this.styler.getStyle(element, false);
    if (!style) {
      return null;
    }
    return this.getExplicitPageType(style);
  }

  getPageStartPageType(
    layoutPosition: Vtree.LayoutPosition | null,
  ): string | null | undefined {
    const pageStartOffset = this.getPageStartOffset(layoutPosition, true);
    const startElement = this.getPageStartElement(
      layoutPosition,
      pageStartOffset,
    );
    let currentElement = startElement;
    while (currentElement) {
      // Resolve the page-start named page before page master selection, where
      // `styler.cascade.currentPageType` may still describe the previous page.
      const pageType = this.getPageGroupPageType(currentElement);
      if (pageType) {
        return pageType;
      }
      if (currentElement === this.xmldoc.root) {
        break;
      }
      currentElement = currentElement.parentElement;
    }
    return "";
  }

  getPageStartPageTypeOverride(
    layoutPosition: Vtree.LayoutPosition | null,
  ): string | null | undefined {
    const pageStartPageType = this.getPageStartPageType(layoutPosition);
    if (pageStartPageType !== "") {
      return undefined;
    }
    // A page can start at a wrapper element while the actual named page is on
    // its first in-flow child, e.g. `section > div.B { page: B; }`.
    const pageStartOffset = this.getPageStartOffset(layoutPosition, true);
    let currentElement = this.getPageStartElement(
      layoutPosition,
      pageStartOffset,
    );
    if (
      currentElement &&
      this.xmldoc.getElementOffset(currentElement) < pageStartOffset
    ) {
      return "";
    }
    while (currentElement) {
      currentElement = this.getFirstInFlowChildElement(currentElement);
      if (!currentElement) {
        break;
      }
      const pageType = this.getPageGroupPageType(currentElement);
      if (pageType) {
        return pageType;
      }
    }
    return "";
  }

  private getPreviousInFlowSibling(element: Element): Element | null {
    let sibling = element.previousElementSibling;
    while (sibling) {
      if (this.isPageBoundaryCandidateElement(sibling)) {
        return sibling;
      }
      sibling = sibling.previousElementSibling;
    }
    return null;
  }

  private getFirstDocumentFlowElement(): Element | null {
    const searchRoot = this.xmldoc.body || this.xmldoc.root;
    if (!searchRoot) {
      return null;
    }
    const searchRootOffset = this.xmldoc.getElementOffset(searchRoot);
    const startElement = this.getFirstInFlowElementAtOrAfter(
      searchRoot,
      searchRootOffset,
    );
    return startElement === searchRoot
      ? (this.getFirstInFlowChildElement(searchRoot) ?? startElement)
      : startElement;
  }

  private getEffectiveFirstPageType(element: Element | null): string | null {
    let currentElement = element;
    let effectivePageType = currentElement
      ? this.getPageGroupPageType(currentElement)
      : null;
    while (currentElement) {
      const child = this.getFirstInFlowChildElement(currentElement);
      if (!child) {
        return effectivePageType;
      }
      const childPageType = this.getPageGroupPageType(child);
      if (childPageType) {
        effectivePageType = childPageType;
      }
      currentElement = child;
    }
    return effectivePageType;
  }

  private getEffectivePageGroupStartElement(startElement: Element): Element {
    let effectiveStartElement = startElement;
    let currentElement: Element | null = startElement;
    while (currentElement) {
      const child = this.getFirstInFlowChildElement(currentElement);
      if (!child) {
        return effectiveStartElement;
      }
      if (this.getPageGroupPageType(child)) {
        effectiveStartElement = child;
      }
      currentElement = child;
    }
    return effectiveStartElement;
  }

  /**
   * Resolve the page type for the first page by examining the first in-flow
   * element's CSS `page` property. This is needed because `currentPageType`
   * is only set during layout (in ViewFactory), but the first page's type
   * must be known before layout begins for correct @page rule matching.
   *
   * Note: This must NOT set `currentPageType` as a side effect. Setting it
   * early would cause intermediate wrapper elements (whose page type is
   * null/auto) to get unwanted `breakBefore: "page"` during view tree
   * construction, since their page type would differ from `currentPageType`.
   * The `currentPageType` will be set naturally when the content element
   * is processed during layout. (Issue #1869, #1870)
   */
  private resolveFirstPageType(): string | null {
    const firstElement = this.getFirstDocumentFlowElement();
    return this.getEffectiveFirstPageType(firstElement);
  }

  private shouldStartPageGroup(
    element: Element,
    pageType: string,
    pageStartOffset: number,
  ): boolean {
    const style = this.styler.getStyle(element, false);
    if (!style) {
      return false;
    }

    if (this.getFirstDocumentFlowElement() === element) {
      return true;
    }

    const elementOffset = this.xmldoc.getElementOffset(element);
    const searchRoot = this.xmldoc.body || this.xmldoc.root;
    const searchRootOffset = this.xmldoc.getElementOffset(searchRoot);
    const isDocumentStart = pageStartOffset <= searchRootOffset;

    // Root/body page groups can start at document start even when the first
    // in-flow element is a descendant.
    if (isDocumentStart && element === searchRoot) {
      return true;
    }

    if (
      !this.getPreviousInFlowSibling(element) &&
      pageStartOffset === elementOffset
    ) {
      return true;
    }

    if (elementOffset !== pageStartOffset) {
      return false;
    }

    if (this.hasForcedPageBreakBefore(style)) {
      return true;
    }

    const previousSibling = this.getPreviousInFlowSibling(element);
    if (!previousSibling) {
      return false;
    }
    const previousStyle = this.styler.getStyle(previousSibling, false);
    if (!previousStyle) {
      return false;
    }

    const previousPageType = this.getExplicitPageType(previousStyle);
    return previousPageType !== pageType;
  }

  private updatePageGroupPageIndices(
    layoutPosition: Vtree.LayoutPosition | null,
  ): void {
    const pageCascade = this.pageManager.pageCascadeInstance;
    pageCascade.pageTypePageIndices = Object.create(null);
    const startSide = layoutPosition?.startSideOfFlow("body") || null;
    const bodyFlowPosition = layoutPosition?.flowPositions["body"];
    const hasBodyFlowContent = !!(
      bodyFlowPosition && bodyFlowPosition.positions.length
    );
    const isSpreadDeferredBlankPage =
      !!startSide &&
      Break.isSpreadBreakValue(startSide) &&
      !this.matchPageSide(startSide) &&
      !hasBodyFlowContent;
    // A synthetic blank first page can be inserted between concatenated
    // documents for spread alignment (issue #666). It must not consume
    // :nth(An+B of <page-type>) page-group indices.
    const isBlankPageAtDocumentStart =
      this.blankPageAtStart && (!layoutPosition || layoutPosition.page === 1);
    const canStartNewPageGroup =
      !isBlankPageAtDocumentStart &&
      !layoutPosition?.isBlankPage &&
      !isSpreadDeferredBlankPage;

    const pageStartOffset = this.getPageStartOffset(layoutPosition);
    const rawStartElement = this.getPageStartElement(
      layoutPosition,
      pageStartOffset,
    );

    if (!rawStartElement) {
      return;
    }

    const startElement =
      this.getEffectivePageGroupStartElement(rawStartElement);
    const effectivePageStartOffset =
      startElement === rawStartElement
        ? pageStartOffset
        : this.xmldoc.getElementOffset(startElement);

    const startDocument = startElement.ownerDocument;
    const isNewPageGroupDocument =
      this.currentPageGroupDocument !== startDocument;
    // Do not consume new-document boundary on synthetic blank pages at start;
    // keep it for the first real content page.
    const shouldActivateNewPageGroupDocument =
      isNewPageGroupDocument && canStartNewPageGroup;
    if (shouldActivateNewPageGroupDocument) {
      this.pageGroupPageCounts = Object.create(null);
      this.currentPageGroupDocument = startDocument;
    }

    let currentElement: Element | null = startElement;
    while (currentElement) {
      const pageType = this.getPageGroupPageType(currentElement);
      if (pageType) {
        const countsByElement =
          this.pageGroupPageCounts[pageType] ||
          (this.pageGroupPageCounts[pageType] = new Map());
        let pageIndex = countsByElement.get(currentElement) || 0;
        if (
          pageIndex > 0 ||
          (canStartNewPageGroup &&
            (shouldActivateNewPageGroupDocument ||
              this.shouldStartPageGroup(
                currentElement,
                pageType,
                effectivePageStartOffset,
              )))
        ) {
          pageIndex += 1;
          countsByElement.set(currentElement, pageIndex);

          const pageTypeIndices =
            pageCascade.pageTypePageIndices[pageType] ||
            (pageCascade.pageTypePageIndices[pageType] = []);
          pageTypeIndices.push(pageIndex);
        }
      }

      if (currentElement === this.xmldoc.root) {
        break;
      }
      currentElement = currentElement.parentElement;
    }
  }

  preparePageGroupPageIndicesForRerender(
    layoutPositions: Array<Vtree.LayoutPosition | null>,
    pageIndexToRender: number,
  ): void {
    this.pageGroupPageCounts = Object.create(null);
    this.currentPageGroupDocument = null;

    for (
      let previousPageIndex = 0;
      previousPageIndex < pageIndexToRender;
      previousPageIndex++
    ) {
      const previousLayoutPosition = layoutPositions[previousPageIndex] || null;
      this.updatePageGroupPageIndices(previousLayoutPosition);
    }
  }

  private getFirstInFlowElementAtOrAfter(
    root: Element,
    offset: number,
  ): Element | null {
    if (
      this.isPageBoundaryCandidateElement(root) &&
      this.xmldoc.getElementOffset(root) >= offset
    ) {
      return root;
    }
    const walker = root.ownerDocument.createTreeWalker(
      root,
      NodeFilter.SHOW_ELEMENT,
      {
        acceptNode: (node) => {
          const element = node as Element;
          if (!this.isNormalFlowElement(element)) {
            return NodeFilter.FILTER_REJECT;
          }
          if (this.isInlineLevelElement(element)) {
            return NodeFilter.FILTER_SKIP;
          }
          const nodeOffset = this.xmldoc.getElementOffset(element);
          if (nodeOffset < offset) {
            return NodeFilter.FILTER_SKIP;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      },
    );
    const node = walker.firstChild() as Element | null;
    return node ?? null;
  }

  private getDeepestFirstInFlowChildOffset(root: Element): number {
    let current = root;
    while (true) {
      const child = this.getFirstInFlowChildElement(current);
      if (!child) {
        return this.xmldoc.getElementOffset(current);
      }
      current = child;
    }
  }

  private getFirstInFlowChildElement(root: Element): Element | null {
    let child = root.firstChild;
    while (child) {
      if (child.nodeType === Node.TEXT_NODE) {
        if (!Vtree.canIgnore(child)) {
          return null;
        }
        child = child.nextSibling;
        continue;
      }
      if (child.nodeType !== Node.ELEMENT_NODE) {
        child = child.nextSibling;
        continue;
      }
      const element = child as Element;
      if (this.isNormalFlowElement(element)) {
        if (this.isInlineLevelElement(element)) {
          return null;
        }
        return element;
      }
      child = child.nextSibling;
    }
    return null;
  }

  private isPageBoundaryCandidateElement(element: Element): boolean {
    return (
      this.isNormalFlowElement(element) && !this.isInlineLevelElement(element)
    );
  }

  private isNormalFlowElement(element: Element): boolean {
    const style = this.styler.getStyle(element, false);
    const display = this.getDisplayValue(element);
    if (display === Css.ident.none) {
      return false;
    }
    const positionVal = (
      style?.["position"] as CssCascade.CascadeValue
    )?.evaluate(this.styler.context, "position");
    const position =
      positionVal && !Css.isDefaultingValue(positionVal)
        ? positionVal
        : Css.ident.static;
    if (
      Display.isRunning(position) ||
      Display.isAbsolutelyPositioned(position)
    ) {
      return false;
    }
    const floatVal = (style?.["float"] as CssCascade.CascadeValue)?.evaluate(
      this.styler.context,
      "float",
    );
    const float =
      floatVal && !Css.isDefaultingValue(floatVal) ? floatVal : Css.ident.none;
    if (float !== Css.ident.none) {
      return false;
    }
    return true;
  }

  private isInlineLevelElement(element: Element): boolean {
    return Display.isInlineLevel(this.getDisplayValue(element));
  }

  private getDisplayValue(element: Element): Css.Ident {
    const style = this.styler.getStyle(element, false);
    const displayVal = (
      style?.["display"] as CssCascade.CascadeValue
    )?.evaluate(this.styler.context, "display");
    return displayVal && !Css.isDefaultingValue(displayVal)
      ? (displayVal as Css.Ident)
      : Css.ident.inline;
  }

  /**
   * @param noLookAhead Do not look ahead elements that are not styled yet
   * @return document offset of the given layoutPosition
   */
  getPosition(
    layoutPosition?: Vtree.LayoutPosition | null,
    noLookAhead?: boolean,
  ): number {
    if (!layoutPosition) {
      return 0;
    }
    let currentPosition = Number.POSITIVE_INFINITY;
    for (const flowName in this.primaryFlows) {
      let flowPosition = layoutPosition.flowPositions[flowName];
      if (
        !noLookAhead &&
        (!flowPosition || flowPosition.positions.length == 0) &&
        this.currentLayoutPosition
      ) {
        this.styler.styleUntilFlowIsReached(flowName);
        flowPosition = this.currentLayoutPosition.flowPositions[flowName];
        if (layoutPosition != this.currentLayoutPosition) {
          if (flowPosition) {
            flowPosition = flowPosition.clone();
            layoutPosition.flowPositions[flowName] = flowPosition;
          }
        }
      }
      if (flowPosition) {
        const consumedOffset = this.getConsumedOffset(flowPosition);
        if (consumedOffset < currentPosition) {
          currentPosition = consumedOffset;
        }
      }
    }
    return currentPosition;
  }

  dumpLocation(position) {
    Logging.logger.debug("Location - page", this.currentLayoutPosition.page);
    Logging.logger.debug("  current:", position);
    Logging.logger.debug("  lookup:", this.lookupOffset);
    for (const flowName in this.currentLayoutPosition.flowPositions) {
      const flowPosition = this.currentLayoutPosition.flowPositions[flowName];
      for (const p of flowPosition.positions) {
        Logging.logger.debug(
          "  Chunk",
          `${flowName}:`,
          p.flowChunk.startOffset,
        );
      }
    }
  }

  matchPageSide(side: string | null): boolean {
    switch (side) {
      case "left":
      case "right":
      case "recto":
      case "verso":
        return new Exprs.Named(this.style.pageScope, `${side}-page`).evaluate(
          this,
        ) as boolean;
      default:
        return true;
    }
  }

  updateStartSide(layoutPosition: Vtree.LayoutPosition) {
    for (const name in layoutPosition.flowPositions) {
      const flowPos = layoutPosition.flowPositions[name];
      if (flowPos && flowPos.positions.length > 0) {
        const flowChunk = flowPos.positions[0].flowChunk;
        if (this.getConsumedOffset(flowPos) === flowChunk.startOffset) {
          const flowChunkBreakBefore =
            flowPos.positions[0].flowChunk.breakBefore;
          const flowBreakAfter = flowPos.startBreakType;
          flowPos.startBreakType = Break.breakValueToStartBreakType(
            Break.resolveEffectiveBreakValue(
              flowBreakAfter,
              flowChunkBreakBefore,
            ),
          );
        }
      }
    }
  }

  /**
   * @param cascadedPageStyle Cascaded page style specified in page context
   */
  selectPageMaster(
    cascadedPageStyle: CssCascade.ElementStyle,
  ): PageMaster.PageMasterInstance | null {
    const cp = this.currentLayoutPosition;

    // 3.5. Page Layout Processing Model
    // 1. Determine current position in the document: Find the minimal
    // consumed-offset for all elements not fully-consumed in each primary flow.
    // Current position is maximum of the results among all primary flows.
    let currentPosition = this.getPosition(cp);
    if (currentPosition == Number.POSITIVE_INFINITY) {
      if (this.hasActiveRootPageFloatLayoutContext()) {
        currentPosition =
          cp.highestSeenOffset ?? this.styler.getReachedOffset();
      }
    }
    if (currentPosition == Number.POSITIVE_INFINITY) {
      // end of primary content is reached
      return null;
    }

    // 2. Page master selection: for each page master:
    const pageMasters = this.rootPageBoxInstance
      .children as PageMaster.PageMasterInstance[];
    let pageMaster: PageMaster.PageMasterInstance;
    for (let i = 0; i < pageMasters.length; i++) {
      pageMaster = pageMasters[i];

      // Skip a page master generated for @page rules
      if (pageMaster.pageBox.pseudoName === CssPage.pageRuleMasterPseudoName) {
        continue;
      }
      let coeff = 1;
      if (
        pageMaster.pageBox.pseudoName ===
          PageMaster.userAgentPageMasterPseudo &&
        !(this.actualPageWidth && this.actualPageHeight)
      ) {
        // If page master is UA page master and page size is not determined,
        // set lookup position to infinity.
        // This is to prevent pagination problem depending on viewport size.
        // (Fix for Issue #1228)
        coeff = Infinity;
      }

      // A. Calculate lookup position using current position and utilization
      // (see -epubx-utilization property)
      const utilization = pageMaster.getProp(this, "utilization");
      if (utilization && utilization.isNum()) {
        coeff = (utilization as Css.Num).num;
      }
      const em = this.queryUnitSize("em", false);
      const pageArea = this.pageWidth() * this.pageHeight();
      const lookup = Math.ceil((coeff * pageArea) / (em * em));

      // B. Determine element eligibility. Each element in a flow is considered
      // eligible if it is is not marked as fully consumed and it comes in the
      // document before the lookup position. Feed lookupOffset and flow
      // availability into the context
      const savedPageType = this.styler.cascade.currentPageType;
      this.lookupOffset = this.styler.styleUntil(currentPosition, lookup);
      this.styler.cascade.currentPageType = savedPageType; // Fix for Issue #1450
      Asserts.assert(cp);
      this.updateStartSide(cp);

      // update layoutPositionAtPageStart since startSide of FlowChunks may be
      // updated
      this.layoutPositionAtPageStart = cp.clone();
      this.initLingering();
      this.clearScope(this.style.pageScope);

      // C. Determine content availability. Flow has content available if it
      // contains eligible elements. D. Determine if page master is enabled
      // using rules in Section 3.4.7
      const enabled = pageMaster.getProp(this, "enabled");

      // E. First enabled page master is used for the next page
      if (!enabled || enabled === Css.ident._true) {
        if (VIVLIOSTYLE_DEBUG) {
          this.dumpLocation(currentPosition);
        }

        // The blank page caused by a spread break between two documents
        // should have no margin box content (issue #666)
        if (cp.page === 1 && this.blankPageAtStart) {
          pageMaster.style = {}; // clear root background-color/image
          const size = cascadedPageStyle["size"];
          cascadedPageStyle = {}; // clear margin boxes
          if (size) {
            // Restore page size (fix for issue #743)
            cascadedPageStyle["size"] = size;
          }
        }

        // Apply @page rules
        return this.pageManager.getPageRulePageMaster(
          pageMaster,
          cascadedPageStyle,
        );
      }
    }
    throw new Error("No enabled page masters");
  }

  flowChunkIsAfterParentFlowForcedBreak(flowChunk: Vtree.FlowChunk): boolean {
    const flows = this.layoutPositionAtPageStart.flows;
    const parentFlowName = flows[flowChunk.flowName].parentFlowName;
    if (parentFlowName) {
      const startOffset = flowChunk.startOffset;
      const forcedBreakOffsets = flows[parentFlowName].forcedBreakOffsets;
      if (!forcedBreakOffsets.length || startOffset < forcedBreakOffsets[0]) {
        return false;
      }
      const breakOffsetBeforeStartIndex =
        Base.binarySearch(
          forcedBreakOffsets.length,
          (i) => forcedBreakOffsets[i] > startOffset,
        ) - 1;
      const breakOffsetBeforeStart =
        forcedBreakOffsets[breakOffsetBeforeStartIndex];
      const parentFlowPosition =
        this.layoutPositionAtPageStart.flowPositions[parentFlowName];
      const parentStartOffset = this.getConsumedOffset(parentFlowPosition);
      if (breakOffsetBeforeStart < parentStartOffset) {
        return false;
      }
      if (parentStartOffset < breakOffsetBeforeStart) {
        return true;
      }

      // Special case: parentStartOffset === breakOffsetBeforeStart
      // In this case, the flowChunk can be used if the start side of the parent
      // flow matches the current page side.
      return !this.matchPageSide(parentFlowPosition.startBreakType);
    }
    return false;
  }

  beginIsolatedRootPageFloatLayoutContext(
    previousPageFloatLayoutContext?: PageFloatsType.AttachedPageFloatLayoutContext | null,
  ): PageFloats.RootPageFloatLayoutContext {
    const originalRootPageFloatLayoutContext = this.rootPageFloatLayoutContext;
    this.rootPageFloatLayoutContext =
      PageFloats.RootPageFloatLayoutContext.createRoot();
    if (previousPageFloatLayoutContext) {
      this.rootPageFloatLayoutContext.addPageFloatLayoutContextAsPreviousSibling(
        previousPageFloatLayoutContext,
      );
    }
    return originalRootPageFloatLayoutContext;
  }

  endIsolatedRootPageFloatLayoutContext(
    originalRootPageFloatLayoutContext: PageFloats.RootPageFloatLayoutContext,
  ): void {
    this.rootPageFloatLayoutContext = originalRootPageFloatLayoutContext;
  }

  hasActiveRootPageFloatLayoutContext(): boolean {
    return (
      this.rootPageFloatLayoutContext.getDeferredPageFloatContinuations()
        .length > 0 ||
      this.rootPageFloatLayoutContext.getPageFloatContinuationsDeferredToNext()
        .length > 0 ||
      this.rootPageFloatLayoutContext.getFloatsDeferredToNextInChildContexts()
        .length > 0
    );
  }

  private hasOnlyDeferredPageFloats(cp: Vtree.LayoutPosition): boolean {
    return (
      this.noMorePrimaryFlows(cp) && this.hasActiveRootPageFloatLayoutContext()
    );
  }

  layoutDeferredPageFloats(column: LayoutType.Column): Task.Result<boolean> {
    const pageFloatLayoutContext = column.pageFloatLayoutContext;
    const deferredFloats =
      pageFloatLayoutContext.getDeferredPageFloatContinuations();
    const inCounterResolveScope =
      this.counterStore.currentPageCountersStack.length > 0;

    // Prevent deferred page floats from appearing in the preceding pages,
    // e.g., during re-layout the TOC page with target-counter() referencing
    // later sections containing page floats. (Issue #681)
    const checkPageFloatForLaterPage = (
      float: PageFloats.PageFloat,
    ): boolean => {
      if (!inCounterResolveScope) {
        return false;
      }
      // FIXME: This check is incomplete when float-reference is other than "page".
      // so give up for now to prevent another problem (Issue #962, #1273).
      if (float.floatReference !== PageFloats.FloatReference.PAGE) {
        return false;
      }
      const pageStartPos =
        this.layoutPositionAtPageStart?.flowPositions?.body || null;
      const pageStartOffsetFromBody = pageStartPos
        ? this.getConsumedOffset(pageStartPos)
        : Number.NaN;
      const pageStartOffset = isFinite(pageStartOffsetFromBody)
        ? pageStartOffsetFromBody
        : this.getPageStartOffset(this.layoutPositionAtPageStart, true);
      const deferredFloatOffset = this.xmldoc.getNodeOffset(
        float.nodePosition.steps[0].node,
        0,
        false,
      );
      return (
        deferredFloatOffset != null &&
        isFinite(pageStartOffset) &&
        deferredFloatOffset > pageStartOffset
      );
    };

    const frame = Task.newFrame<boolean>("layoutDeferredPageFloats");
    let invalidated = false;
    let i = 0;
    frame
      .loopWithFrame((loopFrame) => {
        if (i === deferredFloats.length) {
          loopFrame.breakLoop();
          return;
        }
        const continuation = deferredFloats[i++];
        const float = continuation.float;

        // Prevent deferred page floats from appearing in the preceding pages
        // (Issue #681)
        if (checkPageFloatForLaterPage(float)) {
          loopFrame.breakLoop();
          return;
        }

        const strategy =
          new PageFloats.PageFloatLayoutStrategyResolver().findByFloat(float);
        const pageFloatFragment = strategy.findPageFloatFragment(
          float,
          pageFloatLayoutContext,
        );
        if (pageFloatFragment && pageFloatFragment.hasFloat(float)) {
          loopFrame.continueLoop();
          return;
        } else if (
          pageFloatLayoutContext.isForbidden(float) ||
          pageFloatLayoutContext.hasPrecedingFloatsDeferredToNext(float)
        ) {
          pageFloatLayoutContext.deferPageFloat(continuation);
          loopFrame.breakLoop();
          return;
        }
        column
          .layoutPageFloatInner(continuation, strategy, null, pageFloatFragment)
          .then((success) => {
            if (!success) {
              loopFrame.breakLoop();
              return;
            }
            const parentInvalidated =
              pageFloatLayoutContext.parent.isInvalidated();
            if (parentInvalidated) {
              loopFrame.breakLoop();
              return;
            } else if (
              pageFloatLayoutContext.isInvalidated() &&
              !parentInvalidated
            ) {
              invalidated = true;
              pageFloatLayoutContext.validate();
            }
            loopFrame.continueLoop();
          });
      })
      .then(() => {
        if (invalidated) {
          pageFloatLayoutContext.invalidate();
        }
        frame.finish(true);
      });
    return frame.result();
  }

  getLastAfterPositionIfDeferredFloatsExists(
    column: LayoutType.Column,
    newPosition: Vtree.ChunkPosition | null,
  ): Vtree.ChunkPosition | null {
    const pageFloatLayoutContext = column.pageFloatLayoutContext;
    const deferredFloats =
      pageFloatLayoutContext.getPageFloatContinuationsDeferredToNext();
    if (deferredFloats.length > 0) {
      if (column.lastAfterPosition) {
        let result: Vtree.ChunkPosition;
        if (newPosition) {
          // Need overflown footnotes owned by newPosition
          result = newPosition.clone();
          result.primary = column.lastAfterPosition;
        } else {
          result = new Vtree.ChunkPosition(column.lastAfterPosition);
        }
        return result;
      } else {
        // Deferred floats do not imply an after position. A column that laid
        // out no content leaves none.
        return null;
      }
    } else {
      return null;
    }
  }

  // A flow is registered only once a chunk of it is encountered, so a column
  // for a flow that has none has no root to share a context with.
  private flowRootFormattingContextFor(
    flowName: string,
  ): Vtree.FormattingContext {
    return (
      this.currentLayoutPosition.flows[flowName]?.formattingContext ??
      new LayoutProcessor.BlockFormattingContext(null)
    );
  }

  /**
   * @return holding true
   */
  layoutColumn(
    column: LayoutType.Column,
    flowName: string,
  ): Task.Result<boolean> {
    const flowPosition = this.currentLayoutPosition.flowPositions[flowName];
    if (!flowPosition || !this.matchPageSide(flowPosition.startBreakType)) {
      // On blank pages created by spread breaks (e.g., break-after: left),
      // still try to place deferred page floats such as footnotes that were
      // deferred from the previous page. (Issue #1880)
      if (flowPosition) {
        return this.layoutDeferredPageFloats(column);
      }
      return Task.newResult(true);
    }

    if (this.primaryFlows[flowName] && column.bands.length > 0) {
      // In general, we force non-fitting content. Exception is only for primary
      // flow columns that have exclusions.
      column.forceNonfitting = false;
    }
    const frame: Task.Frame<boolean> = Task.newFrame("layoutColumn");
    this.layoutDeferredPageFloats(column).then(() => {
      if (column.pageFloatLayoutContext.isInvalidated()) {
        frame.finish(true);
        return;
      }

      // Record indices of repeated positions and removed positions
      const repeatedIndices = [] as number[];
      const removedIndices = [] as number[];
      let leadingEdge = true;
      frame
        .loopWithFrame((loopFrame) => {
          if (
            column.pageFloatLayoutContext.hasContinuingFloatFragmentsInFlow(
              flowName,
            )
          ) {
            loopFrame.breakLoop();
            return;
          }
          while (flowPosition.positions.length - removedIndices.length > 0) {
            let index = 0;

            // Skip all removed positions
            while (removedIndices.includes(index)) {
              index++;
            }
            let selected = flowPosition.positions[index];
            if (
              selected.flowChunk.startOffset > this.lookupOffset ||
              this.flowChunkIsAfterParentFlowForcedBreak(selected.flowChunk)
            ) {
              break;
            }
            for (let k = index + 1; k < flowPosition.positions.length; k++) {
              if (removedIndices.includes(k)) {
                continue; // Skip removed positions
              }
              const alt = flowPosition.positions[k];
              if (
                alt.flowChunk.startOffset > this.lookupOffset ||
                this.flowChunkIsAfterParentFlowForcedBreak(alt.flowChunk)
              ) {
                break;
              }
              if (alt.flowChunk.isBetter(selected.flowChunk)) {
                selected = alt;
                index = k;
              }
            }
            const flowChunk = selected.flowChunk;
            let pending = true;
            column
              .layout(
                selected.chunkPosition,
                leadingEdge,
                flowPosition.breakAfter,
              )
              .then((newPosition) => {
                if (column.pageFloatLayoutContext.isInvalidated()) {
                  loopFrame.breakLoop();
                  return;
                }
                leadingEdge = false;

                // static: keep in the flow
                if (
                  selected.flowChunk.repeated &&
                  (newPosition === null || flowChunk.exclusive)
                ) {
                  repeatedIndices.push(index);
                }
                if (flowChunk.exclusive) {
                  // exclusive, only can have one, remove from the flow even
                  // if it did not fit
                  removedIndices.push(index);
                  loopFrame.breakLoop();
                  return;
                } else {
                  // not exclusive
                  const endOfColumn = !!newPosition || !!column.pageBreakType;
                  const lastAfterPosition =
                    this.getLastAfterPositionIfDeferredFloatsExists(
                      column,
                      newPosition,
                    );
                  // CSS Fragmentation: forced break-after on the last child
                  // of a fragmentainer has no effect when there is no more
                  // content after it. When all content in the flow is consumed
                  // (newPosition is null and no remaining flow chunks) and the
                  // column has a pageBreakType from the last element's
                  // break-after, clear it to avoid generating unnecessary
                  // blank pages. (Issue #1880)
                  if (!newPosition && column.pageBreakType) {
                    // Count remaining positions (excluding current and removed)
                    const remainingPositions =
                      flowPosition.positions.length - removedIndices.length - 1; // -1 for current position being removed
                    if (remainingPositions <= 0) {
                      column.pageBreakType = null;
                    }
                  }
                  if (column.pageBreakType && lastAfterPosition) {
                    selected.chunkPosition = lastAfterPosition;

                    // TODO propagate pageBreakType
                    flowPosition.breakAfter = column.pageBreakType;
                    column.pageBreakType = null;
                  } else {
                    // go to the next element in the flow
                    removedIndices.push(index);
                    if (newPosition || lastAfterPosition) {
                      // did not fit completely
                      selected.chunkPosition = newPosition || lastAfterPosition;
                      repeatedIndices.push(index);
                    }
                    // forced break or "auto"
                    flowPosition.startBreakType =
                      Break.breakValueToStartBreakType(column.pageBreakType);
                  }
                  if (endOfColumn) {
                    loopFrame.breakLoop();
                    return;
                  }
                }

                // Since at least one flowChunk has been placed in the
                // column, the next flowChunk of the flow can be deferred to
                // the next partition if there is not enough space in the
                // current partition.
                column.forceNonfitting = false;
                if (pending) {
                  // Sync result
                  pending = false;
                } else {
                  // Async result
                  loopFrame.continueLoop();
                }
              });
            if (pending) {
              // Async result
              pending = false;
              return;
            }
          }

          // Sync result
          loopFrame.breakLoop();
        })
        .then(() => {
          if (!column.pageFloatLayoutContext.isInvalidated()) {
            // Keep positions repeated or not removed
            flowPosition.positions = flowPosition.positions.filter(
              (pos, i) =>
                repeatedIndices.includes(i) || !removedIndices.includes(i),
            );
            if (flowPosition.breakAfter === "column") {
              flowPosition.breakAfter = null;
            }
            column.saveDistanceToBlockEndFloats();
            const edge = column.pageFloatLayoutContext.getMaxReachedAfterEdge();
            column.updateMaxReachedAfterEdge(edge);

            // CSS GCPM §2.4.2: "The max-height property on the footnote area
            // limits the size of this area, unless the page contains only
            // footnotes." (Issue #1878)
            // Detect pages with only footnote continuation(s) and no body
            // content. If the column placed no body content (computedBlockSize
            // is 0) and there are footnote fragments with max-height, remove
            // those fragments and retry without max-height.
            if (column.computedBlockSize === 0) {
              const colCtx = column.pageFloatLayoutContext;
              // Traverse up the context hierarchy to find footnote fragments
              // (footnotes are stored at the PAGE-level context)
              let ctx: PageFloatsType.PageFloatLayoutContext | null = colCtx;
              while (ctx) {
                const footnoteFragments = ctx.floatFragments.filter(
                  (f) => "isFootnote" in f.area && (f.area as any).isFootnote,
                );
                if (
                  footnoteFragments.length > 0 &&
                  !ctx.ignoreFootnoteAreaMaxHeight
                ) {
                  const hasMaxHeight = footnoteFragments.some((f) => {
                    const cs = getComputedStyle(f.area.element);
                    const isSet = (v: string) => v !== "" && v !== "none";
                    // Check the logical property first, then the
                    // corresponding physical property for block direction
                    return (
                      isSet(cs.getPropertyValue("max-block-size")) ||
                      isSet(
                        (f.area as any).vertical ? cs.maxWidth : cs.maxHeight,
                      )
                    );
                  });
                  if (hasMaxHeight) {
                    ctx.ignoreFootnoteAreaMaxHeight = true;
                    for (const frag of footnoteFragments) {
                      // Remove fragment so it can be re-laid out
                      colCtx.removePageFloatFragment(frag, true);
                      // Remove deferred continuation from first pass
                      const float = frag.continuations[0]?.float;
                      if (float) {
                        ctx.removeFloatDeferredToNext(float);
                      }
                    }
                    // Invalidate column to trigger retry
                    colCtx.invalidate();
                    break;
                  }
                }
                ctx = ctx.parent;
              }
            }
          }
          frame.finish(true);
        });
    });
    return frame.result();
  }

  createLayoutConstraint(
    pageFloatLayoutContext: PageFloats.PageFloatLayoutContext,
  ): LayoutType.LayoutConstraint {
    const pageIndex = this.currentLayoutPosition.page - 1;
    const counterConstraint =
      this.counterStore.createLayoutConstraint(pageIndex);
    return new Layout.AllLayoutConstraint(
      [counterConstraint].concat(pageFloatLayoutContext.getLayoutConstraints()),
    );
  }

  private createAndLayoutColumn(
    boxInstance: PageMaster.PageBoxInstance,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
    layoutContainer: Vtree.Container,
    currentColumnIndex: number,
    flowNameStr: string,
    regionPageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    columnCount: number,
    columnGap: number,
    columnWidth: number,
    innerShape: GeometryUtil.Shape | null,
    layoutContext: Vtree.LayoutContext,
    forceNonFitting: boolean,
  ): Task.Result<LayoutType.Column> {
    // Don't apply exclusions from sibling partitions when the partition's
    // position or inline-size is unknown during layout:
    // - auto block-size with before-edge dependency: position is unknown
    // - auto inline-size: partition will shrink to fit content, so exclusions
    //   from distant positions create incorrect float spacers (Issue #1171)
    const dontApplyExclusions = boxInstance.vertical
      ? (boxInstance.isAutoWidth && boxInstance.isRightDependentOnAutoWidth) ||
        boxInstance.isAutoHeight
      : (boxInstance.isAutoHeight && boxInstance.isTopDependentOnAutoHeight) ||
        boxInstance.isAutoWidth;
    const boxContainer = layoutContainer.element;
    const columnPageFloatLayoutContext =
      PageFloats.PageFloatLayoutContext.create(
        regionPageFloatLayoutContext,
        PageFloats.FloatReference.COLUMN,
        flowNameStr,
        null,
        null,
        null,
      );
    const positionAtColumnStart = this.currentLayoutPosition.clone();
    const frame: Task.Frame<LayoutType.Column> = Task.newFrame(
      "createAndLayoutColumn",
    );
    let column: LayoutType.Column;
    frame
      .loopWithFrame((loopFrame) => {
        const layoutConstraint = this.createLayoutConstraint(
          columnPageFloatLayoutContext,
        );
        if (columnCount > 1) {
          const columnContainer = this.viewport.document.createElement("div");
          Base.setCSSProperty(columnContainer, "position", "absolute");
          boxContainer.appendChild(columnContainer);
          let columnLeft: number;
          let columnTop: number;
          let columnBoxWidth: number;
          let columnBoxHeight: number;
          if (layoutContainer.vertical) {
            const columnY =
              (layoutContainer.rtl
                ? columnCount - currentColumnIndex - 1
                : currentColumnIndex) *
                (columnWidth + columnGap) +
              layoutContainer.paddingTop;
            const outerWidth = parseFloat(boxContainer.style.width);
            columnLeft =
              layoutContainer.paddingLeft + outerWidth - layoutContainer.width;
            columnBoxWidth = layoutContainer.width;
            columnTop = columnY;
            columnBoxHeight = columnWidth;
          } else {
            const columnX =
              (layoutContainer.rtl
                ? columnCount - currentColumnIndex - 1
                : currentColumnIndex) *
                (columnWidth + columnGap) +
              layoutContainer.paddingLeft;
            columnLeft = columnX;
            columnBoxWidth = columnWidth;
            columnTop = layoutContainer.paddingTop;
            columnBoxHeight = layoutContainer.height;
          }
          // Position the freshly created element before it is measured.
          Base.setCSSProperty(columnContainer, "left", `${columnLeft}px`);
          Base.setCSSProperty(columnContainer, "top", `${columnTop}px`);
          column = new Layout.Column(
            columnContainer,
            layoutContext,
            this.clientLayout,
            layoutConstraint,
            columnPageFloatLayoutContext,
            {
              vertical: layoutContainer.vertical,
              rtl: layoutContainer.rtl,
              snapWidth: layoutContainer.snapWidth,
              snapHeight: layoutContainer.snapHeight,
              originX: offsetX,
              originY: offsetY,
              left: columnLeft,
              top: columnTop,
              width: columnBoxWidth,
              height: columnBoxHeight,
              marginLeft: 0,
              marginRight: 0,
              marginTop: 0,
              marginBottom: 0,
              borderLeft: 0,
              borderRight: 0,
              borderTop: 0,
              borderBottom: 0,
              paddingLeft: 0,
              paddingRight: 0,
              paddingTop: 0,
              paddingBottom: 0,
              borderBoxSizing: false,
            },
            innerShape,
            dontApplyExclusions ? [] : [...exclusions],
            this.flowRootFormattingContextFor(flowNameStr),
          );
          // Issue #1842: columns after the first treat already-satisfied leading
          // column breaks differently.
          column.isNonFirstColumn = currentColumnIndex > 0;
          column.forceNonfitting = forceNonFitting;
        } else {
          column = new Layout.Column(
            boxContainer,
            layoutContext,
            this.clientLayout,
            layoutConstraint,
            columnPageFloatLayoutContext,
            layoutContainer,
            innerShape,
            dontApplyExclusions ? [] : [...exclusions],
            this.flowRootFormattingContextFor(flowNameStr),
          );
          // Single-column layout always behaves like the first column on a page.
          column.isNonFirstColumn = false;
        }
        if ((column.vertical ? column.height : column.width) >= 0) {
          // column.element.style.outline = "1px dotted green";
          const columnContext = column.pageFloatLayoutContext;
          this.layoutColumn(column, flowNameStr).then(() => {
            if (!columnContext.isInvalidated()) {
              columnContext.finish();
            }
            if (
              column.pageFloatLayoutContext.isInvalidated() &&
              !regionPageFloatLayoutContext.isInvalidated()
            ) {
              column.pageFloatLayoutContext.validate();
              this.currentLayoutPosition = positionAtColumnStart.clone();
              if (column.element !== boxContainer) {
                boxContainer.removeChild(column.element);
              }
              loopFrame.continueLoop();
            } else {
              loopFrame.breakLoop();
            }
          });
        } else {
          column.pageFloatLayoutContext.finish();
          loopFrame.breakLoop();
        }
      })
      .then(() => {
        frame.finish(column);
      });
    return frame.result();
  }

  getRegionPageFloatLayoutContext(
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    boxInstance: PageMaster.PageBoxInstance,
    layoutContainer: Vtree.Container,
    flowName: string,
  ): PageFloats.AttachedPageFloatLayoutContext {
    Asserts.assert(boxInstance instanceof PageMaster.PartitionInstance);
    const writingMode = boxInstance.getProp(this, "writing-mode") || null;
    const direction = boxInstance.getProp(this, "direction") || null;
    return PageFloats.PageFloatLayoutContext.createWithContainer(
      layoutContainer,
      pagePageFloatLayoutContext,
      PageFloats.FloatReference.REGION,
      flowName,
      null,
      writingMode,
      direction,
    );
  }

  layoutFlowColumnsWithBalancing(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    layoutContainer: Vtree.Container,
    flowNameStr: string,
    columnCount: number,
  ): Task.Result<LayoutType.Column[] | null> {
    const positionAtContainerStart = this.currentLayoutPosition.clone();
    const regionPageFloatLayoutContext = this.getRegionPageFloatLayoutContext(
      pagePageFloatLayoutContext,
      boxInstance,
      layoutContainer,
      flowNameStr,
    );
    let isFirstTime = true;

    const layoutColumns = () => {
      this.currentLayoutPosition = positionAtContainerStart.clone();
      return this.layoutFlowColumns(
        page,
        boxInstance,
        offsetX,
        offsetY,
        exclusions,
        pagePageFloatLayoutContext,
        regionPageFloatLayoutContext,
        layoutContainer,
        flowNameStr,
        columnCount,
        isFirstTime,
      ).thenAsync((columns) => {
        if (columns) {
          return Task.newResult({
            columns,
            position: this.currentLayoutPosition,
          });
        } else {
          return Task.newResult(null);
        }
      });
    };

    return layoutColumns().thenAsync((generatorResult) => {
      if (!generatorResult) {
        return Task.newResult(null);
      }
      if (columnCount <= 1) {
        return Task.newResult(generatorResult.columns);
      }
      const columnFill =
        (boxInstance.getProp(this, "column-fill") as Css.Ident) ||
        Css.ident.balance;
      const flowPosition =
        this.currentLayoutPosition.flowPositions[flowNameStr];
      Asserts.assert(flowPosition);
      const columnBalancer = Columns.createColumnBalancer(
        columnCount,
        columnFill,
        layoutColumns,
        regionPageFloatLayoutContext,
        layoutContainer,
        generatorResult.columns,
        flowPosition,
      );
      if (!columnBalancer) {
        return Task.newResult(generatorResult.columns);
      }
      isFirstTime = false;
      pagePageFloatLayoutContext.lock();
      regionPageFloatLayoutContext.lock();
      return columnBalancer
        .balanceColumns(generatorResult)
        .thenAsync((result) => {
          pagePageFloatLayoutContext.unlock();
          pagePageFloatLayoutContext.validate();
          regionPageFloatLayoutContext.unlock();
          this.currentLayoutPosition = result.position;
          return Task.newResult(result.columns);
        });
    });
  }

  layoutFlowColumns(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    regionPageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    layoutContainer: Vtree.Container,
    flowNameStr: string,
    columnCount: number,
    forceNonFitting: boolean,
  ): Task.Result<LayoutType.Column[] | null> {
    const frame: Task.Frame<LayoutType.Column[] | null> =
      Task.newFrame("layoutFlowColumns");
    const positionAtContainerStart = this.currentLayoutPosition.clone();
    // Save formatting context states so they can be restored on region-level
    // retry (e.g., when footnotes invalidate the page float context).
    // LayoutPosition.clone() shares formatting context objects by reference
    // (via NodePositionStep.formattingContext), so modifications like
    // cellBreakPositions in TableFormattingContext persist across retries
    // unless explicitly restored. (Issue #1663)
    const savedRegionFCStates = collectFormattingContextStates(
      this.currentLayoutPosition,
    );
    const columnGap = boxInstance.getPropAsNumber(this, "column-gap");

    // Don't query columnWidth when it's not needed, so that width calculation
    // can be delayed for width: auto columns.
    const columnWidth =
      columnCount > 1
        ? boxInstance.getPropAsNumber(this, "column-width")
        : layoutContainer.vertical
          ? layoutContainer.height
          : layoutContainer.width;
    const regionIds = boxInstance.getActiveRegions(this);
    const innerShapeVal = boxInstance.getProp(this, "shape-inside");
    const innerShape = CssProp.toShape(
      innerShapeVal,
      0,
      0,
      layoutContainer.width,
      layoutContainer.height,
      this,
    );
    const layoutContext = new Vgen.ViewFactory(
      flowNameStr,
      this,
      this.viewport,
      this.styler,
      regionIds,
      this.xmldoc,
      this.faces,
      this.style.footnoteProps,
      this,
      page,
      this.customRenderer,
      this.fallbackMap,
      this.documentURLTransformer,
      this.style.pageProps,
      this.currentCascadedPageStyle,
      this.semanticFootnoteFirstRefOffsets,
      this.semanticFootnoteFirstRefOffsetsInitialized,
    );
    let columnIndex = 0;
    let column: LayoutType.Column | null = null;
    let columns: LayoutType.Column[] = [];
    frame
      .loopWithFrame((loopFrame) => {
        this.createAndLayoutColumn(
          boxInstance,
          offsetX,
          offsetY,
          exclusions,
          layoutContainer,
          columnIndex++,
          flowNameStr,
          regionPageFloatLayoutContext,
          columnCount,
          columnGap,
          columnWidth,
          innerShape,
          layoutContext,
          forceNonFitting,
        ).then((c) => {
          if (pagePageFloatLayoutContext.isInvalidated()) {
            columns = null;
            loopFrame.breakLoop();
            return;
          }
          const forcedRegionBreak =
            !!c.pageBreakType && c.pageBreakType !== "column";
          if (
            (forcedRegionBreak || columnIndex === columnCount) &&
            !regionPageFloatLayoutContext.isInvalidated()
          ) {
            regionPageFloatLayoutContext.finish();
          }
          if (regionPageFloatLayoutContext.isInvalidated()) {
            columnIndex = 0;
            this.currentLayoutPosition = positionAtContainerStart.clone();
            // Restore formatting context states on region-level retry
            // (Issue #1663)
            restoreFormattingContextStates(savedRegionFCStates);
            regionPageFloatLayoutContext.validate();
            if (regionPageFloatLayoutContext.isLocked()) {
              columns = null;
              loopFrame.breakLoop();
            } else {
              loopFrame.continueLoop();
            }
            return;
          }
          column = c;
          columns[columnIndex - 1] = column;
          if (column.pageBreakType) {
            if (column.pageBreakType != "column") {
              // skip remaining columns
              columnIndex = columnCount;
              if (column.pageBreakType != "region") {
                // skip remaining regions
                this.pageBreaks[flowNameStr] = true;
              }
            }
          }
          if (columnIndex < columnCount) {
            loopFrame.continueLoop();
          } else {
            loopFrame.breakLoop();
          }
        });
      })
      .then(() => {
        frame.finish(columns);
      });
    return frame.result();
  }

  private openPageBox(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    parentContainer: HTMLElement,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
  ): OpenedPageBox {
    const wrapFlow = boxInstance.getProp(this, "wrap-flow");
    const dontExclude = wrapFlow === Css.ident.auto;
    const flowName = boxInstance.getProp(this, "flow-from");
    const boxContainer = this.viewport.document.createElement("div");
    boxContainer.role =
      boxInstance instanceof CssPage.PageMarginBoxPartitionInstance
        ? "complementary"
        : "presentation";
    const position = boxInstance.getProp(this, "position");
    Base.setCSSProperty(
      boxContainer,
      "position",
      position ? (position as any).name : "absolute",
    );

    // The -epubx-page-master partitions are laid out in the reverse order
    // (see the spec http://idpf.org/epub/pgt/ ),
    // but for css-page rules, now use forward order, i.e., the page-area first.
    // This is necessary for running headers named strings support.
    const forwardOrderInLayout =
      boxInstance instanceof CssPage.PageRuleMasterInstance;
    const forwardOrderInTree =
      boxInstance instanceof PageMaster.PartitionInstance;

    if (forwardOrderInTree) {
      parentContainer.appendChild(boxContainer);
    } else {
      parentContainer.insertBefore(boxContainer, parentContainer.firstChild);
    }

    const container = new Vtree.Container(boxContainer);
    container.vertical = boxInstance.vertical;
    container.rtl = boxInstance.rtl;
    container.borderBoxSizing = boxInstance.borderBoxSizing;
    container.exclusions = exclusions;
    boxInstance.prepareContainer(
      this,
      container,
      page,
      this.faces,
      this.clientLayout,
    );

    if (
      (container.width <= 0 || container.height <= 0) &&
      (boxInstance instanceof CssPage.PageRuleMasterInstance ||
        (flowName && flowName.isIdent()))
    ) {
      this.invalidPageAreaOnCurrentPage = true;
      Logging.logger.warn("Negative or zero page area size");
    }

    container.originX = offsetX;
    container.originY = offsetY;
    return {
      boxContainer,
      container,
      offsetX:
        offsetX + container.left + container.marginLeft + container.borderLeft,
      offsetY:
        offsetY + container.top + container.marginTop + container.borderTop,
      flowName,
      dontExclude,
      forwardOrderInLayout,
      removed: false,
    };
  }

  /** Takes no flow, the one part that can run before the context is attached. */
  private layoutGeneratedContent(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    opened: OpenedPageBox,
    parentContainer: HTMLElement,
  ): Task.Result<boolean> {
    const boxContainer = opened.boxContainer;
    const fetchers: TaskUtil.Fetcher<string>[] = [];
    const contentVal = boxInstance.getProp(this, "content");
    if (
      contentVal instanceof Css.Expr &&
      contentVal.expr instanceof Exprs.Native &&
      contentVal.expr.str.startsWith("running-element-")
    ) {
      // Single running element
      contentVal.visit(
        new Vtree.ContentPropertyHandler(
          boxContainer,
          this,
          contentVal,
          this.counterStore.getExprContentListener(),
        ),
      );
    } else if (Vtree.nonTrivialContent(contentVal)) {
      let innerContainerTag = "span";
      if (contentVal instanceof Css.URL) {
        innerContainerTag = "img";
      }
      const innerContainer =
        this.viewport.document.createElement(innerContainerTag);
      contentVal.visit(
        new Vtree.ContentPropertyHandler(
          innerContainer,
          this,
          contentVal,
          this.counterStore.getExprContentListener(),
        ),
      );
      boxContainer.appendChild(innerContainer);
      if (innerContainerTag == "img") {
        boxInstance.transferSingleUriContentProps(
          this,
          innerContainer,
          this.faces,
        );
      }
      boxInstance.transferContentProps(
        this,
        opened.container,
        page,
        this.faces,
      );
      const images = innerContainer.querySelectorAll("img[src]");
      for (let i = 0; i < images.length; i++) {
        const image = images[i] as HTMLImageElement;
        const src = image.getAttribute("src");
        if (!src) {
          continue;
        }
        const fetcher = Net.loadElement(image, src);
        fetchers.push(fetcher);
        page.fetchers.push(fetcher);
      }

      const rootSrc = innerContainer.getAttribute("src");
      if (rootSrc) {
        let image = innerContainer.querySelector(
          "img",
        ) as HTMLImageElement | null;
        if (!image) {
          image = innerContainer as HTMLImageElement;
        }
        const fetcher = Net.loadElement(image, rootSrc);
        fetchers.push(fetcher);
        page.fetchers.push(fetcher);
      }
      if (innerContainerTag == "span") {
        // text-spacing & hanging-punctuation on margin boxes
        TextPolyfill.processGeneratedContent(
          innerContainer,
          boxInstance.getProp(this, "text-autospace"),
          boxInstance.getProp(this, "text-spacing-trim"),
          boxInstance.getProp(this, "hanging-punctuation"),
          this.lang,
          boxInstance.vertical,
        );
      }
    } else if (boxInstance.suppressEmptyBoxGeneration) {
      parentContainer.removeChild(boxContainer);
      opened.removed = true;
    }
    if (!opened.removed) {
      boxInstance.finishContainer(
        this,
        opened.container,
        page,
        null,
        1,
        this.clientLayout,
        this.faces,
      );
    }
    return fetchers.length
      ? TaskUtil.waitForFetchers(fetchers).thenReturn(true)
      : Task.newResult(true);
  }

  private layoutPageBoxContent(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    opened: OpenedPageBox,
    parentContainer: HTMLElement,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
  ): Task.Result<boolean> {
    const boxContainer = opened.boxContainer;
    const flowName = opened.flowName;
    if (!flowName || !flowName.isIdent()) {
      return this.layoutGeneratedContent(
        page,
        boxInstance,
        opened,
        parentContainer,
      );
    }
    if (!this.pageBreaks[flowName.toString()]) {
      const innerFrame: Task.Frame<boolean> = Task.newFrame(
        "layoutPageBoxContent.inner",
      );
      const flowNameStr = flowName.toString();

      // for now only a single column in vertical case
      const columnCount = boxInstance.getPropAsNumber(this, "column-count");
      this.layoutFlowColumnsWithBalancing(
        page,
        boxInstance,
        opened.offsetX,
        opened.offsetY,
        exclusions,
        pagePageFloatLayoutContext,
        opened.container,
        flowNameStr,
        columnCount,
      ).then((columns) => {
        if (!pagePageFloatLayoutContext.isInvalidated()) {
          const column = columns[0];
          Asserts.assert(column);
          if (column.element === boxContainer) {
            opened.container = column;
          }
          opened.container.computedBlockSize = Math.max(
            ...columns.map((c) => c.computedBlockSize),
          );
          boxInstance.finishContainer(
            this,
            opened.container,
            page,
            column,
            columnCount,
            this.clientLayout,
            this.faces,
          );
          const flowPosition =
            this.currentLayoutPosition.flowPositions[flowNameStr];
          if (flowPosition && flowPosition.breakAfter === "region") {
            flowPosition.breakAfter = null;
          }
        }
        innerFrame.finish(true);
      });
      return innerFrame.result();
    }
    if (!pagePageFloatLayoutContext.isInvalidated()) {
      boxInstance.finishContainer(
        this,
        opened.container,
        page,
        null,
        1,
        this.clientLayout,
        this.faces,
      );
    }
    return Task.newResult(true);
  }

  /**
   * Pushes this box's exclusion shape, or removes it when it turned out empty.
   * @return whether the layout continues into the children
   */
  private excludeOrRemovePageBox(
    boxInstance: PageMaster.PageBoxInstance,
    opened: OpenedPageBox,
    parentContainer: HTMLElement,
    exclusions: GeometryUtil.Shape[],
  ): boolean {
    if (
      !boxInstance.isAutoHeight ||
      Math.floor(opened.container.computedBlockSize) > 0
    ) {
      if (!opened.removed && !opened.dontExclude) {
        const outerShapeProp = boxInstance.getProp(this, "shape-outside");
        const outerShape = opened.container.getOuterShape(outerShapeProp, this);
        exclusions.push(outerShape);
      }
    } else if (boxInstance.children.length == 0) {
      parentContainer.removeChild(opened.boxContainer);
      return false;
    }
    return true;
  }

  private layoutPageBoxChildren(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    opened: OpenedPageBox,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
    skip: PageMaster.PageBoxInstance | null = null,
  ): Task.Result<boolean> {
    const frame: Task.Frame<boolean> = Task.newFrame("layoutPageBoxChildren");
    const forwardOrderInLayout = opened.forwardOrderInLayout;
    let i = forwardOrderInLayout ? 0 : boxInstance.children.length - 1;
    frame
      .loop(() => {
        while (i >= 0 && i < boxInstance.children.length) {
          const child = boxInstance.children[forwardOrderInLayout ? i++ : i--];
          if (child === skip) {
            continue;
          }
          const r = this.layoutContainer(
            page,
            child,
            opened.boxContainer,
            opened.offsetX,
            opened.offsetY,
            exclusions,
            pagePageFloatLayoutContext,
          );
          if (r.isPending()) {
            return r.thenAsync(() =>
              Task.newResult(!pagePageFloatLayoutContext.isInvalidated()),
            );
          } else if (pagePageFloatLayoutContext.isInvalidated()) {
            break;
          }
        }
        return Task.newResult(false);
      })
      .then(() => {
        frame.finish(true);
      });
    return frame.result();
  }

  /**
   * The context becomes attached at the page area. Boxes reached before that
   * point cannot take a flow, having no container for its floats.
   */
  private layoutPageAreaEstablishingContainer(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance & PageMaster.PageAreaEstablishing,
    parentContainer: HTMLElement,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.UnattachedPageFloatLayoutContext,
  ): Task.Result<PageFloats.AttachedPageFloatLayoutContext> {
    // No `enabled` test here. A page master's condition was evaluated by
    // selectPageMaster. A page rule master can carry one through the `@page`
    // cascade, but EPUB Adaptive Layout §3.4.7 applies `-epubx-enabled` to
    // `@-epubx-page-master` and `@-epubx-partition` rules, not to `@page`, so
    // that declaration has no defined rendering and base's skip is not a
    // behavior to keep. The boxes below take geometry only.
    boxInstance.reset();
    const frame: Task.Frame<PageFloats.AttachedPageFloatLayoutContext> =
      Task.newFrame("layoutPageAreaEstablishingContainer");
    const opened = this.openPageBox(
      page,
      boxInstance,
      parentContainer,
      offsetX,
      offsetY,
      exclusions,
    );
    const establishingChild = boxInstance.pageAreaEstablishingChild;
    if (establishingChild === null) {
      const attached = pagePageFloatLayoutContext.withContainer(
        opened.container,
      );
      this.layoutPageBoxContent(
        page,
        boxInstance,
        opened,
        parentContainer,
        exclusions,
        attached,
      ).then(() => {
        if (
          attached.isInvalidated() ||
          !this.excludeOrRemovePageBox(
            boxInstance,
            opened,
            parentContainer,
            exclusions,
          )
        ) {
          frame.finish(attached);
          return;
        }
        this.layoutPageBoxChildren(
          page,
          boxInstance,
          opened,
          exclusions,
          attached,
        ).then(() => {
          frame.finish(attached);
        });
      });
      return frame.result();
    }
    this.layoutGeneratedContent(
      page,
      boxInstance,
      opened,
      parentContainer,
    ).then(() => {
      // No invalidation test: generated content cannot invalidate a context.
      // The result is unused. A box on the way down holds the establishing
      // child, and is never the empty box this removes.
      this.excludeOrRemovePageBox(
        boxInstance,
        opened,
        parentContainer,
        exclusions,
      );
      // base laid this child out first as well.
      this.layoutPageAreaEstablishingContainer(
        page,
        establishingChild,
        opened.boxContainer,
        opened.offsetX,
        opened.offsetY,
        exclusions,
        pagePageFloatLayoutContext,
      ).then((attached) => {
        if (attached.isInvalidated()) {
          // base broke out of the children loop here, before the margin boxes.
          frame.finish(attached);
          return;
        }
        this.layoutPageBoxChildren(
          page,
          boxInstance,
          opened,
          exclusions,
          attached,
          establishingChild,
        ).then(() => {
          frame.finish(attached);
        });
      });
    });
    return frame.result();
  }

  /**
   * @return holding true
   */
  layoutContainer(
    page: Vtree.Page,
    boxInstance: PageMaster.PageBoxInstance,
    parentContainer: HTMLElement,
    offsetX: number,
    offsetY: number,
    exclusions: GeometryUtil.Shape[],
    pagePageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext,
  ): Task.Result<boolean> {
    boxInstance.reset();
    const enabled = boxInstance.getProp(this, "enabled");
    if (enabled && enabled !== Css.ident._true) {
      return Task.newResult(true);
    }
    const frame: Task.Frame<boolean> = Task.newFrame("layoutContainer");
    const opened = this.openPageBox(
      page,
      boxInstance,
      parentContainer,
      offsetX,
      offsetY,
      exclusions,
    );
    this.layoutPageBoxContent(
      page,
      boxInstance,
      opened,
      parentContainer,
      exclusions,
      pagePageFloatLayoutContext,
    ).then(() => {
      if (pagePageFloatLayoutContext.isInvalidated()) {
        frame.finish(true);
        return;
      }
      if (
        !this.excludeOrRemovePageBox(
          boxInstance,
          opened,
          parentContainer,
          exclusions,
        )
      ) {
        frame.finish(true);
        return;
      }
      this.layoutPageBoxChildren(
        page,
        boxInstance,
        opened,
        exclusions,
        pagePageFloatLayoutContext,
      ).then(() => {
        frame.finish(true);
      });
    });
    return frame.result();
  }
  processLinger(): void {
    const pageNumber = this.currentLayoutPosition.page;
    for (const flowName in this.currentLayoutPosition.flowPositions) {
      const flowPosition = this.currentLayoutPosition.flowPositions[flowName];
      for (let i = flowPosition.positions.length - 1; i >= 0; i--) {
        const pos = flowPosition.positions[i];
        if (
          pos.flowChunk.startPage >= 0 &&
          pos.flowChunk.startPage + pos.flowChunk.linger - 1 <= pageNumber
        ) {
          flowPosition.positions.splice(i, 1);
        }
      }
    }
  }

  initLingering(): void {
    const pageNumber = this.currentLayoutPosition.page;
    for (const flowName in this.currentLayoutPosition.flowPositions) {
      const flowPosition = this.currentLayoutPosition.flowPositions[flowName];
      for (let i = flowPosition.positions.length - 1; i >= 0; i--) {
        const pos = flowPosition.positions[i];
        if (
          pos.flowChunk.startPage < 0 &&
          pos.flowChunk.startOffset < this.lookupOffset
        ) {
          pos.flowChunk.startPage = pageNumber;
        }
      }
    }
  }

  noMorePrimaryFlows(cp: Vtree.LayoutPosition): boolean {
    for (const flowName in this.primaryFlows) {
      const flowPosition = cp.flowPositions[flowName];
      if (flowPosition && flowPosition.positions.length > 0) {
        return false;
      }
    }
    return true;
  }

  private hasSameFlowPositions(
    first: Vtree.LayoutPosition | null,
    second: Vtree.LayoutPosition | null,
  ): boolean {
    if (first === second) {
      return true;
    }
    if (!first || !second) {
      return false;
    }
    const firstFlowNames = Object.keys(first.flowPositions);
    const secondFlowNames = Object.keys(second.flowPositions);
    if (firstFlowNames.length !== secondFlowNames.length) {
      return false;
    }
    for (const flowName of firstFlowNames) {
      if (
        !first.flowPositions[flowName].isSamePosition(
          second.flowPositions[flowName],
        )
      ) {
        return false;
      }
    }
    return true;
  }

  private checkRepeatedInvalidPageArea(cp: Vtree.LayoutPosition): void {
    const hasInvalidPageArea = this.invalidPageAreaOnCurrentPage;
    this.invalidPageAreaOnCurrentPage = false;

    if (!hasInvalidPageArea) {
      this.repeatedInvalidPageAreaLayoutPosition = null;
      return;
    }
    if (cp.isBlankPage || this.noMorePrimaryFlows(cp)) {
      return;
    }
    if (!this.hasSameFlowPositions(this.layoutPositionAtPageStart, cp)) {
      this.repeatedInvalidPageAreaLayoutPosition = null;
      return;
    }

    const repeatedStall =
      !!this.repeatedInvalidPageAreaLayoutPosition &&
      this.hasSameFlowPositions(
        this.repeatedInvalidPageAreaLayoutPosition,
        this.layoutPositionAtPageStart,
      );
    this.repeatedInvalidPageAreaLayoutPosition =
      this.layoutPositionAtPageStart.clone();

    if (repeatedStall) {
      throw new Error("Negative or zero page area size");
    }
  }

  layoutNextPage(
    page: Vtree.Page,
    cp?: Vtree.LayoutPosition | null,
  ): Task.Result<Vtree.LayoutPosition | null> {
    // TOC box is special page container, no pagination
    const isTocBox = page.container === page.bleedBox;

    this.pageBreaks = {};
    if (cp) {
      this.currentLayoutPosition = cp.clone();
      this.styler.replayFlowElementsFromOffset(cp.highestSeenOffset);
    } else {
      this.currentLayoutPosition = new Vtree.LayoutPosition();
      this.styler.replayFlowElementsFromOffset(-1);
    }
    if (this.lang) {
      page.bleedBox.setAttribute("lang", this.lang);
    }
    this.invalidPageAreaOnCurrentPage = false;
    cp = this.currentLayoutPosition;

    const startSide = cp.startSideOfFlow("body");
    cp.isBlankPage =
      Break.isSpreadBreakValue(startSide) && this.matchPageSide(startSide);
    page.isBlankPage = cp.isBlankPage;
    cp.page++;

    const hasOnlyDeferredPageFloats = this.hasOnlyDeferredPageFloats(cp);

    const pageStartPageType = hasOnlyDeferredPageFloats
      ? undefined
      : this.getPageStartPageTypeOverride(cp);
    if (pageStartPageType === "") {
      page.pageType = "";
    } else if (pageStartPageType) {
      page.pageType = pageStartPageType;
    }
    if (page.pageType == null) {
      const firstPageType = cp.page === 1 ? this.resolveFirstPageType() : null;
      const continuedPageType =
        this.styler.cascade.currentPageType ??
        this.styler.cascade.previousPageType;
      const fallbackPageType = page.isBlankPage
        ? this.styler.cascade.previousPageType
        : hasOnlyDeferredPageFloats
          ? continuedPageType
          : (firstPageType ?? this.styler.cascade.currentPageType);
      page.pageType = fallbackPageType;
      if (!page.pageType) {
        // Issue #1991: `currentPageType` can still be empty when a page starts
        // mid-paragraph after deferred footnote text. Use the direct page-start
        // resolver only as the last fallback so existing named-page/group flows
        // keep their normal continuation behavior.
        const directPageStartPageType = this.getPageStartPageType(cp);
        if (directPageStartPageType) {
          page.pageType = directPageStartPageType;
        }
      }
      page.pageType = page.pageType ?? "";
      // Fix for issue #1309
      this.styler.cascade.previousPageType =
        this.styler.cascade.currentPageType;
    }

    // Update page group page indices for :nth(An+B of <page-type>) selector
    this.updatePageGroupPageIndices(cp);

    this.clearScope(this.style.pageScope);
    this.layoutPositionAtPageStart = cp.clone();
    // Save formatting context states at the beginning of page layout for
    // restoration when page-level retry occurs (Issue #1663).
    // Formatting contexts (e.g., TableFormattingContext with cellBreakPositions)
    // are stored in NodePositionStep.formattingContext and shared by reference
    // across LayoutPosition.clone(). Modifications during layout persist unless
    // explicitly restored.
    const savedPageFCStates = collectFormattingContextStates(cp);

    // Resolve page size before page master selection.
    const cascadedPageStyle = isTocBox
      ? ({} as CssCascade.ElementStyle)
      : this.pageManager.getCascadedPageStyle(page.pageType);

    // Store cascadedPageStyle for use in ViewFactory
    this.currentCascadedPageStyle = cascadedPageStyle;

    // Substitute var()
    this.styler.cascade.applyVarFilter([cascadedPageStyle], null);
    if (CssCascade.resolveRollbackValues(cascadedPageStyle, true)) {
      this.styler.cascade.applyVarFilter([cascadedPageStyle], null);
    }

    // Calculate calc()
    this.styler.cascade.applyCalcFilter(cascadedPageStyle, this.styler.context);

    // Convert device-cmyk() to color(srgb ...)
    this.styler.cascade.applyCmykFilter(cascadedPageStyle);

    if (!isTocBox) {
      const isLeftPage = new Exprs.Named(this.style.pageScope, "left-page");
      page.side = isLeftPage.evaluate(this)
        ? Constants.PageSide.LEFT
        : Constants.PageSide.RIGHT;

      page.container.setAttribute(
        "data-vivliostyle-page-side",
        page.side as string,
      );
    }

    const pageMaster = this.selectPageMaster(cascadedPageStyle);
    if (!pageMaster) {
      // end of primary content
      return Task.newResult<Vtree.LayoutPosition | null>(null);
    }
    let bleedBoxPaddingEdge = 0;
    if (!isTocBox) {
      page.setAutoPageWidth(
        (pageMaster.pageBox.specified["width"] as CssCascade.CascadeValue)
          .value === Css.fullWidth,
      );
      page.setAutoPageHeight(
        (pageMaster.pageBox.specified["height"] as CssCascade.CascadeValue)
          .value === Css.fullHeight,
      );
      // Use counters recorded at the start layout position for this page.
      let { counterOffset: pageStartOffset, changeOffset: pageChangeOffset } =
        this.getPageStartCounterOffsets(this.layoutPositionAtPageStart);
      if (!isFinite(pageStartOffset)) {
        pageStartOffset = this.lookupOffset;
        pageChangeOffset = this.lookupOffset;
      }
      if (isFinite(pageStartOffset)) {
        this.styler.styleUntil(pageStartOffset, 0);
      }
      let pageStartSnapshot =
        this.styler.getCounterSnapshotAtOffset(pageStartOffset);
      let pageChangeSnapshot =
        pageChangeOffset === pageStartOffset
          ? pageStartSnapshot
          : this.styler.getCounterSnapshotAtOffset(pageChangeOffset);
      if (!pageStartSnapshot) {
        pageStartSnapshot = this.styler.getLastCounterSnapshot();
      }
      if (!pageChangeSnapshot) {
        pageChangeSnapshot = pageStartSnapshot;
      }
      const currentPageChangeSnapshot =
        pageChangeSnapshot && pageChangeSnapshot.offset === pageChangeOffset
          ? pageChangeSnapshot
          : null;
      this.counterStore.setCurrentPageDocCounters(
        pageStartSnapshot?.counters ?? null,
        currentPageChangeSnapshot?.changes ?? null,
        currentPageChangeSnapshot?.changeTypes,
      );
      this.counterStore.setCurrentPage(page);
      this.counterStore.updatePageCounters(cascadedPageStyle, this);

      // setup bleed area and crop marks
      const evaluatedPageSizeAndBleed = CssPage.evaluatePageSizeAndBleed(
        CssPage.resolvePageSizeAndBleed(cascadedPageStyle as any),
        this,
      );
      this.setPageSizeAndBleed(evaluatedPageSizeAndBleed, page);

      CssPage.addPrinterMarks(
        cascadedPageStyle,
        evaluatedPageSizeAndBleed,
        page,
        this,
      );
      bleedBoxPaddingEdge =
        evaluatedPageSizeAndBleed.bleedOffset + evaluatedPageSizeAndBleed.bleed;
    }

    const writingMode =
      (!isTocBox && pageMaster.getProp(this, "writing-mode")) ||
      Css.ident.horizontal_tb;

    this.pageVertical = writingMode != Css.ident.horizontal_tb;

    const direction = pageMaster.getProp(this, "direction") || Css.ident.ltr;
    const pageFloatLayoutContext = PageFloats.PageFloatLayoutContext.create(
      this.rootPageFloatLayoutContext,
      PageFloats.FloatReference.PAGE,
      null,
      null,
      writingMode,
      direction,
      null,
      page.side,
    );
    const frame: Task.Frame<Vtree.LayoutPosition | null> =
      Task.newFrame("layoutNextPage");
    let attachedPageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext | null =
      null;
    frame
      .loopWithFrame((loopFrame) => {
        // this.layoutPageAreaEstablishingContainer(page, pageMaster, page.bleedBox, bleedBoxPaddingEdge, bleedBoxPaddingEdge+1, // Compensate 'top: -1px' on page master
        this.layoutPageAreaEstablishingContainer(
          page,
          pageMaster,
          page.bleedBox,
          bleedBoxPaddingEdge,
          bleedBoxPaddingEdge,
          [],
          pageFloatLayoutContext,
        ).then((attached) => {
          attachedPageFloatLayoutContext = attached;
          if (!pageFloatLayoutContext.isInvalidated()) {
            attached.finish();
          }
          if (pageFloatLayoutContext.isInvalidated()) {
            this.currentLayoutPosition = this.layoutPositionAtPageStart.clone();
            // Restore formatting context states on page-level retry
            // (Issue #1663)
            restoreFormattingContextStates(savedPageFCStates);
            pageFloatLayoutContext.validate();
            // Clear bleedBox children before retry to avoid duplicate page-box elements
            while (page.bleedBox.lastChild) {
              page.bleedBox.removeChild(page.bleedBox.lastChild);
            }
            loopFrame.continueLoop();
          } else {
            loopFrame.breakLoop();
          }
        });
      })
      .then(() => {
        page.pageFloatLayoutContext = attachedPageFloatLayoutContext;
        pageMaster.adjustPageLayout(this, page, this.clientLayout);
        if (!isTocBox) {
          this.processLinger();
          cp = this.currentLayoutPosition;
          this.checkRepeatedInvalidPageArea(cp);
          Object.keys(cp.flowPositions).forEach((flowName) => {
            const flowPosition = cp.flowPositions[flowName];
            const breakAfter = flowPosition.breakAfter;
            if (
              breakAfter &&
              (breakAfter === "page" || !this.matchPageSide(breakAfter))
            ) {
              flowPosition.breakAfter = null;
            }
          });
        }
        this.currentLayoutPosition = this.layoutPositionAtPageStart = null;
        cp.highestSeenOffset = this.styler.getReachedOffset();
        const triggers = this.style.store.getTriggersForDoc(this.xmldoc);
        page.finish(triggers, this.clientLayout);
        if (attachedPageFloatLayoutContext) {
          releaseBreakPositions(attachedPageFloatLayoutContext);
        }
        if (
          this.noMorePrimaryFlows(cp) &&
          !this.hasActiveRootPageFloatLayoutContext()
        ) {
          cp = null;
        }
        frame.finish(cp);
      });
    return frame.result();
  }

  /**
   * Set actual page width, height and bleed from style specified in page
   * context.
   */
  private setPageSizeAndBleed(
    evaluatedPageSizeAndBleed: CssPage.EvaluatedPageSizeAndBleed,
    page: Vtree.Page,
  ) {
    this.actualPageWidth = evaluatedPageSizeAndBleed.pageWidth;
    this.actualPageHeight = evaluatedPageSizeAndBleed.pageHeight;
    this.pageSheetWidth =
      evaluatedPageSizeAndBleed.pageWidth +
      evaluatedPageSizeAndBleed.cropOffset * 2;
    this.pageSheetHeight =
      evaluatedPageSizeAndBleed.pageHeight +
      evaluatedPageSizeAndBleed.cropOffset * 2;
    page.container.style.width = `${this.pageSheetWidth}px`;
    page.container.style.height = `${this.pageSheetHeight}px`;
    page.bleedBox.style.left = `${evaluatedPageSizeAndBleed.bleedOffset}px`;
    page.bleedBox.style.right = `${evaluatedPageSizeAndBleed.bleedOffset}px`;
    page.bleedBox.style.top = `${evaluatedPageSizeAndBleed.bleedOffset}px`;
    page.bleedBox.style.bottom = `${evaluatedPageSizeAndBleed.bleedOffset}px`;
    page.bleedBox.style.padding = `${evaluatedPageSizeAndBleed.bleed}px`;
  }
}

export class BaseParserHandler extends CssCascade.CascadeParserHandler {
  insideRegion: boolean = false;

  constructor(
    public masterHandler: StyleParserHandler,
    owner: CssParser.DispatchParserHandler,
    scope: Exprs.LexicalScope,
    validatorSet: CssValidator.ValidatorSet,
    condition: Exprs.Val | null,
    parent: BaseParserHandler | null,
    regionId: string | null,
    delegation: CssParser.Delegation | null,
  ) {
    super(scope, owner, condition, parent, regionId, validatorSet, delegation);
  }

  override startPageTemplateRule(): void {}

  override startPageMasterRule(
    name: string | null,
    pseudoName: string | null,
    classes: string[],
  ): void {
    const pageMaster = new PageMaster.PageMaster(
      this.masterHandler.pageScope,
      name,
      pseudoName,
      classes,
      this.masterHandler.rootBox,
      this.condition,
      this.owner.getBaseSpecificity(),
      this.layer,
    );
    this.owner.delegateTo(
      (delegation) =>
        new PageMaster.PageMasterParserHandler(
          pageMaster.scope,
          this.owner,
          pageMaster,
          this.validatorSet,
          delegation,
        ),
    );
  }

  override startWhenRule(expr: Css.Expr): void {
    let condition = expr.expr;
    if (this.condition != null) {
      condition = Exprs.and(this.scope, this.condition, condition);
    }
    this.owner.delegateTo(
      (delegation) =>
        new BaseParserHandler(
          this.masterHandler,
          this.owner,
          this.scope,
          this.validatorSet,
          condition,
          this,
          this.regionId,
          delegation,
        ),
    );
  }

  override startLayerRule(nameList: string[] | null): void {
    const layer = this.cascade.registerLayer(this.flavor, this.layer, nameList);
    this.owner.delegateTo((delegation) => {
      const handler = new BaseParserHandler(
        this.masterHandler,
        this.owner,
        this.scope,
        this.validatorSet,
        this.condition,
        this,
        this.regionId,
        delegation,
      );
      handler.layer = layer;
      return handler;
    });
  }

  override startDefineRule(): void {
    this.owner.delegateTo(
      (delegation) =>
        new CssCascade.DefineParserHandler(this.scope, this.owner, delegation),
    );
  }

  override startFontFaceRule(): void {
    const properties = {} as CssCascade.ElementStyle;
    this.masterHandler.fontFaces.push({
      properties,
      condition: this.condition,
      priority: this.getBaseSpecificity(),
      layer: this.layer,
    });
    this.owner.delegateTo(
      (delegation) =>
        new CssCascade.PropSetParserHandler(
          this.scope,
          this.owner,
          null,
          properties,
          this.masterHandler.validatorSet,
          delegation,
          "font-face",
          this.layer,
        ),
    );
  }

  override startCounterStyleRule(name: string): void {
    this.owner.delegateTo(
      (delegation) =>
        new CounterStyleParserHandler(
          this.scope,
          this.owner,
          {} as CssCascade.ElementStyle,
          this.masterHandler.validatorSet,
          name,
          this.masterHandler.counterStyles,
          delegation,
          this.layer,
        ),
    );
  }

  override startFlowRule(flowName: string): void {
    let style = this.masterHandler.flowProps[flowName];
    if (!style) {
      style = {} as CssCascade.ElementStyle;
      this.masterHandler.flowProps[flowName] = style;
    }
    this.owner.delegateTo(
      (delegation) =>
        new CssCascade.PropSetParserHandler(
          this.scope,
          this.owner,
          null,
          style,
          this.masterHandler.validatorSet,
          delegation,
          undefined,
          this.layer,
        ),
    );
  }

  override startViewportRule(): void {
    const viewportProps = {} as CssCascade.ElementStyle;
    this.masterHandler.viewportProps.push(viewportProps);
    this.owner.delegateTo(
      (delegation) =>
        new CssCascade.PropSetParserHandler(
          this.scope,
          this.owner,
          this.condition,
          viewportProps,
          this.masterHandler.validatorSet,
          delegation,
          undefined,
          this.layer,
        ),
    );
  }

  override startFootnoteRule(pseudoelem: string | null): void {
    let style = this.masterHandler.footnoteProps;
    if (pseudoelem) {
      const pseudos = CssCascade.getMutableStyleMap(style, "_pseudos");
      style = pseudos[pseudoelem];
      if (!style) {
        style = {} as CssCascade.ElementStyle;
        pseudos[pseudoelem] = style;
      }
    }
    this.owner.delegateTo(
      (delegation) =>
        new CssPage.PageFootnoteAreaParserHandler(
          this.scope,
          this.owner,
          this.masterHandler.validatorSet,
          style,
          delegation,
          this.layer,
        ),
    );
  }

  override startRegionRule(): void {
    this.insideRegion = true;
    this.startSelectorRule();
  }

  override startPageRule(): void {
    const pageHandler = this.owner.delegateTo(
      (delegation) =>
        new CssPage.PageParserHandler(
          this.masterHandler.pageScope,
          this.owner,
          this,
          this.validatorSet,
          this.masterHandler.pageProps,
          delegation,
        ),
    );
    pageHandler.startPageRule();
  }

  override startRuleBody(): void {
    CssCascade.CascadeParserHandler.prototype.startRuleBody.call(this);
    if (this.insideRegion) {
      this.insideRegion = false;
      const regionId = `R${this.masterHandler.regionCount++}`;
      this.special("region-id", Css.getName(regionId));
      this.endRule();
      const regionHandler = this.owner.delegateTo(
        (delegation) =>
          new BaseParserHandler(
            this.masterHandler,
            this.owner,
            this.scope,
            this.validatorSet,
            this.condition,
            this,
            regionId,
            delegation,
          ),
      );
      regionHandler.startRuleBody();
    }
  }
}

export class StyleParserHandler extends CssParser.DispatchParserHandler<BaseParserHandler> {
  readonly rootScope: Exprs.LexicalScope;
  readonly pageScope: Exprs.LexicalScope;
  readonly rootBox: PageMaster.RootPageBox;
  readonly cascadeParserHandler: BaseParserHandler;
  regionCount: number = 0;
  fontFaces = [] as FontFace[];
  counterStyles = new CounterStyle.CounterStyleStore();
  footnoteProps = {} as CssCascade.ElementStyle;
  flowProps = {} as { [key: string]: CssCascade.ElementStyle };
  viewportProps = [] as CssCascade.ElementStyle[];
  pageProps = {} as { [key: string]: CssCascade.ElementStyle };

  constructor(public readonly validatorSet: CssValidator.ValidatorSet) {
    const rootScope = new Exprs.LexicalScope(null);
    super(
      rootScope,
      // The owner is this handler itself, still inside its own super() call,
      // so the cascade handler takes its scope and validator set directly.
      (owner) =>
        new BaseParserHandler(
          owner as StyleParserHandler,
          owner,
          rootScope,
          validatorSet,
          null,
          null,
          null,
          null,
        ),
    );
    this.rootScope = rootScope;
    this.pageScope = new Exprs.LexicalScope(this.rootScope);
    this.rootBox = new PageMaster.RootPageBox(this.rootScope);
    this.cascadeParserHandler = this.initialSlave;
  }
}

export type StyleSheetParam =
  | { url: string; text?: null }
  // url, if present, is the base for resolving relative URLs in the text
  | { url: string | null; text: string };

export type StyleSource = StyleSheetParam & {
  flavor: CssParser.StylesheetFlavor;
  classes: string | null;
  media: string | null;
};

function toStyleSource(
  stylesheet: StyleSheetParam,
  flavor: CssParser.StylesheetFlavor,
): StyleSource {
  if (stylesheet.text != null) {
    const url = stylesheet.url
      ? Base.resolveURL(Base.convertSpecialURL(stylesheet.url), Base.baseURL)
      : stylesheet.url;
    return { url, text: stylesheet.text, flavor, classes: null, media: null };
  }
  const url = stylesheet.url
    ? Base.resolveURL(Base.convertSpecialURL(stylesheet.url), Base.baseURL)
    : stylesheet.url;
  return { url, flavor, classes: null, media: null };
}

export function parseOPSResource(
  response: Net.FetchResponse,
  store: XmlDoc.XMLDocStore,
): Task.Result<XmlDoc.XMLDocHolder | null> {
  return (store as OPSDocStore).parseOPSResource(response);
}

export class OPSDocStore extends Net.ResourceStore<XmlDoc.XMLDocHolder> {
  styleByKey: { [key: string]: Style } = {};
  styleFetcherByKey: { [key: string]: TaskUtil.Fetcher<Style> } = {};
  styleByDocURL: { [key: string]: Style } = {};
  triggersByDocURL: { [key: string]: Vtree.Trigger[] } = {};
  validatorSet: CssValidator.ValidatorSet = CssValidator.baseValidatorSet();
  private styleSheets: StyleSource[] = [];
  protected triggerSingleDocumentPreprocessing: boolean = false;

  protected constructor(
    public fontDeobfuscator:
      ((p1: string) => ((p1: Blob) => Task.Result<Blob>) | null) | null,
    authorStyleSheets: StyleSheetParam[] | null = null,
    userStyleSheets: StyleSheetParam[] | null = null,
  ) {
    super(parseOPSResource, Net.FetchResponseType.DOCUMENT);
    this.setStyleSheets(authorStyleSheets, userStyleSheets);
  }

  getStyleForDoc(xmldoc: XmlDoc.XMLDocHolder): Style {
    return this.styleByDocURL[xmldoc.url];
  }

  getTriggersForDoc(xmldoc: XmlDoc.XMLDocHolder): Vtree.Trigger[] {
    return this.triggersByDocURL[xmldoc.url];
  }

  /**
   * Set author stylesheets and user stylesheets. Existing style sheets are
   * removed.
   */
  private setStyleSheets(
    authorStyleSheets: StyleSheetParam[] | null,
    userStyleSheets: StyleSheetParam[] | null,
  ) {
    this.clearStyleSheets();
    if (authorStyleSheets) {
      authorStyleSheets.forEach(this.addAuthorStyleSheet, this);
    }
    if (userStyleSheets) {
      userStyleSheets.forEach(this.addUserStyleSheet, this);
    }
  }

  private clearStyleSheets() {
    this.styleSheets.splice(0);
  }

  private addAuthorStyleSheet(stylesheet: StyleSheetParam) {
    this.styleSheets.push(
      toStyleSource(stylesheet, CssParser.StylesheetFlavor.AUTHOR),
    );
  }

  private addUserStyleSheet(stylesheet: StyleSheetParam) {
    this.styleSheets.push(
      toStyleSource(stylesheet, CssParser.StylesheetFlavor.USER),
    );
  }

  parseOPSResource(
    response: Net.FetchResponse,
  ): Task.Result<XmlDoc.XMLDocHolder | null> {
    const frame: Task.Frame<XmlDoc.XMLDocHolder | null> =
      Task.newFrame("OPSDocStore.load");
    const url = response.url;

    // Hack for TOCView.showTOC()
    const isTocBox = Base.isTocBoxURL(url);

    XmlDoc.parseXMLResource(response, this).then(
      (xmldoc: XmlDoc.XMLDocHolder | null) => {
        if (!xmldoc) {
          frame.finish(null);
          return;
        }
        if (this.triggerSingleDocumentPreprocessing) {
          const hooks: Plugin.PreProcessSingleDocumentHook[] =
            Plugin.getHooksForName(Plugin.HOOKS.PREPROCESS_SINGLE_DOCUMENT);
          for (let i = 0; i < hooks.length; i++) {
            try {
              hooks[i](xmldoc.document);
            } catch (e) {
              Logging.logger.warn(
                "Error during single document preprocessing:",
                e,
              );
            }
          }
        }
        const triggers: Vtree.Trigger[] = [];
        const triggerList = xmldoc.document.getElementsByTagNameNS(
          Base.NS.epub,
          "trigger",
        );
        for (let i = 0; i < triggerList.length; i++) {
          const triggerElem = triggerList[i];
          const observer = triggerElem.getAttributeNS(Base.NS.EV, "observer");
          const event = triggerElem.getAttributeNS(Base.NS.EV, "event");
          const action = triggerElem.getAttribute("action");
          const ref = triggerElem.getAttribute("ref");
          if (observer && event && action && ref) {
            triggers.push({ observer, event, action, ref });
          }
        }
        this.triggersByDocURL[url] = triggers;
        const sources = [] as StyleSource[];
        sources.push({
          url: Base.resolveURL("user-agent-base.css", Base.resourceBaseURL),
          text: UserAgentBaseCss,
          flavor: CssParser.StylesheetFlavor.USER_AGENT,
          classes: null,
          media: null,
        });
        sources.push({
          url: Base.resolveURL("user-agent-page.css", Base.resourceBaseURL),
          text: UserAgentPageCss,
          flavor: CssParser.StylesheetFlavor.USER_AGENT,
          classes: null,
          media: null,
        });
        sources.push({
          url: Base.resolveURL(
            "user-agent-counter-styles.css",
            Base.resourceBaseURL,
          ),
          text: UserAgentCounterStylesCss,
          flavor: CssParser.StylesheetFlavor.USER_AGENT,
          classes: null,
          media: null,
        });
        if (isTocBox) {
          sources.push({
            url: Base.resolveURL("user-agent-toc.css", Base.resourceBaseURL),
            text: UserAgentTocCss,
            flavor: CssParser.StylesheetFlavor.USER_AGENT,
            classes: null,
            media: null,
          });
        } else {
          const elemList =
            xmldoc.document.querySelectorAll("style, link, meta");
          for (const elem of elemList) {
            const ns = elem.namespaceURI;
            const localName = elem.localName;
            if (ns == Base.NS.XHTML) {
              if (localName == "style") {
                const classes = elem.getAttribute("class");
                const media = elem.getAttribute("media");
                const title = elem.getAttribute("title");
                sources.push({
                  url,
                  text: elem.textContent,
                  flavor: CssParser.StylesheetFlavor.AUTHOR,
                  classes: title ? classes : null,
                  media,
                });
              } else if (localName == "link") {
                const href = elem.getAttribute("href");
                const rel = elem.getAttribute("rel")?.split(/\s+/);
                const classes = elem.getAttribute("class");
                const media = elem.getAttribute("media");
                if (
                  href &&
                  rel?.includes("stylesheet") &&
                  (!rel.includes("alternate") || classes)
                ) {
                  const src = Base.resolveURL(href, url);
                  const title = elem.getAttribute("title");
                  sources.push({
                    url: src,
                    text: null,
                    classes: title ? classes : null,
                    media,
                    flavor: CssParser.StylesheetFlavor.AUTHOR,
                  });
                }
              } else if (
                localName == "meta" &&
                elem.getAttribute("name") == "viewport"
              ) {
                sources.push({
                  url,
                  text: this.processViewportMeta(elem),
                  flavor: CssParser.StylesheetFlavor.AUTHOR,
                  classes: null,
                  media: null,
                });
              }
            }
          }
          for (let i = 0; i < this.styleSheets.length; i++) {
            sources.push(this.styleSheets[i]);
          }
        }
        let key = "";
        for (let i = 0; i < sources.length; i++) {
          key += sources[i].url;
          key += "^";
          if (sources[i].text) {
            key += sources[i].text;
          }
          key += "^";
        }
        let style = this.styleByKey[key];
        if (style) {
          this.styleByDocURL[url] = style;
          frame.finish(xmldoc);
          return;
        }
        let fetcher = this.styleFetcherByKey[key];
        if (!fetcher) {
          fetcher = new TaskUtil.Fetcher(() => {
            const innerFrame: Task.Frame<Style> =
              Task.newFrame("fetchStylesheet");
            let index = 0;
            const sph = new StyleParserHandler(this.validatorSet);
            innerFrame
              .loop(() => {
                if (index < sources.length) {
                  const source = sources[index++];
                  sph.startStylesheet(source.flavor);
                  if (source.text != null) {
                    return CssParser.parseStylesheetFromText(
                      source.text,
                      sph,
                      source.url,
                      source.classes,
                      source.media,
                    ).thenReturn(true);
                  } else {
                    return CssParser.parseStylesheetFromURL(
                      source.url,
                      sph,
                      source.classes,
                      source.media,
                    );
                  }
                }
                return Task.newResult(false);
              })
              .then(() => {
                const cascade = sph.cascadeParserHandler.finish();
                style = new Style(
                  this,
                  sph.rootScope,
                  sph.pageScope,
                  cascade,
                  sph.rootBox,
                  sortFontFaces(sph.fontFaces),
                  sph.footnoteProps,
                  sph.flowProps,
                  sph.viewportProps,
                  sph.pageProps,
                  sph.counterStyles,
                );
                this.styleByKey[key] = style;
                delete this.styleFetcherByKey[key];
                innerFrame.finish(style);
              });
            return innerFrame.result();
          }, `FetchStylesheet ${url}`);
          this.styleFetcherByKey[key] = fetcher;
          fetcher.start();
        }
        fetcher.get().then((style) => {
          this.styleByDocURL[url] = style;
          frame.finish(xmldoc);
        });
      },
    );
    return frame.result();
  }

  processViewportMeta(meta: Element): string {
    return "";
  }
}
