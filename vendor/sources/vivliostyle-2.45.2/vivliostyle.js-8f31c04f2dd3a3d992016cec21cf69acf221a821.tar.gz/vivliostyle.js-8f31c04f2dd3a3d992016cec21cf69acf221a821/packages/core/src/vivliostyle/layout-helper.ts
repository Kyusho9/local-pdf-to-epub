/**
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview LayoutHelper - Helper functions of Layout.
 */
import * as Base from "./base";
import * as Display from "./display";
import * as RangeClientRects from "./range-client-rects";
import * as VtreeImpl from "./vtree";
import { Layout, Vtree } from "./types";

/**
 * A large gap value used to separate columns when using the browser's
 * multi-column feature for page/column breaking.
 * This value should be significantly larger than any objects in the layout
 * to prevent overlapping content between columns, but not too large to cause
 * problems with browser rendering limits.
 */
const BIG_GAP = 100000;

/**
 * Enable page/column breaking using the browser's multi-column feature.
 * This function sets CSS properties on the column element to create a
 * single-column (column-count: 1) that splits into multiple columns
 * when content overflows the column's size. The large column gap
 * (column-gap) ensures that the browser creates new columns
 * apart from the original column position, and it helps determine
 * page/column breaking positions in our layout processing.
 */
export function setBrowserColumnBreaking(column: Vtree.Container): void {
  const style = column.element.style;
  style.columnGap = `${BIG_GAP - (column.vertical ? column.height : column.width)}px`;
  style.columnFill = "auto";
  style.columnCount = "1";
  // Workaround for Safari/WebKit(< 26.2) bug (column-count: 1 should create a multi-column container)
  // https://bugs.webkit.org/show_bug.cgi?id=299836
  style.columnWidth = "0";
}

/**
 * Disable the browser's multi-column feature for page/column breaking.
 * This function resets the CSS properties set by `setBrowserColumnBreaking`.
 */
export function unsetBrowserColumnBreaking(
  columnOrElement: Vtree.Container | HTMLElement,
): void {
  const columnElement =
    "element" in columnOrElement ? columnOrElement.element : columnOrElement;
  const style = columnElement.style;
  style.columnWidth = "";
  style.columnCount = "";
  style.columnGap = "";
  style.columnFill = "";
}

/**
 * Check if the browser's multi-column feature is being used for page/column breaking.
 */
export function isUsingBrowserColumnBreaking(column: Vtree.Container): boolean {
  return column.element.style.columnCount === "1";
}

/**
 * Mark the column as a root column for Vivliostyle layout processing.
 */
export function setAsRootColumn(column: Vtree.Container): void {
  column.element.setAttribute("data-vivliostyle-column", "true");
}

/**
 * Check if the client rectangle of an element or range is located
 * in a column beyond the current one due to the browser's column breaking.
 *
 * @param rect - The client rectangle to check.
 * @param vertical - Whether the layout is vertical.
 * @return the number of columns the end edge of the rectangle is after the current column.
 */
export function checkIfBeyondColumnBreaks(
  rect: Vtree.ClientRect,
  vertical: boolean,
): number {
  const distance = vertical
    ? rect.bottom
    : Math.max(Math.abs(rect.left), Math.abs(rect.right));
  return Math.round(distance / BIG_GAP);
}

/**
 * Adjust the client rectangle of an element or range to account for
 * the browser's column breaking.
 * This function modifies the rectangle's coordinates to ensure that
 * if the rectangle is located in a column beyond the current one,
 * its position in the block-progression direction is moved accordingly
 * so that overflow checks can be performed based solely on the
 * block-progression position.
 *
 * @param rect - The client rectangle to check.
 * @param vertical - Whether the layout is vertical.
 * @return the number of columns the start edge of the rectangle is after the current column.
 */
export function adjustRectForColumnBreaking(
  rect: Vtree.ClientRect,
  vertical: boolean,
): number {
  const columnOverEnd = checkIfBeyondColumnBreaks(rect, vertical);
  if (columnOverEnd === 0) {
    return 0;
  }
  const distanceStart = vertical
    ? rect.top
    : Math.min(Math.abs(rect.left), Math.abs(rect.right));
  const columnOverStart = Math.round(distanceStart / BIG_GAP);
  const shiftStart = columnOverStart * BIG_GAP;
  let shiftEnd = columnOverEnd * BIG_GAP;
  if (vertical) {
    // vertical writing mode, columns are top to bottom
    rect.top -= shiftStart;
    rect.bottom -= shiftEnd;
    if (rect.bottom < rect.top) {
      rect.bottom += BIG_GAP;
    }
    rect.right -= shiftStart;
    rect.left -= shiftEnd;
  } else if (rect.left < -BIG_GAP / 2) {
    // columns are right to left
    rect.right += shiftStart;
    rect.left += shiftEnd;
    if (rect.left > rect.right) {
      rect.left -= BIG_GAP;
    }
    rect.top += shiftStart;
    rect.bottom += shiftEnd;
  } else {
    // columns are left to right
    rect.left -= shiftStart;
    rect.right -= shiftEnd;
    if (rect.right < rect.left) {
      rect.right += BIG_GAP;
    }
    rect.top += shiftStart;
    rect.bottom += shiftEnd;
  }
  rect.width = rect.right - rect.left;
  rect.height = rect.bottom - rect.top;

  return columnOverStart;
}

/**
 * Adjust multiple client rectangles for column breaking.
 */
export function adjustRectsForColumnBreaking(
  rects: Vtree.ClientRect[],
  vertical: boolean,
): void {
  for (let i = 0; i < rects.length; i++) {
    adjustRectForColumnBreaking(rects[i], vertical);
  }
}

/**
 * Get the client rectangle of an element, adjusted for column breaking.
 */
export function getElementClientRectAdjusted(
  clientLayout: Vtree.ClientLayout,
  element: Element,
  vertical: boolean,
): Vtree.ClientRect {
  const rect = clientLayout.getElementClientRect(element);
  const columnOver = adjustRectForColumnBreaking(rect, vertical);

  if (columnOver > 0) {
    let style = clientLayout.getElementComputedStyle(element);
    if (
      style.display.startsWith("table") &&
      !findAncestorNonRootMultiColumn(element)
    ) {
      // For now, browser's column breaking for tables does not work well,
      // so we disable it and use our own fragmentation logic for tables
      // unless the table is inside a non-root multi-column element, which
      // requires the browser's column breaking.
      //
      // Firefox bug: Tables do not break (fragment) in CSS Multi-column Layout
      //   https://bugzilla.mozilla.org/show_bug.cgi?id=888257
      //
      // Chromium also has a bug on table fragmentation:
      //   https://issues.chromium.org/issues/458852795

      const columnElem = element.closest(
        "[data-vivliostyle-column]",
      ) as HTMLElement;
      if (columnElem) {
        unsetBrowserColumnBreaking(columnElem);

        const rect2 = clientLayout.getElementClientRect(element);
        return rect2;
      }
    }
  }
  return rect;
}

/**
 * Clear forced column breaks between two nodes.
 * This is used to prevent unnecessary blank pages.
 */
export function clearForcedColumnBreaks(prevNode: Node, currNode: Node): void {
  if (prevNode.nodeType === 1) {
    const elem = prevNode as HTMLElement;
    if (elem.style?.breakAfter === "column") {
      elem.style.breakAfter = "";
    }
  }
  if (currNode.nodeType === 1) {
    const elem = currNode as HTMLElement;
    if (elem.style?.breakBefore === "column") {
      elem.style.breakBefore = "";
    }
  }
}

/**
 * Check if an element has non-root multi-column styles (column-count or
 * column-width) set on its inline style.
 *
 * NOTE: Do not use `instanceof HTMLElement` for the check because it does
 * not work when the node is inside an iframe. (Issue #1000)
 */
export function hasNonRootMultiColumnStyle(element: Element): boolean {
  const style = (element as HTMLElement).style;
  if (!style) return false;
  return (
    !isNaN(parseFloat(style.columnCount)) ||
    !isNaN(parseFloat(style.columnWidth))
  );
}

/**
 * Check if the given element or any of its descendants establishes a
 * non-root multi-column layout (via inline style).
 */
export function containsNonRootMultiColumn(element: Element): boolean {
  if (
    !element.hasAttribute("data-vivliostyle-column") &&
    hasNonRootMultiColumnStyle(element)
  ) {
    return true;
  }
  for (const descendant of element.querySelectorAll("*")) {
    if (
      !descendant.hasAttribute("data-vivliostyle-column") &&
      hasNonRootMultiColumnStyle(descendant)
    ) {
      return true;
    }
  }
  return false;
}

/**
 * Find the nearest ancestor element that establishes a multi-column
 * layout but is not the root column element.
 */
export function findAncestorNonRootMultiColumn(node: Node): Element | null {
  for (
    let elem = node.nodeType === 1 ? (node as Element) : node.parentElement;
    elem;
    elem = elem.parentElement
  ) {
    const style = (elem as HTMLElement).style;
    if (!style) {
      break;
    }
    if (elem.hasAttribute("data-vivliostyle-column")) {
      // This is the root column element.
      break;
    }
    if (hasNonRootMultiColumnStyle(elem as HTMLElement)) {
      return elem;
    }
    if (style.position === "absolute") {
      break;
    }
  }
  return null;
}

/**
 * Fix overflow caused by forced column breaks in non-root multi-column elements.
 */
export function fixOverflowAtForcedColumnBreak(node: Node): void {
  if (node.nodeType !== 1) {
    return;
  }
  const element = node as HTMLElement;
  const elementStyle = element.style;
  const breakBeforeColumn = elementStyle?.breakBefore === "column";
  const prevElem = element.previousElementSibling as HTMLElement;
  const breakAfterColumn = prevElem && prevElem.style?.breakAfter === "column";
  if (!breakBeforeColumn && !breakAfterColumn) {
    return;
  }
  const nonRootMultiColumn = findAncestorNonRootMultiColumn(element);
  if (!nonRootMultiColumn) {
    return;
  }
  const multiColumnStyle =
    nonRootMultiColumn.ownerDocument.defaultView.getComputedStyle(
      nonRootMultiColumn,
    );
  const { writingMode, direction, columnGap, fontSize } = multiColumnStyle;
  const vertical =
    writingMode === "vertical-rl" || writingMode === "vertical-lr";
  const isRtl = direction === "rtl";
  const halfGap = (parseFloat(columnGap) || parseFloat(fontSize) || 16) / 2;

  // Check if the element is overflowing the multi-column box
  const multiColumnRect = nonRootMultiColumn.getBoundingClientRect();
  const elementRect = element.getBoundingClientRect();
  const columnOverflow = vertical
    ? elementRect.top > multiColumnRect.bottom + halfGap
    : isRtl
      ? elementRect.right < multiColumnRect.left - halfGap
      : elementRect.left > multiColumnRect.right + halfGap;
  if (columnOverflow) {
    // Fix overflow by removing the forced breaks and adding a large margin.
    // This large margin will cause a page break in our layout processing.
    if (breakBeforeColumn) {
      elementStyle.breakBefore = "";
    }
    if (breakAfterColumn && prevElem) {
      prevElem.style.breakAfter = "";
    }
    elementStyle.marginBlockStart = `${BIG_GAP}px`;
  }
}

/**
 * Check if the root column's content overflows.
 *
 * Note: This check is based on the root column's trailing content
 * (lastElementChild), not only on a specific target element.
 */
export function checkRootColumnOverflow(column: Layout.Column): number {
  const element = column.element.lastElementChild;
  const rect = element && column.clientLayout.getElementClientRect(element);
  if (!rect) {
    return 0;
  }
  const columnOver = checkIfBeyondColumnBreaks(rect, column.vertical);
  return columnOver;
}

/**
 * Fix multi-column box with `column-fill: auto` that was changed to `column-fill: balance`
 * for layout processing, by restoring `column-fill: auto` and setting block-size to prevent overflow.
 */
export function fixAutoFillMultiColumnBox(
  element: HTMLElement,
  column: Layout.Column,
): void {
  if (element.getAttribute("data-viv-saved-column-fill") !== "auto") {
    return;
  }
  if (checkRootColumnOverflow(column)) {
    // Do not restore `column-fill: auto` if root-column overflow already exists
    // even with `column-fill: balance`.
    return;
  }
  const computedStyle = column.clientLayout.getElementComputedStyle(element);
  const blockSize1 = parseFloat(computedStyle.blockSize);

  // Restore `column-fill: auto` and check if it overflows.
  // If it overflows, find a non-overflow block-size by binary search.
  element.style.columnFill = "auto";
  const blockSize2 = parseFloat(computedStyle.blockSize);
  if (
    blockSize2 <= 0 ||
    (element.parentElement &&
      findAncestorNonRootMultiColumn(element.parentElement))
  ) {
    // When the multicol has no in-flow content or is nested inside another
    // multicol container, skip setting an explicit block-size. Setting one
    // overrides the browser's natural height and prevents proper sizing in
    // the parent multicol's fragmentation context. (Issue #1916)
    element.removeAttribute("data-viv-saved-column-fill");
    return;
  }
  let blockSize = NaN;
  element.style.blockSize = `${blockSize2}px`;
  if (!checkRootColumnOverflow(column)) {
    blockSize = parseFloat(computedStyle.blockSize);
    if (blockSize < blockSize2) {
      // `computedStyle.blockSize` may return a smaller value than the set `blockSize2` due to rounding,
      // which can cause unexpected column breaking in the multi-column box. So we need to adjust it.
      // (Issue #1773)
      const layoutUnitAdj = 1 / column.clientLayout.layoutUnitPerPixel;
      blockSize = blockSize2 + layoutUnitAdj;
      element.style.blockSize = `${blockSize}px`;
    }
  } else {
    element.style.blockSize = `${blockSize1}px`;
    if (!checkRootColumnOverflow(column)) {
      // `blockSize1` is non-overflow and `blockSize2` is overflow.
      // Search the largest non-overflow value in [blockSize1, blockSize2].
      const delta = 1 / (column.clientLayout.pixelRatio || 1);
      let ok = blockSize1;
      let ng = blockSize2;
      while (ng - ok > delta) {
        const mid = (ok + ng) / 2;
        element.style.blockSize = `${mid}px`;
        if (checkRootColumnOverflow(column)) {
          ng = mid;
        } else {
          ok = mid;
        }
      }
      blockSize = ok;
      element.style.blockSize = `${blockSize}px`;
    }
  }
  if (isNaN(blockSize)) {
    // Fallback for unexpected cases where overflow is not resolved while reducing
    // block-size down to the original balanced size.
    // Restore the stable `balance` state and keep data-viv-saved-column-fill="auto"
    // for diagnostics and possible later retry.
    element.style.blockSize = "";
    element.style.columnFill = "balance";
    return;
  }
  // Successfully restored `column-fill: auto`.
  element.removeAttribute("data-viv-saved-column-fill");
}

export function fixAutoFillMultiColumnBoxes(column: Layout.Column): void {
  // Restore `column-fill: auto` and set block-size for elements with data-viv-saved-column-fill="auto"
  const elements = column.element.querySelectorAll(
    '[data-viv-saved-column-fill="auto"]',
  );
  for (const element of elements) {
    fixAutoFillMultiColumnBox(element as HTMLElement, column);
  }
}

/**
 * Calculate the position of the "after" edge in the block-progression.
 * Returns the edge position in pixels if it was determined successfully,
 * and returns NaN if the position could not be determined and the node
 * should be considered zero-height.
 */
export function calculateEdge(
  nodeContext: Vtree.NodeContext,
  clientLayout: Vtree.ClientLayout,
  extraOffset: number,
  vertical: boolean,
): number {
  const node = nodeContext.viewNode;
  if (!node) {
    return NaN;
  }

  // NOTE: Do not replace `node.nodeType === 1` with `node instanceof Element`,
  // which does not work when the node is inside iframe. (Issue #1000)

  const element = node.nodeType === 1 ? (node as Element) : node.parentElement;
  if (element && element.namespaceURI === Base.NS.XHTML) {
    const style = (element as HTMLElement).style;
    if (
      element.localName === "wbr" ||
      (style &&
        Display.isInlineLevel(style.display) &&
        /^([\d\.]|super|(text-)?top)/.test(style.verticalAlign))
    ) {
      // Avoid incorrect edge calculation at WBR element,
      // or inline element with positive vertical-align (issue #811).
      return NaN;
    }
  }
  if (node === element) {
    // For BR elements, measure the line position by inserting a temporary
    // marker element BEFORE the BR. This is necessary because
    // getBoundingClientRect() on consecutive BRs reports the same rect
    // (the line they're ON), so the binary search can't distinguish them.
    // By measuring before each BR, we get the after-edge of the line
    // the BR is on, which correctly differentiates consecutive BRs:
    // the first BR's line fits while the second BR's blank line overflows.
    // (issue #1685)
    if (element.localName === "br") {
      const doc = element.ownerDocument;
      const marker = doc.createElement("span");
      element.before(marker);
      const markerRect = clientLayout.getElementClientRect(marker);
      marker.remove();
      if (markerRect) {
        const rects = [markerRect];
        adjustRectsForColumnBreaking(rects, vertical);
        const adjustedRect = rects[0];
        const edge = vertical ? adjustedRect.left : adjustedRect.bottom;
        if (!isNaN(edge) && edge !== 0) {
          return edge;
        }
      }
      return NaN;
    }
    if (nodeContext.after || !nodeContext.inline) {
      if (
        nodeContext.after &&
        !nodeContext.inline &&
        element.querySelector("ruby")
      ) {
        // Workaround for issue #987 (unnecessary break caused by ruby)
        const parentNode = element.parentNode;
        const nextSibling = element.nextSibling;
        parentNode.removeChild(element);
        parentNode.insertBefore(element, nextSibling);
      }
      const cbox = getElementClientRectAdjusted(
        clientLayout,
        element,
        vertical,
      );
      if (
        cbox.left === 0 &&
        cbox.top === 0 &&
        cbox.right === 0 &&
        cbox.bottom === 0
      ) {
        // getBoundingClientRect() returns 0,0,0,0 for WBR element (Chrome)
        // (Fix for issue #802)
        return NaN;
      }
      if (cbox.right >= cbox.left && cbox.bottom >= cbox.top) {
        if (nodeContext.after) {
          return vertical ? cbox.left : cbox.bottom;
        } else {
          return vertical ? cbox.right : cbox.top;
        }
      }
    }
    return NaN;
  } else {
    let edge = NaN;
    const length = node.textContent.length;
    if (!length) {
      return NaN;
    }
    if (nodeContext.after) {
      extraOffset += length;
    }
    if (extraOffset >= length) {
      extraOffset = length - 1;
    }
    let boxes = RangeClientRects.getLayoutClientRectsBetween(
      clientLayout,
      RangeClientRects.at(node, extraOffset),
      RangeClientRects.at(node, extraOffset + 1),
    );

    // Adjust boxes' positions for column breaking
    adjustRectsForColumnBreaking(boxes, vertical);

    // Prefer non-zero-area rects for stable edge calculation.
    // Fallback to block-direction-only rects only in preformatted contexts
    // for blank lines (issue #1685).
    const boxesWithArea = boxes.filter(
      (box) => box.right > box.left && box.bottom > box.top,
    );
    if (boxesWithArea.length > 0) {
      boxes = boxesWithArea;
    } else {
      const whiteSpace = element
        ? clientLayout.getElementComputedStyle(element).whiteSpace
        : "";
      const canUseZeroInlineSizeRect =
        whiteSpace === "pre" ||
        whiteSpace === "pre-wrap" ||
        whiteSpace === "pre-line" ||
        whiteSpace === "break-spaces";
      boxes = canUseZeroInlineSizeRect
        ? boxes.filter((box) =>
            vertical ? box.right > box.left : box.bottom > box.top,
          )
        : [];
    }
    if (!boxes.length) {
      return NaN;
    }
    if (vertical) {
      edge = Math.min(...boxes.map((box) => box.left));
    } else {
      edge = Math.max(...boxes.map((box) => box.bottom));
    }
    return edge;
  }
}

export function getElementHeight(
  element: Element,
  column: Layout.Column,
  vertical: boolean,
): number {
  const usingBrowserColumnBreaking = isUsingBrowserColumnBreaking(column);
  if (usingBrowserColumnBreaking) {
    unsetBrowserColumnBreaking(column);
  }
  const rect = column.clientLayout.getElementClientRect(element);
  if (usingBrowserColumnBreaking) {
    setBrowserColumnBreaking(column);
  }
  const margin = column.getComputedMargin(element);
  return vertical
    ? rect["width"] + margin["left"] + margin["right"]
    : rect["height"] + margin["top"] + margin["bottom"];
}

export function isOrphan(node: Node | null): boolean {
  while (node) {
    if (node.parentNode === node.ownerDocument) {
      return false;
    }
    node = node.parentNode;
  }
  return true;
}

export function removeFollowingSiblings(
  parentNode: Node | null,
  viewNode: Node,
): void {
  if (!parentNode) {
    return;
  }
  for (
    let lastChild = parentNode.lastChild, prevSibling = lastChild;
    lastChild !== viewNode;
    lastChild = prevSibling
  ) {
    prevSibling = lastChild.previousSibling;
    if (
      lastChild.nodeType === 1 &&
      (lastChild as Element).hasAttribute("data-vivliostyle-float-box-moved") &&
      (viewNode as HTMLElement).style?.display === "inline"
    ) {
      // Do not remove float box moved after parent inline (Issue #1383, #1422)
      continue;
    }
    parentNode.removeChild(lastChild);
  }
}

/**
 * Marks an element as "special". It should not be used in bbox calculations.
 */
export const SPECIAL_ATTR = "data-adapt-spec";

export function isSpecial(e: Element): boolean {
  return !!e.getAttribute(SPECIAL_ATTR);
}

export function isOutOfFlow(node: Node | null): boolean {
  if (!(node?.nodeType === 1)) return false;
  const e = node as HTMLElement;
  if (isSpecial(e)) return true;
  return isCssOutOfFlow(node);
}

/**
 * Check if element is out-of-flow due to CSS positioning or float.
 * Unlike isOutOfFlow(), this does not check for special marker elements.
 */
export function isCssOutOfFlow(node: Node): boolean {
  if (!(node?.nodeType === 1)) return false;
  const e = node as HTMLElement;
  const position = e.style?.position;
  if (position === "absolute" || position === "fixed") {
    return true;
  }
  const float = e.style?.float;
  return (
    float === "left" ||
    float === "right" ||
    float === "inline-start" ||
    float === "inline-end"
  );
}

/**
 * Check if element has position:fixed. Used to identify running elements
 * (position:running() rendered as position:fixed) without matching
 * position:absolute elements. (Issue #1833, #1869, #1870)
 */
export function isFixedPositioned(node: Node | null): boolean {
  if (!(node?.nodeType === 1)) return false;
  return (node as HTMLElement).style?.position === "fixed";
}

export function isSpecialNodeContext(nodeContext: Vtree.NodeContext): boolean {
  const viewNode = nodeContext?.viewNode;
  return viewNode?.nodeType === 1 && isSpecial(viewNode as Element);
}

export function isSpecialInlineDisplay(display: string): boolean {
  return (
    display !== "inline" &&
    (Display.isInlineLevel(display) || Display.isRubyInternalDisplay(display))
  );
}

export function findAncestorSpecialInlineNodeContext(
  nodeContext: Vtree.NodeContext,
): Vtree.ElementNodeContext | null {
  for (let p = nodeContext.parent; p; p = p.parent) {
    if (
      (p.display !== "inline" || p.vertical !== p.parent?.vertical) &&
      Display.isInlineLevel(p.display)
    ) {
      return VtreeImpl.asElementNodeContext(p);
    }
  }
  return null;
}

export function textSpacingWrapperOf(node: Element | Text): Element | null {
  const inner = node.parentElement;
  return inner?.localName === "viv-ts-inner" ? inner.parentElement : null;
}

export function findLastTextNodeInElement(element: Node): Node | null {
  let node: Node | null = element;
  while (node) {
    if (node.nodeType === Node.TEXT_NODE && node.textContent.length > 0) {
      return node;
    }
    if (node.lastChild) {
      node = node.lastChild;
    } else {
      while (node && !node.previousSibling) {
        node = node.parentNode;
        if (node === element || !node) {
          return null;
        }
      }
      node = node?.previousSibling || null;
    }
  }
  return null;
}
