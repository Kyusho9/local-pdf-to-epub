/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview CssValidator - Parse validation rules (validation.txt), validate
 * properties and shorthands.
 */
import * as CounterStyle from "./counter-style";
import * as Css from "./css";
import * as CssParser from "./css-parser";
import * as CssTokenizer from "./css-tokenizer";
import * as CmykStore from "./cmyk-store";
import * as Exprs from "./exprs";
import * as Base from "./base";
import { ValidationTxt } from "./assets";
import { TokenType } from "./css-tokenizer";

export interface PropertyReceiver {
  unknownProperty(name: string, value: Css.Val): void;

  invalidPropertyValue(name: string, value: Css.Val): void;

  simpleProperty(name: string, value: Css.Val, important): void;
}

export class Node {
  success: Node | null = null;
  failure: Node | null = null;
  code: number = 0;

  constructor(public validator: PropertyValidator | null) {}

  isSpecial(): boolean {
    return this.code != 0;
  }

  markAsStartGroup(): void {
    this.code = -1;
  }

  isStartGroup(): boolean {
    return this.code == -1;
  }

  markAsEndGroup(): void {
    this.code = -2;
  }

  isEndGroup(): boolean {
    return this.code == -2;
  }

  markAsStartAlternate(index: number): void {
    this.code = 2 * index + 1;
  }

  markAsEndAlternate(index: number): void {
    this.code = 2 * index + 2;
  }

  isEndAlternate(): boolean {
    return this.code > 0 && this.code % 2 == 0;
  }

  getAlternate(): number {
    return Math.floor((this.code - 1) / 2);
  }
}

export class Connection {
  what: number = -1;

  constructor(
    public where: number,
    public success: boolean,
  ) {}
}

/**
 * @enum {number}
 */
export enum Add {
  FOLLOW = 1,
  OPTIONAL,
  REPEATED,
  ALTERNATE,
}

/**
 * A class to build a list validator from other validators.
 */
export class ValidatingGroup {
  nodes: Node[] = [];
  connections: Connection[] = [];
  match: number[] = []; // connector indicies
  nomatch: number[] = []; // connector indicies
  error: number[] = []; // connector indicies
  emptyHead: boolean = true;

  connect(arr: number[], nodeIndex: number): void {
    for (let i = 0; i < arr.length; i++) {
      this.connections[arr[i]].what = nodeIndex;
    }
    arr.splice(0, arr.length);
  }

  clone(): ValidatingGroup {
    const group = new ValidatingGroup();
    for (let i = 0; i < this.nodes.length; i++) {
      const node = this.nodes[i];
      const clonedNode = new Node(node.validator);
      clonedNode.code = node.code;
      group.nodes.push(clonedNode);
    }
    for (let i = 0; i < this.connections.length; i++) {
      const connection = this.connections[i];
      const groupConnection = new Connection(
        connection.where,
        connection.success,
      );
      groupConnection.what = connection.what;
      group.connections.push(groupConnection);
    }
    group.match.push(...this.match);
    group.nomatch.push(...this.nomatch);
    group.error.push(...this.error);
    return group;
  }

  /**
   * Add "special" validation node to a given array (match, nomatch, or error).
   * @param start if this a start or the end of a clause/group
   * @param clause 0 indicates group start/end, otherwise clause index
   */
  private addSpecialToArr(arr: number[], start: boolean, clause: number): void {
    const index = this.nodes.length;
    const node = new Node(ALWAYS_FAIL);
    if (clause >= 0) {
      if (start) {
        node.markAsStartAlternate(clause);
      } else {
        node.markAsEndAlternate(clause);
      }
    } else {
      if (start) {
        node.markAsStartGroup();
      } else {
        node.markAsEndGroup();
      }
    }
    this.nodes.push(node);
    this.connect(arr, index);
    const success = new Connection(index, true);
    const failure = new Connection(index, false);
    arr.push(this.connections.length);
    this.connections.push(failure);
    arr.push(this.connections.length);
    this.connections.push(success);
  }

  endSpecialGroup(): void {
    const arrs = [this.match, this.nomatch, this.error];
    for (let i = 0; i < arrs.length; i++) {
      this.addSpecialToArr(arrs[i], false, -1);
    }
  }

  startSpecialGroup(): void {
    if (this.nodes.length) {
      throw new Error("invalid call");
    }
    this.addSpecialToArr(this.match, true, -1);
  }

  endClause(clause: number): void {
    this.addSpecialToArr(this.match, false, clause);
  }

  startClause(clause: number): void {
    if (this.nodes.length) {
      throw new Error("invalid call");
    }
    const node = new Node(ALWAYS_FAIL);
    node.markAsStartAlternate(clause);
    this.nodes.push(node);
    const success = new Connection(0, true);
    const failure = new Connection(0, false);
    this.nomatch.push(this.connections.length);
    this.connections.push(failure);
    this.match.push(this.connections.length);
    this.connections.push(success);
  }

  addPrimitive(validator: PropertyValidator): void {
    const index = this.nodes.length;
    this.nodes.push(new Node(validator));
    const success = new Connection(index, true);
    const failure = new Connection(index, false);
    this.connect(this.match, index);
    if (this.emptyHead) {
      // if did not validate -> no match
      this.nomatch.push(this.connections.length);
      this.emptyHead = false;
    } else {
      // if did not validate -> failure
      this.error.push(this.connections.length);
    }
    this.connections.push(failure);
    this.match.push(this.connections.length);
    this.connections.push(success);
  }

  isSimple(): boolean {
    return this.nodes.length == 1 && !this.nodes[0].isSpecial();
  }

  isPrimitive(): boolean {
    return (
      this.isSimple() && this.nodes[0].validator instanceof PrimitiveValidator
    );
  }

  addGroup(group: ValidatingGroup, how: Add): void {
    if (group.nodes.length == 0) {
      return;
    }
    const index = this.nodes.length;

    // optimization for alternate primitive validators
    if (
      how == Add.ALTERNATE &&
      index == 1 &&
      group.isPrimitive() &&
      this.isPrimitive()
    ) {
      this.nodes[0].validator = (
        this.nodes[0].validator as PrimitiveValidator
      ).combine(group.nodes[0].validator as PrimitiveValidator);
      return;
    }
    for (let i = 0; i < group.nodes.length; i++) {
      this.nodes.push(group.nodes[i]);
    }

    // nodes[index] is group start
    if (how == Add.ALTERNATE) {
      this.emptyHead = true;
      this.connect(this.nomatch, index);
    } else {
      this.connect(this.match, index);
    }
    const connectionIndex = this.connections.length;
    for (let i = 0; i < group.connections.length; i++) {
      const connection = group.connections[i];
      connection.where += index;
      if (connection.what >= 0) {
        connection.what += index;
      }
      this.connections.push(connection);
    }
    for (let i = 0; i < group.match.length; i++) {
      this.match.push(group.match[i] + connectionIndex);
    }
    if (how == Add.REPEATED) {
      this.connect(this.match, index);
    }
    if (how == Add.OPTIONAL || how == Add.REPEATED) {
      for (let i = 0; i < group.nomatch.length; i++) {
        this.match.push(group.nomatch[i] + connectionIndex);
      }
    } else if (this.emptyHead) {
      for (let i = 0; i < group.nomatch.length; i++) {
        this.nomatch.push(group.nomatch[i] + connectionIndex);
      }
      this.emptyHead = group.emptyHead;
    } else {
      for (let i = 0; i < group.nomatch.length; i++) {
        this.error.push(group.nomatch[i] + connectionIndex);
      }
    }
    for (let i = 0; i < group.error.length; i++) {
      this.error.push(group.error[i] + connectionIndex);
    }

    // invalidate group
    group.nodes = null;
    group.connections = null;
  }

  /**
   * @return how
   */
  finish(successTerminal: Node, failTerminal: Node): Node {
    const index = this.nodes.length;
    this.nodes.push(successTerminal);
    this.nodes.push(failTerminal);
    this.connect(this.match, index);
    this.connect(this.nomatch, index + 1);
    this.connect(this.error, index + 1);
    for (const connection of this.connections) {
      if (connection.success) {
        this.nodes[connection.where].success = this.nodes[connection.what];
      } else {
        this.nodes[connection.where].failure = this.nodes[connection.what];
      }
    }

    // make sure that our data structure is correct
    for (let j = 0; j < index; j++) {
      if (this.nodes[j].failure == null || this.nodes[j].success == null) {
        throw new Error("Invalid validator state");
      }
    }
    return this.nodes[0];
  }
}

export const ALLOW_EMPTY = 0x01;

export const ALLOW_STR = 0x02;

export const ALLOW_IDENT = 0x04;

export const ALLOW_POS_NUMERIC = 0x08;

export const ALLOW_POS_NUM = 0x10;

export const ALLOW_POS_INT = 0x20;

export const ALLOW_COLOR = 0x40;

export const ALLOW_URL = 0x80;

export const ALLOW_NEGATIVE = 0x100;

export const ALLOW_ZERO = 0x200;

export const ALLOW_ZERO_PERCENT = 0x400;

export const ALLOW_SLASH = 0x800;

export const ALLOW_URANGE = 0x1000;

export const ALLOW_IMAGE = 0x2000;

export type ValueMap = {
  [key: string]: Css.Val;
};

/**
 * Abstract class to validate simple CSS property value (not a shorthand)
 */
export class PropertyValidator extends Css.Visitor {
  constructor() {
    super();
  }

  /**
   * Validate a subsequence of the given values from the given index. Return the
   * list of matched values or null if there is no match.
   */
  validateForShorthand(values: Css.Val[], index: number): Css.Val[] | null {
    const rval = values[index].visit(this);
    if (rval) {
      return [rval];
    }
    return null;
  }
}

/**
 * Validate a primitive CSS value (not a list or function).
 * @param allowed mask of ALLOW_*** constants.
 */
export class PrimitiveValidator extends PropertyValidator {
  constructor(
    public readonly allowed: number,
    public readonly idents: ValueMap,
    public readonly units: ValueMap,
  ) {
    super();
  }

  override visitEmpty(empty: Css.Val): Css.Val | null {
    if (this.allowed & ALLOW_EMPTY) {
      return empty;
    }
    return null;
  }

  override visitSlash(slash: Css.Val): Css.Val | null {
    if (this.allowed & ALLOW_SLASH) {
      return slash;
    }
    return null;
  }

  override visitStr(str: Css.Str): Css.Val | null {
    if (this.allowed & ALLOW_STR) {
      return str;
    }
    return null;
  }

  override visitIdent(ident: Css.Ident): Css.Val | null {
    const val = this.idents[ident.name.toLowerCase()];
    if (val) {
      return val;
    }
    if (this.allowed & ALLOW_IDENT) {
      return ident;
    }
    if (this.allowed & ALLOW_COLOR) {
      if (CSS.supports("color", ident.name)) {
        return ident;
      }
    }
    return null;
  }

  override visitNumeric(numeric: Css.Numeric): Css.Val | null {
    if (numeric.num == 0 && !(this.allowed & ALLOW_ZERO)) {
      if (numeric.unit == "%" && this.allowed & ALLOW_ZERO_PERCENT) {
        return numeric;
      }
      return null;
    }
    if (numeric.num < 0 && !(this.allowed & ALLOW_NEGATIVE)) {
      return null;
    }
    if (this.units[numeric.unit]) {
      return numeric;
    }
    return null;
  }

  override visitNum(num: Css.Num): Css.Val | null {
    if (num.num == 0) {
      return this.allowed & ALLOW_ZERO ? num : null;
    }
    if (num.num <= 0 && !(this.allowed & ALLOW_NEGATIVE)) {
      return null;
    }
    if (this.allowed & ALLOW_POS_NUM) {
      return num;
    }
    return null;
  }

  override visitInt(num: Css.Int): Css.Val | null {
    if (num.num == 0) {
      return this.allowed & ALLOW_ZERO ? num : null;
    }
    if (num.num <= 0 && !(this.allowed & ALLOW_NEGATIVE)) {
      return null;
    }
    if (this.allowed & (ALLOW_POS_INT | ALLOW_POS_NUM)) {
      return num;
    }
    const val = this.idents[`${num.num}`];
    if (val) {
      return val;
    }
    return null;
  }

  override visitHexColor(color: Css.HexColor): Css.Val | null {
    if (this.allowed & ALLOW_COLOR) {
      if (/^([0-9A-F]{3,4}|([0-9A-F]{2}){3,4})$/i.test(color.hex)) {
        return color;
      }
    }
    return null;
  }

  override visitURL(url: Css.URL): Css.Val | null {
    if (this.allowed & ALLOW_URL) {
      return url;
    }
    return null;
  }

  override visitURange(urange: Css.URange): Css.Val | null {
    if (this.allowed & ALLOW_URANGE) {
      return urange;
    }
    return null;
  }

  override visitSpaceList(list: Css.SpaceList): Css.Val | null {
    return null;
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    return null;
  }

  override visitFunc(func: Css.Func): Css.Val | null {
    if (func.name.toLowerCase() === "attr") {
      const attr = parseAttrFunction(func);
      if (
        attr &&
        validatorSupportsAttrType(attr.type, this.allowed, this.units)
      ) {
        return func;
      }
    }
    if (this.allowed & ALLOW_COLOR) {
      if (func.name === "device-cmyk" || func.name === "cmyk") {
        if (
          CSS.supports("color", "color(srgb 0 0 0)") &&
          CmykStore.parseDeviceCmyk(func) !== null
        ) {
          return func;
        }
        return null;
      }
      if (CSS.supports("color", func.toString())) {
        return func;
      }
    }
    if (this.allowed & ALLOW_IMAGE) {
      // CSS.supports() doesn't understand device-cmyk(), so we need to
      // substitute it with a valid color for structure validation.
      const tempFunc = func.visit(new CmykStore.CmykFilterVisitor());
      if (CSS.supports("background-image", tempFunc.toString())) {
        return func;
      }
    }
    if (
      func.name === "calc" &&
      this.allowed &
        (ALLOW_POS_NUMERIC |
          ALLOW_POS_NUM |
          ALLOW_POS_INT |
          ALLOW_NEGATIVE |
          ALLOW_ZERO |
          ALLOW_ZERO_PERCENT)
    ) {
      return func;
    }
    return null;
  }

  override visitExpr(expr: Css.Expr): Css.Val | null {
    if (this.allowed & 0x7fe) {
      // ALLOW_STR|ALLOW_IDENT|...|ALLOW_ZERO_PERCENT
      return expr;
    }
    return null;
  }

  combine(other: PrimitiveValidator): PrimitiveValidator {
    const idents: ValueMap = {};
    const units: ValueMap = {};
    for (const ident in this.idents) {
      idents[ident] = this.idents[ident];
    }
    for (const ident in other.idents) {
      idents[ident] = other.idents[ident];
    }
    for (const unit in this.units) {
      units[unit] = this.units[unit];
    }
    for (const unit in other.units) {
      units[unit] = other.units[unit];
    }
    return new PrimitiveValidator(this.allowed | other.allowed, idents, units);
  }
}

const NO_IDENTS: ValueMap = Object.create(null);

const ATTR_ANY_NUMBER = ALLOW_POS_NUM | ALLOW_NEGATIVE | ALLOW_ZERO;

const ATTR_ANY_INTEGER = ALLOW_POS_INT | ALLOW_NEGATIVE | ALLOW_ZERO;

const ATTR_ANY_NUMERIC =
  ALLOW_POS_NUMERIC | ALLOW_NEGATIVE | ALLOW_ZERO | ALLOW_ZERO_PERCENT;

function makeUnitMap(unitNames: string[]): ValueMap {
  const units: ValueMap = Object.create(null);
  for (const unit of unitNames) {
    units[unit] = Css.empty;
  }
  return units;
}

const PERCENTAGE_UNITS = makeUnitMap(["%"]);

const LENGTH_UNITS = makeUnitMap([
  "em",
  "ex",
  "ch",
  "rem",
  "lh",
  "rlh",
  "vw",
  "vh",
  "vi",
  "vb",
  "vmin",
  "vmax",
  "pvw",
  "pvh",
  "pvi",
  "pvb",
  "pvmin",
  "pvmax",
  "cm",
  "mm",
  "in",
  "px",
  "pt",
  "pc",
  "q",
]);

const LENGTH_PERCENTAGE_UNITS = {
  ...LENGTH_UNITS,
  ...PERCENTAGE_UNITS,
};

const ANGLE_UNITS = makeUnitMap(["deg", "grad", "rad", "turn"]);

const TIME_UNITS = makeUnitMap(["s", "ms"]);

const FREQUENCY_UNITS = makeUnitMap(["hz", "khz"]);

export type AttrType =
  | { kind: "string" }
  | { kind: "url" }
  | { kind: "syntax"; syntax: string }
  | { kind: "unit"; unit: string };

export type AttrFunction = {
  attributeName: string;
  type: AttrType;
  fallback: Css.Val | null;
};

function normalizeAttrSyntax(syntax: string): string {
  return syntax.replace(/\s+/g, "").toLowerCase();
}

function canonicalAttrUnit(unit: string): string {
  return unit.toLowerCase();
}

function parseAttrTypeValue(value: Css.Val): AttrType | null {
  if (value instanceof Css.Ident) {
    switch (value.name.toLowerCase()) {
      case "string":
      case "raw-string":
        return { kind: "string" };
      case "url":
        return { kind: "url" };
      case "color":
      case "integer":
      case "number":
      case "length":
      case "angle":
      case "time":
      case "frequency":
        return { kind: "syntax", syntax: `<${value.name.toLowerCase()}>` };
      default:
        return { kind: "unit", unit: canonicalAttrUnit(value.name) };
    }
  }
  if (value instanceof Css.Func && value.name.toLowerCase() === "type") {
    if (value.values.length !== 1) {
      return null;
    }
    const syntax = normalizeAttrSyntax(value.values[0].stringValue());
    return syntax ? { kind: "syntax", syntax } : null;
  }
  return null;
}

export function parseAttrFunction(func: Css.Func): AttrFunction | null {
  if (func.name.toLowerCase() !== "attr") {
    return null;
  }
  if (func.values.length < 1 || func.values.length > 2) {
    return null;
  }

  let attributeName: string;
  let type: AttrType | null = { kind: "string" };
  const attributeArg = func.values[0];
  if (attributeArg instanceof Css.Ident) {
    attributeName = attributeArg.name;
  } else if (attributeArg instanceof Css.SpaceList) {
    const values = attributeArg.values;
    if (
      values.length < 1 ||
      values.length > 2 ||
      !(values[0] instanceof Css.Ident)
    ) {
      return null;
    }
    attributeName = values[0].name;
    if (values.length === 2) {
      type = parseAttrTypeValue(values[1]);
      if (!type) {
        return null;
      }
    }
  } else {
    return null;
  }

  return {
    attributeName,
    type,
    fallback: func.values[1] ?? null,
  };
}

function hasAttrUnit(units: ValueMap, unit: string): boolean {
  return !!units[canonicalAttrUnit(unit)];
}

function hasAnyAttrUnit(units: ValueMap, candidates: ValueMap): boolean {
  return Object.keys(candidates).some((unit) => hasAttrUnit(units, unit));
}

function validatorSupportsAttrType(
  type: AttrType,
  allowed: number,
  units: ValueMap,
): boolean {
  switch (type.kind) {
    case "string":
      return !!(allowed & ALLOW_STR);
    case "url":
      return !!(allowed & (ALLOW_URL | ALLOW_IMAGE));
    case "unit":
      return hasAttrUnit(units, type.unit);
    case "syntax":
      switch (type.syntax) {
        case "<string>":
          return !!(allowed & ALLOW_STR);
        case "<url>":
          return !!(allowed & (ALLOW_URL | ALLOW_IMAGE));
        case "<color>":
          return !!(allowed & ALLOW_COLOR);
        case "<integer>":
          return !!(
            allowed &
            (ALLOW_POS_INT | ALLOW_POS_NUM | ALLOW_NEGATIVE | ALLOW_ZERO)
          );
        case "<number>":
          return !!(
            allowed &
            (ALLOW_POS_NUM | ALLOW_POS_INT | ALLOW_NEGATIVE | ALLOW_ZERO)
          );
        case "<length>":
          return hasAnyAttrUnit(units, LENGTH_UNITS);
        case "<length-percentage>":
          return hasAnyAttrUnit(units, LENGTH_PERCENTAGE_UNITS);
        case "<percentage>":
          return hasAnyAttrUnit(units, PERCENTAGE_UNITS);
        case "<angle>":
          return hasAnyAttrUnit(units, ANGLE_UNITS);
        case "<time>":
          return hasAnyAttrUnit(units, TIME_UNITS);
        case "<frequency>":
          return hasAnyAttrUnit(units, FREQUENCY_UNITS);
        default:
          return false;
      }
  }
  return false;
}

function createAttrPrimitiveValidator(
  type: AttrType,
): PrimitiveValidator | null {
  switch (type.kind) {
    case "string":
      return null;
    case "url":
      return null;
    case "unit":
      return new PrimitiveValidator(ATTR_ANY_NUMERIC, NO_IDENTS, {
        [canonicalAttrUnit(type.unit)]: Css.empty,
      });
    case "syntax":
      switch (type.syntax) {
        case "<color>":
          return new PrimitiveValidator(ALLOW_COLOR, NO_IDENTS, NO_IDENTS);
        case "<integer>":
          return new PrimitiveValidator(ATTR_ANY_INTEGER, NO_IDENTS, NO_IDENTS);
        case "<number>":
          return new PrimitiveValidator(ATTR_ANY_NUMBER, NO_IDENTS, NO_IDENTS);
        case "<length>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            LENGTH_UNITS,
          );
        case "<length-percentage>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            LENGTH_PERCENTAGE_UNITS,
          );
        case "<percentage>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            PERCENTAGE_UNITS,
          );
        case "<angle>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            ANGLE_UNITS,
          );
        case "<time>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            TIME_UNITS,
          );
        case "<frequency>":
          return new PrimitiveValidator(
            ATTR_ANY_NUMERIC,
            NO_IDENTS,
            FREQUENCY_UNITS,
          );
        default:
          return null;
      }
  }
  return null;
}

function isSupportedAttrType(type: AttrType): boolean {
  switch (type.kind) {
    case "string":
    case "url":
    case "unit":
      return true;
    case "syntax":
      return (
        type.syntax === "<string>" ||
        type.syntax === "<url>" ||
        !!createAttrPrimitiveValidator(type)
      );
  }
  return false;
}

export function getImplicitAttrFallback(type: AttrType): Css.Val {
  switch (type.kind) {
    case "url":
      return new Css.URL("about:invalid");
    case "string":
      return new Css.Str("");
    default:
      return Css.ident.unset;
  }
}

export function parseAttrValue(
  scope: Exprs.LexicalScope,
  value: string | null,
  type: AttrType,
): Css.Val | null {
  if (value == null) {
    return null;
  }

  switch (type.kind) {
    case "string":
      return new Css.Str(value);
    case "url":
      return value ? new Css.URL(value) : new Css.URL("about:invalid");
    case "unit": {
      const parsed = CssParser.parseValue(
        scope,
        new CssTokenizer.Tokenizer(
          `${value.trim()}${canonicalAttrUnit(type.unit)}`,
          null,
        ),
        "",
      );
      const validator = createAttrPrimitiveValidator(type);
      return parsed && validator ? parsed.visit(validator) : null;
    }
    case "syntax": {
      if (type.syntax === "<string>") {
        return new Css.Str(value);
      }
      if (type.syntax === "<url>") {
        return value ? new Css.URL(value) : new Css.URL("about:invalid");
      }
      const parsed = CssParser.parseValue(
        scope,
        new CssTokenizer.Tokenizer(value, null),
        "",
      );
      const validator = createAttrPrimitiveValidator(type);
      return parsed && validator ? parsed.visit(validator) : null;
    }
  }
  return null;
}

export const ALWAYS_FAIL = new PrimitiveValidator(0, NO_IDENTS, NO_IDENTS);

/**
 * Base class for list validation.
 */
export class ListValidator extends PropertyValidator {
  successTerminal: Node;
  failureTerminal: Node;
  first: Node;

  constructor(group: ValidatingGroup) {
    super();
    this.successTerminal = new Node(null);
    this.failureTerminal = new Node(null);
    this.first = group.finish(this.successTerminal, this.failureTerminal);
  }

  validateList(
    arr: Css.Val[],
    slice: boolean,
    startIndex: number,
  ): Css.Val[] | null {
    let out: Css.Val[] = slice ? [] : arr;
    let current = this.first;
    let index = startIndex;
    let alternativeStack: string[][] = null;
    let alternatives: string[] = null;
    while (
      current !== this.successTerminal &&
      current !== this.failureTerminal
    ) {
      if (index >= arr.length) {
        current = current.failure;
        continue;
      }
      const inval = arr[index];
      let outval: Css.Val | null = inval;
      if (current.isSpecial()) {
        let success = true;
        if (current.isStartGroup()) {
          if (alternativeStack) {
            alternativeStack.push(alternatives);
          } else {
            alternativeStack = [alternatives];
          }
          alternatives = [];
        } else if (current.isEndGroup()) {
          if (alternativeStack.length > 0) {
            alternatives = alternativeStack.pop();
          } else {
            alternatives = null;
          }
        } else if (current.isEndAlternate()) {
          alternatives[current.getAlternate()] = "taken";
        } else {
          success = alternatives[current.getAlternate()] == null;
        }
        current = success ? current.success : current.failure;
      } else {
        if (
          index == 0 &&
          !slice &&
          current.validator instanceof SpaceListValidator &&
          this instanceof SpaceListValidator
        ) {
          // Special nesting case: validate the input space list as a whole.
          outval = new Css.SpaceList(arr).visit(current.validator);
          if (outval) {
            index = arr.length;
            current = current.success;
            continue;
          }
        } else if (
          index == 0 &&
          !slice &&
          current.validator instanceof CommaListValidator &&
          this instanceof SpaceListValidator
        ) {
          // Special nesting case: validate the input comma list as a whole.
          outval = new Css.CommaList(arr).visit(current.validator);
          if (outval) {
            index = arr.length;
            current = current.success;
            continue;
          }
        } else {
          outval = inval.visit(current.validator);
        }
        if (!outval) {
          current = current.failure;
          continue;
        }
        if (outval !== inval && arr === out) {
          // startIndex is zero here
          out = [];
          for (let k = 0; k < index; k++) {
            out[k] = arr[k];
          }
        }
        if (arr !== out) {
          out[index - startIndex] = outval;
        }
        index++;
        current = current.success;
      }
    }
    if (current === this.successTerminal) {
      if (slice ? out.length > 0 : index == arr.length) {
        return out;
      }
    }
    return null;
  }

  validateSingle(inval: Css.Val): Css.Val | null {
    const out = this.validateList([inval], false, 0);
    return out ? out[0] : null;
  }

  override visitEmpty(empty: Css.Val): Css.Val | null {
    return this.validateSingle(empty);
  }

  override visitSlash(slash: Css.Val): Css.Val | null {
    return this.validateSingle(slash);
  }

  override visitStr(str: Css.Str): Css.Val | null {
    return this.validateSingle(str);
  }

  override visitIdent(ident: Css.Ident): Css.Val | null {
    return this.validateSingle(ident);
  }

  override visitNumeric(numeric: Css.Numeric): Css.Val | null {
    return this.validateSingle(numeric);
  }

  override visitNum(num: Css.Num): Css.Val | null {
    return this.validateSingle(num);
  }

  override visitInt(num: Css.Int): Css.Val | null {
    return this.validateSingle(num);
  }

  override visitHexColor(color: Css.HexColor): Css.Val | null {
    return this.validateSingle(color);
  }

  override visitURL(url: Css.URL): Css.Val | null {
    return this.validateSingle(url);
  }

  override visitURange(urange: Css.URange): Css.Val | null {
    return this.validateSingle(urange);
  }

  override visitSpaceList(list: Css.SpaceList): Css.Val | null {
    return null;
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    return null;
  }

  override visitFunc(func: Css.Func): Css.Val | null {
    return this.validateSingle(func);
  }

  override visitExpr(expr: Css.Expr): Css.Val | null {
    return null;
  }
}

export class SpaceListValidator extends ListValidator {
  constructor(group: ValidatingGroup) {
    super(group);
  }

  override visitSpaceList(list: Css.SpaceList): Css.Val | null {
    const arr = this.validateList(list.values, false, 0);
    if (arr === list.values) {
      return list;
    }
    if (!arr) {
      return null;
    }
    return new Css.SpaceList(arr);
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    // Special Case : Issue #156
    let node = this.first;
    let hasCommaListValidator = false;
    while (node) {
      if (node.validator instanceof CommaListValidator) {
        hasCommaListValidator = true;
        break;
      }
      node = node.failure;
    }
    if (hasCommaListValidator) {
      const arr = this.validateList(list.values, false, 0);
      if (arr === list.values) {
        return list;
      }
      if (!arr) {
        return null;
      }
      return new Css.CommaList(arr);
    }
    return null;
  }

  override validateForShorthand(
    values: Css.Val[],
    index: number,
  ): Css.Val[] | null {
    return this.validateList(values, true, index);
  }
}

export class CommaListValidator extends ListValidator {
  constructor(group: ValidatingGroup) {
    super(group);
  }

  override visitSpaceList(list: Css.SpaceList): Css.Val | null {
    return this.validateSingle(list);
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    const arr = this.validateList(list.values, false, 0);
    if (arr === list.values) {
      return list;
    }
    if (!arr) {
      return null;
    }
    return new Css.CommaList(arr);
  }

  override validateForShorthand(
    values: Css.Val[],
    index: number,
  ): Css.Val[] | null {
    let current = this.first;
    let rval: Css.Val[];
    while (current !== this.failureTerminal) {
      rval = current.validator.validateForShorthand(values, index);
      if (rval) {
        return rval;
      }
      current = current.failure;
    }
    return null;
  }
}

export class FuncValidator extends ListValidator {
  constructor(
    public readonly name: string,
    group: ValidatingGroup,
  ) {
    super(group);
  }

  override validateSingle(inval: Css.Val): Css.Val | null {
    return null;
  }

  override visitFunc(func: Css.Func): Css.Val | null {
    if (func.name.toLowerCase() != this.name) {
      return null;
    }
    const arr = this.validateList(func.values, false, 0);
    if (arr === func.values) {
      return func;
    }
    if (!arr) {
      return null;
    }
    return new Css.Func(func.name, arr);
  }
}

class AttrFuncValidator extends PropertyValidator {
  validateSingle(_inval: Css.Val): Css.Val | null {
    return null;
  }

  override visitFunc(func: Css.Func): Css.Val | null {
    const attr = parseAttrFunction(func);
    return attr && isSupportedAttrType(attr.type) ? func : null;
  }
}

//----------------------- Shorthands
//------------------------------------------------------------
export class ShorthandSyntaxNode {
  /**
   * @return new index.
   */
  tryParse(
    values: Css.Val[],
    index: number,
    shorthandValidator: ShorthandValidator,
  ): number {
    return index;
  }

  success(rval: Css.Val, shorthandValidator: ShorthandValidator): void {}
}

export class ShorthandSyntaxProperty extends ShorthandSyntaxNode {
  validator: PropertyValidator;

  constructor(
    validatorSet: ValidatorSet,
    public readonly name: string,
  ) {
    super();
    this.validator = validatorSet.validators.get(this.name);
  }

  override tryParse(
    values: Css.Val[],
    index: number,
    shorthandValidator: ShorthandValidator,
  ): number {
    if (shorthandValidator.values[this.name]) {
      return index;
    }
    const rvals = this.validator.validateForShorthand(values, index);
    if (rvals) {
      const len = rvals.length;
      const rval = len > 1 ? new Css.SpaceList(rvals) : rvals[0];
      this.success(rval, shorthandValidator);
      return index + len;
    }
    return index;
  }

  override success(
    rval: Css.Val,
    shorthandValidator: ShorthandValidator,
  ): void {
    shorthandValidator.values[this.name] = rval;
  }
}

export class ShorthandSyntaxPropertyN extends ShorthandSyntaxProperty {
  constructor(
    validatorSet: ValidatorSet,
    public readonly names: string[],
  ) {
    super(validatorSet, names[0]);
  }

  override success(
    rval: Css.Val,
    shorthandValidator: ShorthandValidator,
  ): void {
    for (let i = 0; i < this.names.length; i++) {
      shorthandValidator.values[this.names[i]] = rval;
    }
  }
}

export class ShorthandSyntaxCompound extends ShorthandSyntaxNode {
  constructor(
    public readonly nodes: ShorthandSyntaxNode[],
    public readonly slash: boolean,
  ) {
    super();
  }

  override tryParse(
    values: Css.Val[],
    index: number,
    shorthandValidator: ShorthandValidator,
  ): number {
    const index0 = index;
    if (this.slash) {
      if (values[index] == Css.slash) {
        if (++index == values.length) {
          return index0;
        }
      } else {
        return index0;
      }
    }
    let newIndex = this.nodes[0].tryParse(values, index, shorthandValidator);
    if (newIndex == index) {
      return index0;
    }
    index = newIndex;
    for (let i = 1; i < this.nodes.length && index < values.length; i++) {
      newIndex = this.nodes[i].tryParse(values, index, shorthandValidator);
      if (newIndex == index) {
        break;
      }
      index = newIndex;
    }
    return index;
  }
}

export class ShorthandValidator extends Css.Visitor {
  error: boolean = false;
  values: ValueMap = {};

  protected constructor(
    public validatorSet: ValidatorSet,
    public syntax: ShorthandSyntaxNode[],
    public propList: string[],
  ) {
    super();
  }

  static create(
    validatorSet: ValidatorSet,
    syntax: ShorthandSyntaxNode[],
    propList: string[],
  ): ShorthandValidator {
    return new this(validatorSet, syntax, propList);
  }

  clone(scope: Exprs.LexicalScope): ShorthandValidator {
    return new (this.constructor as any)(
      this.validatorSet,
      this.syntax,
      this.propList,
    );
  }

  finish(important: boolean, receiver: PropertyReceiver): boolean {
    if (!this.error) {
      for (const name of this.propList) {
        receiver.simpleProperty(
          name,
          this.values[name] ??
            this.validatorSet.defaultValues.get(name) ??
            Css.ident.initial,
          important,
        );
      }
      return true;
    }
    return false;
  }

  propagateDefaultingValue(
    value: Css.Val,
    important: boolean,
    receiver: PropertyReceiver,
  ): void {
    for (const name of this.propList) {
      receiver.simpleProperty(name, value, important);
    }
  }

  validateList(list: Css.Val[]): number {
    this.error = true;
    return 0;
  }

  validateSingle(val: Css.Val): Css.Val | null {
    this.validateList([val]);
    return null;
  }

  override visitEmpty(empty: Css.Val): Css.Val | null {
    return this.validateSingle(empty);
  }

  override visitStr(str: Css.Str): Css.Val | null {
    return this.validateSingle(str);
  }

  override visitIdent(ident: Css.Ident): Css.Val | null {
    return this.validateSingle(ident);
  }

  override visitNumeric(numeric: Css.Numeric): Css.Val | null {
    return this.validateSingle(numeric);
  }

  override visitNum(num: Css.Num): Css.Val | null {
    return this.validateSingle(num);
  }

  override visitInt(num: Css.Int): Css.Val | null {
    return this.validateSingle(num);
  }

  override visitHexColor(color: Css.HexColor): Css.Val | null {
    return this.validateSingle(color);
  }

  override visitURL(url: Css.URL): Css.Val | null {
    return this.validateSingle(url);
  }

  override visitSpaceList(list: Css.SpaceList): Css.Val | null {
    this.validateList(list.values);
    return null;
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    this.error = true;
    return null;
  }

  override visitFunc(func: Css.Func): Css.Val | null {
    return this.validateSingle(func);
  }

  override visitExpr(expr: Css.Expr): Css.Val | null {
    return this.validateSingle(expr);
  }
}

export class SimpleShorthandValidator extends ShorthandValidator {
  override validateList(list: Css.Val[]): number {
    let index = 0;
    let i = 0;
    while (index < list.length) {
      const newIndex = this.syntax[i].tryParse(list, index, this);
      if (newIndex > index) {
        index = newIndex;
        i = 0;
        continue;
      }
      if (++i == this.syntax.length) {
        this.error = true;
        break;
      }
    }
    return index;
  }
}

export class InsetsShorthandValidator extends ShorthandValidator {
  override validateList(list: Css.Val[]): number {
    if (list.length > this.syntax.length || list.length == 0) {
      this.error = true;
      return 0;
    }
    for (let i = 0; i < this.syntax.length; i++) {
      let index = i;
      while (index >= list.length) {
        index = index == 1 ? 0 : index - 2;
      }
      if (this.syntax[i].tryParse(list, index, this) != index + 1) {
        this.error = true;
        return 0;
      }
    }
    return list.length;
  }

  createSyntaxNode(): ShorthandSyntaxPropertyN {
    return new ShorthandSyntaxPropertyN(this.validatorSet, this.propList);
  }
}

export class InsetsSlashShorthandValidator extends ShorthandValidator {
  override validateList(list: Css.Val[]): number {
    let slashIndex = list.length;
    for (let i = 0; i < list.length; i++) {
      if (list[i] === Css.slash) {
        slashIndex = i;
        break;
      }
    }
    if (slashIndex > this.syntax.length || list.length == 0) {
      this.error = true;
      return 0;
    }
    for (let i = 0; i < this.syntax.length; i++) {
      let index0 = i;
      while (index0 >= slashIndex) {
        index0 = index0 == 1 ? 0 : index0 - 2;
      }
      let index1: number;
      if (slashIndex + 1 < list.length) {
        index1 = slashIndex + i + 1;
        while (index1 >= list.length) {
          index1 = index1 - (index1 == slashIndex + 2 ? 1 : 2);
        }
      } else {
        index1 = index0;
      }
      const vals = [list[index0], list[index1]];
      if (this.syntax[i].tryParse(vals, 0, this) != 2) {
        this.error = true;
        return 0;
      }
    }
    return list.length;
  }
}

export class CommaShorthandValidator extends SimpleShorthandValidator {
  mergeIn(acc: { [key: string]: Css.Val[] }, values: ValueMap) {
    for (const name of this.propList) {
      const val =
        values[name] ??
        this.validatorSet.defaultValues.get(name) ??
        Css.ident.initial;
      let arr = acc[name];
      if (!arr) {
        arr = [];
        acc[name] = arr;
      }
      arr.push(val);
    }
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    const acc: { [key: string]: Css.Val[] } = {};
    for (let i = 0; i < list.values.length; i++) {
      this.values = {};
      if (list.values[i] instanceof Css.CommaList) {
        this.error = true;
      } else {
        list.values[i].visit(this);
        this.mergeIn(acc, this.values);
        if (this.values["background-color"] && i != list.values.length - 1) {
          this.error = true;
        }
      }
      if (this.error) {
        return null;
      }
    }
    this.values = {};
    for (const name in acc) {
      if (name == "background-color") {
        this.values[name] = acc[name].pop();
      } else {
        this.values[name] = new Css.CommaList(acc[name]);
      }
    }
    return null;
  }
}

export class FontShorthandValidator extends SimpleShorthandValidator {
  static override create(
    validatorSet: ValidatorSet,
    syntax: ShorthandSyntaxNode[],
    propList: string[],
  ): FontShorthandValidator {
    return new FontShorthandValidator(validatorSet, syntax, [
      ...propList,
      "font-family",
      "line-height",
      "font-size",
      "font-stretch",
      "font-variant-ligatures",
      "font-variant-caps",
      "font-variant-numeric",
      "font-variant-east-asian",
    ]);
  }

  override validateList(list: Css.Val[]): number {
    let index = super.validateList(list);

    const fontVariant = this.values["font-variant_css2"];
    if (fontVariant) {
      delete this.values["font-variant_css2"];
      this.values["font-variant-caps"] = fontVariant;
    }
    const fontStretch = this.values["font-stretch_css3"];
    if (fontStretch) {
      delete this.values["font-stretch_css3"];
      this.values["font-stretch"] = fontStretch;
    }

    // must at least have font-size and font-family at the end
    if (index + 2 > list.length) {
      this.error = true;
      return index;
    }
    this.error = false;
    const validators = this.validatorSet.validators;
    if (!list[index].visit(validators.get("font-size"))) {
      // If font-size validation fails and a calc() was incorrectly consumed
      // as font-weight by super.validateList (calc() is ambiguous between
      // font-weight <number> and font-size <length>), backtrack to the
      // calc() token's position and re-validate as font-size. (Issue #1955)
      const fontWeight = this.values["font-weight"];
      const calcIndex =
        fontWeight instanceof Css.Func && fontWeight.name === "calc"
          ? list.indexOf(fontWeight)
          : -1;
      if (
        calcIndex >= 0 &&
        list[calcIndex].visit(validators.get("font-size"))
      ) {
        delete this.values["font-weight"];
        index = calcIndex;
      } else {
        this.error = true;
        return index;
      }
    }
    this.values["font-size"] = list[index++];
    if (list[index] === Css.slash) {
      index++;

      // must at least have line-height and font-family at the end
      if (index + 2 > list.length) {
        this.error = true;
        return index;
      }
      if (!list[index].visit(validators.get("line-height"))) {
        this.error = true;
        return index;
      }
      this.values["line-height"] = list[index++];
    }
    const fontFamily =
      index == list.length - 1
        ? list[index]
        : new Css.SpaceList(list.slice(index, list.length));
    if (!fontFamily.visit(validators.get("font-family"))) {
      this.error = true;
      return index;
    }
    this.values["font-family"] = fontFamily;
    return list.length;
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    list.values[0].visit(this);
    if (this.error) {
      return null;
    }
    const familyList = [this.values["font-family"]];
    for (let i = 1; i < list.values.length; i++) {
      familyList.push(list.values[i]);
    }
    const family = new Css.CommaList(familyList);
    if (!family.visit(this.validatorSet.validators.get("font-family"))) {
      this.error = true;
    } else {
      this.values["font-family"] = family;
    }
    return null;
  }

  override visitIdent(ident: Css.Ident): Css.Val | null {
    const props = this.validatorSet.systemFonts.get(ident.name);
    if (props) {
      for (const name in props) {
        this.values[name] = props[name];
      }
    } else {
      this.error = true;
    }
    return null;
  }
}

export class TextSpacingShorthandValidator extends SimpleShorthandValidator {
  override validateList(list: Css.Val[]): number {
    if (list.length === 1 && list[0] instanceof Css.Ident) {
      switch (list[0].name.toLowerCase()) {
        case "normal":
          list = [
            this.validatorSet.defaultValues.get("text-autospace"),
            this.validatorSet.defaultValues.get("text-spacing-trim"),
          ];
          break;
        case "auto":
          list = [Css.ident.auto, Css.ident.auto];
          break;
        case "none":
          list = [Css.getName("no-autospace"), Css.getName("space-all")];
          break;
      }
    }
    return super.validateList(list);
  }
}

export class BrowserShorthandValidator extends ShorthandValidator {
  // Browser-supported shorthands that Vivliostyle does not model explicitly
  // still need to participate in shorthand/longhand cascade resolution.
  // This validator reuses the browser's own shorthand expansion instead of
  // requiring one dedicated validator class per shorthand.
  constructor(
    validatorSet: ValidatorSet,
    public readonly name: string,
    propList: string[] = [],
  ) {
    super(validatorSet, [], propList);
  }

  override clone(scope: Exprs.LexicalScope): ShorthandValidator {
    return new ScopedBrowserShorthandValidator(
      this.validatorSet,
      this.name,
      [...this.propList],
      scope,
    );
  }
}

export class ScopedBrowserShorthandValidator extends BrowserShorthandValidator {
  constructor(
    validatorSet: ValidatorSet,
    name: string,
    propList: string[],
    public readonly scope: Exprs.LexicalScope,
  ) {
    super(validatorSet, name, propList);
  }

  private validateValueText(valueText: string): boolean {
    const expanded = this.validatorSet.expandBrowserShorthand(
      this.name,
      valueText,
    );
    if (!expanded) {
      this.error = true;
      return false;
    }

    this.propList = expanded.propList;
    this.values = {};
    for (const name of expanded.propList) {
      const valueText = expanded.values[name];
      if (!valueText) {
        continue;
      }
      const parsed = CssParser.parseValue(
        this.scope,
        new CssTokenizer.Tokenizer(valueText, null),
        "",
      );
      if (!parsed) {
        this.error = true;
        return false;
      }
      this.values[name] = parsed;
    }
    this.error = false;
    return true;
  }

  override validateList(list: Css.Val[]): number {
    const value =
      list.length === 1
        ? list[0].toString()
        : new Css.SpaceList(list).toString();
    if (!this.validateValueText(value)) {
      return 0;
    }
    return list.length;
  }

  override visitCommaList(list: Css.CommaList): Css.Val | null {
    this.validateValueText(list.toString());
    return null;
  }
}

const propsExcludedFromAll = [
  "unicode-bidi",
  "direction",

  // excludes css-logical
  "margin-block-start",
  "margin-block-end",
  "margin-inline-start",
  "margin-inline-end",
  "padding-block-start",
  "padding-block-end",
  "padding-inline-start",
  "padding-inline-end",
  "border-block-start-color",
  "border-block-end-color",
  "border-inline-start-color",
  "border-inline-end-color",
  "border-block-start-style",
  "border-block-end-style",
  "border-inline-start-style",
  "border-inline-end-style",
  "border-block-start-width",
  "border-block-end-width",
  "border-inline-start-width",
  "border-inline-end-width",
  "block-start",
  "block-end",
  "inline-start",
  "inline-end",
  "inset-block-start",
  "inset-block-end",
  "inset-inline-start",
  "inset-inline-end",
  "block-size",
  "inline-size",
  "max-block-size",
  "max-inline-size",
  "min-block-size",
  "min-inline-size",

  // excludes non-standards and special
  "behavior",
  "bleed",
  "conflicting-partitions",
  "crop-offset",
  "crop-marks-line-color",
  "enabled",
  "flow-consume",
  "flow-from",
  "flow-into",
  "flow-linger",
  "flow-options",
  "flow-priority",
  "font-display",
  "font-size-adjust",
  "font-stretch_css3",
  "font-variant_css2",
  "glyph-orientation-vertical",
  "marks",
  "min-page-height",
  "min-page-width",
  "repeat-on-break",
  "required",
  "required-partitions",
  "ruby-align",
  "shape-inside",
  "snap-height",
  "snap-width",
  "src", // @font-face descriptor
  "template",
  "text-decoration-skip",
  "text-justify",
  "text-zoom",
  "unicode-range",
  "utilization",
  "wrap-flow",
];

export class AllShorthandValidator extends SimpleShorthandValidator {
  refreshPropList(): void {
    this.propList = this.validatorSet.getPropertiesForAll();
  }

  override validateList(list: Css.Val[]): number {
    this.error = true;
    return 0;
  }
}

export const shorthandValidators: {
  [key: string]: typeof ShorthandValidator;
} = {
  SIMPLE: SimpleShorthandValidator,
  INSETS: InsetsShorthandValidator,
  INSETS_SLASH: InsetsSlashShorthandValidator,
  COMMA: CommaShorthandValidator,
  FONT: FontShorthandValidator,
  TEXT_SPACING: TextSpacingShorthandValidator,
  ALL: AllShorthandValidator,
};

//---- validation grammar parser and public property validator
//------------------------

const propsBrowserDependent = ["initial-letter"];

/**
 * Object that validates simple and shorthand properties, breaking up shorthand
 * properties into corresponding simple ones, also stripping property prefixes.
 */
export class ValidatorSet {
  validators = new Map<string, PropertyValidator>();
  prefixes = new Map<string, Set<string>>();
  defaultValues = new Map<string, Css.Val>();
  namedValidators = new Map<string, ValidatingGroup>();
  systemFonts = new Map<string, ValueMap>();
  shorthands = new Map<string, ShorthandValidator>();
  layoutProps = new Map<string, Css.Val>();
  backgroundProps = new Map<string, Css.Val>();
  private browserShorthandStyle: CSSStyleDeclaration | null = null;
  private browserShorthandMisses = new Set<string>();
  private browserPropertyNamesForAll: string[] | null = null;
  private allPropertyNames: string[] | null = null;

  private invalidateAllPropertyNames(): void {
    this.allPropertyNames = null;
  }

  private getBrowserPropertyNamesForAll(): string[] | null {
    if (this.browserPropertyNamesForAll) {
      return this.browserPropertyNamesForAll;
    }
    if (
      typeof document === "undefined" ||
      typeof getComputedStyle !== "function"
    ) {
      return null;
    }
    const root = document.documentElement;
    if (!root) {
      return null;
    }
    const computedStyle = getComputedStyle(root);
    const names: string[] = [];
    for (let i = 0; i < computedStyle.length; i++) {
      const name = computedStyle.item(i);
      if (
        !name ||
        Css.isCustomPropName(name) ||
        propsExcludedFromAll.includes(name)
      ) {
        continue;
      }
      names.push(name);
    }
    this.browserPropertyNamesForAll = names;
    return this.browserPropertyNamesForAll;
  }

  getPropertiesForAll(): string[] {
    if (this.allPropertyNames) {
      return this.allPropertyNames;
    }
    const names = new Set<string>();
    for (const name of this.validators.keys()) {
      if (!propsExcludedFromAll.includes(name)) {
        names.add(name);
      }
    }
    const browserPropertyNames = this.getBrowserPropertyNamesForAll();
    if (browserPropertyNames) {
      for (const name of browserPropertyNames) {
        if (this.shorthands.has(name)) {
          continue;
        }
        names.add(name);
      }
    }
    const propList = Array.from(names);
    if (browserPropertyNames) {
      this.allPropertyNames = propList;
    }
    return propList;
  }

  private getBrowserShorthandStyle(): CSSStyleDeclaration | null {
    if (this.browserShorthandStyle !== null) {
      return this.browserShorthandStyle;
    }
    if (typeof document === "undefined") {
      return null;
    }
    this.browserShorthandStyle = document.createElement("div").style;
    return this.browserShorthandStyle;
  }

  expandBrowserShorthand(
    name: string,
    valueText: string,
  ): { propList: string[]; values: { [key: string]: string } } | null {
    const style = this.getBrowserShorthandStyle();
    if (!style) {
      return null;
    }
    style.cssText = "";
    style.setProperty(name, valueText);
    const propList = Array.from({ length: style.length }, (_, i) =>
      style.item(i),
    ).filter((prop): prop is string => !!prop);
    if (
      !propList.length ||
      (propList.length === 1 && propList[0] === name.toLowerCase())
    ) {
      return null;
    }
    // Use a detached CSSStyleDeclaration as a browser-native shorthand parser,
    // then feed the resulting longhand values back into Vivliostyle's cascade.
    const values: { [key: string]: string } = {};
    for (const prop of propList) {
      values[prop] = style.getPropertyValue(prop);
    }
    return { propList, values };
  }

  getShorthand(
    name: string,
    value?: Css.Val | string,
  ): ShorthandValidator | null {
    if (Css.isCustomPropName(name)) {
      return null;
    }
    // CSS property names are ASCII case-insensitive, and callers may pass a
    // name that kept the author's casing, so normalize before every lookup.
    name = name.toLowerCase();
    const shorthand = this.shorthands.get(name);
    if (shorthand) {
      if (
        shorthand instanceof AllShorthandValidator &&
        !this.allPropertyNames
      ) {
        shorthand.refreshPropList();
      }
      return shorthand;
    }
    if (this.validators.has(name)) {
      // Vivliostyle has its own validator for this property and looks it up by
      // this name after the cascade, so it must not be split into the browser's
      // longhands even when the browser treats it as a shorthand
      // (e.g. `background-position` → `background-position-x`/`-y`).
      return null;
    }
    if (this.browserShorthandMisses.has(name)) {
      return null;
    }
    if (value == null) {
      return null;
    }
    const expanded = this.expandBrowserShorthand(
      name,
      typeof value === "string" ? value : value.toString(),
    );
    if (!expanded) {
      if (
        typeof value === "string"
          ? !/\bvar\(/i.test(value)
          : !containsVar(value)
      ) {
        this.browserShorthandMisses.add(name);
      }
      return null;
    }
    const browserShorthand = new BrowserShorthandValidator(
      this,
      name,
      expanded.propList,
    );
    this.shorthands.set(name, browserShorthand);
    this.invalidateAllPropertyNames();
    return browserShorthand;
  }

  private addReplacement(
    val: ValidatingGroup,
    token: CssTokenizer.Token,
  ): ValidatingGroup {
    let cssval: Css.Val;
    if (token.type == TokenType.NUMERIC) {
      cssval = new Css.Numeric(token.num, token.text);
    } else if (token.type == TokenType.HASH) {
      cssval = new Css.HexColor(token.text);
    } else if (token.type == TokenType.IDENT) {
      cssval = Css.getName(token.text);
    } else {
      throw new Error("unexpected replacement");
    }
    if (val.isPrimitive()) {
      const validator = val.nodes[0].validator as PrimitiveValidator;
      const idents = validator.idents;
      for (const ident in idents) {
        idents[ident] = cssval;
      }
      return val;
    }
    throw new Error("unexpected replacement");
  }

  private newGroup(op: string, vals: ValidatingGroup[]): ValidatingGroup {
    const group = new ValidatingGroup();
    if (op == "||") {
      for (let i = 0; i < vals.length; i++) {
        const subgroup = new ValidatingGroup();
        subgroup.startClause(i);
        subgroup.addGroup(vals[i], Add.FOLLOW);
        subgroup.endClause(i);
        group.addGroup(subgroup, i == 0 ? Add.FOLLOW : Add.ALTERNATE);
      }
      const outer = new ValidatingGroup();
      outer.startSpecialGroup();
      outer.addGroup(group, Add.REPEATED);
      outer.endSpecialGroup();
      return outer;
    } else {
      let how: Add;
      switch (op) {
        case " ":
          how = Add.FOLLOW;
          break;
        case "|":
        case "||":
          how = Add.ALTERNATE;
          break;
        default:
          throw new Error("unexpected op");
      }
      for (let i = 0; i < vals.length; i++) {
        group.addGroup(vals[i], i == 0 ? Add.FOLLOW : how);
      }
      return group;
    }
  }

  private addCounts(
    val: ValidatingGroup,
    min: number,
    max: number,
  ): ValidatingGroup {
    const group = new ValidatingGroup();
    for (let i = 0; i < min; i++) {
      group.addGroup(val.clone(), Add.FOLLOW);
    }
    if (max == Number.POSITIVE_INFINITY) {
      group.addGroup(val, Add.REPEATED);
    } else {
      for (let i = min; i < max; i++) {
        group.addGroup(val.clone(), Add.OPTIONAL);
      }
    }
    return group;
  }

  private primitive(validator: PropertyValidator): ValidatingGroup {
    const group = new ValidatingGroup();
    group.addPrimitive(validator);
    return group;
  }

  private newFunc(
    fn: string | undefined,
    val: ValidatingGroup,
  ): ValidatingGroup {
    let validator: PropertyValidator;
    switch (fn) {
      case "COMMA":
        validator = new CommaListValidator(val);
        break;
      case "SPACE":
        validator = new SpaceListValidator(val);
        break;
      case "attr":
        validator = new AttrFuncValidator();
        break;
      default:
        validator = new FuncValidator(fn.toLowerCase(), val);
        break;
    }
    return this.primitive(validator);
  }

  initBuiltInValidators(): void {
    this.namedValidators.set(
      "COLOR",
      this.primitive(new PrimitiveValidator(ALLOW_COLOR, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set("ATTR", this.primitive(new AttrFuncValidator()));
    this.namedValidators.set(
      "IMAGE_FUNCTION",
      this.primitive(new PrimitiveValidator(ALLOW_IMAGE, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set(
      "POS_INT",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_INT, NO_IDENTS, NO_IDENTS),
      ),
    );
    this.namedValidators.set(
      "POS_NUM",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUM, NO_IDENTS, NO_IDENTS),
      ),
    );
    this.namedValidators.set(
      "POS_PERCENTAGE",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, PERCENTAGE_UNITS),
      ),
    );
    this.namedValidators.set(
      "NEGATIVE",
      this.primitive(
        new PrimitiveValidator(ALLOW_NEGATIVE, NO_IDENTS, NO_IDENTS),
      ),
    );
    this.namedValidators.set(
      "ZERO",
      this.primitive(new PrimitiveValidator(ALLOW_ZERO, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set(
      "ZERO_PERCENTAGE",
      this.primitive(
        new PrimitiveValidator(ALLOW_ZERO_PERCENT, NO_IDENTS, NO_IDENTS),
      ),
    );
    this.namedValidators.set(
      "POS_LENGTH",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, LENGTH_UNITS),
      ),
    );
    this.namedValidators.set(
      "POS_ANGLE",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, ANGLE_UNITS),
      ),
    );
    this.namedValidators.set(
      "POS_TIME",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, TIME_UNITS),
      ),
    );
    this.namedValidators.set(
      "FREQUENCY",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, FREQUENCY_UNITS),
      ),
    );
    this.namedValidators.set(
      "RESOLUTION",
      this.primitive(
        new PrimitiveValidator(ALLOW_POS_NUMERIC, NO_IDENTS, {
          dpi: Css.empty,
          dpcm: Css.empty,
          dppx: Css.empty,
        }),
      ),
    );
    this.namedValidators.set(
      "URI",
      this.primitive(new PrimitiveValidator(ALLOW_URL, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set(
      "URANGE",
      this.primitive(
        new PrimitiveValidator(ALLOW_URANGE, NO_IDENTS, NO_IDENTS),
      ),
    );
    this.namedValidators.set(
      "IDENT",
      this.primitive(new PrimitiveValidator(ALLOW_IDENT, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set(
      "STRING",
      this.primitive(new PrimitiveValidator(ALLOW_STR, NO_IDENTS, NO_IDENTS)),
    );
    this.namedValidators.set(
      "SLASH",
      this.primitive(new PrimitiveValidator(ALLOW_SLASH, NO_IDENTS, NO_IDENTS)),
    );
    const stdfont = { "font-family": Css.getName("sans-serif") };
    this.systemFonts.set("caption", stdfont);
    this.systemFonts.set("icon", stdfont);
    this.systemFonts.set("menu", stdfont);
    this.systemFonts.set("message-box", stdfont);
    this.systemFonts.set("small-caption", stdfont);
    this.systemFonts.set("status-bar", stdfont);
  }

  private isBuiltIn(name: string): boolean {
    return !!name.match(/^[A-Z_0-9]+$/);
  }

  private readNameAndPrefixes(
    tok: CssTokenizer.Tokenizer,
    section: number,
  ): string | null {
    let token = tok.token();
    if (token.type == TokenType.EOF) {
      // Finished normally
      return null;
    }
    const rulePrefixes = new Set([""]);
    if (token.type == TokenType.O_BRK) {
      do {
        tok.consume();
        token = tok.token();
        if (token.type != TokenType.IDENT) {
          throw new Error("Prefix name expected");
        }
        rulePrefixes.add(token.text);
        tok.consume();
        token = tok.token();
      } while (token.type == TokenType.COMMA);
      if (token.type != TokenType.C_BRK) {
        throw new Error("']' expected");
      }
      tok.consume();
      token = tok.token();
    }
    if (token.type != TokenType.IDENT) {
      throw new Error("Property name expected");
    }
    if (section == 2 ? token.text == "SHORTHANDS" : token.text == "DEFAULTS") {
      tok.consume();
      return null;
    }
    const name = token.text;
    tok.consume();
    if (section != 2) {
      if (tok.token().type != TokenType.EQ) {
        throw new Error("'=' expected");
      }
      if (!this.isBuiltIn(name)) {
        this.prefixes.set(name, rulePrefixes);
      }
    } else {
      if (tok.token().type != TokenType.COLON) {
        throw new Error("':' expected");
      }
    }
    return name;
  }

  private parseValidators(tok: CssTokenizer.Tokenizer): void {
    while (true) {
      const ruleName = this.readNameAndPrefixes(tok, 1);
      if (!ruleName) {
        return;
      }
      let vals: ValidatingGroup[] = [];
      const stack: {
        vals: ValidatingGroup[];
        op: string;
        b: string;
        fn?: string;
      }[] = [];
      let op = "";
      let val: ValidatingGroup;
      let expectval = true;
      const reduce = (): ValidatingGroup => {
        if (vals.length == 0) {
          throw new Error("No values");
        }
        if (vals.length == 1) {
          return vals[0];
        }
        return this.newGroup(op, vals);
      };
      const setop = (currop: string): void => {
        if (expectval) {
          throw new Error(`'${currop}': unexpected`);
        }
        if (op && op != currop) {
          throw new Error(`mixed operators: '${currop}' and '${op}'`);
        }
        op = currop;
        expectval = true;
      };
      let result: ValidatingGroup | null = null;
      while (!result) {
        tok.consume();
        let token = tok.token();
        switch (token.type) {
          case TokenType.IDENT:
            if (!expectval) {
              setop(" ");
            }
            if (this.isBuiltIn(token.text)) {
              const builtIn = this.namedValidators.get(token.text);
              if (!builtIn) {
                throw new Error(`'${token.text}' unexpected`);
              }
              vals.push(builtIn.clone());
            } else {
              const idents: ValueMap = {};
              idents[token.text.toLowerCase()] = Css.getName(token.text);
              vals.push(
                this.primitive(new PrimitiveValidator(0, idents, NO_IDENTS)),
              );
            }
            expectval = false;
            break;
          case TokenType.INT: {
            const idents: ValueMap = {};
            idents[`${token.num}`] = new Css.Int(token.num);
            vals.push(
              this.primitive(new PrimitiveValidator(0, idents, NO_IDENTS)),
            );
            expectval = false;
            break;
          }
          case TokenType.BAR:
            setop("|");
            break;
          case TokenType.BAR_BAR:
            setop("||");
            break;
          case TokenType.O_BRK:
            if (!expectval) {
              setop(" ");
            }
            stack.push({ vals, op, b: "[" });
            op = "";
            vals = [];
            expectval = true;
            break;
          case TokenType.FUNC:
            if (!expectval) {
              setop(" ");
            }
            stack.push({ vals, op, b: "(", fn: token.text });
            op = "";
            vals = [];
            expectval = true;
            break;
          case TokenType.C_BRK: {
            val = reduce();
            const open = stack.pop();
            if (open.b != "[") {
              throw new Error("']' unexpected");
            }
            vals = open.vals;
            vals.push(val);
            op = open.op;
            expectval = false;
            break;
          }
          case TokenType.C_PAR: {
            val = reduce();
            const open = stack.pop();
            if (open.b != "(") {
              throw new Error("')' unexpected");
            }
            vals = open.vals;
            vals.push(this.newFunc(open.fn, val));
            op = open.op;
            expectval = false;
            break;
          }
          case TokenType.COLON:
            if (expectval) {
              throw new Error("':' unexpected");
            }
            tok.consume();
            vals.push(this.addReplacement(vals.pop(), tok.token()));
            break;
          case TokenType.QMARK:
            if (expectval) {
              throw new Error("'?' unexpected");
            }
            vals.push(this.addCounts(vals.pop(), 0, 1));
            break;
          case TokenType.STAR:
            if (expectval) {
              throw new Error("'*' unexpected");
            }
            vals.push(this.addCounts(vals.pop(), 0, Number.POSITIVE_INFINITY));
            break;
          case TokenType.PLUS:
            if (expectval) {
              throw new Error("'+' unexpected");
            }
            vals.push(this.addCounts(vals.pop(), 1, Number.POSITIVE_INFINITY));
            break;
          case TokenType.O_BRC: {
            tok.consume();
            token = tok.token();
            if (token.type != TokenType.INT) {
              throw new Error("<int> expected");
            }
            const min = token.num;
            let max = min;
            tok.consume();
            token = tok.token();
            if (token.type == TokenType.COMMA) {
              tok.consume();
              token = tok.token();
              if (token.type != TokenType.INT) {
                throw new Error("<int> expected");
              }
              max = token.num;
              tok.consume();
              token = tok.token();
            }
            if (token.type != TokenType.C_BRC) {
              throw new Error("'}' expected");
            }
            vals.push(this.addCounts(vals.pop(), min, max));
            break;
          }
          case TokenType.SEMICOL:
            result = reduce();
            if (stack.length > 0) {
              throw new Error(`unclosed '${stack.pop().b}'`);
            }
            break;
          default:
            throw new Error("unexpected token");
        }
      }
      tok.consume();
      if (this.isBuiltIn(ruleName)) {
        this.namedValidators.set(ruleName, result);
      } else {
        if (result.isSimple()) {
          this.validators.set(ruleName, result.nodes[0].validator);
        } else {
          this.validators.set(ruleName, new SpaceListValidator(result));
        }
      }
    }
  }

  private parseDefaults(tok: CssTokenizer.Tokenizer): void {
    while (true) {
      const propName = this.readNameAndPrefixes(tok, 2);
      if (!propName) {
        return;
      }
      const vals: Css.Val[] = [];
      while (true) {
        tok.consume();
        const token = tok.token();
        if (token.type == TokenType.SEMICOL) {
          tok.consume();
          break;
        }
        switch (token.type) {
          case TokenType.IDENT:
            vals.push(Css.getName(token.text));
            break;
          case TokenType.NUM:
            vals.push(new Css.Num(token.num));
            break;
          case TokenType.INT:
            vals.push(new Css.Int(token.num));
            break;
          case TokenType.NUMERIC:
            vals.push(new Css.Numeric(token.num, token.text));
            break;
          default:
            throw new Error("unexpected token");
        }
      }
      this.defaultValues.set(
        propName,
        vals.length > 1 ? new Css.SpaceList(vals) : vals[0],
      );
    }
  }

  private parseShorthands(tok: CssTokenizer.Tokenizer): void {
    while (true) {
      const ruleName = this.readNameAndPrefixes(tok, 3);
      if (!ruleName) {
        return;
      }
      let token = tok.nthToken(1);
      let validatorClass: typeof ShorthandValidator;
      if (token.type == TokenType.IDENT && shorthandValidators[token.text]) {
        validatorClass = shorthandValidators[token.text];
        tok.consume();
      } else {
        validatorClass = SimpleShorthandValidator;
      }
      let result = false;
      let syntax: ShorthandSyntaxNode[] = [];
      let slash = false;
      const stack: { slash: boolean; syntax: ShorthandSyntaxNode[] }[] = [];
      const propList: string[] = [];
      while (!result) {
        tok.consume();
        token = tok.token();
        switch (token.type) {
          case TokenType.IDENT:
            if (this.validators.has(token.text)) {
              syntax.push(new ShorthandSyntaxProperty(this, token.text));
              // `font-variant_css2` and `font-stretch_css3` are not real properties
              if (!token.text.includes("_")) {
                propList.push(token.text);
              }
            } else if (
              this.shorthands.get(token.text) instanceof
              InsetsShorthandValidator
            ) {
              const insetShorthand = this.shorthands.get(
                token.text,
              ) as InsetsShorthandValidator;
              syntax.push(insetShorthand.createSyntaxNode());
              propList.push(...insetShorthand.propList);
            } else {
              throw new Error(
                `'${token.text}' is neither a simple property nor an inset shorthand`,
              );
            }
            break;
          case TokenType.SLASH:
            if (syntax.length > 0 || slash) {
              throw new Error("unexpected slash");
            }
            slash = true;
            break;
          case TokenType.O_BRK:
            stack.push({ slash, syntax });
            syntax = [];
            slash = false;
            break;
          case TokenType.C_BRK: {
            const compound = new ShorthandSyntaxCompound(syntax, slash);
            const item = stack.pop();
            syntax = item.syntax;
            slash = item.slash;
            syntax.push(compound);
            break;
          }
          case TokenType.SEMICOL:
            result = true;
            tok.consume();
            break;
          default:
            throw new Error("unexpected token");
        }
      }
      const shorthandValidator = validatorClass.create(this, syntax, propList);
      this.shorthands.set(ruleName, shorthandValidator);
      this.invalidateAllPropertyNames();
    }
  }

  parse(text: string): void {
    // Not as robust as CSS parser.
    const tok = new CssTokenizer.Tokenizer(text, null);
    this.parseValidators(tok);
    this.parseDefaults(tok);
    this.parseShorthands(tok);
    this.backgroundProps = this.makePropSet(["background"]);
    this.layoutProps = this.makePropSet([
      "margin",
      "border",
      "padding",
      "columns",
      "column-gap",
      "column-rule",
      "column-fill",
    ]);
  }

  makePropSet(propList: string[]): Map<string, Css.Val> {
    const map = new Map<string, Css.Val>();
    for (const prop of propList) {
      const shorthand = this.shorthands.get(prop);
      const list = shorthand ? shorthand.propList : [prop];
      for (const pname of list) {
        map.set(pname, this.defaultValues.get(pname) ?? Css.ident.initial);
      }
    }
    return map;
  }

  validatePropertyAndHandleShorthand(
    name: string,
    value: Css.Val,
    important: boolean,
    scope: Exprs.LexicalScope,
    receiver: PropertyReceiver,
  ): void {
    const ruleType = (receiver as PropertyReceiver & { ruleType?: string })
      .ruleType;
    if (
      Css.isCustomPropName(name) ||
      // Check if it is a `@font-face` descriptor (Issue #1307)
      ruleType === "font-face"
    ) {
      receiver.simpleProperty(name, value, important);
      return;
    }
    if (ruleType === "counter-style") {
      if (CounterStyle.validateDescriptorValue(name, value)) {
        receiver.simpleProperty(name, value, important);
      } else {
        receiver.invalidPropertyValue(name, value);
      }
      return;
    }
    let prefix = "";
    const origName = name;
    name = name.toLowerCase();
    const r = name.match(/^-([a-z]+)-([-a-z0-9]+)$/);
    if (r) {
      prefix = r[1];
      name = r[2];
    }
    const shorthandName = prefix ? origName : name;
    if (containsVar(value)) {
      // Register browser-supported shorthands before var() resolution so the
      // later cascade pass can still expand mixed shorthand/longhand usage.
      this.getShorthand(shorthandName, value);
      // Store the declaration under the name the rest of the engine looks up.
      // The non-var path below stores the lowercased name for properties
      // Vivliostyle validates itself, and consumers such as passPostProperties
      // and transferPropsToRoot() look them up that way.
      receiver.simpleProperty(shorthandName, value, important);
      return;
    }
    const px = this.prefixes.get(name);
    // The rollback keywords (`revert`, `revert-layer` and `revert-rule`) are
    // resolved by Vivliostyle's own cascade rather than handed to the browser,
    // so whether this browser build happens to support the keyword must not
    // decide whether the declaration is valid, nor how a shorthand expands.
    // Probe the property with `unset` instead, which every browser accepts
    // wherever a CSS-wide keyword is allowed.
    const probeText = Css.isRollbackValue(value) ? "unset" : value.toString();
    if (!px || !px.has(prefix)) {
      if (CSS.supports(origName, probeText)) {
        const shorthand = this.getShorthand(shorthandName, probeText)?.clone(
          scope,
        );
        if (shorthand) {
          if (Css.isDefaultingValue(value)) {
            shorthand.propagateDefaultingValue(value, important, receiver);
          } else {
            value.visit(shorthand);
            if (!shorthand.finish(important, receiver)) {
              receiver.invalidPropertyValue(origName, value);
            }
          }
        } else {
          // Browser supports this property
          receiver.simpleProperty(origName, value, important);
        }
      } else if (prefix && !Base.knownPrefixes.includes(`-${prefix}-`)) {
        // Ignore properties with unknown prefix to avoid unnecessary warnings
      } else {
        receiver.unknownProperty(origName, value);
      }
      return;
    } else if (propsBrowserDependent.includes(name)) {
      // For properties whose support depends on browser, check via CSS.supports
      if (
        !Array.from(px).some((p) =>
          Base.checkIfPropertySupported(p ? `-${p}-` : "", name),
        )
      ) {
        receiver.unknownProperty(origName, value);
        return;
      }
    }
    const validator = this.validators.get(name);
    if (validator) {
      const rvalue =
        Css.isDefaultingValue(value) || value.isExpr()
          ? value
          : value.visit(validator);
      if (rvalue) {
        receiver.simpleProperty(name, rvalue, important);
      } else if (!prefix && CSS.supports(name, value.toString())) {
        // Browser supports this property value
        receiver.simpleProperty(name, value, important);
      } else {
        receiver.invalidPropertyValue(origName, value);
      }
    } else {
      const shorthand = this.getShorthand(name, value)?.clone(scope);
      if (!shorthand) {
        receiver.unknownProperty(origName, value);
        return;
      }
      if (Css.isDefaultingValue(value)) {
        shorthand.propagateDefaultingValue(value, important, receiver);
      } else {
        value.visit(shorthand);
        if (!shorthand.finish(important, receiver)) {
          receiver.invalidPropertyValue(origName, value);
        }
      }
    }
  }
}

export function baseValidatorSet(): ValidatorSet {
  const validatorSet = new ValidatorSet();
  validatorSet.initBuiltInValidators();
  validatorSet.parse(ValidationTxt);
  return validatorSet;
}

class VarCheckVisitor extends Css.Visitor {
  varFound = false;

  visitFunc(func: Css.Func): Css.Val | null {
    if (func.name === "var") {
      this.varFound = true;
    } else if (!this.varFound) {
      this.visitValues(func.values);
    }
    return null;
  }
}

export function containsVar(val: Css.Val): boolean {
  const varCheckVisitor = new VarCheckVisitor();
  val.visit(varCheckVisitor);
  return varCheckVisitor.varFound;
}
