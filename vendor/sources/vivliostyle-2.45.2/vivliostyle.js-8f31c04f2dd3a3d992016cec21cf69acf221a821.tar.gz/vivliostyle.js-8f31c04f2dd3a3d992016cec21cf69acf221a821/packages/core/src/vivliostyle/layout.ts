/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Layout - Fills a column with styled content.
 * This file does not communicate with the styling system directly.
 * Instead it goes through the layout interface that gives it one view tree
 * node at a time.
 */
import * as LayoutRetryers from "./layout-retryers";
import * as Asserts from "./asserts";
import * as Shared from "./shared";
import * as Sizing from "./sizing";
import * as Break from "./break";
import * as Logging from "./logging";
import * as Diff from "./diff";
import * as Base from "./base";
import * as BreakPosition from "./break-position";
import * as CssCascade from "./css-cascade";
import * as Css from "./css";
import * as GeometryUtil from "./geometry-util";
import * as LayoutHelper from "./layout-helper";
import * as LayoutProcessor from "./layout-processor";
import * as PageFloats from "./page-floats";
import * as Plugin from "./plugin";
import * as Matchers from "./matchers";
import * as PseudoElement from "./pseudo-element";
import * as RangeClientRects from "./range-client-rects";
import * as SemanticFootnote from "./semantic-footnote";
import * as Task from "./task";
import * as Vgen from "./vgen";
import * as VtreeImpl from "./vtree";
import { Footnote } from "./footnotes";
import {
  FragmentLayoutConstraintType,
  Layout,
  RepetitiveElement,
  Selectors,
  Table,
  Vtree,
} from "./types";

export const registerFragmentIndex =
  Matchers.NthFragmentMatcher.registerFragmentIndex;
export const clearFragmentIndices =
  Matchers.NthFragmentMatcher.clearFragmentIndices;

export class AfterIfContinues implements Selectors.AfterIfContinues {
  constructor(
    public readonly sourceNode: Element,
    public readonly styler: PseudoElement.PseudoelementStyler,
  ) {}

  createElement(
    column: Layout.Column,
    parentNodeContext: Vtree.ElementNodeContext,
  ): Task.Result<Element> {
    const doc = parentNodeContext.viewNode.ownerDocument;
    const viewRoot = doc.createElement("div");
    const pseudoColumn = new PseudoColumn(column, viewRoot, parentNodeContext);
    const initialPageBreakType = pseudoColumn.getColumn().pageBreakType;
    pseudoColumn.getColumn().pageBreakType = null;
    return pseudoColumn
      .layout(this.createNodePositionForPseudoElement(), true)
      .thenAsync(() => {
        this.styler.contentProcessed["after-if-continues"] = false;
        pseudoColumn.getColumn().pageBreakType = initialPageBreakType;
        const pseudoElement = viewRoot.firstChild as Element;
        Base.setCSSProperty(pseudoElement, "display", "block");
        return Task.newResult(pseudoElement);
      });
  }

  private createNodePositionForPseudoElement(): Vtree.ChunkPosition {
    const sourceNode = PseudoElement.document.createElementNS(
      Base.NS.XHTML,
      "div",
    );
    PseudoElement.setPseudoName(sourceNode, "after-if-continues");
    const shadowContext = this.createShadowContext(sourceNode);
    const step = {
      node: sourceNode,
      shadowType: shadowContext.type,
      shadowContext,
      nodeShadow: null,
      shadowSibling: null,
    };
    const nodePosition = {
      steps: [step],
      offsetInNode: 0,
      after: false,
      preprocessedTextContent: null,
    };
    return new VtreeImpl.ChunkPosition(nodePosition as any);
  }

  private createShadowContext(root: Element): Vtree.ShadowContext {
    return new VtreeImpl.ShadowContext(
      this.sourceNode,
      root,
      null,
      null,
      null,
      Vtree.ShadowType.ROOTED,
      this.styler,
    );
  }
}

export class AfterIfContinuesLayoutConstraint
  implements Selectors.AfterIfContinuesLayoutConstraint
{
  flagmentLayoutConstraintType: FragmentLayoutConstraintType =
    "AfterIfContinue";

  constructor(
    public nodeContext: Vtree.ElementNodeContext,
    public afterIfContinues: Selectors.AfterIfContinues,
    public pseudoElementHeight: number,
  ) {}

  /** @override */
  allowLayout(
    nodeContext: Vtree.NodeContext,
    overflownNodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): boolean {
    if (
      (overflownNodeContext && !nodeContext) ||
      (nodeContext && nodeContext.overflow)
    ) {
      return false;
    } else {
      return true;
    }
  }

  /** @override */
  nextCandidate(nodeContext: Vtree.NodeContext): boolean {
    return false;
  }

  /** @override */
  postLayout(
    allowed: boolean,
    positionAfter: Vtree.NodeContext,
    initialPosition: Vtree.NodeContext,
    column: Layout.Column,
  ) {}

  /** @override */
  finishBreak(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<boolean> {
    if (!this.getRepetitiveElements().affectTo(nodeContext)) {
      return Task.newResult(true);
    }
    return this.afterIfContinues
      .createElement(column, this.nodeContext)
      .thenAsync((element) => {
        this.nodeContext.viewNode.appendChild(element);
        return Task.newResult(true);
      });
  }

  getRepetitiveElements() {
    return new AfterIfContinuesElementsOffset(
      this.nodeContext,
      this.pseudoElementHeight,
    );
  }

  /** @override */
  equalsTo(constraint: Layout.FragmentLayoutConstraint): boolean {
    if (!(constraint instanceof AfterIfContinuesLayoutConstraint)) {
      return false;
    }
    return (
      this.afterIfContinues ==
      (constraint as AfterIfContinuesLayoutConstraint).afterIfContinues
    );
  }

  /** @override */
  getPriorityOfFinishBreak(): number {
    return 9;
  }
}

export class AfterIfContinuesElementsOffset
  implements Selectors.AfterIfContinuesElementsOffset
{
  constructor(
    public nodeContext,
    public pseudoElementHeight,
  ) {}

  /** @override */
  calculateOffset(nodeContext: Vtree.NodeContext): number {
    if (!this.affectTo(nodeContext)) {
      return 0;
    }
    return this.pseudoElementHeight;
  }

  /** @override */
  calculateMinimumOffset(nodeContext: Vtree.NodeContext): number {
    return this.calculateOffset(nodeContext);
  }

  affectTo(nodeContext: Vtree.NodeContext): boolean {
    if (!nodeContext) {
      return false;
    }
    const sourceNode = nodeContext.shadowContext
      ? nodeContext.shadowContext.owner
      : nodeContext.sourceNode;
    if (sourceNode === this.nodeContext.sourceNode) {
      return !!nodeContext.after;
    }
    for (let n = sourceNode.parentNode; n; n = n.parentNode) {
      if (n === this.nodeContext.sourceNode) {
        return true;
      }
    }
    return false;
  }
}

function processAfterIfContinuesOfNodeContext(
  nodeContext: Vtree.NodeContext | null,
  column: Layout.Column,
): Task.Result<Vtree.NodeContext | null> {
  const host =
    nodeContext && VtreeImpl.asAfterIfContinuesNodeContext(nodeContext);
  if (!host || host.after || column.asFloatNodeContext(host)) {
    return Task.newResult(nodeContext);
  }
  const afterIfContinues = host.afterIfContinues;
  const rendered = host;
  return afterIfContinues
    .createElement(column, rendered)
    .thenAsync((pseudoElement) => {
      const pseudoElementHeight = calculatePseudoElementHeight(
        rendered,
        column,
        pseudoElement,
      );
      column.fragmentLayoutConstraints.push(
        new AfterIfContinuesLayoutConstraint(
          rendered,
          afterIfContinues,
          pseudoElementHeight,
        ),
      );
      return Task.newResult(nodeContext);
    });
}

export function processAfterIfContinues(
  result: Task.Result<Vtree.NodeContext | null>,
  column: Layout.Column,
): Task.Result<Vtree.NodeContext | null> {
  return result.thenAsync((nodeContext) =>
    processAfterIfContinuesOfNodeContext(nodeContext, column),
  );
}

export function processAfterIfContinuesOfAncestors(
  nodeContext: Vtree.NodeContext,
  column: Layout.Column,
): Task.Result<boolean> {
  const frame: Task.Frame<boolean> = Task.newFrame(
    "processAfterIfContinuesOfAncestors",
  );
  let current: Vtree.NodeContext | null = nodeContext;
  frame
    .loop(() => {
      if (current !== null) {
        const result = processAfterIfContinuesOfNodeContext(current, column);
        current = current.parent;
        return result.thenReturn(true);
      } else {
        return Task.newResult(false);
      }
    })
    .then(() => {
      frame.finish(true);
    });
  return frame.result();
}

export function calculatePseudoElementHeight(
  nodeContext: Vtree.NodeContext,
  column: Layout.Column,
  pseudoElement: Element,
): number {
  const parentNode = nodeContext.viewNode as Element;
  parentNode.appendChild(pseudoElement);
  const height = LayoutHelper.getElementHeight(
    pseudoElement,
    column,
    nodeContext.vertical,
  );
  parentNode.removeChild(pseudoElement);
  return height;
}

/**
 * Represents a constraint on layout
 */
export type LayoutConstraint = Layout.LayoutConstraint;

/**
 * Represents a constraint that allows layout if all the constraints it contains
 * allow layout.
 */
export class AllLayoutConstraint implements LayoutConstraint {
  constructor(public readonly constraints: LayoutConstraint[]) {}

  /** @override */
  allowLayout(nodeContext: Vtree.NodeContext): boolean {
    return this.constraints.every((c) => c.allowLayout(nodeContext));
  }

  allowLayoutAfterPageBreak(nodeContext: Vtree.NodeContext): boolean {
    // Hooks may update retained layout state (the counter constraint does).
    // Reject on ordinary constraints first so a later failure cannot leave a
    // one-shot page-break allowance consumed by an otherwise rejected node.
    for (const constraint of this.constraints) {
      if (
        !constraint.allowLayoutAfterPageBreak &&
        !constraint.allowLayout(nodeContext)
      ) {
        return false;
      }
    }
    for (const constraint of this.constraints) {
      if (
        constraint.allowLayoutAfterPageBreak &&
        !constraint.allowLayoutAfterPageBreak(nodeContext)
      ) {
        return false;
      }
    }
    return true;
  }
}

/**
 * Represents constraints on laying out fragments
 */
export type FragmentLayoutConstraint = Layout.FragmentLayoutConstraint;

export type BreakPositionAndNodeContext = Layout.BreakPositionAndNodeContext;

/**
 * Potential breaking position inside CSS box (between lines).
 * @param checkPoints array of breaking points for breakable block
 */
export class BoxBreakPosition
  extends BreakPosition.AbstractBreakPosition
  implements Layout.BoxBreakPosition
{
  private alreadyEvaluated: boolean = false;
  breakNodeContext: Vtree.NodeContext | null = null;

  constructor(
    public readonly checkPoints: Vtree.RenderedNodeContext[],
    public readonly penalty: number,
  ) {
    super();
  }

  override findAcceptableBreak(
    column: Layout.Column,
    penalty: number,
  ): Vtree.NodeContext | null {
    if (penalty < this.getMinBreakPenalty()) {
      return null;
    }
    if (!this.alreadyEvaluated) {
      this.breakNodeContext = column.findBoxBreakPosition(this, penalty > 0);
      this.alreadyEvaluated =
        !!this.breakNodeContext || penalty > 0 || !!column.pseudoParent;
    }
    return this.breakNodeContext;
  }

  override getMinBreakPenalty(): number {
    return this.penalty;
  }

  override getNodeContext(): Vtree.NodeContext | null {
    return this.alreadyEvaluated
      ? this.breakNodeContext
      : this.checkPoints.at(-1);
  }
}

export function validateCheckPoints(
  checkPoints: Vtree.RenderedNodeContext[],
): void {
  for (let i = 1; i < checkPoints.length; i++) {
    const cp0 = checkPoints[i - 1];
    const cp1 = checkPoints[i];
    if (cp0 === cp1) {
      Logging.logger.warn("validateCheckPoints: duplicate entry");
    } else if (cp0.boxOffset >= cp1.boxOffset) {
      Logging.logger.warn("validateCheckPoints: incorrect boxOffset");
    } else if (cp0.sourceNode == cp1.sourceNode) {
      if (cp1.after) {
        if (cp0.after) {
          Logging.logger.warn("validateCheckPoints: duplicate after points");
        }
      } else {
        if (!cp0.after) {
          if (
            cp1.boxOffset - cp0.boxOffset !=
            cp1.offsetInNode - cp0.offsetInNode
          ) {
            Logging.logger.warn(
              "validateCheckPoints: boxOffset inconsistent with offsetInNode",
            );
          }
        }
      }
    }
  }
}

export class Column extends VtreeImpl.Container implements Layout.Column {
  last: Node | null;
  viewDocument: Document;
  // Issue #1842: true only for columns reached after automatic column overflow.
  isNonFirstColumn: boolean = false;
  isFloat: boolean = false;
  isFootnote: boolean = false;
  startEdge: number = 0;
  endEdge: number = 0;
  beforeEdge: number = 0;
  afterEdge: number = 0;
  footnoteEdge: number = 0;
  chunkPositions: Vtree.ChunkPosition[] = [];
  bands: GeometryUtil.Band[];
  overflown: boolean = false;
  breakPositions: BreakPosition.BreakPosition[] = [];
  pageBreakType: string | null = null;
  forceNonfitting: boolean = true;
  leftFloatEdge: number = 0; // bottom of the bottommost left float
  rightFloatEdge: number = 0; // bottom of the bottommost right float
  bottommostFloatTop: number = 0; // Top of the bottommost float
  stopAtOverflow: boolean = true;
  lastAfterPosition: Vtree.NodePosition | null = null;
  fragmentLayoutConstraints: FragmentLayoutConstraint[] = [];
  pseudoParent: Column | null = null;
  nodeContextOverflowingDueToRepetitiveElements: Vtree.NodeContext | null =
    null;
  blockDistanceToBlockEndFloats: number = NaN;
  lastLineStride: number = 0;
  breakAtTheEdgeBeforeFloat: string | null = null;
  private lineFootnoteOverflowEdge: number | null = null;

  readonly pageFloatLayoutContext: PageFloats.AttachedPageFloatLayoutContext;

  constructor(
    element: HTMLElement,
    public layoutContext: Vtree.LayoutContext,
    public clientLayout: Vtree.ClientLayout,
    public readonly layoutConstraint: LayoutConstraint,
    pageFloatLayoutContext: PageFloats.UnattachedPageFloatLayoutContext,
    geometry: Vtree.ContainerGeometry,
    innerShape: GeometryUtil.Shape | null,
    exclusions: GeometryUtil.Shape[],
    public flowRootFormattingContext: Vtree.FormattingContext,
  ) {
    super(element);

    // Mark this column (including subclasses such as PageFloatArea) as a root column for layout processing
    LayoutHelper.setAsRootColumn(this);

    this.last = element.lastChild;
    this.viewDocument = element.ownerDocument;
    this.pageFloatLayoutContext = pageFloatLayoutContext.withContainer(this);

    VtreeImpl.copyGeometry(geometry, this);
    this.innerShape = innerShape;
    this.exclusions = exclusions;
    // measure() writes the width/height CSS; a freshly created element's left/top
    // CSS is written by the caller before construction. An adopted container's
    // element keeps its existing position.
    this.bands = this.measure();
    this.createFloats();
  }

  getTopEdge(): number {
    return this.vertical
      ? this.rtl
        ? this.endEdge
        : this.startEdge
      : this.beforeEdge;
  }

  getBottomEdge(): number {
    return this.vertical
      ? this.rtl
        ? this.startEdge
        : this.endEdge
      : this.afterEdge;
  }

  getLeftEdge(): number {
    return this.vertical
      ? this.afterEdge
      : this.rtl
        ? this.endEdge
        : this.startEdge;
  }

  getRightEdge(): number {
    return this.vertical
      ? this.beforeEdge
      : this.rtl
        ? this.startEdge
        : this.endEdge;
  }

  asFloatNodeContext(
    nodeContext: Vtree.NodeContext,
  ): Vtree.FloatNodeContext | null {
    const elementContext = VtreeImpl.asElementNodeContext(nodeContext);
    return elementContext &&
      !!elementContext.floatSide &&
      (!this.isFloat || !!elementContext.parent)
      ? (elementContext as Vtree.FloatNodeContext)
      : null;
  }

  stopByOverflow(nodeContext: Vtree.NodeContext): boolean {
    return this.stopAtOverflow && !!nodeContext && nodeContext.overflow;
  }

  private almostEquals(
    a: number,
    b: number,
    precision = this.clientLayout.pixelRatio === 0
      ? 0.5
      : 1.5 / (this.clientLayout.pixelRatio || 1),
  ): boolean {
    return Math.abs(a - b) < precision;
  }

  private getFloatLayoutUnit(): number {
    // Disable artificial float/clear compensation when pixelRatio=0 so
    // rendering follows native browser float precision without artificial
    // offsets. This is used for WPT reftests and also applies to environments
    // where pixelRatio emulation is unavailable. (Issue #1913)
    if (this.clientLayout.pixelRatio === 0) {
      return 0;
    }
    return 1 / (this.clientLayout.pixelRatio || 1);
  }

  private getFloatLayoutTolerance(floatUnit: number): number {
    // Even when compensation is disabled by pixelRatio=0, keep a 1px
    // tolerance so tiny DOM measurement deltas do not create a clearance
    // spacer via Math.max(1, ...). (Issue #1913)
    return floatUnit || 1;
  }

  isOverflown(edge: number): boolean {
    // Prevent incorrect overflow detection due to precision issues,
    // especially when the footnote edge is touching the edge of a
    // multi-column box, getBoundingClientRect() of its child element
    // spanning multiple columns may return a value that is slightly
    // (about 1.2/pixelRatio) beyond the parent multi-column box edge,
    // which may cause incorrect overflow detection and thus layout failure.
    // (Issue #1460)
    // Use a wider tolerance (1.5px) even when pixelRatio=0, because
    // multi-column measurement errors in exclusion shapes can make
    // footnoteEdge ~1.2px too small while the default 0.5px precision
    // (needed for float band snapping, Issue #1917) is too tight.
    const precision = 1.5 / (this.clientLayout.pixelRatio || 1);
    if (this.almostEquals(edge, this.footnoteEdge, precision)) {
      return false;
    }

    if (this.vertical) {
      return edge < this.footnoteEdge;
    } else {
      return edge > this.footnoteEdge;
    }
  }

  getExclusions(): GeometryUtil.Shape[] {
    const pageFloatExclusions =
      this.pageFloatLayoutContext.getFloatFragmentExclusions();
    return this.exclusions.concat(pageFloatExclusions);
  }

  openAllViews(position: Vtree.NodePosition): Task.Result<Vtree.NodeContext> {
    const frame: Task.Frame<Vtree.NodeContext> = Task.newFrame("openAllViews");
    const steps = position.steps;
    this.layoutContext.setViewRoot(this.element, this.isFootnote);
    let stepIndex = steps.length - 1;
    let nodeContext: Vtree.NodeContext | null = null;
    frame
      .loop(() => {
        while (stepIndex >= 0) {
          const prevContext = nodeContext;
          nodeContext = prevContext
            ? VtreeImpl.makeNodeContextFromNodePositionStep(
                steps[stepIndex],
                prevContext,
              )
            : VtreeImpl.makeRootNodeContextFromNodePositionStep(
                VtreeImpl.rootStepOfNodePosition(position),
                this.flowRootFormattingContext,
              );
          if (stepIndex == 0) {
            nodeContext.offsetInNode =
              this.calculateOffsetInNodeForNodeContext(position);
            nodeContext.after = position.after;
            nodeContext.preprocessedTextContent =
              position.preprocessedTextContent;
            if (nodeContext.after) {
              break;
            }
          }
          const r = this.layoutContext.setCurrent(
            nodeContext,
            stepIndex == 0 && nodeContext.offsetInNode == 0,
          );
          stepIndex--;
          if (r.isPending()) {
            return r;
          }
        }
        return Task.newResult(false);
      })
      .then(() => {
        Asserts.assert(nodeContext);
        frame.finish(nodeContext);
      });
    return frame.result();
  }

  calculateOffsetInNodeForNodeContext(position: Vtree.NodePosition): number {
    return position.preprocessedTextContent
      ? Diff.resolveNewIndex(
          position.preprocessedTextContent,
          position.offsetInNode,
        )
      : position.offsetInNode;
  }

  /**
   * @param count first-XXX nesting identifier
   */
  maybePeelOff(
    position: Vtree.NodeContext,
    count: number,
  ): Task.Result<Vtree.NodeContext> {
    if (
      position.firstPseudo &&
      position.inline &&
      !position.after &&
      position.firstPseudo.count == 0
    ) {
      // first char
      const textPosition = VtreeImpl.asTextNodeContext(position);
      if (textPosition) {
        const viewNode = textPosition.viewNode;
        const text = viewNode.textContent;
        const r = text.match(Base.firstLetterPattern);
        let firstLetterLength = r ? r[0].length : 0;
        if (
          !r &&
          position.sourceNode?.nodeType === 3 &&
          position.sourceNode.nextSibling?.nodeType === 3 &&
          text === position.sourceNode.textContent
        ) {
          // The text '“Foo' may be split to '“' and 'Foo'
          const text2 = text + position.sourceNode.nextSibling.textContent;
          const r2 = text2.match(Base.firstLetterPattern);
          if (r2) {
            const firstLetterText = r2[0];
            firstLetterLength = firstLetterText.length;
            position.sourceNode.textContent = firstLetterText;
            viewNode.textContent = firstLetterText;
            position.sourceNode.nextSibling.textContent =
              text2.slice(firstLetterLength);
          }
        }
        if (firstLetterLength > 0) {
          const viewText = viewNode.textContent ?? "";
          viewNode.textContent = viewText.slice(0, firstLetterLength);
        }
        return this.layoutContext.peelOff(textPosition, firstLetterLength);
      }
    }
    return Task.newResult<Vtree.NodeContext>(position);
  }

  /**
   * Builds the view until a CSS box edge is reached.
   * @param position start source position.
   * @param checkPoints array to append possible breaking points.
   * @return holding box edge position reached or null if the source is exhausted.
   */
  buildViewToNextBlockEdge(
    position: Vtree.NodeContext,
    checkPoints: Vtree.RenderedNodeContext[],
  ): Task.Result<Vtree.NodeContext> {
    let violateConstraint = false;
    const frame: Task.Frame<Vtree.NodeContext> = Task.newFrame(
      "buildViewToNextBlockEdge",
    );
    frame
      .loopWithFrame((bodyFrame) => {
        const renderedPos = VtreeImpl.asRenderedNodeContext(position);
        if (
          renderedPos &&
          !LayoutHelper.isSpecialNodeContext(renderedPos) &&
          // Prevent breaking inside SVG etc. (Issue #1406)
          renderedPos.viewNode.parentElement?.namespaceURI === Base.NS.XHTML
        ) {
          checkPoints.push(renderedPos.copy());

          // Prevent performance degradation when the text block is very large.
          // (Issue #1256)
          const CHECKPOINTS_THRESHOLD = 1000;
          if (checkPoints.length > CHECKPOINTS_THRESHOLD) {
            const element =
              renderedPos.viewNode.nodeType === 1
                ? (renderedPos.viewNode as Element)
                : renderedPos.viewNode.parentElement;
            const rect = this.clientLayout.getElementClientRect(element);

            // Check if the box position is beyond column breaks with
            // the browser's column breaking.
            const columnOver = LayoutHelper.checkIfBeyondColumnBreaks(
              rect,
              this.vertical,
            );
            if (columnOver >= 2) {
              // When the box position is beyond two or more column breaks,
              // it should not be necessary to continue processing further
              // because it will be processed again in the next column.
              // Exit the loop
              bodyFrame.breakLoop();
              return;
            }
          }
        }
        this.maybePeelOff(position, 0).then((position1Param) => {
          const position1 = position1Param as Vtree.NodeContext;
          if (position1 !== position) {
            position = position1;
            const renderedPeeled = VtreeImpl.asRenderedNodeContext(position1);
            if (
              renderedPeeled &&
              !LayoutHelper.isSpecialNodeContext(renderedPeeled)
            ) {
              checkPoints.push(renderedPeeled.copy());
            }
          }
          this.nextInTree(position).then((positionParam) => {
            position = positionParam as Vtree.NodeContext;
            if (!position) {
              // Exit the loop
              bodyFrame.breakLoop();
              return;
            }
            if (
              violateConstraint ||
              !this.layoutConstraint.allowLayout(position)
            ) {
              violateConstraint = true;
              position = position.modify();
              position.overflow = true;
            }
            const floatNodeContext = this.asFloatNodeContext(position);
            if (
              floatNodeContext &&
              // Exclude normal floats (fix for issue #611)
              (PageFloats.isPageFloat(floatNodeContext.floatReference) ||
                floatNodeContext.floatSide === "footnote")
            ) {
              this.layoutFloatOrFootnote(floatNodeContext).then(
                (positionParam) => {
                  position = positionParam;
                  if (this.pageFloatLayoutContext.isInvalidated()) {
                    position = null;
                  }
                  if (!position) {
                    bodyFrame.breakLoop();
                    return;
                  }
                  if (position.pluginProps["lineFootnoteOverflow"]) {
                    bodyFrame.breakLoop();
                    return;
                  }
                  bodyFrame.continueLoop();
                },
              );
            } else if (!position.inline) {
              // Exit the loop
              bodyFrame.breakLoop();
            } else {
              // Continue the loop
              bodyFrame.continueLoop();
            }
          });
        });
      })
      .then(() => {
        frame.finish(position);
      });
    return frame.result();
  }

  nextInTree(
    position: Vtree.NodeContext,
    atUnforcedBreak?: boolean,
  ): Task.Result<Vtree.NodeContext | null> {
    const cont = this.layoutContext.nextInTree(position, atUnforcedBreak);
    return processAfterIfContinues(cont, this);
  }

  /**
   * Builds the view for a single unbreakable element.
   * @param position start source position.
   * @return holding box edge position reached or null if the source is exhausted.
   */
  buildDeepElementView(
    position: Vtree.NodeContext,
  ): Task.Result<Vtree.NodeContext> {
    if (!position.viewNode) {
      return Task.newResult(position);
    }
    let checkPoints: Vtree.RenderedNodeContext[] = [];
    const sourceNode = position.sourceNode;
    const frame: Task.Frame<Vtree.NodeContext> = Task.newFrame(
      "buildDeepElementView",
    );

    // TODO: end the loop based on depth, not sourceNode comparison
    frame
      .loopWithFrame((bodyFrame) => {
        const renderedPos = VtreeImpl.asRenderedNodeContext(position);
        if (
          renderedPos &&
          renderedPos.inline &&
          !LayoutHelper.isSpecialNodeContext(renderedPos)
        ) {
          checkPoints.push(renderedPos.copy());
        } else {
          if (checkPoints.length > 0) {
            this.postLayoutBlock(position, checkPoints);
          }
          checkPoints = [];
        }
        this.maybePeelOff(position, 0).then((position1Param) => {
          const position1 = position1Param as Vtree.NodeContext;
          if (position1 !== position) {
            let p: Vtree.NodeContext | null = position1;
            while (p && p.sourceNode != sourceNode) {
              p = p.parent;
            }
            if (p == null) {
              // outside of the subtree
              position = position1;
              bodyFrame.breakLoop();
              return;
            }
            const renderedPeeled = VtreeImpl.asRenderedNodeContext(position1);
            if (
              renderedPeeled &&
              !LayoutHelper.isSpecialNodeContext(renderedPeeled)
            ) {
              checkPoints.push(renderedPeeled.copy());
            }
          }
          this.nextInTree(position1).then((positionParam) => {
            position = positionParam as Vtree.NodeContext;
            if (!position || position.sourceNode == sourceNode) {
              bodyFrame.breakLoop();
              return;
            }
            if (!this.layoutConstraint.allowLayout(position)) {
              position = position.modify();
              position.overflow = true;
              if (this.stopAtOverflow) {
                bodyFrame.breakLoop();
                return;
              }
            }
            const floatNodeContext = this.asFloatNodeContext(position);
            if (
              floatNodeContext &&
              // Exclude normal floats (fix for issue #611)
              (PageFloats.isPageFloat(floatNodeContext.floatReference) ||
                floatNodeContext.floatSide === "footnote")
            ) {
              this.layoutFloatOrFootnote(floatNodeContext).then(
                (positionParam) => {
                  position = positionParam;
                  if (this.pageFloatLayoutContext.isInvalidated()) {
                    position = null;
                  }
                  if (!position) {
                    bodyFrame.breakLoop();
                    return;
                  }
                  bodyFrame.continueLoop();
                },
              );
              return;
            }
            bodyFrame.continueLoop();
          });
        });
      })
      .then(() => {
        if (checkPoints.length > 0) {
          this.postLayoutBlock(position, checkPoints);
        }
        frame.finish(position);
      });
    return frame.result();
  }

  /**
   * Create a single floating element (for exclusion areas).
   * @param ref container's child to insert float before (can be null).
   * @param side float side ("left" or "right").
   * @param width float inline dimension.
   * @param height float box progression dimension.
   * @return newly created float element.
   */
  createFloat(
    ref: Node | null,
    side: string,
    width: number,
    height: number,
  ): Element {
    const div = this.viewDocument.createElement("div");
    if (this.vertical) {
      if (height >= this.height) {
        height -= 0.1;
      }
      if (height < 1) {
        height = 0;
      }
      Base.setCSSProperty(div, "height", `${width}px`);
      Base.setCSSProperty(div, "width", `${height}px`);
    } else {
      if (width >= this.width) {
        width -= 0.1;
      }
      if (width < 1) {
        width = 0;
      }
      Base.setCSSProperty(div, "width", `${width}px`);
      Base.setCSSProperty(div, "height", `${height}px`);
    }
    Base.setCSSProperty(div, "float", side);
    Base.setCSSProperty(div, "clear", side);

    // enable to visualize
    // Base.setCSSProperty(div, "background-color", "#50F0FF");
    this.element.insertBefore(div, ref);
    return div;
  }

  /**
   * Remove all the exclusion floats.
   */
  killFloats(): void {
    let c: Node | null = this.element.firstChild;
    while (c) {
      const nc = c.nextSibling;
      if (c.nodeType == 1) {
        const e = c as HTMLElement;
        const f = e.style.cssFloat;
        if (f == "left" || f == "right" || f === "none") {
          this.element.removeChild(e);
        } else {
          break;
        }
      }
      c = nc;
    }
  }

  /**
   * Create exclusion floats for a column.
   */
  createFloats(): void {
    const ref = this.element.firstChild;
    const bands = this.bands;
    const x1 = this.vertical ? this.getTopEdge() : this.getLeftEdge();
    const x2 = this.vertical ? this.getBottomEdge() : this.getRightEdge();
    const y1 = this.vertical ? -this.getRightEdge() : this.getTopEdge();
    const y2 = this.vertical ? -this.getLeftEdge() : this.getBottomEdge();
    let foundNonZeroWidthBand: GeometryUtil.Band | null = null;

    // First pass: adjust band edges to column edges if they are almost equal
    // to avoid creating unnecessary floats that may cause layout issues.
    // (Issue #1460)
    // In multi-column layout, getBoundingClientRect() of a child element
    // spanning multiple columns can be offset by ~1.2px from the parent
    // column box edges in all directions. Use wider tolerance for bands
    // that approximately span the full column width (indicating a content
    // area band affected by multi-column measurement offset), but keep
    // default tolerance for partial-width bands (e.g. flexbox alignment
    // exclusions) to avoid incorrectly snapping them. (Issue #1917)
    const widerPrecision = 1.5 / (this.clientLayout.pixelRatio || 1);
    for (const band of bands) {
      // Check if this band approximately spans the full column width
      // (both x edges are close to column edges within wider tolerance).
      // Such bands are likely affected by multi-column measurement offset
      // and need wider snapping precision.
      const isFullWidthBand =
        Math.abs(band.x1 - x1) < widerPrecision &&
        Math.abs(band.x2 - x2) < widerPrecision;
      const precision = isFullWidthBand ? widerPrecision : undefined;
      if (this.almostEquals(band.x1, x1, precision)) {
        band.x1 = x1;
      } else if (this.almostEquals(band.x1, x2, precision)) {
        band.x1 = x2;
      }
      if (this.almostEquals(band.x2, x2, precision)) {
        band.x2 = x2;
      } else if (this.almostEquals(band.x2, x1, precision)) {
        band.x2 = x1;
      }
      if (this.almostEquals(band.y1, y1, precision)) {
        band.y1 = y1;
      } else if (this.almostEquals(band.y1, y2, precision)) {
        band.y1 = y2;
      }
      if (this.almostEquals(band.y2, y2, precision)) {
        band.y2 = y2;
      } else if (this.almostEquals(band.y2, y1, precision)) {
        band.y2 = y1;
      }
    }

    // Compute float heights rounded to renderable precision and adjust at
    // boundaries between bands with different float widths to prevent text
    // from wrapping incorrectly due to sub-pixel float height rounding.
    // WebKit only supports 1px precision for float heights and truncates
    // (floors) non-integer values, so when compensation is enabled we use
    // Math.floor for WebKit and Math.round for other browsers. (Issue #1738)
    // This also fixes incorrect wrapping when float heights specified with
    // lh/rlh units slightly exceed actual line heights. (Issue #1494)
    // When pixelRatio=0, skip rounding/adjustment and keep native float
    // measurements as-is. (Issue #1913)
    const floatUnit = this.getFloatLayoutUnit();
    const roundToUnit = Base.browserType === "webkit" ? Math.floor : Math.round;
    const floatHeights = bands.map((band) =>
      floatUnit > 0
        ? (roundToUnit(band.y2 / floatUnit) -
            roundToUnit(band.y1 / floatUnit)) *
          floatUnit
        : band.y2 - band.y1,
    );
    // Adjust float heights at boundaries between bands with different float
    // widths. When the next band has a wider float (more exclusion), extend
    // the current band's float height by one unit and shrink the next by one
    // unit. When the current band has a wider float, do the reverse.
    // This shifts the boundary so that the narrower-float band absorbs
    // sub-pixel rounding error, preventing text from appearing at an
    // unexpected position.
    // The loop includes one extra iteration (i === bands.length - 1) to
    // handle the boundary between the last band and the implicit area below
    // it where text flows at full width (no float exclusion).
    const widthDiffThreshold = 0.01;
    for (let i = 0; i < bands.length; i++) {
      // For the last band, compare against the column edges (x1, x2)
      // representing the implicit full-width area below all floats.
      const nextX1 = i < bands.length - 1 ? bands[i + 1].x1 : x1;
      const nextX2 = i < bands.length - 1 ? bands[i + 1].x2 : x2;
      const leftWidthDiff = nextX1 - bands[i].x1;
      const rightWidthDiff = bands[i].x2 - nextX2;

      let leftDir = 0;
      let rightDir = 0;
      if (leftWidthDiff > widthDiffThreshold) {
        leftDir = 1;
      } else if (leftWidthDiff < -widthDiffThreshold) {
        leftDir = -1;
      }
      if (rightWidthDiff > widthDiffThreshold) {
        rightDir = 1;
      } else if (rightWidthDiff < -widthDiffThreshold) {
        rightDir = -1;
      }
      const adjustDir =
        leftDir !== 0 && rightDir !== 0
          ? leftDir === rightDir
            ? leftDir
            : 0
          : leftDir || rightDir;

      if (floatUnit > 0 && adjustDir !== 0) {
        const delta = adjustDir * floatUnit;
        if (
          floatHeights[i] + delta >= 0 &&
          (i >= bands.length - 1 || floatHeights[i + 1] - delta >= 0)
        ) {
          floatHeights[i] += delta;
          if (i < bands.length - 1) {
            floatHeights[i + 1] -= delta;
          }
        }
      }
    }

    // Second pass: create float elements with adjusted heights
    for (let i = 0; i < bands.length; i++) {
      const band = bands[i];
      band.left = this.createFloat(ref, "left", band.x1 - x1, floatHeights[i]);
      band.right = this.createFloat(
        ref,
        "right",
        x2 - band.x2,
        floatHeights[i],
      );

      // Hacky workaround for issue #1071
      // (Top page float should not absorb margin/border/padding of the block below)
      if (band.x1 < x2 && band.x2 > x1) {
        foundNonZeroWidthBand = band;
      } else if (!foundNonZeroWidthBand) {
        Base.setCSSProperty(band.right, "float", "none");
      }
    }

    if (foundNonZeroWidthBand) {
      // Update footnoteEdge (Fix for issue #1298)
      const lastBand = bands.at(-1);
      // Use wider tolerance for the y2 comparison: in multi-column layout,
      // getBoundingClientRect() can report band edges ~1.2px off from the
      // actual column edge. The default 0.5px precision (pixelRatio=0) is
      // too tight here. (Issue #1460)
      const y2Precision = 1.5 / (this.clientLayout.pixelRatio || 1);
      if (
        foundNonZeroWidthBand !== lastBand &&
        (lastBand.y2 >= y2 || this.almostEquals(lastBand.y2, y2, y2Precision))
      ) {
        this.footnoteEdge = this.vertical
          ? -foundNonZeroWidthBand.y2
          : foundNonZeroWidthBand.y2;

        // Remove unnecessary floats that may cause layout issues
        // (Fix for issue #1662; Partial fix for issue #1490)
        if (
          foundNonZeroWidthBand.x1 === x1 &&
          foundNonZeroWidthBand.x2 === x2
        ) {
          for (
            let i = bands.indexOf(foundNonZeroWidthBand);
            i < bands.length;
            i++
          ) {
            const band = bands[i];
            this.element.removeChild(band.left);
            this.element.removeChild(band.right);
            band.left = null;
            band.right = null;
          }
        }
      }
    }
    // Fix for footnotes/block-end-page-floats and table/multicol issue (#1662, #1460)
    this.adjustColumnBlockSizeForBlockEndFloats();
  }

  private adjustColumnBlockSizeForBlockEndFloats(): void {
    // During column balancing, this column is a child of the page-area
    // container re-laid out by ColumnBalancer. Skip CSS block-size adjustment
    // for those trial columns so balancing is based on the original fragmentainer
    // size, while keeping the adjustment for the final layout pass to avoid the
    // half-leading overlap regression. (Issue #1787, #1826)
    if (
      this.element.hasAttribute("data-vivliostyle-in-column-balancing") ||
      this.element.parentElement?.hasAttribute(
        "data-vivliostyle-in-column-balancing",
      )
    ) {
      return;
    }
    const initialBlockSize = this.vertical ? this.width : this.height;
    const blockSize = this.getBoxDir() * (this.footnoteEdge - this.beforeEdge);
    // Use wider tolerance (1.5px) for the same reason as isOverflown():
    // multi-column measurement errors can make footnoteEdge ~1.2px off,
    // which should not trigger column height adjustment. (Issue #1460)
    const precision = 1.5 / (this.clientLayout.pixelRatio || 1);
    if (
      blockSize > 0 &&
      blockSize < initialBlockSize &&
      !this.almostEquals(blockSize, initialBlockSize, precision)
    ) {
      const sizeProp = this.vertical ? "width" : "height";
      Base.setCSSProperty(this.element, sizeProp, `${blockSize}px`);
      if (this.vertical) {
        const left = this.left + (initialBlockSize - blockSize);
        Base.setCSSProperty(this.element, "left", `${left}px`);
      }
      this.element.setAttribute(
        "data-vivliostyle-column-block-size-adjusted",
        "true",
      );
    }
  }

  /**
   * @param nodeContext position after the block
   * @param checkPoints array of possible breaking points.
   * @param index index of the breaking point
   * @param boxOffset box offset
   * @return edge position
   */
  calculateEdge(
    nodeContext: Vtree.NodeContext | null,
    checkPoints: Vtree.RenderedNodeContext[],
    index: number,
    boxOffset: number,
  ): number {
    let edge: number;
    if (nodeContext && LayoutHelper.isOrphan(nodeContext.viewNode)) {
      return NaN;
    } else if (nodeContext && nodeContext.after && !nodeContext.inline) {
      edge = LayoutHelper.calculateEdge(
        nodeContext,
        this.clientLayout,
        0,
        this.vertical,
      );
      if (!isNaN(edge)) {
        return edge;
      }
    }
    nodeContext = checkPoints[index];
    let offset = boxOffset - nodeContext.boxOffset;
    while (true) {
      edge = LayoutHelper.calculateEdge(
        nodeContext,
        this.clientLayout,
        offset,
        this.vertical,
      );
      if (!isNaN(edge)) {
        return edge;
      }
      if (offset > 0) {
        offset--;
        continue;
      }
      index--;
      if (index < 0) {
        return this.beforeEdge;
      }
      const cp = checkPoints[index];
      nodeContext = cp;
      if (cp.viewNode.nodeType != 1) {
        offset = cp.viewNode.textContent.length;
      }
    }
  }

  /**
   * Parse CSS computed length (in pixels)
   * @param val CSS length in "px"
   * @return parsed and adjusted length value in pixels or 0 if not parsable
   */
  parseComputedLength(val: string): number {
    const r = val.match(/^(-?[0-9]*(\.[0-9]*)?)px$/);
    if (r) {
      return this.clientLayout.adjustLengthValue(parseFloat(r[0]));
    }
    return 0;
  }

  /**
   * Reads element's computed CSS margin.
   */
  getComputedMargin(element: Element): GeometryUtil.Insets {
    const style = this.clientLayout.getElementComputedStyle(element);
    const insets = new GeometryUtil.Insets(0, 0, 0, 0);
    if (style) {
      insets.left = this.parseComputedLength(style.marginLeft);
      insets.top = this.parseComputedLength(style.marginTop);
      insets.right = this.parseComputedLength(style.marginRight);
      insets.bottom = this.parseComputedLength(style.marginBottom);
    }
    return insets;
  }

  /**
   * Reads element's computed padding + borders.
   */
  getComputedPaddingBorder(element: Element): GeometryUtil.Insets {
    const style = this.clientLayout.getElementComputedStyle(element);
    const insets = new GeometryUtil.Insets(0, 0, 0, 0);
    if (style) {
      insets.left =
        this.parseComputedLength(style.borderLeftWidth) +
        this.parseComputedLength(style.paddingLeft);
      insets.top =
        this.parseComputedLength(style.borderTopWidth) +
        this.parseComputedLength(style.paddingTop);
      insets.right =
        this.parseComputedLength(style.borderRightWidth) +
        this.parseComputedLength(style.paddingRight);
      insets.bottom =
        this.parseComputedLength(style.borderBottomWidth) +
        this.parseComputedLength(style.paddingBottom);
    }
    return insets;
  }

  /**
   * Reads element's computed CSS insets(margins + border + padding or margins :
   * depends on box-sizing)
   */
  getComputedInsets(element: Element): GeometryUtil.Insets {
    const style = this.clientLayout.getElementComputedStyle(element);
    const insets = new GeometryUtil.Insets(0, 0, 0, 0);
    if (style) {
      if (style.boxSizing == "border-box") {
        return this.getComputedMargin(element);
      }
      insets.left =
        this.parseComputedLength(style.marginLeft) +
        this.parseComputedLength(style.borderLeftWidth) +
        this.parseComputedLength(style.paddingLeft);
      insets.top =
        this.parseComputedLength(style.marginTop) +
        this.parseComputedLength(style.borderTopWidth) +
        this.parseComputedLength(style.paddingTop);
      insets.right =
        this.parseComputedLength(style.marginRight) +
        this.parseComputedLength(style.borderRightWidth) +
        this.parseComputedLength(style.paddingRight);
      insets.bottom =
        this.parseComputedLength(style.marginBottom) +
        this.parseComputedLength(style.borderBottomWidth) +
        this.parseComputedLength(style.paddingBottom);
    }
    return insets;
  }

  /**
   * Set element's computed CSS insets to Column Container
   */
  setComputedInsets(element: Element, container: Layout.Column) {
    const style = this.clientLayout.getElementComputedStyle(element);
    if (style) {
      container.marginLeft = this.parseComputedLength(style.marginLeft);
      container.borderLeft = this.parseComputedLength(style.borderLeftWidth);
      container.paddingLeft = this.parseComputedLength(style.paddingLeft);
      container.marginTop = this.parseComputedLength(style.marginTop);
      container.borderTop = this.parseComputedLength(style.borderTopWidth);
      container.paddingTop = this.parseComputedLength(style.paddingTop);
      container.marginRight = this.parseComputedLength(style.marginRight);
      container.borderRight = this.parseComputedLength(style.borderRightWidth);
      container.paddingRight = this.parseComputedLength(style.paddingRight);
      container.marginBottom = this.parseComputedLength(style.marginBottom);
      container.borderBottom = this.parseComputedLength(
        style.borderBottomWidth,
      );
      container.paddingBottom = this.parseComputedLength(style.paddingBottom);
    }
  }

  /**
   * Set element's computed width and height to Column Container
   */
  setComputedWidthAndHeight(element: Element, container: Layout.Column) {
    const style = this.clientLayout.getElementComputedStyle(element);
    if (style) {
      container.width = this.parseComputedLength(style.width);
      container.height = this.parseComputedLength(style.height);
    }
  }

  /**
   * Layout a single unbreakable element.
   */
  layoutUnbreakable(
    nodeContextIn: Vtree.NodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    return this.buildDeepElementView(nodeContextIn);
  }

  /**
   * Layout a single float element.
   */
  layoutFloat(
    nodeContext: Vtree.RenderedNodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("layoutFloat");
    const element = nodeContext.viewNode as Element;
    const floatSide = PageFloats.resolveInlineFloatDirection(
      nodeContext.floatSide,
      nodeContext.vertical,
      nodeContext.direction,
      (this.layoutContext as Vgen.ViewFactory).page.side,
    );
    Base.setCSSProperty(element, "float", "none");
    Base.setCSSProperty(element, "display", "inline-block");
    Base.setCSSProperty(element, "vertical-align", "top");
    this.buildDeepElementView(nodeContext).then((nodeContextAfter) => {
      const floatBBox = LayoutHelper.getElementClientRectAdjusted(
        this.clientLayout,
        element,
        this.vertical,
      );
      const margin = this.getComputedMargin(element);
      let floatBox = new GeometryUtil.Rect(
        floatBBox.left - margin.left,
        floatBBox.top - margin.top,
        floatBBox.right + margin.right,
        floatBBox.bottom + margin.bottom,
      );
      let x1 = this.rtl ? this.endEdge : this.startEdge;
      let x2 = this.rtl ? this.startEdge : this.endEdge;
      let parent = nodeContext.parent;
      while (parent && parent.inline) {
        parent = parent.parent;
      }
      const parentRendered = parent && VtreeImpl.asRenderedNodeContext(parent);
      if (parentRendered) {
        const parentViewNode = parentRendered.viewNode;
        // Position it at the parent element's edge.
        // We need to get the edge of the parent's content area, calling
        // getElementClientRect will also give us borders. Avoid it by creating
        // a temporary element and using it for measurment.
        const probe = parentViewNode.ownerDocument.createElement("div");
        probe.style.left = "0px";
        probe.style.top = "0px";
        if (this.vertical) {
          probe.style.bottom = "0px";
          probe.style.width = "1px";
        } else {
          probe.style.right = "0px";
          probe.style.height = "1px";
        }
        parentViewNode.appendChild(probe);
        const parentBox = LayoutHelper.getElementClientRectAdjusted(
          this.clientLayout,
          probe,
          this.vertical,
        );
        x1 = Math.max(
          this.rtl ? this.getEndEdge(parentBox) : this.getStartEdge(parentBox),
          x1,
        );
        x2 = Math.min(
          this.rtl ? this.getStartEdge(parentBox) : this.getEndEdge(parentBox),
          x2,
        );
        parentViewNode.removeChild(probe);
        const floatBoxMeasure = this.vertical
          ? floatBox.y2 - floatBox.y1
          : floatBox.x2 - floatBox.x1;
        if (floatSide == "left") {
          x2 = Math.max(x2, x1 + floatBoxMeasure);
        } else {
          x1 = Math.min(x1, x2 - floatBoxMeasure);
        }

        // Move the float below the block parent.
        // Otherwise, if the float is attached to an inline box with 'position:
        // relative', the absolute positioning of the float gets broken, since
        // the inline parent can be pushed horizontally by exclusion floats
        // after the layout of the float is done.
        if (parent !== nodeContext.parent && !nodeContext.firstPseudo) {
          // Unless float is specified on ::first-letter (Fix for issue #923)
          parentViewNode.appendChild(element);

          // Mark the moved float box so that it is not removed wrongly
          // when page breaking occurs inside the inline parent.
          // (Issue #1383, #1422)
          element.setAttribute("data-vivliostyle-float-box-moved", "true");
        }
      }

      // box is rotated for vertical orientation
      let box = new GeometryUtil.Rect(
        x1,
        this.getBoxDir() * this.beforeEdge,
        x2,
        this.getBoxDir() * this.afterEdge,
      );
      let floatHorBox = floatBox;
      if (this.vertical) {
        floatHorBox = GeometryUtil.rotateBox(floatBox);
      }
      const dir = this.getBoxDir();
      if (floatHorBox.y1 < this.bottommostFloatTop * dir) {
        const boxExtent = floatHorBox.y2 - floatHorBox.y1;
        floatHorBox.y1 = this.bottommostFloatTop * dir;
        floatHorBox.y2 = floatHorBox.y1 + boxExtent;
      }

      // Handle clear property on inline floats (Issue #1803)
      if (nodeContext.clearSide) {
        const clearLR =
          /^(top|bottom|inside|outside|(block|inline)-(start|end))$/.test(
            nodeContext.clearSide,
          )
            ? PageFloats.resolveInlineFloatDirection(
                nodeContext.clearSide,
                nodeContext.vertical,
                nodeContext.direction,
                (this.layoutContext as Vgen.ViewFactory).page.side,
              )
            : nodeContext.clearSide === "same"
              ? floatSide
              : nodeContext.clearSide;
        let clearEdge = this.beforeEdge;
        if (clearLR !== "right") {
          clearEdge = dir * Math.max(clearEdge * dir, this.leftFloatEdge * dir);
        }
        if (clearLR !== "left") {
          clearEdge =
            dir * Math.max(clearEdge * dir, this.rightFloatEdge * dir);
        }
        const clearY = clearEdge * dir;
        if (floatHorBox.y1 < clearY) {
          const boxExtent = floatHorBox.y2 - floatHorBox.y1;
          floatHorBox.y1 = clearY;
          floatHorBox.y2 = floatHorBox.y1 + boxExtent;
        }
      }

      // When compensation is enabled, extend box after-edge slightly so
      // positionFloat() does not reject a float that barely overflows due to
      // sub-pixel rounding when clear pushes it near the column boundary.
      // With pixelRatio=0 this stays unchanged (no extra extension).
      // (Issue #1803, #1913)
      box.y2 += this.getFloatLayoutUnit();

      GeometryUtil.positionFloat(box, this.bands, floatHorBox, floatSide);
      if (this.vertical) {
        floatBox = GeometryUtil.unrotateBox(floatHorBox);
      }
      const insets = this.getComputedInsets(element);
      Base.setCSSProperty(
        element,
        "width",
        `${floatBox.x2 - floatBox.x1 - insets.left - insets.right}px`,
      );
      Base.setCSSProperty(
        element,
        "height",
        `${floatBox.y2 - floatBox.y1 - insets.top - insets.bottom}px`,
      );
      Base.setCSSProperty(element, "position", "absolute");
      Asserts.assert(nodeContext.display);
      Base.setCSSProperty(element, "display", nodeContext.display);
      let offsets;
      const containingBlockForAbsolute = parent
        ? parent.containingBlockForAbsolute
          ? VtreeImpl.asElementNodeContext(parent)
          : parent.getContainingBlockForAbsolute()
        : null;
      if (containingBlockForAbsolute) {
        const containingBlockViewNode = containingBlockForAbsolute.viewNode;
        const probe =
          containingBlockViewNode.ownerDocument.createElement("div");
        probe.style.position = "absolute";
        if (containingBlockForAbsolute.vertical) {
          probe.style.right = "0";
        } else {
          probe.style.left = "0";
        }
        probe.style.top = "0";
        containingBlockViewNode.appendChild(probe);
        offsets = LayoutHelper.getElementClientRectAdjusted(
          this.clientLayout,
          probe,
          this.vertical,
        );
        containingBlockViewNode.removeChild(probe);
      } else {
        offsets = {
          left: this.getLeftEdge() - this.paddingLeft,
          right: this.getRightEdge() + this.paddingRight,
          top: this.getTopEdge() - this.paddingTop,
        };
      }
      // The computed float offset from the block-start edge of its
      // containing block may be negative when the containing block has
      // `position: relative` and has been pushed along the block-progression
      // direction by a margin carried over from a preceding sibling across
      // a column/page break. Clamp the offset to be non-negative so that
      // the float stays inside the containing block. (Issue #1885)
      if (
        containingBlockForAbsolute
          ? containingBlockForAbsolute.vertical
          : this.vertical
      ) {
        const rightValue = Math.max(0, offsets.right - floatBox.x2);
        Base.setCSSProperty(element, "right", `${rightValue}px`);
      } else {
        const leftValue = Math.max(0, floatBox.x1 - offsets.left);
        Base.setCSSProperty(element, "left", `${leftValue}px`);
      }
      const topValue = Math.max(0, floatBox.y1 - offsets.top);
      Base.setCSSProperty(element, "top", `${topValue}px`);
      if (nodeContext.clearSpacer) {
        nodeContext.clearSpacer.remove();
        nodeContext.clearSpacer = null;
      }
      const floatBoxEdge = this.vertical ? floatBox.x1 : floatBox.y2;
      const floatBoxTop = this.vertical ? floatBox.x2 : floatBox.y1;

      // TODO: subtract after margin when determining overflow.
      if (!this.isOverflown(floatBoxEdge) || this.breakPositions.length == 0) {
        // no overflow
        this.killFloats();
        box = new GeometryUtil.Rect(
          this.getLeftEdge(),
          this.getTopEdge(),
          this.getRightEdge(),
          this.getBottomEdge(),
        );
        if (this.vertical) {
          box = GeometryUtil.rotateBox(box);
        }
        GeometryUtil.addFloatToBands(
          box,
          this.bands,
          floatHorBox,
          null,
          floatSide,
        );
        this.createFloats();
        if (floatSide == "left") {
          this.leftFloatEdge = floatBoxEdge;
        } else {
          this.rightFloatEdge = floatBoxEdge;
        }
        this.bottommostFloatTop = floatBoxTop;
        this.updateMaxReachedAfterEdge(floatBoxEdge);
        frame.finish(nodeContextAfter);
      } else {
        nodeContext = nodeContext.modify();
        nodeContext.overflow = true;
        frame.finish(nodeContext);
      }
    });
    return frame.result();
  }

  setupFloatArea(
    area: PageFloatArea,
    floatReference: PageFloats.FloatReference,
    floatSide: string,
    anchorEdge: number | null,
    strategy: PageFloats.PageFloatLayoutStrategy,
    condition: PageFloats.PageFloatPlacementCondition,
  ): Task.Result<boolean> {
    const floatLayoutContext = this.pageFloatLayoutContext;
    const floatContainer =
      floatLayoutContext.getPageFloatLayoutContext(floatReference).container;
    const element = area.element;
    return strategy
      .adjustPageFloatArea(area, floatContainer, this)
      .thenAsync(() => {
        // adjustPageFloatArea may have changed the geometry, so re-measure; the
        // exclusion floats created at construction must be dropped first.
        area.killFloats();
        area.remeasure();
        const fitWithinContainer = !!floatLayoutContext.setFloatAreaDimensions(
          area,
          floatReference,
          floatSide,
          anchorEdge,
          true,
          area.isFootnote || !floatLayoutContext.hasFloatFragments(),
          condition,
        );
        if (fitWithinContainer) {
          // For footnotes with max-block-size, setFloatAreaDimensions may
          // have set the block dimension larger than the CSS max-block-size
          // (because positioning uses page-level limits, not area bounds).
          // Clamp to max-block-size so the JS dimension matches the browser-
          // rendered dimension, preventing coordinate mismatches in
          // measure()/computedBlockSize calculations. (Issue #1878)
          if (area.isFootnote) {
            const cs = getComputedStyle(area.element);
            if (area.vertical) {
              const maxW = parseFloat(cs.maxWidth);
              if (!isNaN(maxW) && area.width > maxW) {
                area.width = maxW;
                Base.setCSSProperty(area.element, "width", `${maxW}px`);
              }
            } else {
              const maxH = parseFloat(cs.maxHeight);
              if (!isNaN(maxH) && area.height > maxH) {
                area.height = maxH;
                Base.setCSSProperty(area.element, "height", `${maxH}px`);
              }
            }
          }
          // New dimensions have been set, remove exclusion floats and re-measure
          area.killFloats();
          area.remeasure();
        } else {
          element.remove();
        }
        return Task.newResult(fitWithinContainer);
      });
  }

  createPageFloatArea(
    float: PageFloats.PageFloat,
    floatSide: string,
    anchorEdge: number | null,
    strategy: PageFloats.PageFloatLayoutStrategy,
    condition: PageFloats.PageFloatPlacementCondition,
  ): Task.Result<Layout.PageFloatArea | null> {
    const floatAreaElement = this.element.ownerDocument.createElement("div");
    Base.setCSSProperty(floatAreaElement, "position", "absolute");
    const parentPageFloatLayoutContext =
      this.pageFloatLayoutContext.getPageFloatLayoutContext(
        float.floatReference,
      );

    // Create the page float area context without a parent to avoid side
    // effects (children registration, invalidation propagation, etc.).
    // Instead, set outerContext for getParent() navigation so nested page
    // floats and footnotes can propagate to the region/page level.
    // (Issue #1675)
    const pageFloatLayoutContext =
      PageFloats.PageFloatLayoutContext.createDetached(
        this.pageFloatLayoutContext,
        PageFloats.FloatReference.COLUMN,
        this.pageFloatLayoutContext.flowName,
        float.nodePosition,
      );
    const parentContainer = parentPageFloatLayoutContext.container;
    const floatContainer =
      this.pageFloatLayoutContext.getPageFloatLayoutContext(
        float.floatReference,
      ).container;
    // The constructor measures through a DOM probe, so attach the element first.
    floatContainer.element.parentNode!.appendChild(floatAreaElement);
    const containingBlockRect = floatContainer.getPaddingRect();
    const floatLeft = containingBlockRect.x1 - floatContainer.originX;
    const floatTop = containingBlockRect.y1 - floatContainer.originY;
    // Position the freshly created element before it is measured.
    Base.setCSSProperty(floatAreaElement, "left", `${floatLeft}px`);
    Base.setCSSProperty(floatAreaElement, "top", `${floatTop}px`);
    const floatArea = new PageFloatArea(
      floatSide,
      floatAreaElement,
      this.layoutContext.clone(),
      this.clientLayout,
      this.layoutConstraint,
      pageFloatLayoutContext,
      parentContainer,
      {
        vertical: floatContainer.vertical,
        rtl: floatContainer.rtl,
        snapWidth: 0,
        snapHeight: 0,
        originX: floatContainer.originX,
        originY: floatContainer.originY,
        left: floatLeft,
        top: floatTop,
        width: containingBlockRect.x2 - containingBlockRect.x1,
        height: containingBlockRect.y2 - containingBlockRect.y1,
        marginLeft: 0,
        marginRight: 0,
        marginTop: 0,
        marginBottom: 0,
        borderLeft: 0,
        borderRight: 0,
        borderTop: 0,
        borderBottom: 0,
        paddingLeft: 0,
        paddingRight: 0,
        paddingTop: 0,
        paddingBottom: 0,
        borderBoxSizing: false,
      },
      null,
      [...(floatContainer.exclusions || [])],
      this.flowRootFormattingContext,
    );
    floatArea.isFloat = true;
    floatArea.forceNonfitting =
      !this.pageFloatLayoutContext.hasFloatFragments();
    return this.setupFloatArea(
      floatArea,
      float.floatReference,
      floatSide,
      anchorEdge,
      strategy,
      condition,
    ).thenAsync((fitWithinContainer) => {
      if (fitWithinContainer) {
        return Task.newResult(floatArea);
      } else {
        return Task.newResult(null);
      }
    });
  }

  layoutSinglePageFloatFragment(
    continuations: PageFloats.PageFloatContinuation[],
    floatSide: string,
    clearSide: string | null,
    allowFragmented: boolean,
    strategy: PageFloats.PageFloatLayoutStrategy,
    anchorEdge: number | null,
    pageFloatFragment?: PageFloats.PageFloatFragment | null,
  ): Task.Result<SinglePageFloatLayoutResult> {
    const context = this.pageFloatLayoutContext;
    const originalContinuations = pageFloatFragment
      ? pageFloatFragment.continuations
      : [];
    continuations = originalContinuations.concat(continuations);
    const firstFloat = continuations[0].float;
    const condition = context.getPageFloatPlacementCondition(
      firstFloat,
      floatSide,
      clearSide,
    );
    const result: SinglePageFloatLayoutResult = {
      floatArea: null,
      pageFloatFragment: null,
      newPosition: null,
    };
    const frame = Task.newFrame<SinglePageFloatLayoutResult>(
      "layoutSinglePageFloatFragment",
    );
    this.createPageFloatArea(
      firstFloat,
      floatSide,
      anchorEdge,
      strategy,
      condition,
    ).then((floatArea) => {
      result.floatArea = floatArea;
      if (!floatArea) {
        frame.finish(result);
        return;
      }
      let failed = false;
      let i = 0;
      frame
        .loopWithFrame((loopFrame) => {
          if (i >= continuations.length) {
            loopFrame.breakLoop();
            return;
          }
          const c = continuations[i];
          const floatChunkPosition = new VtreeImpl.ChunkPosition(
            c.nodePosition,
          );
          const prevRootViewNodeCount = floatArea.getRootViewNodeCount();
          floatArea.layout(floatChunkPosition, true).then((newPosition) => {
            result.newPosition = newPosition;
            if (!newPosition || allowFragmented) {
              // For footnotes: if fragmented, check if meaningful content was
              // placed for this continuation. doLayout() resets
              // breakPositions for each layout call, so this check must be
              // self-contained for the current continuation; comparing with a
              // previous continuation rejects valid later footnotes in a shared
              // footnote area. (Issue #1956, #2026)
              if (
                newPosition &&
                floatArea.isFootnote &&
                floatArea.breakPositions
              ) {
                const hasNewLineContent =
                  floatArea.breakPositions.some(
                    (bp) => bp instanceof BoxBreakPosition,
                  ) &&
                  floatArea.hasNonPseudoTextContentAfter(prevRootViewNodeCount);
                if (!hasNewLineContent) {
                  failed = true;
                  loopFrame.breakLoop();
                  return;
                }
              }
              i++;
              loopFrame.continueLoop();
            } else {
              failed = true;
              loopFrame.breakLoop();
            }
          });
        })
        .then(() => {
          if (
            !failed &&
            floatArea.isFootnote &&
            floatArea.computedBlockSize <= 0 &&
            result.newPosition
          ) {
            // Footnote content could not be placed (e.g., widows/orphans
            // constraints prevented fragmentation). Fail the layout so
            // the footnote is deferred to the next page.
            // Exception: during iterative footnote sizing, an empty first
            // fragment can mean we need to start or continue the retry cycle
            // instead of deferring the whole footnote. This is what lets the
            // moved-call multicol case retry on the current page (#1891).
            const floatContext = context.getPageFloatLayoutContext(
              firstFloat.floatReference,
            );
            if (floatContext.footnoteMaxBlockSize == null) {
              if (
                floatContext.initFootnoteRetryFromEmptyFragment(
                  firstFloat,
                  floatArea,
                )
              ) {
                if (floatArea.element.parentNode) {
                  floatArea.element.parentNode.removeChild(floatArea.element);
                }
                this.layoutSinglePageFloatFragment(
                  continuations,
                  floatSide,
                  clearSide,
                  allowFragmented,
                  strategy,
                  anchorEdge,
                  pageFloatFragment,
                ).then((retryResult) => {
                  frame.finish(retryResult);
                });
                return;
              }
              failed = true;
            }
          }
          if (!failed) {
            Asserts.assert(floatArea);
            if (floatArea.isFootnote) {
              floatArea.applyCompactFootnoteDisplay();
            }
            const logicalFloatSide = context.setFloatAreaDimensions(
              floatArea,
              firstFloat.floatReference,
              floatSide,
              anchorEdge,
              false,
              allowFragmented,
              condition,
            );
            if (!logicalFloatSide) {
              failed = true;
            } else {
              const newFragment = strategy.createPageFloatFragment(
                continuations,
                logicalFloatSide,
                clearSide,
                floatArea,
                !!result.newPosition,
              );
              context.addPageFloatFragment(newFragment, true);
              result.pageFloatFragment = newFragment;
            }
          }
          frame.finish(result);
        });
    });
    return frame.result();
  }

  layoutPageFloatInner(
    continuation: PageFloats.PageFloatContinuation,
    strategy: PageFloats.PageFloatLayoutStrategy,
    anchorEdge: number | null,
    pageFloatFragment?: PageFloats.PageFloatFragment | null,
  ): Task.Result<boolean> {
    const context = this.pageFloatLayoutContext;
    const float = continuation.float;
    const isFootnote = float instanceof Footnote;
    const layoutLineFootnoteSeparately =
      isFootnote &&
      float.footnotePolicy === Css.ident.line &&
      !!pageFloatFragment &&
      !pageFloatFragment.hasFloat(float);

    // Snapshot insidePageFloatArea fragments before the layout attempt.
    // If this float's layout is cancelled, any NEW insidePageFloatArea
    // fragments (from nested page floats or footnotes inside the page float
    // area) need to be cleaned up from ancestor contexts. (Issue #1675)
    const savedInsideFragments = new Set<PageFloats.PageFloatFragment>();
    for (
      let ctx: PageFloats.PageFloatLayoutContext | null =
        context as PageFloats.PageFloatLayoutContext;
      ctx;
      ctx = ctx.effectiveParent
    ) {
      for (const frag of ctx.floatFragments) {
        if (frag.continuations.some((c) => c.float.insidePageFloatArea)) {
          savedInsideFragments.add(frag);
        }
      }
    }

    if (!layoutLineFootnoteSeparately) {
      context.stashEndFloatFragments(float);
    }

    function cancelLayout(floatArea, pageFloatFragment) {
      if (pageFloatFragment) {
        context.removePageFloatFragment(pageFloatFragment, true);
      } else if (floatArea) {
        floatArea.element.parentNode.removeChild(floatArea.element);
      }

      // Remove insidePageFloatArea fragments created during the cancelled
      // page float area's content layout. These fragments were added to
      // ancestor contexts (e.g. PAGE level) but the parent page float that
      // contains them was cancelled, so they are orphaned. (Issue #1675)
      const fragmentsToRemove: PageFloats.PageFloatFragment[] = [];
      for (
        let ctx: PageFloats.PageFloatLayoutContext | null =
          context as PageFloats.PageFloatLayoutContext;
        ctx;
        ctx = ctx.effectiveParent
      ) {
        for (const frag of ctx.floatFragments) {
          if (
            !savedInsideFragments.has(frag) &&
            frag.continuations.some((c) => c.float.insidePageFloatArea)
          ) {
            fragmentsToRemove.push(frag);
          }
        }
      }
      for (const frag of fragmentsToRemove) {
        context.removePageFloatFragment(frag, true);
      }

      context.restoreStashedFragments(float.floatReference);
      context.deferPageFloat(continuation);
    }
    const frame: Task.Frame<boolean> = Task.newFrame("layoutPageFloatInner");
    this.layoutSinglePageFloatFragment(
      [continuation],
      float.floatSide,
      float.clearSide,
      isFootnote || !context.hasFloatFragments(),
      strategy,
      anchorEdge,
      layoutLineFootnoteSeparately ? null : pageFloatFragment,
    ).then((result) => {
      const floatArea = result.floatArea;
      const newFragment = result.pageFloatFragment;
      const newPosition = result.newPosition;
      if (newFragment) {
        this.layoutStashedPageFloats(float.floatReference, [
          pageFloatFragment,
        ]).then((success) => {
          if (success) {
            // Add again to invalidate the context.
            // When inside a page float area (generatingNodePosition is set),
            // suppress invalidation to avoid interrupting the outer page float
            // layout. The region will be invalidated later when the outer page
            // float fragment is added. (Issue #1675)
            Asserts.assert(newFragment);
            let fragmentForContext = newFragment;
            if (layoutLineFootnoteSeparately && pageFloatFragment) {
              // Existing shared footnote areas can receive a later
              // line-policy footnote. Layout it in a scratch area first, then
              // merge the rendered nodes and resize the existing area so the
              // shared fragment keeps one physical footnote box.
              const footnoteArea = pageFloatFragment.area as PageFloatArea;
              const previousRootViewNodeCount =
                footnoteArea.getRootViewNodeCount();
              footnoteArea.appendContentFrom(newFragment.area as PageFloatArea);
              context.removePageFloatFragment(newFragment, true);
              const logicalFloatSide = context.setFloatAreaDimensions(
                footnoteArea,
                float.floatReference,
                pageFloatFragment.floatSide,
                anchorEdge,
                false,
                true,
                context.getPageFloatPlacementCondition(
                  float,
                  float.floatSide,
                  float.clearSide,
                ),
              );
              if (!logicalFloatSide) {
                footnoteArea.removeContentAfter(previousRootViewNodeCount);
                cancelLayout(floatArea, newFragment);
                frame.finish(false);
                return;
              }
              pageFloatFragment.addContinuations(newFragment.continuations);
              fragmentForContext = pageFloatFragment;
            }
            const isInsidePageFloat = !!context.generatingNodePosition;
            // Issue #2024, #2026: Placing a `footnote-policy: line` footnote
            // shrinks the body area and invalidates the page so the body
            // reflows. On each page-layout retry the same footnote is placed
            // again; if it invalidated every time, layout may fail to converge
            // or the final fragment area can be cleared by a later retry.
            // Allow exactly one invalidation per line-policy footnote per
            // retry size; suppress redundant invalidations after that so
            // pagination can complete with the footnote area attached.
            const isLineFootnoteForInvalidation =
              !isInsidePageFloat &&
              float instanceof Footnote &&
              float.footnotePolicy === Css.ident.line;
            const alreadyInvalidatedForLineFootnote =
              isLineFootnoteForInvalidation &&
              context.hasInvalidatedForLineFootnote(float);
            context.addPageFloatFragment(
              fragmentForContext,
              isInsidePageFloat || alreadyInvalidatedForLineFootnote,
            );
            if (
              isLineFootnoteForInvalidation &&
              !alreadyInvalidatedForLineFootnote
            ) {
              context.markInvalidatedForLineFootnote(float);
            }
            context.discardStashedFragments(float.floatReference);
            if (newPosition) {
              const continuation = new PageFloats.PageFloatContinuation(
                float,
                newPosition.primary,
              );
              context.deferPageFloat(continuation);
            }
            frame.finish(true);
          } else {
            cancelLayout(floatArea, newFragment);
            frame.finish(false);
          }
        });
      } else {
        cancelLayout(floatArea, newFragment);
        frame.finish(false);
      }
    });
    return frame.result();
  }

  /**
   * @returns Represents if the layout was succeeded or not
   */
  private layoutStashedPageFloats(
    floatReference: PageFloats.FloatReference,
    excluded: PageFloats.PageFloatFragment[],
  ): Task.Result<boolean> {
    const context = this.pageFloatLayoutContext;
    const stashedFloatFragments =
      context.getStashedFloatFragments(floatReference);
    const newFloatAreas: Layout.PageFloatArea[] = [];
    const newFragments: PageFloats.PageFloatFragment[] = [];
    let failed = false;
    const frame = Task.newFrame<boolean>("layoutStashedPageFloats");
    let i = 0;
    frame
      .loopWithFrame((loopFrame) => {
        if (i >= stashedFloatFragments.length) {
          loopFrame.breakLoop();
          return;
        }
        const stashedFragment = stashedFloatFragments[i];
        if (excluded.includes(stashedFragment)) {
          i++;
          loopFrame.continueLoop();
          return;
        }
        const strategy =
          new PageFloats.PageFloatLayoutStrategyResolver().findByFloat(
            stashedFragment.continuations[0].float,
          );

        // Value of 'clear' is irrelevant when laying out stashed floats
        // since whether the 'clear' value allows placing the float
        // here is already resolved.

        // NOTE: added clearSide for issue #1550
        this.layoutSinglePageFloatFragment(
          stashedFragment.continuations,
          stashedFragment.floatSide,
          stashedFragment.clearSide,
          false,
          strategy,
          null,
        ).then((result) => {
          const floatArea = result.floatArea;
          if (floatArea) {
            newFloatAreas.push(floatArea);
          }
          const fragment = result.pageFloatFragment;
          if (fragment) {
            newFragments.push(fragment);
            i++;
            loopFrame.continueLoop();
          } else {
            failed = true;
            loopFrame.breakLoop();
          }
        });
      })
      .then(() => {
        if (failed) {
          newFragments.forEach((fragment) => {
            context.removePageFloatFragment(fragment, true);
          });
          newFloatAreas.forEach((area) => {
            const elem = area.element;
            if (elem && elem.parentNode) {
              elem.parentNode.removeChild(elem);
            }
          });
        } else {
          stashedFloatFragments.forEach((fragment) => {
            const elem = fragment.area.element;
            if (elem && elem.parentNode) {
              elem.parentNode.removeChild(elem);
            }
          });
        }
        frame.finish(!failed);
      });
    return frame.result();
  }

  private findFootnoteCallElement(footnoteViewNode: Node): Element | null {
    let prev = footnoteViewNode.previousSibling;
    while (prev) {
      if (
        prev.nodeType === Node.ELEMENT_NODE &&
        PseudoElement.getPseudoName(prev as Element) === "footnote-call"
      ) {
        return prev as Element;
      }
      prev = prev.previousSibling;
    }
    return null;
  }

  setFloatAnchorViewNode(
    nodeContext: Vtree.RenderedNodeContext,
  ): Vtree.RenderedNodeContext {
    let anchor: Element =
      nodeContext.viewNode.ownerDocument.createElement("span");
    anchor.setAttribute(LayoutHelper.SPECIAL_ATTR, "1");
    if (nodeContext.floatSide === "footnote") {
      // Issue #868: Find footnote-call already generated as a sibling
      const footnoteCall = this.findFootnoteCallElement(nodeContext.viewNode);
      if (footnoteCall) {
        anchor = footnoteCall;
      } else {
        nodeContext.viewNode.before(anchor);
      }
    } else {
      // the anchored view node is attached
      nodeContext.viewNode.parentNode!.appendChild(anchor);
    }

    nodeContext.viewNode.remove();
    const nodeContextAfter = nodeContext.modify();
    nodeContextAfter.after = true;
    nodeContextAfter.viewNode = anchor;
    // Issue #868: For footnote-call anchors, set display to inline so that
    // text-spacing can look through this element to find adjacent text nodes
    if (nodeContext.floatSide === "footnote") {
      nodeContextAfter.display = "inline";
    }
    return nodeContextAfter;
  }

  resolveFloatReferenceFromColumnSpan(
    floatReference: PageFloats.FloatReference,
    columnSpan: Css.Val | null,
    nodeContext: Vtree.NodeContext,
  ): Task.Result<PageFloats.FloatReference> {
    const frame = Task.newFrame(
      "resolveFloatReferenceFromColumnSpan",
    ) as Task.Frame<PageFloats.FloatReference>;
    const columnContext = this.pageFloatLayoutContext;
    const regionContext = columnContext.getPageFloatLayoutContext(
      PageFloats.FloatReference.REGION,
    );
    const isRegionWider =
      columnContext.container.width < regionContext.container.width;
    if (isRegionWider && floatReference === PageFloats.FloatReference.COLUMN) {
      if (columnSpan === Css.ident.auto) {
        this.buildDeepElementView(nodeContext.copy()).then((position) => {
          const element = position.viewNode as Element;
          let inlineSize = Sizing.getSize(this.clientLayout, element, [
            Sizing.Size.MIN_CONTENT_INLINE_SIZE,
          ])[Sizing.Size.MIN_CONTENT_INLINE_SIZE];
          const margin = this.getComputedMargin(element);
          if (this.vertical) {
            inlineSize += margin.top + margin.bottom;
          } else {
            inlineSize += margin.left + margin.right;
          }
          if (inlineSize > this.width) {
            frame.finish(PageFloats.FloatReference.REGION);
          } else {
            frame.finish(floatReference);
          }
        });
      } else if (columnSpan === Css.ident.all) {
        frame.finish(PageFloats.FloatReference.REGION);
      } else {
        frame.finish(floatReference);
      }
    } else {
      frame.finish(floatReference);
    }
    return frame.result();
  }

  layoutPageFloat(
    nodeContext: Vtree.FloatNodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    const context = this.pageFloatLayoutContext;
    const strategy =
      new PageFloats.PageFloatLayoutStrategyResolver().findByNodeContext(
        nodeContext,
      );
    let cont: Task.Result<PageFloats.PageFloat>;
    const float = context.findPageFloatByNodePosition(
      nodeContext.toNodePosition(),
    );
    if (!float) {
      cont = strategy.createPageFloat(nodeContext, context, this);
    } else {
      cont = Task.newResult(float);
    }
    return cont.thenAsync((float) => {
      const nodePosition = VtreeImpl.newNodePositionFromNodeContext(
        nodeContext,
        0,
      );
      const nodeContextAfter = this.setFloatAnchorViewNode(nodeContext);
      // Record the anchor before fragment lookup so empty-fragment retries can
      // still tell that this footnote call has already been encountered on the
      // current page (Issue #1891).
      context.markPageFloatAnchorSeen(float);
      const pageFloatFragment = strategy.findPageFloatFragment(float, context);
      const continuation = new PageFloats.PageFloatContinuation(
        float,
        nodePosition,
      );
      if (pageFloatFragment && pageFloatFragment.hasFloat(float)) {
        context.registerPageFloatAnchor(float, nodeContextAfter.viewNode);
        return Task.newResult(nodeContextAfter as Vtree.NodeContext);
      }
      if (
        context.isForbidden(float) ||
        context.hasPrecedingFloatsDeferredToNext(float)
      ) {
        context.deferPageFloat(continuation);
        context.registerPageFloatAnchor(float, nodeContextAfter.viewNode);
        return Task.newResult(nodeContextAfter as Vtree.NodeContext);
      } else if (this.nodeContextOverflowingDueToRepetitiveElements) {
        return Task.newResult(null);
      } else {
        const getFootnoteEdgeFromViewNode = (viewNode: Node | null): number => {
          if (!viewNode || viewNode.nodeType !== 1) {
            return NaN;
          }
          const rect = LayoutHelper.getElementClientRectAdjusted(
            this.clientLayout,
            viewNode as Element,
            this.vertical,
          );
          if (rect.right >= rect.left && rect.bottom >= rect.top) {
            return this.vertical ? rect.left : rect.bottom;
          }
          return NaN;
        };
        let edge = LayoutHelper.calculateEdge(
          nodeContextAfter,
          this.clientLayout,
          0,
          this.vertical,
        );
        if (nodeContext.floatSide === "footnote") {
          const footnote = float as Footnote;
          if (footnote.footnotePolicy === Css.ident.line || isNaN(edge)) {
            let anchorContext: Vtree.NodeContext | null = nodeContextAfter;
            while (anchorContext) {
              const sourceNode = anchorContext.shadowContext
                ? anchorContext.shadowContext.owner
                : anchorContext.sourceNode;
              if (sourceNode === footnote.policyAnchorNode) {
                const anchorEdge = getFootnoteEdgeFromViewNode(
                  anchorContext.viewNode,
                );
                if (!isNaN(anchorEdge)) {
                  edge = anchorEdge;
                }
                break;
              }
              anchorContext = anchorContext.parent;
            }
          }
        }
        // For footnotes, calculateEdge may return NaN because footnote-call
        // has vertical-align: super. After trying the rendered anchor context,
        // fall back to the call element's bounding rect to enable
        // footnote fragmentation.
        if (isNaN(edge) && nodeContext.floatSide === "footnote") {
          edge = getFootnoteEdgeFromViewNode(nodeContextAfter.viewNode);
        }
        const skipOverflowPrecheck =
          nodeContext.floatSide === "footnote" &&
          (float as Footnote).footnotePolicy === Css.ident.line;
        if (!skipOverflowPrecheck && this.isOverflown(edge)) {
          return Task.newResult(nodeContextAfter);
        } else {
          if (nodeContext.floatSide === "footnote") {
            context.registerPageFloatAnchor(float, nodeContextAfter.viewNode);
          }
          return this.layoutPageFloatInner(
            continuation,
            strategy,
            edge,
            pageFloatFragment,
          ).thenAsync((success) => {
            Asserts.assert(float);
            if (!success) {
              context.registerPageFloatAnchor(float, nodeContextAfter.viewNode);
              return Task.newResult(nodeContextAfter);
            }
            // Issue #868: For footnotes, return nodeContextAfter so the layout loop
            // continues to process following elements (like text after footnote-call).
            // This ensures footnote-call and following content are processed
            // in the same postLayoutBlock, allowing correct text-spacing.
            if (nodeContext.floatSide === "footnote") {
              const footnote = float as Footnote;
              if (
                footnote.footnotePolicy === Css.ident.line &&
                context.hasInvalidatedForLineFootnote(float)
              ) {
                if (context.isInvalidated()) {
                  return Task.newResult<Vtree.NodeContext | null>(null);
                }
                const continuingFragment = strategy.findPageFloatFragment(
                  float,
                  context,
                );
                if (
                  continuingFragment?.hasFloat(float) &&
                  continuingFragment.continues
                ) {
                  // Issue #2029: keep building the rest of this inline line.
                  // The forced overflow break is resolved later from the full
                  // block checkpoints so text-spacing wrappers and normal line
                  // breaking decide the natural end of the anchor line.
                  this.registerLineFootnoteOverflowEdge(edge);
                  return Task.newResult(nodeContextAfter);
                }
              }
              return Task.newResult(nodeContextAfter);
            }
            // When inside a page float area, return nodeContextAfter to continue
            // processing the remaining content. Without this, the layout terminates
            // early and computedBlockSize doesn't reflect the full CSS box size,
            // resulting in incorrect exclusion float sizing. (Issue #1675)
            if (context.generatingNodePosition) {
              return Task.newResult(nodeContextAfter);
            }
            return Task.newResult<Vtree.NodeContext | null>(null);
          });
        }
      }
    });
  }

  processLineStyling(
    nodeContext: Vtree.NodeContext,
    resNodeContext: Vtree.NodeContext | null,
    checkPoints: Vtree.RenderedNodeContext[],
  ): Task.Result<Vtree.NodeContext | null> {
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("processLineStyling");
    if (VIVLIOSTYLE_DEBUG) {
      validateCheckPoints(checkPoints);
    }
    let lastCheckPoints = [...checkPoints]; // make a copy
    checkPoints.splice(0, checkPoints.length); // make empty
    let totalLineCount = 0;
    let firstPseudo = nodeContext.firstPseudo; // :first-letter is not processed here
    if (firstPseudo?.count === 0) {
      firstPseudo = firstPseudo.outer; // move to line pseudoelement (if any)
    }
    frame
      .loopWithFrame((loopFrame) => {
        if (!firstPseudo) {
          loopFrame.breakLoop();
          return;
        }
        const linePositions = this.findLinePositions(lastCheckPoints);
        const count = firstPseudo.count - totalLineCount;
        if (linePositions.length <= count) {
          loopFrame.breakLoop();
          return;
        }
        const lineBreak = this.findAcceptableBreakInside(
          lastCheckPoints,
          linePositions[count - 1],
          true,
        );
        const childLineBreak =
          lineBreak && VtreeImpl.asChildNodeContext(lineBreak);
        if (!childLineBreak) {
          loopFrame.breakLoop();
          return;
        }
        this.finishBreak(childLineBreak, false, false).then(() => {
          totalLineCount += count;
          this.layoutContext
            .peelOff(childLineBreak, 0)
            .then((resNodeContextParam) => {
              nodeContext = resNodeContextParam;
              firstPseudo = nodeContext.firstPseudo;
              lastCheckPoints = []; // Wipe out line breaks inside pseudoelements
              this.buildViewToNextBlockEdge(nodeContext, lastCheckPoints).then(
                (resNodeContextParam) => {
                  resNodeContext = resNodeContextParam;
                  loopFrame.continueLoop();
                },
              );
            });
        });
      })
      .then(() => {
        checkPoints.push(...lastCheckPoints);
        if (VIVLIOSTYLE_DEBUG) {
          validateCheckPoints(checkPoints);
        }
        frame.finish(resNodeContext);
      });
    return frame.result();
  }

  private registerLineFootnoteOverflowEdge(edge: number): void {
    if (!isFinite(edge)) {
      return;
    }
    const dir = this.getBoxDir();
    if (
      this.lineFootnoteOverflowEdge == null ||
      dir * edge < dir * this.lineFootnoteOverflowEdge
    ) {
      this.lineFootnoteOverflowEdge = edge;
    }
  }

  private findLineFootnoteOverflowBreak(
    checkPoints: Vtree.RenderedNodeContext[],
  ): Vtree.NodeContext | null {
    if (this.lineFootnoteOverflowEdge == null || checkPoints.length === 0) {
      return null;
    }
    const linePositions = this.findLinePositions(checkPoints);
    const dir = this.getBoxDir();
    const tolerance = 1.5 / (this.clientLayout.pixelRatio || 1);
    // Use the first rendered line whose block-end reaches the footnote call.
    // This avoids forcing a break immediately after the call, which can leave
    // an underfull justified line when the following text still fits.
    const linePosition = linePositions.find(
      (position) =>
        dir * (position - this.lineFootnoteOverflowEdge) >= -tolerance,
    );
    if (linePosition == null) {
      return null;
    }
    return this.findAcceptableBreakInside(checkPoints, linePosition, true);
  }

  isLoneImage(checkPoints: Vtree.RenderedNodeContext[]): boolean {
    if (checkPoints.length != 2 && this.breakPositions.length > 0) {
      return false;
    }
    return (
      checkPoints[0].sourceNode == checkPoints[1].sourceNode &&
      Base.mediaTags[(checkPoints[0].sourceNode as Element).localName]
    );
  }

  getTrailingMarginEdgeAdjustment(
    trailingEdgeContexts: Vtree.NodeContext[],
  ): number {
    // Margins push the computed height, but are not counted as overflow. We
    // need to find the overall collapsed margin from all enclosed blocks.
    let maxPos = 0;
    let minNeg = 0;
    for (let i = trailingEdgeContexts.length - 1; i >= 0; i--) {
      const nodeContext = trailingEdgeContexts[i];
      if (!nodeContext) {
        break;
      }
      if (
        !nodeContext.after ||
        !nodeContext.viewNode ||
        nodeContext.viewNode.nodeType != 1
      ) {
        break;
      }
      const margin = this.getComputedMargin(nodeContext.viewNode as Element);
      const m = this.vertical ? -margin.left : margin.bottom;
      if (m > 0) {
        maxPos = Math.max(maxPos, m);
      } else {
        minNeg = Math.min(minNeg, m);
      }
    }
    return maxPos + minNeg;
  }

  /**
   * Layout a single CSS box.
   */
  layoutBreakableBlock(
    nodeContext: Vtree.NodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    const frame: Task.Frame<Vtree.NodeContext | null> = Task.newFrame(
      "layoutBreakableBlock",
    );
    const checkPoints: Vtree.RenderedNodeContext[] = [];
    this.lineFootnoteOverflowEdge = null;
    this.buildViewToNextBlockEdge(nodeContext, checkPoints).then(
      (resNodeContext) => {
        // at this point a single block was appended to the column
        // flowPosition is either null or
        //  - if !after: contains view for the next block element
        //  - if after: contains view for the enclosing block element
        const checkPointIndex = checkPoints.length - 1;
        if (checkPointIndex < 0) {
          frame.finish(resNodeContext);
          return;
        }

        // Text-spacing etc. must be done before calculating edge. (Issue #898)
        this.postLayoutBlock(resNodeContext, checkPoints);

        // Record the height
        // TODO: should this be done after first-line calculation?
        // Suppress ancestor block-end padding/border during edge
        // calculation to prevent false overflow from browser column
        // breaking. (Issue #1846)
        const restoreInset = this.suppressOpenAncestorBlockEndInset(
          resNodeContext ?? nodeContext,
        );
        let edge = this.calculateEdge(
          resNodeContext,
          checkPoints,
          checkPointIndex,
          checkPoints[checkPointIndex].boxOffset,
        );
        restoreInset();
        let overflown = false;
        if (
          !resNodeContext ||
          !LayoutHelper.isOrphan(resNodeContext.viewNode)
        ) {
          const offsets = BreakPosition.calculateOffset(
            resNodeContext,
            this.collectElementsOffset(),
          );
          overflown = this.isOverflown(
            edge + (this.vertical ? -1 : 1) * offsets.minimum,
          );
          if (
            this.isOverflown(
              edge + (this.vertical ? -1 : 1) * offsets.current,
            ) &&
            !this.nodeContextOverflowingDueToRepetitiveElements
          ) {
            this.nodeContextOverflowingDueToRepetitiveElements = resNodeContext;
          }
        }
        if (resNodeContext == null) {
          edge += this.getTrailingMarginEdgeAdjustment(checkPoints);
        }
        this.updateMaxReachedAfterEdge(edge);
        let lineCont: Task.Result<Vtree.NodeContext | null>;
        if (nodeContext.firstPseudo) {
          // possibly need to deal with :first-line and friends
          lineCont = this.processLineStyling(
            nodeContext,
            resNodeContext,
            checkPoints,
          );
        } else {
          lineCont = Task.newResult(resNodeContext);
        }
        lineCont.then((nodeContext) => {
          // Text-spacing etc. must be done before calculating edge. (Issue #898)
          // this.postLayoutBlock(nodeContext, checkPoints);

          const lineFootnoteOverflowBreak =
            this.findLineFootnoteOverflowBreak(checkPoints);
          if (lineFootnoteOverflowBreak) {
            const overflowNodeContext = lineFootnoteOverflowBreak.modify();
            overflowNodeContext.overflow = true;
            overflowNodeContext.pluginProps["lineFootnoteOverflow"] = 1;
            this.breakPositions = [];
            this.saveEdgeBreakPosition(overflowNodeContext, null, true);
            this.lineFootnoteOverflowEdge = null;
            frame.finish(overflowNodeContext);
            return;
          }
          this.lineFootnoteOverflowEdge = null;

          if (checkPoints.length > 0) {
            this.saveBoxBreakPosition(checkPoints);

            // TODO: how to signal overflow in the last pagargaph???
            if (overflown && !this.isLoneImage(checkPoints) && nodeContext) {
              nodeContext = nodeContext.modify();
              nodeContext.overflow = true;
            }
          }
          frame.finish(nodeContext);
        });
      },
    );
    return frame.result();
  }

  postLayoutBlock(
    nodeContext: Vtree.NodeContext | null,
    checkPoints: Vtree.RenderedNodeContext[],
  ) {
    const hooks: Plugin.PostLayoutBlockHook[] = Plugin.getHooksForName(
      Plugin.HOOKS.POST_LAYOUT_BLOCK,
    );
    hooks.forEach((hook) => {
      hook(nodeContext, checkPoints, this);
    });
  }

  findEndOfLine(
    linePosition: number,
    checkPoints: Vtree.RenderedNodeContext[],
    isUpdateMaxReachedAfterEdge: boolean,
  ): {
    nodeContext: Vtree.RenderedNodeContext;
    index: number;
    checkPointIndex: number;
  } {
    if (VIVLIOSTYLE_DEBUG) {
      validateCheckPoints(checkPoints);
    }

    // Workaround for Blink not returning correct fractional values for
    // Range.getClientRects.
    // https://bugs.chromium.org/p/chromium/issues/detail?id=629828
    const effectiveLinePosition = this.vertical
      ? linePosition - 1
      : linePosition + 1;

    // find the first character which is out
    let lowCP = 0;
    let low = checkPoints[0].boxOffset;
    let low1 = lowCP;
    let highCP = checkPoints.length - 1;
    let high = checkPoints[highCP].boxOffset;
    let mid: number;
    while (low < high) {
      mid = low + Math.ceil((high - low) / 2);

      // find the node which contains mid index
      low1 = lowCP;
      let high1 = highCP;
      while (low1 < high1) {
        const mid1 = low1 + Math.ceil((high1 - low1) / 2);
        if (checkPoints[mid1].boxOffset > mid) {
          high1 = mid1 - 1;
        } else {
          low1 = mid1;
        }
      }
      const edge = this.calculateEdge(null, checkPoints, low1, mid);
      if (
        this.vertical
          ? edge <= effectiveLinePosition
          : edge >= effectiveLinePosition
      ) {
        high = mid - 1;
        while (checkPoints[low1].boxOffset == mid) {
          low1--;
        }
        highCP = low1;
      } else {
        if (isUpdateMaxReachedAfterEdge) {
          this.updateMaxReachedAfterEdge(edge);
        }
        low = mid;
        lowCP = low1;
      }
    }
    return {
      nodeContext: checkPoints[low1],
      index: low,
      checkPointIndex: low1,
    };
  }

  findAcceptableBreakInside(
    checkPoints: Vtree.RenderedNodeContext[],
    edgePosition: number,
    force: boolean,
  ): Vtree.NodeContext | null {
    const position = this.findEndOfLine(edgePosition, checkPoints, true);
    const cpNodeContext = position.nodeContext;
    let nodeContext: Vtree.NodeContext = cpNodeContext;

    if (
      position.checkPointIndex === 0 &&
      position.index === nodeContext.boxOffset
    ) {
      // Prevent wrong break at beginning of paragraph (Issue #1401, #1406)
      return null;
    }

    const viewNode = cpNodeContext.viewNode;
    if (
      viewNode.nodeType != 1 &&
      viewNode.parentElement?.localName !== "viv-ts-inner"
    ) {
      const textNode = viewNode as Text;
      const textNodeBreaker = this.resolveTextNodeBreaker(nodeContext);
      nodeContext = textNodeBreaker.breakTextNode(
        textNode,
        cpNodeContext,
        position.index,
        checkPoints,
        position.checkPointIndex,
        force,
      );
    } else {
      // Fix for issue #821, #885, #1459
      const p = LayoutHelper.findAncestorSpecialInlineNodeContext(nodeContext);
      if (p) {
        if (
          this.breakPositions?.[0] instanceof BoxBreakPosition &&
          p.viewNode.contains(this.breakPositions[0].checkPoints[0].viewNode)
        ) {
          // Prevent breaks at beginning of the column
          return null;
        }
        // Prevent breaks inside inline-blocks
        nodeContext = p;

        // Prevent breaks at beginning of paragraph content (Issue #1459)
        while (!nodeContext.after && nodeContext.inline && nodeContext.parent) {
          let node = nodeContext.viewNode?.previousSibling;
          while (
            node &&
            (VtreeImpl.canIgnore(node, nodeContext.parent.whitespace) ||
              LayoutHelper.isOutOfFlow(node))
          ) {
            node = node.previousSibling;
          }
          if (node) {
            break;
          }
          nodeContext = nodeContext.parent;
        }
      }
    }
    this.clearOverflownViewNodes(nodeContext, false);
    return nodeContext;
  }

  resolveTextNodeBreaker(nodeContext: Vtree.NodeContext): TextNodeBreaker {
    const hooks: Plugin.ResolveTextNodeBreakerHook[] = Plugin.getHooksForName(
      Plugin.HOOKS.RESOLVE_TEXT_NODE_BREAKER,
    );
    return hooks.reduce(
      (prev, hook) => hook(nodeContext) || prev,
      TextNodeBreaker.instance,
    );
  }

  /**
   * Read ranges skipping special elements
   */
  getRangeBoxes(
    start: Element | Text,
    end: Element | Text,
  ): Vtree.ClientRect[] {
    const arr: Vtree.ClientRect[] = [];
    let wentUp = false;
    let node: Node = start;
    let lastGood: Node | null = null;
    let rangeStart: RangeClientRects.RangeBoundary | null = null;
    let endNotReached = true;
    while (endNotReached) {
      let seekRange = true;
      do {
        let next: Node | null = null;
        if (node == end) {
          if (end.nodeType === 1) {
            // If end is an element, continue traversing its children to find
            // the last text node inside it. Finish when end has no child or
            // when came back from its children (wentUp==true).
            endNotReached = !(!end.firstChild || wentUp);
          } else {
            endNotReached = false;
          }
        }
        const element = node.nodeType === 1 ? (node as Element) : null;
        if (!element) {
          if (!rangeStart) {
            if (node.parentNode == null) {
              endNotReached = false;
            } else {
              rangeStart = RangeClientRects.before(node);
            }
          }
          lastGood = node;
        } else if (wentUp) {
          wentUp = false;
        } else if (LayoutHelper.isSpecial(element)) {
          // Skip special
          seekRange = !rangeStart;
        } else if (
          !element.firstChild ||
          Base.mediaTags[element.localName] ||
          /^r(uby|[bt]c?)$/.test(element.localName) ||
          LayoutHelper.isSpecialInlineDisplay(
            this.clientLayout.getElementComputedStyle(element).display,
          )
        ) {
          // img, ruby, inline-block, etc.
          seekRange = !rangeStart;
          if (seekRange) {
            if (element.localName === "ruby" && node.firstChild) {
              // Fix for issue #985
              node = node.firstChild;
            }
            rangeStart = RangeClientRects.before(node);
            lastGood = node;
          } else if (!/^r(uby|tc?)$/.test(element.localName)) {
            // Fix for issue #1319 and #1401
            lastGood = node;
          }
          if (node.contains(end)) {
            endNotReached = false;
          }
        } else {
          next = node.firstChild;
        }
        if (!next) {
          next = node.nextSibling;
          if (!next) {
            wentUp = true;
            next = node.parentNode;
          }
        }
        node = next;
      } while (seekRange && endNotReached);
      if (rangeStart) {
        const boxList = RangeClientRects.getLayoutClientRectsBetween(
          this.clientLayout,
          rangeStart,
          RangeClientRects.after(lastGood),
        );

        // Adjust boxes' positions for column breaking
        LayoutHelper.adjustRectsForColumnBreaking(boxList, this.vertical);

        for (let i = 0; i < boxList.length; i++) {
          arr.push(boxList[i]);
        }
        rangeStart = null;
      }
    }
    return arr;
  }

  /**
   * Give block's initial and final nodes, find positions of the line bottoms.
   * This is, of course, somewhat hacky implementation.
   * @return position of line breaks
   */
  findLinePositions(checkPoints: Vtree.RenderedNodeContext[]): number[] {
    const LOW_OVERLAP = 0.2;
    const MID_OVERLAP = 0.6;
    const positions: number[] = [];
    const boxes = this.getRangeBoxes(
      checkPoints[0].viewNode,
      checkPoints.at(-1).viewNode,
    );
    boxes.sort(
      this.vertical
        ? VtreeImpl.clientrectDecreasingRight
        : VtreeImpl.clientrectIncreasingTop,
    );
    let lineBefore = 0;
    let lineAfter = 0;
    let lineEnd = 0;
    let lineLength = 0;
    let i = 0;
    const dir = this.getBoxDir();
    while (true) {
      if (i < boxes.length) {
        const box = boxes[i];
        let overlap = 1;
        if (lineLength > 0) {
          const boxSize = Math.max(this.getBoxSize(box), 1);
          if (dir * this.getBeforeEdge(box) < dir * lineBefore) {
            overlap = (dir * (this.getAfterEdge(box) - lineBefore)) / boxSize;
          } else if (dir * this.getAfterEdge(box) > dir * lineAfter) {
            overlap = (dir * (lineAfter - this.getBeforeEdge(box))) / boxSize;
          } else {
            overlap = 1;
          }
        }
        if (
          lineLength == 0 ||
          overlap >= MID_OVERLAP ||
          (overlap >= LOW_OVERLAP && this.getStartEdge(box) >= lineEnd - 1)
        ) {
          lineEnd = this.getEndEdge(box);
          if (this.vertical) {
            lineBefore =
              lineLength == 0 ? box.right : Math.max(lineBefore, box.right);
            lineAfter =
              lineLength == 0 ? box.left : Math.min(lineAfter, box.left);
          } else {
            lineBefore =
              lineLength == 0 ? box.top : Math.min(lineBefore, box.top);
            lineAfter =
              lineLength == 0 ? box.bottom : Math.max(lineAfter, box.bottom);
          }
          lineLength++;
          i++;
          continue;
        }
      }

      // Add line
      if (lineLength > 0) {
        positions.push(lineAfter);
        lineLength = 0;
      }
      if (i >= boxes.length) {
        break;
      }
    }
    positions.sort(Base.numberCompare);
    if (this.vertical) {
      positions.reverse();
    }
    return positions;
  }

  calculateClonedPaddingBorder(nodeContext: Vtree.NodeContext): number {
    let clonedPaddingBorder = 0;
    for (let nc: Vtree.NodeContext | null = nodeContext; nc; nc = nc.parent) {
      if (
        !nc.inline &&
        Break.isCloneBoxDecorationBreak(nc.viewNode as Element)
      ) {
        const paddingBorders = this.getComputedPaddingBorder(
          nc.viewNode as Element,
        );
        clonedPaddingBorder += nc.vertical
          ? -paddingBorders.left
          : paddingBorders.bottom;
        if (nc.display === "table") {
          clonedPaddingBorder += (nc.vertical ? -1 : 1) * nc.blockBorderSpacing;
        }
      }
    }
    return clonedPaddingBorder;
  }

  private getOffsetByRepetitiveElements(
    bp?: BreakPosition.BreakPosition,
  ): number {
    let offset: { current: number; minimum: number };
    if (bp) {
      offset = bp.calculateOffset(this);
    } else {
      offset = BreakPosition.calculateOffset(
        null,
        this.collectElementsOffset(),
      );
    }
    return offset.current;
  }

  findBoxBreakPosition(
    bp: BoxBreakPosition,
    force: boolean,
  ): Vtree.NodeContext | null {
    // Workaround for issue #816 (Text with ruby overflowed at column/page break)
    const parentNode = this.element.parentNode;
    const nextSibling = this.element.nextSibling;
    parentNode.removeChild(this.element);
    parentNode.insertBefore(this.element, nextSibling);

    const checkPoints = bp.checkPoints;
    let block: Vtree.NodeContext = checkPoints[0];
    while (block.parent && block.inline) {
      block = block.parent;
    }
    let widows: number;
    let orphans: number;
    if (force && !this.isFootnote) {
      // Last resort, ignore widows/orphans
      // (but keep enforcing them for footnotes to avoid violating
      // widows/orphans when fragmenting footnotes across pages)
      widows = 1;
      orphans = 1;
    } else {
      // Get widows/orphans settings from the block element
      widows = Math.max(
        ((block.inheritedProps["widows"] as number) || 2) - 0,
        1,
      );
      orphans = Math.max(
        ((block.inheritedProps["orphans"] as number) || 2) - 0,
        1,
      );
    }

    // In case of box-decoration-break: clone, width (or height in vertical
    // writing mode) of cloned paddings and borders should be taken into
    // account.
    const clonedPaddingBorder = this.calculateClonedPaddingBorder(block);

    // Select the first overflowing line break position
    const linePositions = this.findLinePositions(checkPoints);
    let edge = this.footnoteEdge - clonedPaddingBorder;
    const dir = this.getBoxDir();
    const repetitiveElementsOffset = this.getOffsetByRepetitiveElements(bp);
    edge -= dir * repetitiveElementsOffset;

    // If an "overflowing" checkpoint (e.g. not allowed by LayoutConstraint)
    // exists before the edge, a line containing the checkpoint should be
    // deferred to the next column.
    const firstOverflowing =
      this.findFirstOverflowingEdgeAndCheckPoint(checkPoints);
    if (isNaN(firstOverflowing.edge)) {
      firstOverflowing.edge = dir * Infinity;
    }
    let lineIndex = Base.binarySearch(linePositions.length, (i) => {
      const p = linePositions[i];
      return this.vertical
        ? p < edge || p <= firstOverflowing.edge
        : p > edge || p >= firstOverflowing.edge;
    });

    // If no break point is found due to the "overflowing" checkpoint,
    // give up deferring a line containing the checkpoint and try to cut the
    // line just before it.
    const forceCutBeforeOverflowing = lineIndex <= 0;
    if (forceCutBeforeOverflowing) {
      lineIndex = Base.binarySearch(linePositions.length, (i) =>
        this.vertical ? linePositions[i] < edge : linePositions[i] > edge,
      );
    }

    // Workaround for the case of block child after text in parent block
    // (Issue #1036)
    let lastNode = checkPoints.at(-1).viewNode;
    lastNode = LayoutHelper.textSpacingWrapperOf(lastNode) ?? lastNode;
    if (
      (lineIndex === linePositions.length && lastNode.nextSibling) ||
      (lineIndex >= linePositions.length - 1 &&
        lastNode.parentElement?.querySelector(".MJXc-display")) // for MathJax
    ) {
      // Prevent unnecessary page break before the last line
      // when a block box (may be generated by MathJax) exists
      // just after the text or inline box.
      // Use a special value widows=0 to allow breaking after the last line.
      // Keep orphans at the minimum valid constraint (1), otherwise
      // lineIndex < orphans may wrongly reject this break (Issue #1709).
      widows = 0;
      orphans = 1;
    }

    // First edge after the one that both fits and satisfies widows constraint.
    lineIndex = Math.min(linePositions.length - widows, lineIndex);
    if (lineIndex < orphans) {
      // Not enough lines to satisfy orphans constraint, cannot break here.
      return null;
    }
    edge = linePositions[lineIndex - 1];
    let nodeContext: Vtree.NodeContext | null;
    if (forceCutBeforeOverflowing) {
      nodeContext = firstOverflowing.checkPoint;
    } else {
      nodeContext = this.findAcceptableBreakInside(bp.checkPoints, edge, force);
    }
    if (nodeContext) {
      // When line-height is small, the edge calculated above (using Range)
      // can be larger than the edge of the block container containing the text.
      // We update the edge by measuring the block edge.
      const blockEdge = this.getAfterEdgeOfBlockContainer(nodeContext);
      if (!isNaN(blockEdge) && dir * (edge - blockEdge) > 0) {
        edge = blockEdge;
      }
      this.computedBlockSize =
        dir * (edge - this.beforeEdge) + repetitiveElementsOffset;
      // Store line stride for column balancing half-leading correction.
      // Use the stride around the actual break line instead of always
      // assuming the first two lines have the representative stride.
      if (linePositions.length >= 2) {
        const strideIndex = Math.max(
          1,
          Math.min(lineIndex - 1, linePositions.length - 1),
        );
        this.lastLineStride = Math.abs(
          linePositions[strideIndex] - linePositions[strideIndex - 1],
        );
      }
    }
    return nodeContext;
  }

  getAfterEdgeOfBlockContainer(nodeContext: Vtree.NodeContext): number {
    let blockParent: Vtree.NodeContext | null = nodeContext;
    do {
      blockParent = blockParent.parent;
    } while (blockParent && blockParent.inline);
    if (blockParent) {
      blockParent = blockParent.copy().modify();
      blockParent.after = true;
      return LayoutHelper.calculateEdge(
        blockParent,
        this.clientLayout,
        0,
        this.vertical,
      );
    } else {
      return NaN;
    }
  }

  findFirstOverflowingEdgeAndCheckPoint(
    checkPoints: Vtree.RenderedNodeContext[],
  ): {
    edge: number;
    checkPoint: Vtree.RenderedNodeContext | null;
  } {
    const index = checkPoints.findIndex((cp) => cp.overflow);
    if (index < 0) {
      return { edge: NaN, checkPoint: null };
    }
    const cp = checkPoints[index];
    return {
      edge: this.calculateEdge(null, checkPoints, index, cp.boxOffset),
      checkPoint: cp,
    };
  }

  findEdgeBreakPosition(
    bp: BreakPosition.EdgeBreakPosition,
  ): Vtree.NodeContext {
    this.computedBlockSize =
      bp.computedBlockSize + this.getOffsetByRepetitiveElements(bp);
    return bp.position;
  }

  /**
   * Finalize a line break.
   * @return holing true
   */
  finishBreak(
    nodeContext: Vtree.NodeContext,
    forceRemoveSelf: boolean,
    endOfColumn: boolean,
  ): Task.Result<boolean> {
    const layoutProcessor = new LayoutProcessor.LayoutProcessorResolver().find(
      nodeContext.formattingContext,
    );
    let result = layoutProcessor.finishBreak(
      this,
      nodeContext,
      forceRemoveSelf,
      endOfColumn,
    );
    if (!result) {
      result = LayoutProcessor.blockLayoutProcessor.finishBreak(
        this,
        nodeContext,
        forceRemoveSelf,
        endOfColumn,
      );
    }
    return result;
  }

  findAcceptableBreakPosition(): BreakPositionAndNodeContext | null {
    let found: BreakPositionAndNodeContext | null = null;
    let penalty = 0;
    let nextPenalty = 0;
    do {
      penalty = nextPenalty;
      nextPenalty = Number.MAX_VALUE;
      for (let i = this.breakPositions.length - 1; i >= 0 && !found; --i) {
        const bp = this.breakPositions[i];
        const nodeContext = bp.findAcceptableBreak(this, penalty);
        if (nodeContext) {
          found = { breakPosition: bp, nodeContext };
        }
        const minPenalty = bp.getMinBreakPenalty();
        if (minPenalty > penalty) {
          nextPenalty = Math.min(nextPenalty, minPenalty);
        }
      }
    } while (
      // Don't need to find a non-optimal break position if
      // forceNonfitting=false
      nextPenalty > penalty &&
      !found &&
      this.forceNonfitting
    );
    return found;
  }

  doFinishBreak(
    nodeContext: Vtree.NodeContext | null,
    overflownNodeContext: Vtree.NodeContext | null,
    initialNodeContext: Vtree.NodeContext | null,
    initialComputedBlockSize: number,
  ): Task.Result<Vtree.NodeContext | null> {
    if (
      this.pageFloatLayoutContext.isInvalidated() ||
      this.pageBreakType ||
      !overflownNodeContext
    ) {
      return Task.newResult(nodeContext);
    }
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("doFinishBreak");
    let forceRemoveSelf = false;
    if (!nodeContext) {
      // Last resort
      if (this.forceNonfitting && !this.isFootnote) {
        Logging.logger.warn("Could not find any page breaks?!!");
        this.skipTailEdges(overflownNodeContext).then((nodeContext) => {
          if (nodeContext) {
            nodeContext = nodeContext.modify();
            nodeContext.overflow = false;
            this.finishBreak(nodeContext, forceRemoveSelf, true).then(() => {
              frame.finish(nodeContext);
            });
          } else {
            frame.finish(nodeContext);
          }
        });
        return frame.result();
      } else {
        nodeContext = initialNodeContext;
        forceRemoveSelf = true;
        this.computedBlockSize = initialComputedBlockSize;
      }
    }
    this.finishBreak(nodeContext, forceRemoveSelf, true).then(() => {
      frame.finish(nodeContext);
    });
    return frame.result();
  }

  /**
   * Determines if a page break is acceptable at this position
   */
  isBreakable(flowPosition: Vtree.NodeContext): boolean {
    for (let nc: Vtree.NodeContext | null = flowPosition; nc; nc = nc.parent) {
      if (LayoutHelper.isOutOfFlow(nc.viewNode)) {
        return false;
      }
    }
    if (flowPosition.after) {
      return true; // may be an empty block
    }
    switch ((flowPosition.sourceNode as Element).namespaceURI) {
      case Base.NS.SVG:
        return false;
    }
    return !flowPosition.flexContainer;
  }

  /**
   * Determines if a CSS length value is empty or zero.
   */
  isZeroLength(val: string): boolean {
    const s = val.trim();
    return s === "" || /^0+(?:\.0+)?(?:[a-z%]*)$/i.test(s);
  }

  /**
   * Check if element has non-zero block-start inset (padding + border).
   * Handles both horizontal and vertical writing modes.
   */
  hasNonZeroBlockStartInset(style: CSSStyleDeclaration): boolean {
    if (this.vertical) {
      return !(
        this.isZeroLength(style.paddingRight) &&
        this.isZeroLength(style.borderRightWidth)
      );
    } else {
      return !(
        this.isZeroLength(style.paddingTop) &&
        this.isZeroLength(style.borderTopWidth)
      );
    }
  }

  /**
   * Check if element has non-zero block-end inset (padding + border).
   * Handles both horizontal and vertical writing modes.
   */
  hasNonZeroBlockEndInset(style: CSSStyleDeclaration): boolean {
    if (this.vertical) {
      return !(
        this.isZeroLength(style.paddingLeft) &&
        this.isZeroLength(style.borderLeftWidth)
      );
    } else {
      return !(
        this.isZeroLength(style.paddingBottom) &&
        this.isZeroLength(style.borderBottomWidth)
      );
    }
  }

  /**
   * Temporarily suppress block-end padding/border on ancestor containers
   * that are still being laid out (not yet complete) when using browser
   * column breaking for overflow detection. This prevents the browser's
   * column-breaking layout from incorrectly accounting for padding that
   * will be removed at actual break points due to box-decoration-break:
   * slice (the default). (Issue #1846)
   *
   * Returns a cleanup function that restores the original state.
   */
  private suppressOpenAncestorBlockEndInset(
    nodeContext: Vtree.NodeContext,
  ): () => void {
    if (!LayoutHelper.isUsingBrowserColumnBreaking(this)) {
      return () => {};
    }
    const saved: { element: Element; original: string | null }[] = [];
    for (let nc = nodeContext?.parent; nc; nc = nc.parent) {
      if (nc.after || nc.inline) {
        continue;
      }
      const element = nc.viewNode as Element;
      if (!element || element.nodeType !== 1) {
        continue;
      }
      if (Break.isCloneBoxDecorationBreak(element)) {
        continue;
      }
      const style = this.clientLayout.getElementComputedStyle(element);
      if (style && !this.hasNonZeroBlockEndInset(style)) {
        continue;
      }
      const original = element.getAttribute("data-viv-box-break");
      Break.setBoxBreakFlag(element, "block-end");
      saved.push({ element, original });
    }
    return () => {
      for (const { element, original } of saved) {
        if (original === null) {
          element.removeAttribute("data-viv-box-break");
        } else {
          element.setAttribute("data-viv-box-break", original);
        }
      }
    };
  }

  /**
   * @return true if overflows
   */
  checkOverflowAndSaveEdge(
    nodeContext: Vtree.NodeContext | null,
    trailingEdgeContexts: Vtree.NodeContext[] | null,
  ): boolean {
    if (!nodeContext) {
      return false;
    }
    for (let nc: Vtree.NodeContext | null = nodeContext; nc; nc = nc.parent) {
      if (LayoutHelper.isOutOfFlow(nc.viewNode)) {
        return false;
      }
    }
    if (LayoutHelper.isOrphan(nodeContext.viewNode)) {
      return false;
    }
    const restoreInset = this.suppressOpenAncestorBlockEndInset(nodeContext);
    let edge = LayoutHelper.calculateEdge(
      nodeContext,
      this.clientLayout,
      0,
      this.vertical,
    );
    restoreInset();
    const offsets = BreakPosition.calculateOffset(
      nodeContext,
      this.collectElementsOffset(),
    );
    const overflown = this.isOverflown(
      edge + (this.vertical ? -1 : 1) * offsets.minimum,
    );
    if (
      this.isOverflown(edge + (this.vertical ? -1 : 1) * offsets.current) &&
      !this.nodeContextOverflowingDueToRepetitiveElements
    ) {
      this.nodeContextOverflowingDueToRepetitiveElements = nodeContext;
    } else if (trailingEdgeContexts) {
      // If the edge does not overflow add the trailing margin, which is
      // truncated to the remaining fragmentainer extent.
      const marginEdge =
        edge + this.getTrailingMarginEdgeAdjustment(trailingEdgeContexts);
      const footnoteEdge =
        this.footnoteEdge - this.getBoxDir() * offsets.current;
      edge = this.vertical
        ? Math.min(edge, Math.max(marginEdge, footnoteEdge))
        : Math.max(edge, Math.min(marginEdge, footnoteEdge));
    }
    this.updateMaxReachedAfterEdge(edge);
    return overflown;
  }

  /**
   * Save a possible page break position on a CSS block edge. Check if it
   * overflows.
   * @return true if overflows
   */
  checkOverflowAndSaveEdgeAndBreakPosition(
    nodeContext: Vtree.NodeContext | null,
    trailingEdgeContexts: Vtree.NodeContext[] | null,
    saveEvenOverflown: boolean,
    breakAtTheEdge: string | null,
  ): boolean {
    if (!nodeContext) {
      return false;
    }
    if (LayoutHelper.isOrphan(nodeContext.viewNode)) {
      return false;
    }
    const overflown = this.checkOverflowAndSaveEdge(
      nodeContext,
      trailingEdgeContexts,
    );
    if (saveEvenOverflown || !overflown) {
      this.saveEdgeBreakPosition(nodeContext, breakAtTheEdge, overflown);
    }
    return overflown;
  }

  applyClearance(nodeContext: Vtree.RenderedNodeContext): boolean {
    if (!nodeContext.viewNode.parentNode) {
      // Cannot do clearance for nodes without parents
      return false;
    }
    if (nodeContext.floatReference !== PageFloats.FloatReference.INLINE) {
      // For page floats, clearance is handled differently
      return false;
    }
    if (nodeContext.floatSide) {
      // Clear on inline floats is handled in layoutFloat()
      return false;
    }

    const clear =
      (nodeContext.clearSide === "same"
        ? nodeContext.floatSide
        : nodeContext.clearSide) ?? "";
    const useRawSpacerGeometry = /^(page|column|region)$/.test(clear);
    // measure where the edge of the element would be without clearance
    const margin = this.getComputedMargin(nodeContext.viewNode as Element);
    const spacer = nodeContext.viewNode.ownerDocument.createElement("div");
    if (this.vertical) {
      spacer.style.bottom = "0px";
      spacer.style.width = "1px";
      spacer.style.marginRight = `${margin.right}px`;
    } else {
      spacer.style.right = "0px";
      spacer.style.height = "1px";
      spacer.style.marginTop = `${margin.top}px`;
    }
    const getSpacerBox = () =>
      useRawSpacerGeometry
        ? this.clientLayout.getElementClientRect(spacer)
        : LayoutHelper.getElementClientRectAdjusted(
            this.clientLayout,
            spacer,
            this.vertical,
          );
    nodeContext.viewNode.parentNode.insertBefore(spacer, nodeContext.viewNode);
    // Use raw spacer geometry for page/column/region clears. Browser
    // column-breaking adjustment can move the following cleared block outside
    // the page area. (Issue #2010)
    let spacerBox = getSpacerBox();
    const edge = this.getBeforeEdge(spacerBox);
    const dir = this.getBoxDir();
    const clearLR =
      /^(top|bottom|inside|outside|(block|inline)-(start|end))$/.test(clear)
        ? PageFloats.resolveInlineFloatDirection(
            clear,
            nodeContext.vertical,
            nodeContext.direction,
            (this.layoutContext as Vgen.ViewFactory).page.side,
          )
        : clear;

    const clearLogical =
      clearLR === "left" || clearLR === "right"
        ? (nodeContext.direction === "rtl") === (clearLR === "left")
          ? "inline-end"
          : "inline-start"
        : clearLR;

    let clearEdge = this.pageFloatLayoutContext.getPageFloatClearEdge(
      clearLogical,
      this,
    );
    const pageFloatClearEdge = clearEdge;

    switch (clearLR) {
      case "left":
        clearEdge = dir * Math.max(clearEdge * dir, this.leftFloatEdge * dir);
        break;
      case "right":
        clearEdge = dir * Math.max(clearEdge * dir, this.rightFloatEdge * dir);
        break;
      default:
        clearEdge =
          dir *
          Math.max(
            clearEdge * dir,
            Math.max(this.rightFloatEdge * dir, this.leftFloatEdge * dir),
          );
    }

    // edge holds the position where element border "before" edge will be
    // without clearance. clearEdge is the "after" edge of the float to clear.

    // Round clearEdge to the next float unit boundary to account for
    // exclusion float height rounding in createFloats(). Add an extra unit
    // margin only when the clear edge comes from inline float edges
    // (leftFloatEdge/rightFloatEdge), which are subject to sub-pixel
    // rendering differences with exclusion floats. Page/column float clear
    // edges from getPageFloatClearEdge() are accurate DOM measurements and
    // don't need the extra margin. (Issue #1803)
    // Only apply rounding when actual inline floats have been laid out
    // (leftFloatEdge or rightFloatEdge moved past beforeEdge). Without this
    // guard, clearEdge equals beforeEdge (since leftFloatEdge/rightFloatEdge
    // are initialized to beforeEdge in measure()), and Math.ceil rounding
    // can push clearEdge past edge + tolerance, creating unnecessary
    // clearance that causes infinite page generation. (Issue #1959)
    const floatUnit = this.getFloatLayoutUnit();
    const hasInlineFloats =
      this.leftFloatEdge * dir > this.beforeEdge * dir ||
      this.rightFloatEdge * dir > this.beforeEdge * dir;
    if (floatUnit > 0 && hasInlineFloats) {
      const inlineFloatEdgeDominates =
        clearEdge * dir > pageFloatClearEdge * dir;
      clearEdge =
        dir *
        (Math.ceil((clearEdge * dir) / floatUnit) +
          (inlineFloatEdgeDominates ? 1 : 0)) *
        floatUnit;
    }

    // tolerance to avoid unnecessary clearance due to the pixel rounding errors
    // (Issue #1608)
    const tolerance = this.getFloatLayoutTolerance(floatUnit);
    if (edge * dir + tolerance > clearEdge * dir) {
      // No need for clearance
      nodeContext.viewNode.parentNode.removeChild(spacer);
      return false;
    } else {
      // Need some clearance, determine how much. Add the clearance node,
      // measure its after edge and adjust after margin (required due to
      // possible margin collapse before clearance was introduced).
      const height = Math.max(1, (clearEdge - edge) * dir);
      if (this.vertical) {
        spacer.style.width = `${height}px`;
      } else {
        spacer.style.height = `${height}px`;
      }
      spacerBox = getSpacerBox();
      const afterEdge = this.getAfterEdge(spacerBox);
      if (!nodeContext.floatSide) {
        if (this.vertical) {
          let wAdj = afterEdge - margin.right - clearEdge;
          if (wAdj > 0 == margin.right >= 0) {
            // In addition to collapsed portion
            wAdj += margin.right;
          }
          spacer.style.marginLeft = `${wAdj}px`;
        } else {
          let hAdj = clearEdge - (afterEdge + margin.top);
          if (hAdj > 0 == margin.top >= 0) {
            // In addition to collapsed portion
            hAdj += margin.top;
          }
          spacer.style.marginBottom = `${hAdj}px`;
        }
      }
      nodeContext.clearSpacer = spacer;
      return true;
    }
  }

  isBFC(formattingContext: Vtree.FormattingContext): boolean {
    if (LayoutProcessor.isInstanceOfBlockFormattingContext(formattingContext)) {
      return true;
    }
    if (
      RepetitiveElement.isInstanceOfRepetitiveElementsOwnerFormattingContext(
        formattingContext,
      )
    ) {
      return true;
    }
    return false;
  }

  /**
   * Check if the nodeContext has a position:fixed ancestor in the view tree.
   * Used to detect text inside running elements (position:running() rendered
   * as position:fixed). (Issue #1833)
   */
  hasFixedPositionAncestor(nodeContext: Vtree.NodeContext): boolean {
    for (let nc: Vtree.NodeContext | null = nodeContext; nc; nc = nc.parent) {
      if (LayoutHelper.isFixedPositioned(nc.viewNode)) {
        return true;
      }
    }
    return false;
  }

  /**
   * Skips positions until either the start of unbreakable block or inline
   * content. Also sets breakBefore on the result combining break-before and
   * break-after properties from all elements that meet at the edge.
   */
  skipEdges(
    initialNodeContext: Vtree.NodeContext,
    leadingEdge: boolean,
    forcedBreakValue: string | null,
  ): Task.Result<Vtree.NodeContext | null> {
    let nodeContext: Vtree.NodeContext | null = initialNodeContext;
    const fc = nodeContext.after
      ? nodeContext.parent?.formattingContext
      : nodeContext.formattingContext;
    if (fc && !this.isBFC(fc)) {
      return Task.newResult(nodeContext);
    }
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("skipEdges");
    const column = this;

    // If a forced break occurred at the end of the previous column,
    // nodeContext.after should be false.
    let atUnforcedBreak =
      !forcedBreakValue && leadingEdge && nodeContext && nodeContext.after;
    let breakAtTheEdge = forcedBreakValue;
    let lastAfterNodeContext: Vtree.ElementNodeContext | null = null;
    let leadingEdgeContexts: Vtree.RenderedNodeContext[] = [];
    let trailingEdgeContexts: Vtree.NodeContext[] = [];
    let onStartEdges = false;

    // Issue #1842: if a stronger page/spread break wins at the page's first
    // column, drop weaker ancestor column breaks so they do not fire again
    // later.
    function suppressWeakerLeadingColumnBreaks(
      currentNodeContext: Vtree.NodeContext,
    ): void {
      if (
        !leadingEdge ||
        column.isNonFirstColumn ||
        forcedBreakValue ||
        !Break.isPageLevelForcedBreak(breakAtTheEdge)
      ) {
        return;
      }
      for (
        let nc: Vtree.NodeContext | null = currentNodeContext;
        nc;
        nc = nc.parent
      ) {
        if (nc.breakBefore === "column") {
          nc.breakBefore = null;
        }
        if (nc.viewNode?.nodeType === 1) {
          const elem = nc.viewNode as HTMLElement;
          if (elem.style?.breakBefore === "column") {
            elem.style.breakBefore = "";
          }
        }
      }
    }

    // Issue #1842: a column break at the start of a follow-up column is already
    // satisfied by the overflow that moved us into this column.
    function consumeSatisfiedLeadingColumnBreak(
      currentNodeContext: Vtree.NodeContext,
    ): void {
      if (
        !leadingEdge ||
        !column.isNonFirstColumn ||
        forcedBreakValue ||
        breakAtTheEdge !== "column"
      ) {
        return;
      }
      for (
        let nc: Vtree.NodeContext | null = currentNodeContext;
        nc;
        nc = nc.parent
      ) {
        if (nc.breakBefore === "column") {
          nc.breakBefore = null;
        }
        if (nc.viewNode?.nodeType === 1) {
          const elem = nc.viewNode as HTMLElement;
          if (elem.style?.breakBefore === "column") {
            elem.style.breakBefore = "";
          }
        }
      }
      breakAtTheEdge = null;
    }

    function suppressWeakerTrailingColumnBreaks(
      currentNodeContext: Vtree.NodeContext,
    ): void {
      if (forcedBreakValue || !Break.isPageLevelForcedBreak(breakAtTheEdge)) {
        return;
      }
      for (
        let nc: Vtree.NodeContext | null = currentNodeContext;
        nc;
        nc = nc.parent
      ) {
        if (nc.breakAfter === "column") {
          nc.breakAfter = null;
        }
        if (nc.viewNode?.nodeType === 1) {
          const elem = nc.viewNode as HTMLElement;
          if (elem.style?.breakAfter === "column") {
            elem.style.breakAfter = "";
          }
        }
      }
    }

    function setBreakAtTheEdge(nextBreakValue: string | null): void {
      breakAtTheEdge = Break.resolveEffectiveBreakValue(
        breakAtTheEdge,
        nextBreakValue,
      );
    }

    function allowLayout(nodeContext: Vtree.NodeContext): boolean {
      if (column.layoutConstraint.allowLayout(nodeContext)) {
        return true;
      }
      if (
        !leadingEdge ||
        column.isNonFirstColumn ||
        forcedBreakValue ||
        !Break.isPageLevelForcedBreak(breakAtTheEdge)
      ) {
        return false;
      }
      const allowedAfterPageBreak =
        column.layoutConstraint.allowLayoutAfterPageBreak?.(nodeContext) ??
        false;
      if (allowedAfterPageBreak) {
        // The page-level break has already been satisfied by entering this
        // page. Consume it only when it is what allows this exact node to move
        // earlier; keeping a broader flag here changes later, unrelated break
        // combinations on the same leading edge.
        breakAtTheEdge = null;
      }
      return allowedAfterPageBreak;
    }

    function needForcedBreak(): boolean {
      if (forcedBreakValue) {
        return true;
      }
      if (!Break.isForcedBreakValue(breakAtTheEdge)) {
        return false;
      }
      if (leadingEdge) {
        // Issue #1842: allow page/spread breaks at the start of overflowed
        // columns, but still suppress column/region breaks already satisfied by
        // entering that column.
        return (
          column.isNonFirstColumn &&
          breakAtTheEdge !== "column" &&
          breakAtTheEdge !== "region"
        );
      }
      return (
        // prevent unnecessary breaks at the beginning of the column/page
        // after out-of-flow elements, e.g. position:absolute or running().
        // (Issue #1176)
        !atLeadingEdgeIgnoringOutOfFlow() &&
        !atLeadingEdgeAfterOnlyOutOfFlowSiblings()
      );
    }

    function atLeadingEdgeIgnoringOutOfFlow(): boolean {
      if (!lastAfterNodeContext) {
        return false;
      }
      // Exclude if itself is a float (Issue #1288)
      if (!nodeContext || nodeContext.floatSide) {
        return false;
      }
      for (
        let nc: Vtree.NodeContext | null = lastAfterNodeContext;
        nc?.parent;
        nc = nc.parent
      ) {
        // Skip levels inside out-of-flow ancestors (e.g. position:running()
        // rendered as position:fixed). Child nodes of out-of-flow elements
        // should not prevent break suppression at the page start.
        // (Issue #1833)
        if (
          nc.parent.viewNode &&
          LayoutHelper.isOutOfFlow(nc.parent.viewNode)
        ) {
          continue;
        }
        let node = nc.after ? nc.viewNode : nc.viewNode?.previousSibling;
        while (
          node &&
          (VtreeImpl.canIgnore(node, nc.parent.whitespace) ||
            LayoutHelper.isOutOfFlow(node))
        ) {
          node = node.previousSibling;
        }
        if (node) {
          return false;
        }
      }
      return true;
    }

    // Issue #1915: if a normal-flow element is preceded only by out-of-flow
    // siblings, treat it like the leading edge and suppress an extra forced
    // break. Keep pseudo/shadow-generated content out of this special case.
    function atLeadingEdgeAfterOnlyOutOfFlowSiblings(): boolean {
      if (
        lastAfterNodeContext ||
        !nodeContext?.viewNode ||
        nodeContext.shadowContext ||
        nodeContext.after ||
        nodeContext.floatSide ||
        !nodeContext.parent?.viewNode ||
        LayoutHelper.isOutOfFlow(nodeContext.parent.viewNode)
      ) {
        return false;
      }
      let sawOutOfFlowSibling = false;
      for (let nc = nodeContext; nc?.parent && !nc.after; nc = nc.parent) {
        if (nc !== nodeContext && LayoutHelper.isOutOfFlow(nc.viewNode)) {
          return false;
        }
        let node = nc.viewNode?.previousSibling;
        while (
          node &&
          (VtreeImpl.canIgnore(node, nc.parent.whitespace) ||
            LayoutHelper.isOutOfFlow(node))
        ) {
          if (LayoutHelper.isOutOfFlow(node)) {
            sawOutOfFlowSibling = true;
          }
          node = node.previousSibling;
        }
        if (node) {
          return false;
        }
      }
      return sawOutOfFlowSibling;
    }

    const processForcedBreak = (current: Vtree.RenderedNodeContext) => {
      const target = leadingEdgeContexts[0] || current;
      nodeContext = target;
      target.viewNode.remove();
      this.pageBreakType = breakAtTheEdge;
    };

    frame
      .loopWithFrame((loopFrame) => {
        while (nodeContext) {
          const layoutProcessor =
            new LayoutProcessor.LayoutProcessorResolver().find(
              nodeContext.formattingContext,
            );

          // A code block to be able to use break. Break moves to the next
          // node position.
          do {
            const rendered = VtreeImpl.asRenderedNodeContext(nodeContext);
            if (!rendered) {
              // Non-displayable content, skip
              break;
            }
            if (nodeContext.inline && rendered.viewNode.nodeType != 1) {
              if (
                VtreeImpl.canIgnore(rendered.viewNode, nodeContext.whitespace)
              ) {
                // Ignorable text content, skip
                break;
              }
              // Text inside running elements (position:running() rendered
              // as position:fixed) should not be treated as in-flow content
              // for break detection. Only check position:fixed ancestors,
              // not position:absolute, to avoid breaking abspos layout.
              // (Issue #1833, #1869, #1870)
              if (this.hasFixedPositionAncestor(nodeContext)) {
                break;
              }
              if (!nodeContext.after) {
                setBreakAtTheEdge(nodeContext.breakBefore);
                suppressWeakerLeadingColumnBreaks(nodeContext);
                consumeSatisfiedLeadingColumnBreak(nodeContext);
                // Leading edge of non-empty block -> finished going through
                // all starting edges of the box
                if (needForcedBreak()) {
                  processForcedBreak(rendered);
                } else if (
                  this.checkOverflowAndSaveEdgeAndBreakPosition(
                    lastAfterNodeContext,
                    null,
                    true,
                    breakAtTheEdge,
                  )
                ) {
                  nodeContext = (
                    this.stopAtOverflow
                      ? lastAfterNodeContext || nodeContext
                      : nodeContext
                  ).modify();
                  nodeContext.overflow = true;
                } else {
                  // When lastAfterNodeContext is null (no in-flow trailing
                  // edge before this content, e.g. after CSS floats
                  // converted to position:absolute) and no block-level
                  // leading edges were encountered (bare inline text
                  // directly after the float), save a break position at
                  // the content start. This parallels the block-level
                  // break opportunity saved for Issue #611 below.
                  // The leadingEdge guard prevents break positions at the
                  // very start of a column (first layoutNext call).
                  // (Issue #1786)
                  if (
                    !lastAfterNodeContext &&
                    !leadingEdge &&
                    leadingEdgeContexts.length === 0
                  ) {
                    this.saveEdgeBreakPosition(
                      nodeContext,
                      breakAtTheEdge,
                      false,
                    );
                  }
                  nodeContext = nodeContext.modify();
                  nodeContext.breakBefore = breakAtTheEdge;
                }
                loopFrame.breakLoop();
                return;
              }
            }
            if (!nodeContext.after) {
              if (nodeContext.floatSide) {
                // Save break-after:avoid* value at before the float
                // (Fix for issue #904)
                this.breakAtTheEdgeBeforeFloat = Break.isAvoidBreakValue(
                  breakAtTheEdge,
                )
                  ? breakAtTheEdge
                  : null;
              }
              if (layoutProcessor) {
                if (layoutProcessor.startNonInlineElementNode(nodeContext)) {
                  break;
                }
              }
              const clearNodeContext =
                VtreeImpl.asClearNodeContext(nodeContext);
              if (clearNodeContext) {
                // clear
                if (
                  this.applyClearance(clearNodeContext) &&
                  leadingEdge &&
                  this.breakPositions.length === 0
                ) {
                  this.saveEdgeBreakPosition(
                    nodeContext.copy(),
                    breakAtTheEdge,
                    false,
                  );
                }
              }
              // Check break opportunity between anonymous block box and block-level box
              // (Issue #611)
              if (
                !nodeContext.inline &&
                !nodeContext.repeatOnBreak &&
                (lastAfterNodeContext
                  ? LayoutHelper.findAncestorSpecialInlineNodeContext(
                      lastAfterNodeContext,
                    )
                  : this.breakPositions.at(-1) instanceof BoxBreakPosition ||
                    // When lastAfterNodeContext is null (no in-flow
                    // trailing edge, e.g. after CSS floats converted to
                    // position:absolute) and no block-level leading edges
                    // were encountered, save a break position at the
                    // block-level element. This parallels the inline text
                    // break opportunity above. (Issue #1786)
                    (!leadingEdge && leadingEdgeContexts.length === 0))
              ) {
                this.saveEdgeBreakPosition(
                  nodeContext.copy(),
                  breakAtTheEdge,
                  false,
                );
              }
              if (
                !this.isBFC(nodeContext.formattingContext) ||
                RepetitiveElement.isInstanceOfRepetitiveElementsOwnerFormattingContext(
                  nodeContext.formattingContext,
                ) ||
                this.asFloatNodeContext(nodeContext) !== null ||
                nodeContext.flexContainer ||
                // Check empty block box (Issue #749)
                (!nodeContext.nodeShadow &&
                  !(nodeContext.sourceNode as Element).firstElementChild &&
                  VtreeImpl.canIgnore(
                    nodeContext.sourceNode.firstChild,
                    nodeContext.whitespace,
                  ))
              ) {
                // new formatting context, or float or flex container,
                // or empty block box (unbreakable)
                leadingEdgeContexts.push(rendered.copy());
                setBreakAtTheEdge(nodeContext.breakBefore);
                suppressWeakerLeadingColumnBreaks(nodeContext);
                consumeSatisfiedLeadingColumnBreak(nodeContext);

                // check if a forced break must occur before the block.
                if (needForcedBreak()) {
                  processForcedBreak(rendered);
                } else if (
                  this.checkOverflowAndSaveEdgeAndBreakPosition(
                    lastAfterNodeContext,
                    null,
                    true,
                    breakAtTheEdge,
                  ) ||
                  !allowLayout(nodeContext)
                ) {
                  // overflow
                  nodeContext = (
                    this.stopAtOverflow
                      ? lastAfterNodeContext || nodeContext
                      : nodeContext
                  ).modify();
                  nodeContext.overflow = true;
                }
                loopFrame.breakLoop();
                return;
              }
            }
            const elementContext = VtreeImpl.asElementNodeContext(rendered);
            if (!elementContext) {
              // not an element
              break;
            }
            const viewElement = elementContext.viewNode as HTMLElement;
            const style = viewElement.style;
            if (nodeContext.after) {
              // Fix multi-column box with `column-fill: auto` (Issue #1720, #1758)
              LayoutHelper.fixAutoFillMultiColumnBox(viewElement, this);

              if (nodeContext.floatSide) {
                // Restore break-after:avoid* value at before the float
                // (Fix for issue #904)
                breakAtTheEdge =
                  breakAtTheEdge ?? this.breakAtTheEdgeBeforeFloat;
                this.breakAtTheEdgeBeforeFloat = null;
              }
              const element = nodeContext.sourceNode as Element;
              // Make breakable after svg and math elements
              // (Fix for issue #750)
              if (
                element.localName === "svg" ||
                element.localName === "math" ||
                element.getAttribute("data-math-typeset") === "true"
              ) {
                onStartEdges = false;
                lastAfterNodeContext = elementContext.copy();
                trailingEdgeContexts.push(lastAfterNodeContext);
                breakAtTheEdge = null;
                setBreakAtTheEdge(nodeContext.breakAfter);
                suppressWeakerTrailingColumnBreaks(nodeContext);
                this.checkOverflowAndSaveEdgeAndBreakPosition(
                  lastAfterNodeContext,
                  null,
                  !this.stopAtOverflow,
                  breakAtTheEdge,
                );
                break;
              }
              // Skip an empty inline box at the start of a block
              // (An anonymous block consisting entirely of
              // collapsible white space is removed from the rendering tree)
              if (nodeContext.inline) {
                break;
              }
              if (layoutProcessor) {
                if (
                  layoutProcessor.afterNonInlineElementNode(
                    nodeContext,
                    this.stopAtOverflow,
                  )
                ) {
                  break;
                }
              }

              // Trailing edge
              if (onStartEdges) {
                // Running elements (position:running() rendered as
                // position:fixed) should not end the leading edge sequence.
                // Their trailing edges must not reset leadingEdge, otherwise
                // the next in-flow element's forced break would be treated
                // as a mid-page break. Only skip position:fixed, not
                // position:absolute. (Issue #1833, #1869, #1870)
                if (LayoutHelper.isFixedPositioned(nodeContext.viewNode)) {
                  break;
                }
                // finished going through all starting edges of the box.
                // check if a forced break must occur before the block.
                if (needForcedBreak()) {
                  processForcedBreak(elementContext);
                  loopFrame.breakLoop();
                  return;
                }

                // since a break did not occur, move to the next edge. this
                // edge is no longer the leading edge.
                leadingEdgeContexts = [];
                leadingEdge = false;
                atUnforcedBreak = false;
                breakAtTheEdge = null;
              }
              onStartEdges = false; // we are now on end edges.
              // Do not use CSS-positioned out-of-flow elements
              // (absolute/fixed positioned and CSS floated elements) as
              // lastAfterNodeContext, since their edge positions are not
              // in the block flow and would prevent correct overflow
              // detection. (Issue #1775)
              // Note: Use isCssOutOfFlow() instead of isOutOfFlow() to
              // allow special marker elements (e.g. page float anchors)
              // which are positioned in normal flow and are needed for
              // break position tracking. (Issue #1790)
              if (!LayoutHelper.isCssOutOfFlow(elementContext.viewNode)) {
                lastAfterNodeContext = elementContext.copy();
                trailingEdgeContexts.push(lastAfterNodeContext);
              }
              setBreakAtTheEdge(nodeContext.breakAfter);
              suppressWeakerTrailingColumnBreaks(nodeContext);
              if (
                style &&
                !LayoutHelper.isOutOfFlow(nodeContext.viewNode) &&
                this.hasNonZeroBlockEndInset(style)
              ) {
                // Non-zero trailing inset.
                // Margins don't collapse across non-zero borders and
                // paddings.
                trailingEdgeContexts = lastAfterNodeContext
                  ? [lastAfterNodeContext]
                  : [];
              }
            } else {
              // Leading edge
              leadingEdgeContexts.push(elementContext.copy());
              setBreakAtTheEdge(nodeContext.breakBefore);
              suppressWeakerLeadingColumnBreaks(nodeContext);
              consumeSatisfiedLeadingColumnBreak(nodeContext);

              // Prevent unnecessary blank pages by removing unnecessary forced column breaks
              if (
                lastAfterNodeContext &&
                Break.isForcedBreakValue(breakAtTheEdge)
              ) {
                LayoutHelper.clearForcedColumnBreaks(
                  lastAfterNodeContext.viewNode,
                  elementContext.viewNode,
                );
              }

              if (
                (nodeContext.pageType != nodeContext.parent?.pageType || // Fix for issue #771
                  !Break.isForcedBreakValue(breakAtTheEdge)) && // Fix for issue #722
                !allowLayout(nodeContext)
              ) {
                this.checkOverflowAndSaveEdgeAndBreakPosition(
                  lastAfterNodeContext,
                  null,
                  !this.stopAtOverflow,
                  breakAtTheEdge,
                );
                nodeContext = nodeContext.modify();
                nodeContext.overflow = true;
                if (this.stopAtOverflow) {
                  loopFrame.breakLoop();
                  return;
                }
              }
              const viewTag = viewElement.localName;
              if (Base.mediaTags[viewTag]) {
                // elements that have inherent content
                // check if a forced break must occur before the block.
                if (needForcedBreak()) {
                  processForcedBreak(elementContext);
                } else if (
                  this.checkOverflowAndSaveEdgeAndBreakPosition(
                    lastAfterNodeContext,
                    null,
                    true,
                    breakAtTheEdge,
                  )
                ) {
                  // overflow
                  nodeContext = (
                    this.stopAtOverflow
                      ? lastAfterNodeContext || nodeContext
                      : nodeContext
                  ).modify();
                  nodeContext.overflow = true;
                }
                loopFrame.breakLoop();
                return;
              }
              if (style && this.hasNonZeroBlockStartInset(style)) {
                // Non-zero leading inset
                atUnforcedBreak = false;
                trailingEdgeContexts = [];
              }
              onStartEdges = true; // we are now on starting edges.
            }
          } while (false); // End of block of code to use break

          const nextResult = this.nextInTree(nodeContext, atUnforcedBreak);
          if (nextResult.isPending()) {
            nextResult.then((nodeContextParam) => {
              nodeContext = nodeContextParam;
              loopFrame.continueLoop();
            });
            return;
          } else {
            nodeContext = nextResult.get();
          }
        }

        if (
          this.checkOverflowAndSaveEdgeAndBreakPosition(
            lastAfterNodeContext,
            trailingEdgeContexts,
            !this.stopAtOverflow,
            breakAtTheEdge,
          )
        ) {
          if (lastAfterNodeContext && this.stopAtOverflow) {
            nodeContext = lastAfterNodeContext.modify();
            nodeContext.overflow = true;
          } else {
            // TODO: what to return here??
          }
        } else if (Break.isForcedBreakValue(breakAtTheEdge)) {
          this.pageBreakType = breakAtTheEdge;
        }
        loopFrame.breakLoop();
      })
      .then(() => {
        if (lastAfterNodeContext) {
          this.lastAfterPosition = lastAfterNodeContext.toNodePosition();
        }
        frame.finish(nodeContext);
      });
    return frame.result();
  }

  /**
   * Skips non-renderable positions until it hits the end of the flow or some
   * renderable content. Returns the nodeContext that was passed in if some
   * content remains and null if all content could be skipped.
   */
  skipTailEdges(
    initialNodeContext: Vtree.NodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    let nodeContext: Vtree.NodeContext | null = initialNodeContext;
    let resultNodeContext: Vtree.NodeContext | null = nodeContext.copy();
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("skipEdges");
    let breakAtTheEdge: string | null = null;
    let onStartEdges = false;
    frame
      .loopWithFrame((loopFrame) => {
        while (nodeContext) {
          // A code block to be able to use break. Break moves to the next
          // node position.
          do {
            if (!nodeContext.viewNode) {
              // Non-displayable content, skip
              break;
            }
            if (nodeContext.inline && nodeContext.viewNode.nodeType != 1) {
              if (
                VtreeImpl.canIgnore(
                  nodeContext.viewNode,
                  nodeContext.whitespace,
                )
              ) {
                // Ignorable text content, skip
                break;
              }
              if (!nodeContext.after) {
                // Leading edge of non-empty block -> finished going through
                // all starting edges of the box
                if (Break.isForcedBreakValue(breakAtTheEdge)) {
                  this.pageBreakType = breakAtTheEdge;
                }
                loopFrame.breakLoop();
                return;
              }
            }
            if (!nodeContext.after) {
              if (
                this.asFloatNodeContext(nodeContext) !== null ||
                nodeContext.flexContainer
              ) {
                // float or flex container (unbreakable)
                breakAtTheEdge = Break.resolveEffectiveBreakValue(
                  breakAtTheEdge,
                  nodeContext.breakBefore,
                );

                // check if a forced break must occur before the block.
                if (Break.isForcedBreakValue(breakAtTheEdge)) {
                  this.pageBreakType = breakAtTheEdge;
                }
                loopFrame.breakLoop();
                return;
              }
            }
            if (nodeContext.viewNode.nodeType != 1) {
              // not an element
              break;
            }
            const viewElement = nodeContext.viewNode as HTMLElement;
            const style = viewElement.style;
            if (nodeContext.after) {
              // Trailing edge
              if (onStartEdges) {
                // finished going through all starting edges of the box.
                // check if a forced break must occur before the block.
                if (Break.isForcedBreakValue(breakAtTheEdge)) {
                  this.pageBreakType = breakAtTheEdge;
                  loopFrame.breakLoop();
                  return;
                }

                // since a break did not occur, move to the next edge.
                breakAtTheEdge = null;
              }
              onStartEdges = false; // we are now on end edges.
              breakAtTheEdge = Break.resolveEffectiveBreakValue(
                breakAtTheEdge,
                nodeContext.breakAfter,
              );
            } else {
              // Leading edge
              breakAtTheEdge = Break.resolveEffectiveBreakValue(
                breakAtTheEdge,
                nodeContext.breakBefore,
              );
              const viewTag = viewElement.localName;
              if (Base.mediaTags[viewTag]) {
                // elements that have inherent content
                // check if a forced break must occur before the block.
                if (Break.isForcedBreakValue(breakAtTheEdge)) {
                  this.pageBreakType = breakAtTheEdge;
                }
                loopFrame.breakLoop();
                return;
              }
              if (style && this.hasNonZeroBlockStartInset(style)) {
                // Non-zero leading inset
                loopFrame.breakLoop();
                return;
              }
            }
            onStartEdges = true; // we are now on starting edges.
          } while (false); // End of block of code to use break

          const nextResult = this.layoutContext.nextInTree(nodeContext);
          if (nextResult.isPending()) {
            nextResult.then((nodeContextParam) => {
              nodeContext = nodeContextParam;
              loopFrame.continueLoop();
            });
            return;
          } else {
            nodeContext = nextResult.get();
          }
        }
        resultNodeContext = null;
        loopFrame.breakLoop();
      })
      .then(() => {
        frame.finish(resultNodeContext);
      });
    return frame.result();
  }

  layoutFloatOrFootnote(
    nodeContext: Vtree.FloatNodeContext,
  ): Task.Result<Vtree.NodeContext | null> {
    if (
      PageFloats.isPageFloat(nodeContext.floatReference) ||
      nodeContext.floatSide === "footnote"
    ) {
      // When inside a page float area, the float element that generated
      // this area is laid out as content. Its float/footnote CSS properties
      // must not trigger another page float layout (which would create
      // infinite recursion). Only skip processing for the generating element
      // itself; genuinely nested floats/footnotes are allowed. (Issue #1784)
      const generatingNodePosition =
        this.pageFloatLayoutContext.generatingNodePosition;
      if (
        generatingNodePosition &&
        nodeContext.sourceNode === generatingNodePosition.steps[0].node
      ) {
        const nodeContextMod: Vtree.NodeContext = nodeContext.modify();
        nodeContextMod.floatSide = null;
        nodeContextMod.floatReference = PageFloats.FloatReference.INLINE;
        nodeContextMod.clearSide = null;
        if (this.isBreakable(nodeContextMod)) {
          return this.layoutBreakableBlock(nodeContextMod);
        } else {
          return this.layoutUnbreakable(nodeContextMod);
        }
      }
      return this.layoutPageFloat(nodeContext);
    } else {
      return this.layoutFloat(nodeContext);
    }
  }

  /**
   * Layout next portion of the source.
   */
  layoutNext(
    nodeContext: Vtree.NodeContext,
    leadingEdge: boolean,
    forcedBreakValue?: string | null,
  ): Task.Result<Vtree.NodeContext> {
    const frame: Task.Frame<Vtree.NodeContext> = Task.newFrame("layoutNext");
    this.skipEdges(nodeContext, leadingEdge, forcedBreakValue || null).then(
      (nodeContextParam) => {
        nodeContext = nodeContextParam as Vtree.NodeContext;
        if (
          !nodeContext ||
          this.pageBreakType ||
          this.stopByOverflow(nodeContext)
        ) {
          // finished all content, explicit page break or overflow (automatic
          // page break)
          frame.finish(nodeContext);
        } else {
          const formattingContext = nodeContext.formattingContext;
          const layoutProcessor =
            new LayoutProcessor.LayoutProcessorResolver().find(
              formattingContext,
            );
          layoutProcessor
            .layout(nodeContext, this, leadingEdge)
            .thenFinish(frame);
        }
      },
    );
    return frame.result();
  }

  clearOverflownViewNodes(
    nodeContext: Vtree.NodeContext | null,
    removeSelf: boolean,
  ): void {
    if (!nodeContext) {
      return;
    }
    for (
      let parent: Vtree.NodeContext | null = nodeContext.parent;
      nodeContext;
      nodeContext = parent, parent = parent ? parent.parent : null
    ) {
      const formattingContext = (parent || nodeContext).formattingContext;
      const layoutProcessor =
        new LayoutProcessor.LayoutProcessorResolver().find(formattingContext);
      layoutProcessor.clearOverflownViewNodes(
        this,
        parent,
        nodeContext,
        removeSelf,
      );
      removeSelf = false;
    }
  }

  private measure(): GeometryUtil.Band[] {
    Base.setCSSProperty(this.element, "width", `${this.width}px`);
    Base.setCSSProperty(this.element, "height", `${this.height}px`);
    // Use a probe element to measure the content area via
    // getBoundingClientRect(). We cannot query the container element directly
    // because that would include padding (border-box), and we need content-box
    // coordinates. We also cannot simply compute these from stored CSS property
    // values (e.g. getInnerRect()) because layout calculations throughout the
    // engine compare against getBoundingClientRect() values from content
    // elements, and there can be sub-pixel differences between computed values
    // and actual browser-rendered positions, which would break float
    // positioning and overflow detection.
    const probe = this.element.ownerDocument.createElement("div");
    probe.style.position = "absolute";
    probe.style.top = `${this.paddingTop}px`;
    probe.style.right = `${this.paddingRight}px`;
    probe.style.bottom = `${this.paddingBottom}px`;
    probe.style.left = `${this.paddingLeft}px`;
    this.element.appendChild(probe);
    const columnBBox = this.clientLayout.getElementClientRect(probe);
    this.element.removeChild(probe);
    const offsetX = this.originX + this.left + this.getInsetLeft();
    const offsetY = this.originY + this.top + this.getInsetTop();
    const box = new GeometryUtil.Rect(
      offsetX,
      offsetY,
      offsetX + this.width,
      offsetY + this.height,
    );
    this.startEdge = columnBBox
      ? this.vertical
        ? this.rtl
          ? columnBBox.bottom
          : columnBBox.top
        : this.rtl
          ? columnBBox.right
          : columnBBox.left
      : 0;
    this.endEdge = columnBBox
      ? this.vertical
        ? this.rtl
          ? columnBBox.top
          : columnBBox.bottom
        : this.rtl
          ? columnBBox.left
          : columnBBox.right
      : 0;
    this.beforeEdge = columnBBox
      ? this.vertical
        ? columnBBox.right
        : columnBBox.top
      : 0;
    this.afterEdge = columnBBox
      ? this.vertical
        ? columnBBox.left
        : columnBBox.bottom
      : 0;
    this.leftFloatEdge = this.beforeEdge;
    this.rightFloatEdge = this.beforeEdge;
    this.bottommostFloatTop = this.beforeEdge;
    this.footnoteEdge = this.afterEdge;
    return GeometryUtil.shapesToBands(
      box,
      [this.getInnerShape()],
      this.getExclusions(),
      8,
      this.snapHeight,
      this.vertical,
    );
  }

  /**
   * Re-measure a column whose geometry changed after construction, refreshing
   * bands and exclusion floats and resetting the layout-pass state.
   */
  private remeasure(): void {
    this.chunkPositions = [];
    this.bands = this.measure();
    this.createFloats();
    this.computedBlockSize = 0;
    this.overflown = false;
    this.pageBreakType = null;
    this.lastAfterPosition = null;
    this.lastLineStride = 0;
  }

  /**
   * Save the potential breaking position at the edge. Should, in general, save
   * "after" position but only after skipping all of the "before" ones and
   * getting to the non-empty content (to get breakAtEdge right).
   */
  saveEdgeBreakPosition(
    position: Vtree.NodeContext,
    breakAtEdge: string | null,
    overflows: boolean,
  ): void {
    const copy = position.copy();
    const layoutProcessor = new LayoutProcessor.LayoutProcessorResolver().find(
      position.formattingContext,
    );
    const clonedPaddingBorder = this.calculateClonedPaddingBorder(copy);
    const bp = layoutProcessor.createEdgeBreakPosition(
      copy,
      breakAtEdge,
      overflows,
      this.computedBlockSize + clonedPaddingBorder,
    );
    this.breakPositions.push(bp);
  }

  /**
   * @param checkPoints array of breaking points for breakable block
   */
  saveBoxBreakPosition(checkPoints: Vtree.RenderedNodeContext[]): void {
    let penalty = checkPoints[0].breakPenalty;
    if (penalty) {
      // Fix for issue #546
      let block: Vtree.NodeContext = checkPoints[0];
      while (block.parent && block.inline) {
        block = block.parent;
      }
      penalty = block.breakPenalty;
    }
    const bp = new BoxBreakPosition(checkPoints, penalty);
    this.breakPositions.push(bp);
  }

  updateMaxReachedAfterEdge(afterEdge: number) {
    if (!isNaN(afterEdge)) {
      const size = this.getBoxDir() * (afterEdge - this.beforeEdge);
      this.computedBlockSize = Math.max(size, this.computedBlockSize);
    }
  }

  /**
   * @param chunkPosition starting position.
   * @return holding end position.
   */
  layout(
    chunkPosition: Vtree.ChunkPosition,
    leadingEdge: boolean,
    breakAfter?: string | null,
  ): Task.Result<Vtree.ChunkPosition | null> {
    this.chunkPositions.push(chunkPosition); // So we can re-layout this column later
    if (chunkPosition.primary.after) {
      this.lastAfterPosition = chunkPosition.primary;
    }
    if (this.stopAtOverflow && this.overflown) {
      return Task.newResult(chunkPosition as Vtree.ChunkPosition);
    }
    if (this.isFullWithPageFloats()) {
      if (
        chunkPosition.primary.after &&
        chunkPosition.primary.steps.length === 1
      ) {
        // End of contents
        return Task.newResult<Vtree.ChunkPosition | null>(null);
      } else {
        return Task.newResult(chunkPosition as Vtree.ChunkPosition);
      }
    }

    // Enable page/column breaking using the browser's multi-column feature.
    LayoutHelper.setBrowserColumnBreaking(this);

    const frame: Task.Frame<Vtree.ChunkPosition | null> =
      Task.newFrame("layout");

    // ------ start the column -----------
    this.openAllViews(chunkPosition.primary).then((nodeContext) => {
      let initialNodeContext: Vtree.NodeContext | null = null;
      if (nodeContext.viewNode) {
        initialNodeContext = nodeContext.copy();
      } else {
        const nextInTreeListener = (evt) => {
          if (evt.nodeContext.viewNode) {
            initialNodeContext = evt.nodeContext;
            this.layoutContext.removeEventListener(
              "nextInTree",
              nextInTreeListener,
            );
          }
        };
        this.layoutContext.addEventListener("nextInTree", nextInTreeListener);
      }
      const retryer = new ColumnLayoutRetryer(leadingEdge, breakAfter);
      retryer.layout(nodeContext, this).then((nodeContextParam) => {
        this.doFinishBreak(
          nodeContextParam,
          retryer.context.overflownNodeContext,
          initialNodeContext,
          retryer.initialComputedBlockSize,
        ).then((positionAfter) => {
          let cont: Task.Result<boolean>;
          if (!this.pseudoParent) {
            cont = this.doFinishBreakOfFragmentLayoutConstraints(positionAfter);
          } else {
            // The value is never read. This result only sequences the steps.
            cont = Task.newResult(true);
          }
          cont.then(() => {
            if (LayoutHelper.isUsingBrowserColumnBreaking(this)) {
              // Fix multi-column boxes with `column-fill: auto` (Issue #1720, #1758)
              LayoutHelper.fixAutoFillMultiColumnBoxes(this);

              // Unset browser's multi-column (Issue #1637, #1747)
              LayoutHelper.unsetBrowserColumnBreaking(this);
            }
            // Restore root column block-size if it was reduced by
            // footnotes/block-end-page-floats and table/multicol issue
            // workaround (Issue #1662, #1460).
            if (
              this.element.hasAttribute(
                "data-vivliostyle-column-block-size-adjusted",
              )
            ) {
              if (this.vertical) {
                Base.setCSSProperty(this.element, "width", `${this.width}px`);
                Base.setCSSProperty(this.element, "left", `${this.left}px`);
              } else {
                Base.setCSSProperty(this.element, "height", `${this.height}px`);
              }
              this.element.removeAttribute(
                "data-vivliostyle-column-block-size-adjusted",
              );
            }
            if (this.pageFloatLayoutContext.isInvalidated()) {
              frame.finish(null);
              return;
            }
            if (!positionAfter) {
              frame.finish(null);
            } else {
              this.overflown = true;
              const result = new VtreeImpl.ChunkPosition(
                positionAfter.toNodePosition(),
              );
              frame.finish(result);
            }
          });
        });
      });
    });
    return frame.result();
  }

  isFullWithPageFloats(): boolean {
    return this.pageFloatLayoutContext.isColumnFullWithPageFloats(this);
  }

  getMaxBlockSizeOfPageFloats(): number {
    return this.pageFloatLayoutContext.getMaxBlockSizeOfPageFloats();
  }

  doFinishBreakOfFragmentLayoutConstraints(
    nodeContext: Vtree.NodeContext | null,
  ): Task.Result<boolean> {
    const frame: Task.Frame<boolean> = Task.newFrame(
      "doFinishBreakOfFragmentLayoutConstraints",
    );
    const sortedFragmentLayoutConstraints =
      this.fragmentLayoutConstraints.slice();
    sortedFragmentLayoutConstraints.sort(
      (a, b) => a.getPriorityOfFinishBreak() - b.getPriorityOfFinishBreak(),
    );
    let i = 0;
    frame
      .loop(() => {
        if (i < sortedFragmentLayoutConstraints.length) {
          const result = sortedFragmentLayoutConstraints[i++].finishBreak(
            nodeContext,
            this,
          );
          return result.thenReturn(true);
        } else {
          return Task.newResult(false);
        }
      })
      .then(() => {
        frame.finish(true);
      });
    return frame.result();
  }

  /**
   * @param nodeContext starting position.
   * @return holding end position.
   */
  doLayout(
    nodeContext: Vtree.NodeContext | null,
    leadingEdge: boolean,
    breakAfter?: string | null,
  ): Task.Result<{
    nodeContext: Vtree.NodeContext | null;
    overflownNodeContext: Vtree.NodeContext | null;
  }> {
    const frame: Task.Frame<{
      nodeContext: Vtree.NodeContext | null;
      overflownNodeContext: Vtree.NodeContext | null;
    }> = Task.newFrame("doLayout");
    let overflownNodeContext: Vtree.NodeContext | null = null;

    // ------ init backtracking list -----
    this.breakPositions = [];
    this.nodeContextOverflowingDueToRepetitiveElements = null;

    // ------- fill the column -------------
    frame
      .loopWithFrame((loopFrame) => {
        while (nodeContext) {
          // fill a single block
          let pending = true;
          this.layoutNext(nodeContext, leadingEdge, breakAfter || null).then(
            (nodeContextParam) => {
              leadingEdge = false;
              breakAfter = null;
              if (
                this.nodeContextOverflowingDueToRepetitiveElements &&
                this.stopAtOverflow
              ) {
                this.pageBreakType = null;
                nodeContext =
                  this.nodeContextOverflowingDueToRepetitiveElements;
                nodeContext.overflow = true;
              } else {
                nodeContext = nodeContextParam;
              }
              if (this.pageFloatLayoutContext.isInvalidated()) {
                loopFrame.breakLoop();
              } else if (this.pageBreakType) {
                // explicit page break
                loopFrame.breakLoop(); // Loop end
              } else if (nodeContext && this.stopByOverflow(nodeContext)) {
                // overflow (implicit page break): back up and find a
                // page break
                overflownNodeContext = nodeContext;
                const bp = this.findAcceptableBreakPosition();
                nodeContext = bp && bp.nodeContext;
                if (bp) {
                  bp.breakPosition.breakPositionChosen(this);
                }
                loopFrame.breakLoop(); // Loop end
              } else {
                if (pending) {
                  // Sync case
                  pending = false;
                } else {
                  // Async case
                  loopFrame.continueLoop();
                }
              }
            },
          );
          if (pending) {
            // Async case and loop end
            pending = false;
            return;
          }
        }

        // Sync case
        this.computedBlockSize += this.getOffsetByRepetitiveElements();
        loopFrame.breakLoop();
      })
      .then(() => {
        frame.finish({ nodeContext, overflownNodeContext });
      });
    return frame.result();
  }

  saveDistanceToBlockEndFloats() {
    const blockStartEdgeOfBlockEndFloats =
      this.pageFloatLayoutContext.getBlockStartEdgeOfBlockEndFloats();
    if (
      blockStartEdgeOfBlockEndFloats > 0 &&
      isFinite(blockStartEdgeOfBlockEndFloats)
    ) {
      this.blockDistanceToBlockEndFloats =
        this.getBoxDir() *
        (blockStartEdgeOfBlockEndFloats -
          this.beforeEdge -
          this.computedBlockSize);
    }
  }

  collectElementsOffset(): RepetitiveElement.ElementsOffset[] {
    const repetitiveElements: RepetitiveElement.ElementsOffset[] = [];
    for (
      let current: Column | null = this;
      current;
      current = current.pseudoParent
    ) {
      current.fragmentLayoutConstraints.forEach((constraint) => {
        if (
          RepetitiveElement.isInstanceOfRepetitiveElementsOwnerLayoutConstraint(
            constraint,
          )
        ) {
          const repetitiveElement = constraint.getRepetitiveElements();
          repetitiveElements.push(repetitiveElement);
        }
        if (
          Selectors.isInstanceOfAfterIfContinuesLayoutConstraint(constraint)
        ) {
          const repetitiveElement = constraint.getRepetitiveElements();
          repetitiveElements.push(repetitiveElement);
        }
        if (Table.isInstanceOfTableRowLayoutConstraint(constraint)) {
          constraint
            .getElementsOffsetsForTableCell(this)
            .forEach((repetitiveElement) => {
              repetitiveElements.push(repetitiveElement);
            });
        }
      });
    }
    return repetitiveElements;
  }
}

/**
 * Represents a "pseudo"-column nested inside a real column.
 * This class is created to handle parallel fragmented flows (e.g. table columns
 * in a single table row). A pseudo-column behaves in the same way as the
 * original column, sharing its properties. Property changes on the
 * pseudo-column are not propagated to the original column. The LayoutContext of
 * the original column is also cloned and used by the pseudo-column, not to
 * propagate state changes of the LayoutContext caused by the pseudo-column.
 * @param column The original (parent) column
 * @param viewRoot Root element for the pseudo-column, i.e., the root of the
 *     fragmented flow.
 * @param parentNodeContext A NodeContext generating this PseudoColumn
 */
export class PseudoColumn {
  startNodeContexts: Vtree.NodeContext[] = [];
  private column: Layout.Column;
  // Issue #1854: retain the source subtree root so we can detect breaks that
  // land after the last significant node in a table-cell pseudo column.
  private readonly flowRootSourceNode: Node;
  constructor(
    column: Layout.Column,
    viewRoot: HTMLElement,
    parentNodeContext: Vtree.NodeContext,
  ) {
    this.flowRootSourceNode = parentNodeContext.sourceNode;
    this.column = Object.create(column) as Layout.Column;
    this.column.element = viewRoot;
    this.column.layoutContext = column.layoutContext.clone();
    this.column.stopAtOverflow = false;
    this.column.flowRootFormattingContext = parentNodeContext.formattingContext;
    this.column.pseudoParent = column;
    const parentClonedPaddingBorder =
      this.column.calculateClonedPaddingBorder(parentNodeContext);
    this.column.footnoteEdge =
      this.column.footnoteEdge - parentClonedPaddingBorder;
    const pseudoColumn = this;
    this.column.openAllViews = function (position) {
      return Column.prototype.openAllViews
        .call(this, position)
        .thenAsync((result) => {
          pseudoColumn.startNodeContexts.push(result.copy());
          return Task.newResult(result);
        });
    };
  }
  /**
   * @param chunkPosition starting position.
   * @return holding end position.
   */
  layout(
    chunkPosition: Vtree.ChunkPosition,
    leadingEdge: boolean,
  ): Task.Result<Vtree.ChunkPosition | null> {
    return this.column.layout(chunkPosition, leadingEdge);
  }
  findAcceptableBreakPosition(): Layout.BreakPositionAndNodeContext {
    const p = this.column.findAcceptableBreakPosition();
    const startNodeContext = this.startNodeContexts[0].copy();
    const bp = new BreakPosition.EdgeBreakPosition(
      startNodeContext,
      null,
      startNodeContext.overflow,
      0,
    );
    // updates the column's overflow state, so it runs whether or not the
    // start position is the one taken
    bp.findAcceptableBreak(this.column, 0);
    return p ?? { breakPosition: bp, nodeContext: startNodeContext };
  }
  /**
   * @return holing true
   */
  finishBreak(
    nodeContext: Vtree.NodeContext,
    forceRemoveSelf: boolean,
    endOfColumn: boolean,
  ): Task.Result<boolean> {
    return this.column.finishBreak(nodeContext, forceRemoveSelf, endOfColumn);
  }
  isStartNodeContext(nodeContext: Vtree.NodeContext): boolean {
    const startNodeContext = this.startNodeContexts[0];
    return (
      startNodeContext.viewNode === nodeContext.viewNode &&
      startNodeContext.after === nodeContext.after &&
      startNodeContext.offsetInNode === nodeContext.offsetInNode
    );
  }
  isLastAfterNodeContext(nodeContext: Vtree.NodeContext): boolean {
    return (
      VtreeImpl.isSameNodePosition(
        nodeContext.toNodePosition(),
        this.column.lastAfterPosition,
      ) || this.isEffectivelyLastAfterNodeContext(nodeContext)
    );
  }

  private isEffectivelyLastAfterNodeContext(
    nodeContext: Vtree.NodeContext,
  ): boolean {
    // Issue #1854: a table cell can break immediately after its last visible
    // text node without matching lastAfterPosition exactly; treat that as a
    // terminal break so table row fragmentation does not create an empty
    // continuation fragment that only carries borders.
    const flowRoot = this.flowRootSourceNode;
    const sourceNode = nodeContext.sourceNode;
    if (!flowRoot || !sourceNode || !nodeContext.after) {
      return false;
    }
    if (
      flowRoot !== sourceNode &&
      !(flowRoot as Element).contains?.(sourceNode)
    ) {
      return false;
    }
    if (sourceNode.nodeType === Node.TEXT_NODE) {
      const textNode = sourceNode as Text;
      if (nodeContext.offsetInNode < textNode.length) {
        const remainingText = textNode.data.slice(nodeContext.offsetInNode);
        if (!VtreeImpl.canIgnoreText(remainingText, nodeContext.whitespace)) {
          return false;
        }
      }
    }
    for (
      let node: Node | null = sourceNode;
      node && node !== flowRoot;
      node = node.parentNode
    ) {
      for (
        let sibling = node.nextSibling;
        sibling;
        sibling = sibling.nextSibling
      ) {
        if (!VtreeImpl.canIgnore(sibling, nodeContext.whitespace)) {
          return false;
        }
      }
    }
    return true;
  }
  getColumnElement(): Element {
    return this.column.element;
  }
  getColumn(): Layout.Column {
    return this.column;
  }
}

export type SinglePageFloatLayoutResult = Layout.SinglePageFloatLayoutResult;

/**
 * breaking point resolver for Text Node.
 */
export class TextNodeBreaker implements Layout.TextNodeBreaker {
  breakTextNode(
    textNode: Text,
    nodeContext: Vtree.NodeContext,
    low: number,
    checkPoints: Vtree.RenderedNodeContext[],
    checkpointIndex: number,
    force: boolean,
  ): Vtree.NodeContext {
    if (nodeContext.after) {
      nodeContext.offsetInNode = textNode.length;
    } else {
      // Character with index low is the last one that fits.
      let viewIndex = low - nodeContext.boxOffset;
      const text = textNode.data;
      if (text.charCodeAt(viewIndex) == 173) {
        viewIndex = this.breakAfterSoftHyphen(
          textNode,
          text,
          viewIndex,
          nodeContext,
        );
      } else {
        viewIndex = this.breakAfterOtherCharacter(
          textNode,
          text,
          viewIndex,
          nodeContext,
        );
      }
      if (viewIndex > 0) {
        nodeContext = this.updateNodeContext(nodeContext, viewIndex, textNode);
      }
    }
    return nodeContext;
  }

  breakAfterSoftHyphen(
    textNode: Text,
    text: string,
    viewIndex: number,
    nodeContext: Vtree.NodeContext,
  ): number {
    // convert trailing soft hyphen to a real hyphen
    const checkJoiningType =
      // /[\p{Joining_Type=D}\p{Joining_Type=C}]\p{Mn}*$/
      // eslint-disable-next-line no-misleading-character-class
      /[\u0620\u0626\u0628\u062A-\u062E\u0633-\u0647\u0649\u064A\u066E\u066F\u0678-\u0687\u069A-\u06BF\u06C1\u06C2\u06CC\u06CE\u06D0\u06D1\u06FA-\u06FC\u06FF\u0712-\u0714\u071A-\u071D\u071F-\u0727\u0729\u072B\u072D\u072E\u074E-\u0758\u075C-\u076A\u076D-\u0770\u0772\u0775-\u0777\u077A-\u077F\u07CA-\u07EA\u07FA\u0841-\u0845\u0848\u084A-\u0853\u0855\u0860\u0862-\u0865\u0868\u0883-\u0886\u0889-\u088D\u08A0-\u08A9\u08AF\u08B0\u08B3-\u08B8\u08BA-\u08C8\u1807\u180A\u1820-\u1878\u1887-\u18A8\u18AA\u200D\uA840-\uA871\u{10AC0}-\u{10AC4}\u{10AD3}-\u{10AD6}\u{10AD8}-\u{10ADC}\u{10ADE}-\u{10AE0}\u{10AEB}-\u{10AEE}\u{10B80}\u{10B82}\u{10B86}-\u{10B88}\u{10B8A}\u{10B8B}\u{10B8D}\u{10B90}\u{10BAD}\u{10BAE}\u{10D01}-\u{10D21}\u{10D23}\u{10EC3}\u{10EC4}\u{10F30}-\u{10F32}\u{10F34}-\u{10F44}\u{10F51}-\u{10F53}\u{10F70}-\u{10F73}\u{10F76}-\u{10F81}\u{10FB0}\u{10FB2}\u{10FB3}\u{10FB8}\u{10FBB}\u{10FBC}\u{10FBE}\u{10FBF}\u{10FC1}\u{10FC4}\u{10FCA}\u{1E900}-\u{1E943}]\p{Mn}*$/u;
    const zwj = checkJoiningType.test(text.slice(0, viewIndex)) ? "\u200D" : "";
    textNode.replaceData(
      viewIndex,
      text.length - viewIndex,
      !nodeContext.breakWord
        ? zwj + resolveHyphenateCharacter(nodeContext)
        : "",
    );
    if (zwj) {
      const p = nodeContext.preprocessedTextContent[0][1] as string;
      nodeContext.preprocessedTextContent[0][1] =
        p.slice(0, viewIndex + 1) + zwj + p.slice(viewIndex + 1);
    }
    return viewIndex + 1;
  }

  breakAfterOtherCharacter(
    textNode: Text,
    text: string,
    viewIndex: number,
    nodeContext: Vtree.NodeContext,
  ): number {
    // keep the trailing character (it may be a space or not)
    const ch0 = text.charAt(viewIndex);
    viewIndex++;
    const ch1 = text.charAt(viewIndex);

    // If automatic hyphen was inserted here, add a real hyphen.
    textNode.replaceData(
      viewIndex,
      text.length - viewIndex,
      !nodeContext.breakWord && Base.isLetter(ch0) && Base.isLetter(ch1)
        ? resolveHyphenateCharacter(nodeContext)
        : "",
    );
    return viewIndex;
  }

  updateNodeContext(
    nodeContext: Vtree.NodeContext,
    viewIndex: number,
    textNode: Text,
  ): Vtree.NodeContext {
    nodeContext = nodeContext.modify();
    nodeContext.offsetInNode += viewIndex;
    nodeContext.breakBefore = null;
    return nodeContext;
  }

  static instance: TextNodeBreaker;
}
TextNodeBreaker.instance = new TextNodeBreaker();

export function resolveHyphenateCharacter(
  nodeContext: Vtree.NodeContext,
): string {
  return (
    nodeContext.hyphenateCharacter ||
    (nodeContext.parent && nodeContext.parent.hyphenateCharacter) ||
    "-"
  );
}

export class ColumnLayoutRetryer extends LayoutRetryers.AbstractLayoutRetryer {
  breakAfter: string | null;
  private initialPageBreakType: string | null = null;
  initialComputedBlockSize: number = 0;
  private initialOverflown: boolean = false;
  private initialLastLineStride: number = 0;
  context: { overflownNodeContext: Vtree.NodeContext | null } = {
    overflownNodeContext: null,
  };

  constructor(
    public readonly leadingEdge: boolean,
    breakAfter?: string | null,
  ) {
    super();
    this.breakAfter = breakAfter || null;
  }

  override resolveLayoutMode(
    nodeContext: Vtree.NodeContext,
  ): Layout.LayoutMode {
    return new DefaultLayoutMode(
      this.leadingEdge,
      this.breakAfter,
      this.context,
    );
  }

  override prepareLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ) {
    column.fragmentLayoutConstraints = [];
    if (!column.pseudoParent) {
      Shared.clearRepetitiveElementsCache();
    }
  }

  override clearNodes(initialPosition: Vtree.NodeContext) {
    super.clearNodes(initialPosition);
    let nodeContext: Vtree.NodeContext | null = initialPosition;
    while (nodeContext) {
      const viewNode = nodeContext.viewNode;
      if (viewNode) {
        LayoutHelper.removeFollowingSiblings(viewNode.parentNode, viewNode);
      }
      nodeContext = nodeContext.parent;
    }
  }

  override saveState(nodeContext: Vtree.NodeContext, column: Layout.Column) {
    super.saveState(nodeContext, column);
    this.initialPageBreakType = column.pageBreakType;
    this.initialComputedBlockSize = column.computedBlockSize;
    this.initialOverflown = column.overflown;
    this.initialLastLineStride = column.lastLineStride;
  }

  override restoreState(nodeContext: Vtree.NodeContext, column: Layout.Column) {
    super.restoreState(nodeContext, column);
    column.pageBreakType = this.initialPageBreakType;
    column.computedBlockSize = this.initialComputedBlockSize;
    column.overflown = this.initialOverflown;
    column.lastLineStride = this.initialLastLineStride;
  }
}

export class DefaultLayoutMode implements Layout.LayoutMode {
  constructor(
    public readonly leadingEdge: boolean,
    public readonly breakAfter: string | null,
    public readonly context: { overflownNodeContext: Vtree.NodeContext | null },
  ) {}

  /** @override */
  doLayout(
    nodeContext: Vtree.NodeContext,
    column: Layout.Column,
  ): Task.Result<Vtree.NodeContext | null> {
    const frame: Task.Frame<Vtree.NodeContext | null> = Task.newFrame(
      "DefaultLayoutMode.doLayout",
    );

    processAfterIfContinuesOfAncestors(nodeContext, column).then(() => {
      column
        .doLayout(nodeContext, this.leadingEdge, this.breakAfter)
        .then((result) => {
          this.context.overflownNodeContext = result.overflownNodeContext;
          frame.finish(result.nodeContext);
        });
    });
    return frame.result();
  }

  /** @override */
  accept(nodeContext: Vtree.NodeContext, column: Layout.Column): boolean {
    if (column.pageFloatLayoutContext.isInvalidated() || column.pageBreakType) {
      return true;
    }
    if (column.fragmentLayoutConstraints.length <= 0) {
      return true;
    }
    return column.fragmentLayoutConstraints.every((constraint) =>
      constraint.allowLayout(
        nodeContext,
        this.context.overflownNodeContext,
        column,
      ),
    );
  }

  /** @override */
  postLayout(
    positionAfter: Vtree.NodeContext,
    initialPosition: Vtree.NodeContext,
    column: Layout.Column,
    accepted: boolean,
  ): boolean {
    if (!accepted) {
      const hasNextCandidate = column.fragmentLayoutConstraints.some(
        (constraint) => constraint.nextCandidate(positionAfter),
      );

      // If there is no next candidate, we accept the current layout trial.
      // Later Column#doFinishBreak decides whether the overflowing content
      // should be placed as is or be deferred to the next column,
      // depending on the value of Column#forceNonfitting.
      accepted = !hasNextCandidate;
    }
    column.fragmentLayoutConstraints.forEach((constraint) => {
      constraint.postLayout(accepted, positionAfter, initialPosition, column);
    });
    return accepted;
  }
}

export class PageFloatArea extends Column implements Layout.PageFloatArea {
  private rootViewNodes: Element[] = [];
  private floatMargins: GeometryUtil.Insets[] = [];
  adjustContentRelativeSize: boolean = true;

  constructor(
    public readonly floatSide: string,
    element: HTMLElement,
    layoutContext: Vtree.LayoutContext,
    clientLayout: Vtree.ClientLayout,
    layoutConstraint: LayoutConstraint,
    pageFloatLayoutContext: PageFloats.UnattachedPageFloatLayoutContext,
    public readonly parentContainer: Vtree.Container,
    geometry: Vtree.ContainerGeometry,
    innerShape: GeometryUtil.Shape | null,
    exclusions: GeometryUtil.Shape[],
    flowRootFormattingContext: Vtree.FormattingContext,
  ) {
    super(
      element,
      layoutContext,
      clientLayout,
      layoutConstraint,
      pageFloatLayoutContext,
      geometry,
      innerShape,
      exclusions,
      flowRootFormattingContext,
    );
    this.parentElement = parentContainer.element;
  }

  readonly parentElement: Element | null;

  override openAllViews(
    position: Vtree.NodePosition,
  ): Task.Result<Vtree.NodeContext> {
    return super.openAllViews(position).thenAsync((nodeContext) => {
      if (nodeContext) {
        this.fixFloatSizeAndPosition(nodeContext);
      }
      return Task.newResult(nodeContext);
    });
  }

  convertPercentageSizesToPx(target: Element) {
    const containingBlockRect = this.parentContainer.getPaddingRect();
    const refWidth = containingBlockRect.x2 - containingBlockRect.x1;
    const refHeight = containingBlockRect.y2 - containingBlockRect.y1;

    function convertPercentageToPx(props: string[], refValue: number) {
      props.forEach((propName) => {
        const valueString = Base.getCSSProperty(target, propName);
        if (valueString?.endsWith("%")) {
          const percentageValue = parseFloat(valueString);
          const value = (refValue * percentageValue) / 100;
          Base.setCSSProperty(target, propName, `${value}px`);
        }
      });
    }
    convertPercentageToPx(["width", "max-width", "min-width"], refWidth);
    convertPercentageToPx(["height", "max-height", "min-height"], refHeight);
    convertPercentageToPx(
      [
        "margin-top",
        "margin-right",
        "margin-bottom",
        "margin-left",
        "padding-top",
        "padding-right",
        "padding-bottom",
        "padding-left",
      ],
      this.vertical ? refHeight : refWidth,
    );
    ["margin-top", "margin-right", "margin-bottom", "margin-left"].forEach(
      (propName) => {
        const value = Base.getCSSProperty(target, propName);
        if (value === "auto") {
          Base.setCSSProperty(target, propName, "0");
        }
      },
    );
  }

  fixFloatSizeAndPosition(nodeContext: Vtree.NodeContext) {
    while (nodeContext.parent) {
      nodeContext = nodeContext.parent;
    }
    Asserts.assert(nodeContext.viewNode.nodeType === 1);
    const rootViewNode = nodeContext.viewNode as Element;
    this.rootViewNodes.push(rootViewNode);
    if (this.adjustContentRelativeSize) {
      this.convertPercentageSizesToPx(rootViewNode);
    }
    this.floatMargins.push(this.getComputedMargin(rootViewNode));
    if (this.adjustContentRelativeSize) {
      const floatSide = this.floatSide;
      const isVertical = this.parentContainer.vertical;
      if (isVertical) {
        if (floatSide === "block-end" || floatSide === "left") {
          const height = Base.getCSSProperty(rootViewNode, "height");
          if (height !== "" && height !== "auto") {
            Base.setCSSProperty(rootViewNode, "margin-top", "auto");
          }
        }
      } else {
        if (floatSide === "block-end" || floatSide === "bottom") {
          const width = Base.getCSSProperty(rootViewNode, "width");
          if (width !== "" && width !== "auto") {
            Base.setCSSProperty(rootViewNode, "margin-left", "auto");
          }
        }
      }
    }
  }

  getRootViewNodeCount(): number {
    return this.rootViewNodes.length;
  }

  hasNonPseudoTextContentAfter(rootViewNodeIndex: number): boolean {
    const hasNonPseudoText = (node: Node): boolean => {
      if (node.nodeType === Node.TEXT_NODE) {
        return !!node.textContent?.trim();
      }
      if (node.nodeType !== Node.ELEMENT_NODE) {
        return false;
      }
      if (PseudoElement.getPseudoName(node as Element)) {
        return false;
      }
      return Array.from(node.childNodes).some(hasNonPseudoText);
    };
    return this.rootViewNodes.slice(rootViewNodeIndex).some(hasNonPseudoText);
  }

  appendContentFrom(other: PageFloatArea): void {
    other.rootViewNodes.forEach((node) => {
      this.element.appendChild(node);
    });
    this.rootViewNodes.push(...other.rootViewNodes);
    this.floatMargins.push(...other.floatMargins);
    other.rootViewNodes.splice(0);
    other.floatMargins.splice(0);
    if (other.element.parentNode) {
      other.element.parentNode.removeChild(other.element);
    }
    this.applyCompactFootnoteDisplay();
    this.updateComputedBlockSizeForFootnoteArea(true);
  }

  removeContentAfter(rootViewNodeIndex: number): void {
    const removedRootViewNodes = this.rootViewNodes.splice(rootViewNodeIndex);
    this.floatMargins.splice(rootViewNodeIndex);
    removedRootViewNodes.forEach((node) => {
      if (node.parentNode) {
        node.parentNode.removeChild(node);
      }
    });
    this.applyCompactFootnoteDisplay();
    this.updateComputedBlockSizeForFootnoteArea(true);
  }

  getContentInlineSize(): number {
    return Math.max(
      ...this.rootViewNodes.map((r, i) => {
        const box = LayoutHelper.getElementClientRectAdjusted(
          this.clientLayout,
          r,
          this.vertical,
        );
        const margin = this.floatMargins[i];
        return this.vertical
          ? margin.top + box.height + margin.bottom
          : margin.left + box.width + margin.right;
      }),
    );
  }

  getContentBlockMarginAfter(): number {
    if (this.rootViewNodes.length === 0) {
      return 0;
    }
    return Math.max(
      ...this.rootViewNodes.map((r, i) => {
        const margin = this.floatMargins[i];
        return this.vertical ? margin.left : margin.bottom;
      }),
    );
  }

  applyCompactFootnoteDisplay(): void {
    const viewFactory = this.layoutContext as Vgen.ViewFactory | undefined;
    const styler = viewFactory?.styler;
    const xmldoc = viewFactory?.xmldoc;
    const compactFootnotes = this.rootViewNodes.filter((node) => {
      const computedStyle =
        node.ownerDocument.defaultView?.getComputedStyle(node);
      const renderedFootnoteDisplay =
        computedStyle?.getPropertyValue("--viv-footnote-display").trim() || "";
      if (renderedFootnoteDisplay === "compact") {
        return !(
          computedStyle?.display === "list-item" &&
          computedStyle.getPropertyValue("list-style-position").trim() ===
            "outside"
        );
      }
      const offset = node.getAttribute(Base.ELEMENT_OFFSET_ATTR);
      if (!offset || !styler || !xmldoc) {
        return false;
      }
      const sourceNode = xmldoc.getNodeByOffset(parseInt(offset, 10));
      if (!sourceNode || sourceNode.nodeType !== Node.ELEMENT_NODE) {
        return false;
      }
      const style = styler.getStyle(sourceNode as Element, false);
      const footnoteDisplay = CssCascade.getProp(
        style,
        "footnote-display",
      )?.value?.toString();
      const usesOutsideFootnoteMarker = !!CssCascade.getProp(
        style,
        "--viv-marker-content",
      )?.value;
      return footnoteDisplay === "compact" && !usesOutsideFootnoteMarker;
    }) as HTMLElement[];
    if (compactFootnotes.length === 0) {
      this.updateInlineFootnoteSeparators();
      this.updateComputedBlockSizeForFootnoteArea(true);
      return;
    }

    const areaRect = this.element.getBoundingClientRect();
    const availableMeasure = this.vertical ? areaRect.height : areaRect.width;
    compactFootnotes.forEach((footnote) => {
      Base.setCSSProperty(footnote, "display", "inline");
      footnote.style.setProperty("--viv-footnote-white-space", "nowrap");
    });

    const tolerance = 1.5 / (this.clientLayout.pixelRatio || 1);
    const measureCompactInlineSize = (element: HTMLElement): number => {
      const clone = element.cloneNode(true) as HTMLElement;
      Base.setCSSProperty(clone, "display", "inline-block");
      Base.setCSSProperty(clone, "position", "absolute");
      Base.setCSSProperty(clone, "visibility", "hidden");
      Base.setCSSProperty(clone, "white-space", "nowrap");
      Base.setCSSProperty(clone, "max-width", "none");
      Base.setCSSProperty(clone, "left", "0");
      Base.setCSSProperty(clone, "top", "0");
      this.element.appendChild(clone);
      const rect = clone.getBoundingClientRect();
      this.element.removeChild(clone);
      return this.vertical ? rect.height : rect.width;
    };

    compactFootnotes.forEach((footnote) => {
      if (measureCompactInlineSize(footnote) > availableMeasure + tolerance) {
        Base.setCSSProperty(footnote, "display", "block");
        footnote.style.removeProperty("--viv-footnote-white-space");
      }
    });

    this.updateInlineFootnoteSeparators();
    this.updateComputedBlockSizeForFootnoteArea(true);
  }

  private updateComputedBlockSizeForFootnoteArea(
    useActualBlockStart: boolean = false,
  ): void {
    if (this.rootViewNodes.length === 0) {
      this.computedBlockSize = 0;
      return;
    }

    const dir = this.getBoxDir();
    let contentBeforeEdge = this.beforeEdge;
    if (useActualBlockStart) {
      const areaBox = LayoutHelper.getElementClientRectAdjusted(
        this.clientLayout,
        this.element,
        this.vertical,
      );
      const contentInsetBefore = this.vertical
        ? this.borderRight + this.paddingRight
        : this.borderTop + this.paddingTop;
      // getBoundingClientRect() gives the border box; adding margins here
      // would shrink computedBlockSize and let footnotes protrude below the
      // @page area. (Issue #2029)
      contentBeforeEdge =
        this.getBeforeEdge(areaBox) + dir * contentInsetBefore;
    }
    this.computedBlockSize = Math.max(
      0,
      ...this.rootViewNodes.map((node) => {
        const box = LayoutHelper.getElementClientRectAdjusted(
          this.clientLayout,
          node,
          this.vertical,
        );
        const margin = this.getComputedMargin(node);
        const marginAfter = this.vertical ? margin.left : margin.bottom;
        return (
          dir * (this.getAfterEdge(box) - contentBeforeEdge) +
          Math.max(0, marginAfter)
        );
      }),
    );
  }

  private getFootnoteAfterPseudo(element: Element): HTMLElement | null {
    return Array.from(element.children).find(
      (child) => PseudoElement.getPseudoName(child) === "after",
    ) as HTMLElement | null;
  }

  private hasAuthorFootnoteAfterPseudo(element: Element): boolean {
    const afterPseudo = this.getFootnoteAfterPseudo(element);
    if (
      !!afterPseudo &&
      !afterPseudo.hasAttribute("data-vivliostyle-default-footnote-separator")
    ) {
      return true;
    }
    const semanticFootnoteChild = Array.from(element.children).find(
      (child) =>
        child instanceof Element &&
        SemanticFootnote.isSemanticFootnoteElement(child),
    ) as Element | undefined;
    const semanticAfterPseudo = semanticFootnoteChild
      ? this.getFootnoteAfterPseudo(semanticFootnoteChild)
      : null;
    return (
      !!semanticAfterPseudo &&
      !semanticAfterPseudo.hasAttribute(
        "data-vivliostyle-default-footnote-separator",
      )
    );
  }

  private createDefaultFootnoteAfterPseudo(element: HTMLElement): void {
    const after = element.ownerDocument.createElement("span");
    PseudoElement.setPseudoName(after, "after");
    after.setAttribute("data-vivliostyle-default-footnote-separator", "1");
    after.style.whiteSpace = "normal";
    after.textContent = " ";
    element.appendChild(after);
  }

  private getFootnoteBreakOpportunity(element: Element): HTMLElement | null {
    const nextSibling = element.nextElementSibling;
    return nextSibling?.hasAttribute("data-vivliostyle-footnote-break")
      ? (nextSibling as HTMLElement)
      : null;
  }

  private createFootnoteBreakOpportunity(element: HTMLElement): void {
    const breakOpportunity = element.ownerDocument.createElement("wbr");
    breakOpportunity.setAttribute("data-vivliostyle-footnote-break", "1");
    element.insertAdjacentElement("afterend", breakOpportunity);
  }

  private updateInlineFootnoteSeparators(): void {
    this.rootViewNodes.forEach((node, index) => {
      const element = node as HTMLElement;
      const display =
        element.ownerDocument.defaultView?.getComputedStyle(element).display;
      const nextElement = this.rootViewNodes[index + 1] as
        HTMLElement | undefined;
      const nextDisplay =
        nextElement?.ownerDocument.defaultView?.getComputedStyle(
          nextElement,
        ).display;
      const afterPseudo = this.getFootnoteAfterPseudo(element);
      const authorAfterPseudoExists =
        this.hasAuthorFootnoteAfterPseudo(element);
      const isDefaultAfterPseudo = !!afterPseudo?.hasAttribute(
        "data-vivliostyle-default-footnote-separator",
      );
      const breakOpportunity = this.getFootnoteBreakOpportunity(element);
      if (display === "inline" && nextDisplay === "inline") {
        const needsDefaultSeparator = !afterPseudo && !authorAfterPseudoExists;
        // Insert the UA default only when the rendered footnote element
        // or its direct semantic footnote child does not already carry an
        // author-defined ::after pseudo.
        if (needsDefaultSeparator) {
          this.createDefaultFootnoteAfterPseudo(element);
        }
        // Author overrides can remove or replace the default separating space,
        // which would otherwise remove the wrap opportunity between compact
        // inline footnotes. Add an invisible break opportunity in that case.
        if (!needsDefaultSeparator && !breakOpportunity) {
          this.createFootnoteBreakOpportunity(element);
        } else if (needsDefaultSeparator) {
          breakOpportunity?.remove();
        }
      } else {
        if (isDefaultAfterPseudo) {
          afterPseudo.remove();
        }
        breakOpportunity?.remove();
      }
    });
  }
}
