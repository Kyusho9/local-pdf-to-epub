/**
 * Copyright 2013 Google, Inc.
 * Copyright 2015 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Vgen - View tree generator.
 */
import * as Asserts from "./asserts";
import * as Base from "./base";
import * as Break from "./break";
import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as CssPage from "./css-page";
import * as CssParser from "./css-parser";
import * as CssTokenizer from "./css-tokenizer";
import * as CssProp from "./css-prop";
import * as CssStyler from "./css-styler";
import * as Diff from "./diff";
import * as Display from "./display";
import * as Exprs from "./exprs";
import * as Font from "./font";
import * as LayoutHelper from "./layout-helper";
import * as Logging from "./logging";
import * as Matchers from "./matchers";
import * as Net from "./net";
import * as PageFloats from "./page-floats";
import * as Plugin from "./plugin";
import * as PseudoElement from "./pseudo-element";
import * as RepetitiveElement from "./repetitive-element";
import * as Scripts from "./scripts";
import * as SemanticFootnote from "./semantic-footnote";
import * as Task from "./task";
import * as TaskUtil from "./task-util";
import * as Urls from "./urls";
import * as Vtree from "./vtree";
import * as Layout from "./layout";
import { XmlDoc } from "./types";

const namespacePrefixMap: { [key: string]: string } = {};
const xhtmlElementsRenderedAsDiv = new Set([
  "base",
  "body",
  "head",
  "html",
  "link",
  "meta",
  "script",
  "style",
  "title",
]);

function getWebKitMarkerListStyleType(markerContent: Css.Val): Css.Str | null {
  if (markerContent instanceof Css.Str) {
    return markerContent;
  }
  if (markerContent instanceof Css.SpaceList) {
    const parts: string[] = [];
    for (const item of markerContent.values) {
      if (item instanceof Css.Str) {
        parts.push(item.str);
      } else {
        return null;
      }
    }
    if (parts.length > 0) {
      return new Css.Str(parts.join(""));
    }
  }
  return null;
}

function getWebKitMarkerListStyleImage(markerContent: Css.Val): Css.URL | null {
  if (markerContent instanceof Css.URL) {
    return markerContent;
  }
  if (
    markerContent instanceof Css.SpaceList &&
    markerContent.values[0] instanceof Css.URL &&
    markerContent.values
      .slice(1)
      .every((item) => item instanceof Css.Str && item.str.trim() === "")
  ) {
    return markerContent.values[0];
  }
  return null;
}

function applyWebKitMarkerFallback(computedStyle: {
  [key: string]: Css.Val;
}): boolean {
  if (Base.browserType !== "webkit") {
    return false;
  }

  const markerContent = computedStyle["--viv-marker-content"];
  if (!markerContent) {
    return false;
  }

  const listStyleImage = getWebKitMarkerListStyleImage(markerContent);
  if (listStyleImage) {
    computedStyle["list-style-type"] = Css.ident.none;
    computedStyle["list-style-image"] = listStyleImage;
    delete computedStyle["--viv-marker-content"];
    return true;
  }

  const listStyleType = getWebKitMarkerListStyleType(markerContent);
  if (listStyleType) {
    computedStyle["list-style-type"] = listStyleType;
    computedStyle["list-style-image"] = Css.ident.none;
    return true;
  }

  return false;
}

export type CustomRenderer = (
  p1: Element,
  p2: Element,
  p3: { [key: string]: Css.Val },
) => Task.Result<Element | null>;

export interface CustomRendererFactory {
  makeCustomRenderer(xmldoc: XmlDoc.XMLDocHolder): CustomRenderer;
}

/**
 * Creates an epubReadingSystem object in the iframe.contentWindow.navigator
 * when load event fires.
 */
export function initIFrame(iframe: HTMLIFrameElement): void {
  iframe.addEventListener(
    "load",
    () => {
      // the load event fires only when the iframe has a browsing context
      iframe.contentWindow!.navigator["epubReadingSystem"] = {
        name: "adapt",
        version: "0.1",
        layoutStyle: "paginated",
        hasFeature: function (name, version) {
          switch (name) {
            case "mouse-events":
              return true;
          }
          return false;
        },
      };
    },
    false,
  );
}

export interface StylerProducer {
  getStylerForDoc(xmldoc: XmlDoc.XMLDocHolder): CssStyler.AbstractStyler;
}

export class ViewFactory
  extends Base.SimpleEventTarget
  implements Vtree.LayoutContext
{
  private static SVG_URL_ATTRIBUTES: string[] = [
    "color-profile",
    "clip-path",
    "cursor",
    "filter",
    "marker",
    "marker-start",
    "marker-end",
    "marker-mid",
    "fill",
    "stroke",
    "mask",
  ];
  private static FOOTNOTE_CALL_OWNER_ATTR = "data-viv-footnote-call-owner";
  document: Document;
  exprContentListener: Vtree.ExprContentListener;
  private computedStyleParentFontSizeOverride: number | null = null;
  private computedStyleParentLineHeightOverride: number | null = null;

  // provided by layout
  nodeContext: Vtree.NodeContext | null = null;
  viewRoot: Element | null = null;
  isFootnote: boolean = false;
  sourceNode: Node | null = null;
  offsetInNode: number = 0;

  // computed
  // TODO: only set it on NodeContext
  viewNode: Element | Text | null = null;

  constructor(
    public readonly flowName: string,
    public readonly context: Exprs.Context,
    public readonly viewport: Viewport,
    public readonly styler: CssStyler.Styler,
    public readonly regionIds: string[] | null,
    public readonly xmldoc: XmlDoc.XMLDocHolder,
    public readonly docFaces: Font.DocumentFaces,
    public readonly footnoteStyle: CssCascade.ElementStyle,
    public readonly stylerProducer: StylerProducer,
    public readonly page: Vtree.Page,
    public readonly customRenderer: CustomRenderer,
    public readonly fallbackMap: { [key: string]: string },
    public readonly documentURLTransformer: Base.DocumentURLTransformer,
    public readonly pageProps?: { [key: string]: CssCascade.ElementStyle },
    public readonly cascadedPageStyle?: CssCascade.ElementStyle | null,
    private readonly semanticFootnoteFirstRefOffsets: Map<
      string,
      number
    > = new Map(),
    private readonly semanticFootnoteFirstRefOffsetsInitialized: {
      value: boolean;
    } = { value: false },
  ) {
    super();
    this.document = viewport.document;
    this.exprContentListener = styler.counterListener.getExprContentListener();
  }

  /** @override */
  clone(): Vtree.LayoutContext {
    return new ViewFactory(
      this.flowName,
      this.context,
      this.viewport,
      this.styler,
      this.regionIds,
      this.xmldoc,
      this.docFaces,
      this.footnoteStyle,
      this.stylerProducer,
      this.page,
      this.customRenderer,
      this.fallbackMap,
      this.documentURLTransformer,
      this.pageProps,
      this.cascadedPageStyle,
      this.semanticFootnoteFirstRefOffsets,
      this.semanticFootnoteFirstRefOffsetsInitialized,
    );
  }

  private getExplicitPageType(
    style: CssCascade.ElementStyle | null | undefined,
  ): string | null {
    const pageValue = style?.["page"] as CssCascade.CascadeValue;
    if (!pageValue || Css.isDefaultingValue(pageValue.value)) {
      return null;
    }
    const pageType = pageValue.evaluate(this.context, "page").toString();
    return !pageType || pageType.toLowerCase() === "auto" ? null : pageType;
  }

  private isNormalFlowElement(element: Element): boolean {
    const style = this.styler.getStyle(element, false);
    const displayValue = (
      style?.["display"] as CssCascade.CascadeValue
    )?.evaluate(this.styler.context, "display");
    const display =
      displayValue && !Css.isDefaultingValue(displayValue)
        ? (displayValue as Css.Ident)
        : Css.ident.inline;
    if (display === Css.ident.none) {
      return false;
    }
    const positionValue = (
      style?.["position"] as CssCascade.CascadeValue
    )?.evaluate(this.styler.context, "position");
    const position =
      positionValue && !Css.isDefaultingValue(positionValue)
        ? positionValue
        : Css.ident.static;
    if (
      Display.isRunning(position) ||
      Display.isAbsolutelyPositioned(position)
    ) {
      return false;
    }
    const floatValue = (style?.["float"] as CssCascade.CascadeValue)?.evaluate(
      this.styler.context,
      "float",
    );
    const float =
      floatValue && !Css.isDefaultingValue(floatValue)
        ? floatValue
        : Css.ident.none;
    return float === Css.ident.none;
  }

  private getFirstInFlowChildElement(root: Element): Element | null {
    let child = root.firstChild;
    while (child) {
      if (child.nodeType === Node.TEXT_NODE) {
        if (!Vtree.canIgnore(child)) {
          return null;
        }
        child = child.nextSibling;
        continue;
      }
      if (child.nodeType !== Node.ELEMENT_NODE) {
        child = child.nextSibling;
        continue;
      }
      const element = child as Element;
      if (this.isNormalFlowElement(element)) {
        const style = this.styler.getStyle(element, false);
        const displayValue = (
          style?.["display"] as CssCascade.CascadeValue
        )?.evaluate(this.styler.context, "display");
        const display =
          displayValue && !Css.isDefaultingValue(displayValue)
            ? (displayValue as Css.Ident)
            : Css.ident.inline;
        if (Display.isInlineLevel(display)) {
          return null;
        }
        return element;
      }
      child = child.nextSibling;
    }
    return null;
  }

  private getEffectiveStartPageType(
    element: Element,
    pageType: string | null,
  ): string | null {
    let effectivePageType = pageType;
    let currentElement: Element | null = element;
    while (currentElement) {
      const child = this.getFirstInFlowChildElement(currentElement);
      if (!child) {
        return effectivePageType;
      }
      const childPageType = this.getExplicitPageType(
        this.styler.getStyle(child, false),
      );
      if (childPageType) {
        effectivePageType = childPageType;
      }
      currentElement = child;
    }
    return effectivePageType;
  }

  private syncTextNodePageTypeBoundary(nodeContext: Vtree.NodeContext): void {
    if (
      nodeContext.sourceNode.nodeType !== Node.TEXT_NODE ||
      Vtree.canIgnore(nodeContext.sourceNode) ||
      nodeContext.fragmentIndex !== 1
    ) {
      return;
    }
    const pageType = nodeContext.pageType;
    if (this.styler.cascade.currentPageType === pageType) {
      return;
    }
    if (!Break.isSpreadBreakValue(nodeContext.breakBefore)) {
      nodeContext.breakBefore = Break.resolveEffectiveBreakValue(
        nodeContext.breakBefore,
        "page",
      );
    }
    if (pageType !== this.styler.cascade.previousPageType) {
      this.styler.cascade.previousPageType =
        this.styler.cascade.currentPageType;
    }
    this.styler.cascade.currentPageType = pageType;
  }

  private syncSemanticFootnoteCounterToTarget(element: Element): void {
    if (
      element.localName !== "a" ||
      !SemanticFootnote.isSemanticFootnoteNoterefElement(element) ||
      !SemanticFootnote.shouldGenerateSemanticFootnote(
        element,
        this.xmldoc.url,
        (noteref) => this.xmldoc.getElementOffset(noteref),
        this.semanticFootnoteFirstRefOffsets,
        this.semanticFootnoteFirstRefOffsetsInitialized,
      )
    ) {
      return;
    }
    const footnoteCounter = element.getAttribute(
      CssCascade.FOOTNOTE_COUNTER_ATTR,
    );
    if (!footnoteCounter) {
      return;
    }
    const target = SemanticFootnote.resolveSemanticFootnoteTarget(
      element,
      this.xmldoc.url,
      (reference) => this.xmldoc.getElement(reference),
    );
    if (target) {
      target.setAttribute(CssCascade.FOOTNOTE_COUNTER_ATTR, footnoteCounter);
    }
  }

  createPseudoelementShadow(
    nodeContext: Vtree.NodeContext,
    element: Element,
    isRoot: boolean,
    cascStyle: CssCascade.ElementStyle,
    computedStyle: { [key: string]: Css.Val },
    styler: CssStyler.AbstractStyler,
    context: Exprs.Context,
    parentShadow: Vtree.ShadowContext | null,
    subShadow: Vtree.ShadowContext | null,
  ): Vtree.ShadowContext | null {
    const pseudoMap = this.getPseudoMap(
      cascStyle,
      this.regionIds,
      this.isFootnote,
      nodeContext,
      context,
    );
    if (!pseudoMap) {
      return subShadow;
    }
    const addedNames: string[] = [];
    const root = PseudoElement.document.createElementNS(Base.NS.SHADOW, "root");
    let att = root;
    const suppressSemanticNoterefContent =
      SemanticFootnote.isSemanticFootnoteNoterefElement(element) &&
      !!pseudoMap["footnote-call"] &&
      Vtree.nonTrivialContent(
        (pseudoMap["footnote-call"]["content"] as CssCascade.CascadeValue)
          ?.value,
      );
    for (const name of PseudoElement.pseudoNames) {
      let elem: Element;
      if (name) {
        if (!pseudoMap[name]) {
          continue;
        }
        const isSemanticFootnote =
          SemanticFootnote.isSemanticFootnoteElement(element);
        const isSemanticFootnoteContentInclude =
          element.namespaceURI === Base.NS.SHADOW &&
          element.localName === "include" &&
          element.classList.contains("-vivliostyle-footnote-content");
        if (
          name == "footnote-call" &&
          !SemanticFootnote.isSemanticFootnoteNoterefElement(element)
        ) {
          continue;
        }
        if (
          name == "footnote-marker" &&
          !(
            isSemanticFootnote ||
            isSemanticFootnoteContentInclude ||
            (isRoot && this.isFootnote)
          ) &&
          !this.nodeContext?.pluginProps["nestedFootnoteDetached"] // (Issue #1352)
        ) {
          continue;
        }
        if (name.startsWith("first-")) {
          const display = computedStyle["display"];
          if (!display || display === Css.ident.inline) {
            continue;
          }
          const child = element.firstElementChild;
          if (child && Vtree.canIgnore(child.previousSibling)) {
            const childStyle = styler.getStyle(child, false);
            if (childStyle) {
              const childDisplay = CssCascade.getProp(childStyle, "display");
              if (
                childDisplay?.value &&
                childDisplay.value !== Css.ident.inline
              ) {
                continue;
              }
            }
          }
        }
        if (
          name === "before" ||
          name === "after" ||
          name === "footnote-call" ||
          name === "footnote-marker"
        ) {
          const content = pseudoMap[name]["content"] as CssCascade.CascadeValue;
          const allowFootnoteEmptyPseudo =
            (name === "before" || name === "after") &&
            ((computedStyle["float"] as Css.Val) === Css.ident.footnote ||
              isSemanticFootnote ||
              isSemanticFootnoteContentInclude) &&
            !!content;
          if (
            !content ||
            (!Vtree.nonTrivialContent(content.value) &&
              !allowFootnoteEmptyPseudo)
          ) {
            continue;
          }
        }
        addedNames.push(name);
        elem = PseudoElement.document.createElementNS(Base.NS.XHTML, "span");
        PseudoElement.setPseudoName(elem, name);
      } else {
        if (suppressSemanticNoterefContent) {
          continue;
        }
        elem = PseudoElement.document.createElementNS(
          Base.NS.SHADOW,
          "content",
        );
      }
      att.appendChild(elem);
      if (name.startsWith("first-")) {
        att = elem;
      }
    }
    if (!addedNames.length) {
      return subShadow;
    }
    const shadowStyler = new PseudoElement.PseudoelementStyler(
      element,
      cascStyle,
      styler,
      context,
      this.exprContentListener,
    );
    const pseudoShadow = new Vtree.ShadowContext(
      element,
      root,
      null,
      parentShadow,
      subShadow,
      Vtree.ShadowType.ROOTLESS,
      shadowStyler,
    );
    return subShadow || pseudoShadow;
  }

  getPseudoMap(
    cascStyle: CssCascade.ElementStyle,
    regionIds: string[] | null,
    isFootnote: boolean,
    nodeContext: Vtree.NodeContext,
    context: Exprs.Context,
  ): CssCascade.ElementStyleMap | null {
    const pseudoMap = CssCascade.getStyleMap(cascStyle, "_pseudos");
    if (!pseudoMap) {
      return null;
    }
    const computedPseudoStyleMap: CssCascade.ElementStyleMap = {};
    for (const key in pseudoMap) {
      const computedPseudoStyle: { [key: string]: CssCascade.CascadeValue } =
        (computedPseudoStyleMap[key] = {});
      CssCascade.mergeStyle(computedPseudoStyle, pseudoMap[key], context);
      CssCascade.mergeViewConditionalStyles(
        computedPseudoStyle,
        context,
        pseudoMap[key],
      );
      CssCascade.forEachStylesInRegion(
        pseudoMap[key],
        regionIds,
        isFootnote,
        (regionId, regionStyle) => {
          CssCascade.mergeStyle(computedPseudoStyle, regionStyle, context);
          CssCascade.forEachViewConditionalStyles(
            regionStyle,
            (viewConditionalStyles) => {
              CssCascade.mergeStyle(
                computedPseudoStyle,
                viewConditionalStyles,
                context,
              );
            },
          );
        },
      );
    }
    return computedPseudoStyleMap;
  }

  createRefShadow(
    href: string,
    type: Vtree.ShadowType,
    element: Element,
    parentShadow: Vtree.ShadowContext | null,
    subShadow: Vtree.ShadowContext | null,
  ): Task.Result<Vtree.ShadowContext | null> {
    const frame: Task.Frame<Vtree.ShadowContext | null> =
      Task.newFrame("createRefShadow");
    this.xmldoc.store.load(href).then((refDocParam) => {
      const refDoc = refDocParam;
      if (refDoc) {
        const refElement = refDoc.getElement(href);
        if (refElement) {
          const refStyler = this.stylerProducer.getStylerForDoc(refDoc);
          subShadow = new Vtree.ShadowContext(
            element,
            refElement,
            refDoc,
            parentShadow,
            subShadow,
            type,
            refStyler,
          );
        }
      }
      frame.finish(subShadow);
    });
    return frame.result();
  }

  createShadows(
    nodeContext: Vtree.NodeContext,
    element: Element,
    isRoot: boolean,
    cascStyle: CssCascade.ElementStyle,
    computedStyle: { [key: string]: Css.Val },
    styler: CssStyler.AbstractStyler,
    context: Exprs.Context,
    shadowContext: Vtree.ShadowContext | null,
  ): Task.Result<Vtree.ShadowContext | null> {
    const frame: Task.Frame<Vtree.ShadowContext | null> =
      Task.newFrame("createShadows");
    const shadow: Vtree.ShadowContext | null = null;
    const templateURLVal = computedStyle["template"];
    let cont: Task.Result<Vtree.ShadowContext | null>;
    if (
      templateURLVal instanceof Css.URL ||
      templateURLVal === Css.ident.footnote
    ) {
      if (
        templateURLVal !== Css.ident.footnote ||
        SemanticFootnote.shouldGenerateSemanticFootnote(
          element,
          this.xmldoc.url,
          (noteref) => this.xmldoc.getElementOffset(noteref),
          this.semanticFootnoteFirstRefOffsets,
          this.semanticFootnoteFirstRefOffsetsInitialized,
        )
      ) {
        const url =
          templateURLVal instanceof Css.URL
            ? templateURLVal.url
            : Base.resolveURL("user-agent.xml#footnote", Base.resourceBaseURL);
        cont = this.createRefShadow(
          url,
          Vtree.ShadowType.ROOTLESS,
          element,
          shadowContext,
          shadow,
        );
      } else {
        cont = Task.newResult(shadow);
      }
    } else {
      cont = Task.newResult(shadow);
    }
    cont.then((shadow) => {
      let cont1: Task.Result<Vtree.ShadowContext | null> | null = null;
      if (element.namespaceURI == Base.NS.SHADOW) {
        if (element.localName == "include") {
          let href = element.getAttribute("href");
          let xmldoc: XmlDoc.XMLDocHolder = this.xmldoc;
          if (href) {
            xmldoc = shadowContext?.xmldoc ?? this.xmldoc;
          } else if (shadowContext) {
            if (shadowContext.owner.namespaceURI == Base.NS.XHTML) {
              href = shadowContext.owner.getAttribute("href");
            } else {
              href = shadowContext.owner.getAttributeNS(Base.NS.XLINK, "href");
            }
            xmldoc = shadowContext.parentShadow?.xmldoc ?? this.xmldoc;
          }
          if (href) {
            href = Base.resolveReferenceURL(href, xmldoc.url);
            cont1 = this.createRefShadow(
              href,
              Vtree.ShadowType.ROOTED,
              element,
              shadowContext,
              shadow,
            );
          }
        }
      }
      if (cont1 == null) {
        cont1 = Task.newResult(shadow);
      }
      let cont2: Task.Result<Vtree.ShadowContext | null> | null = null;
      cont1.then((shadow) => {
        if (computedStyle["display"] === Css.ident.table_cell) {
          const url = Base.resolveURL(
            "user-agent.xml#table-cell",
            Base.resourceBaseURL,
          );
          cont2 = this.createRefShadow(
            url,
            Vtree.ShadowType.ROOTLESS,
            element,
            shadowContext,
            shadow,
          );
        } else {
          cont2 = Task.newResult(shadow);
        }
        cont2.then((shadow) => {
          shadow = this.createPseudoelementShadow(
            nodeContext,
            element,
            isRoot,
            cascStyle,
            computedStyle,
            styler,
            context,
            shadowContext,
            shadow,
          );
          frame.finish(shadow);
        });
      });
    });
    return frame.result();
  }

  /** @override */
  setViewRoot(viewRoot: Element, isFootnote: boolean) {
    this.viewRoot = viewRoot;
    this.isFootnote = isFootnote;
  }

  /**
   * @return vertical
   */
  computeStyle(
    vertical: boolean,
    rtl: boolean,
    style: CssCascade.ElementStyle,
    computedStyle: { [key: string]: Css.Val },
  ): boolean {
    const context = this.context;
    const cascMap = CssCascade.flattenCascadedStyle(
      style,
      context,
      this.regionIds,
      this.isFootnote,
    );
    const isRoot = !this.nodeContext?.parent;
    if (isRoot) {
      // Ensure that writing-mode and direction are set on the root element,
      // except when the values are propagated from the body element. That
      // propagation is done on used values rather than computed values
      // (CSS Writing Modes spec), so it must not affect the root element's
      // computed style; otherwise the values would be inherited by the page
      // context (e.g., page margin boxes). (Issue #1122)
      const rootWritingMode = this.styler.rootStyle[
        "writing-mode"
      ] as CssCascade.CascadeValue;
      if (
        !cascMap["writing-mode"] &&
        rootWritingMode &&
        this.styler.bodyPropagatedStyle["writing-mode"] !== rootWritingMode
      ) {
        cascMap["writing-mode"] = rootWritingMode;
      }
      const rootDirection = this.styler.rootStyle[
        "direction"
      ] as CssCascade.CascadeValue;
      if (
        !cascMap["direction"] &&
        rootDirection &&
        this.styler.bodyPropagatedStyle["direction"] !== rootDirection
      ) {
        cascMap["direction"] = rootDirection;
      }
    }
    const verticalParent = vertical;
    vertical = CssCascade.isVertical(cascMap, context, vertical);
    // When writing-mode is propagated from the body element to the root
    // element as a used value (CSS Writing Modes spec), the root element's
    // used writing mode is the propagated one although its computed style is
    // unchanged. Return the used value verticality for the root so that the
    // body element is not treated as a writing-mode change (which would
    // cause the vertical-in-horizontal treatment (Issue #1264), e.g.,
    // `inline-size: auto` becoming `max-content`). (Issue #1122 follow-up)
    let usedVertical = vertical;
    if (isRoot && !vertical) {
      const rootWritingModeCasc = this.styler.rootStyle[
        "writing-mode"
      ] as CssCascade.CascadeValue;
      if (
        rootWritingModeCasc &&
        this.styler.bodyPropagatedStyle["writing-mode"] === rootWritingModeCasc
      ) {
        usedVertical = CssCascade.isVertical(
          { "writing-mode": rootWritingModeCasc },
          context,
          vertical,
        );
      }
    }
    const verticalChanged = !isRoot && vertical !== verticalParent;
    rtl = CssCascade.isRtl(cascMap, context, rtl);

    const transform = (
      name: string,
      cascVal: CssCascade.CascadeValue,
    ): Css.Val => {
      // The percent value of inline-size on vertical-in-horizontal or
      // horizontal-in-vertical block needs to be resolved against the
      // page area height or width. (Fix for issue #1264)
      let percentRef: number | undefined;
      if (verticalChanged) {
        if (vertical) {
          if (/^(min-|max-)?(height|inline-size)$/.test(name)) {
            percentRef = context.pageAreaHeight ?? undefined;
          }
        } else {
          if (/^(min-|max-)?(width|inline-size)$/.test(name)) {
            percentRef = context.pageAreaWidth ?? undefined;
          }
        }
      }
      let value = cascVal.evaluate(context, name, percentRef, vertical);
      if (name == "font-family" || name == "--viv-marker-font-family") {
        value = this.docFaces.filterFontFamily(value);
      }
      return value;
    };

    const isLeftPage = !!new Exprs.Named(
      (context as any).style.pageScope,
      "left-page",
    ).evaluate(context);

    CssCascade.convertToPhysical(
      cascMap,
      computedStyle,
      vertical,
      rtl,
      isLeftPage,
      transform,
    );

    if (verticalChanged) {
      // The auto value of inline-size on vertical-in-horizontal or
      // horizontal-in-vertical block is changed to max-content.
      // (Fix for issue #1264)
      const inlineSize = computedStyle[vertical ? "height" : "width"];
      if (!inlineSize || inlineSize === Css.ident.auto) {
        computedStyle[vertical ? "height" : "width"] = Css.ident.max_content;
      }
    }

    if (Display.isRunning(computedStyle["position"])) {
      // Running elements
      computedStyle["position"] = Css.ident.fixed;
      computedStyle["visibility"] = Css.ident.hidden;
      return usedVertical;
    }

    // Compute values of display, position and float
    const position = computedStyle["position"] as Css.Ident;
    const float = computedStyle["float"];
    const display =
      (computedStyle["display"] as Css.Ident) ||
      (this.sourceNode &&
      (this.sourceNode as Element).namespaceURI === Base.NS.XHTML
        ? Css.ident.inline
        : undefined); // leave it to the browser for MathML and SVG
    const displayValues = Display.getComputedDisplayValue(
      display,
      position,
      float,
      this.sourceNode === this.xmldoc.root,
    );
    ["display", "position", "float"].forEach((name) => {
      if (displayValues[name]) {
        computedStyle[name] = displayValues[name];
      }
    });
    return usedVertical;
  }

  private inheritFromSourceParent(
    nodeContext: Vtree.NodeContext,
    elementStyle: CssCascade.ElementStyle,
  ): {
    lang: string | null;
    elementStyle: CssCascade.ElementStyle;
  } {
    let node: Node | null = nodeContext.sourceNode;
    const styles: CssCascade.ElementStyle[] = [];
    let lang: string | null = null;
    const isFootnoteContentInclude =
      node instanceof Element &&
      node.namespaceURI === Base.NS.SHADOW &&
      node.localName === "include" &&
      node.classList.contains("-vivliostyle-footnote-content");
    const shouldSkipAncestorMarkerProps =
      this.isFootnote && (!nodeContext.parent || isFootnoteContentInclude);

    // TODO: this is hacky. We need to recover the path through the shadow
    // trees, but we do not have the full shadow tree structure at this point.
    // This code handles coming out of the shadow trees, but does not go back in
    // (through shadow:content element).
    let shadowContext = nodeContext.shadowContext;

    // For semantic footnotes, the wrapper generated from
    // <s:include class="-vivliostyle-footnote-content"> should inherit from
    // the referenced footnote's source parent, not from the noteref owner.
    // (Issue #1770)
    if (
      node instanceof Element &&
      node.namespaceURI === Base.NS.SHADOW &&
      node.localName === "include" &&
      node.classList.contains("-vivliostyle-footnote-content")
    ) {
      const owner = shadowContext?.owner;
      if (
        owner instanceof Element &&
        SemanticFootnote.isSemanticFootnoteNoterefElement(owner)
      ) {
        const href =
          owner.getAttribute("href") ||
          owner.getAttributeNS(Base.NS.XLINK, "href");
        if (href) {
          const resolvedHref = Base.resolveReferenceURL(href, this.xmldoc.url);
          const target = this.xmldoc.getElement(resolvedHref);
          if (
            target &&
            SemanticFootnote.isSemanticFootnoteElement(target) &&
            target.parentNode?.nodeType === 1
          ) {
            node = target.parentNode;
            shadowContext = null;
          }
        }
      }
    }

    let steps = -1;
    while (node && node.nodeType == 1) {
      const shadow = shadowContext;
      const shadowRoot = shadow !== null && shadow.root == node;
      const semanticFootnoteRootInRootedShadow =
        shadowRoot &&
        shadow.type == Vtree.ShadowType.ROOTED &&
        SemanticFootnote.isSemanticFootnoteElement(node as Element);
      if (
        !shadowRoot ||
        shadow.type == Vtree.ShadowType.ROOTLESS ||
        semanticFootnoteRootInRootedShadow
      ) {
        const styler = shadow
          ? (shadow.styler as CssStyler.AbstractStyler)
          : this.styler;
        const nodeStyle = styler.getStyle(node as Element, false);
        styles.push(nodeStyle);
        lang = lang || Base.getLangAttribute(node as Element);
      }
      if (shadowRoot && !semanticFootnoteRootInRootedShadow) {
        node = shadow.owner;
        shadowContext = shadow.parentShadow;
      } else {
        node = node.parentNode;
        steps++;
      }
    }

    // When reconstructing inherited values for detached/transcluded nodes,
    // keep declarations on the current element (including region-specific
    // rules such as :footnote-content) authoritative over ancestor-derived
    // inherited values.
    const blockedInheritedByCurrent = new Set<string>();
    if (styles.length > 0) {
      const currentStyle = styles[0];
      const flattenedCurrentStyle = CssCascade.flattenCascadedStyle(
        currentStyle,
        this.context,
        this.regionIds,
        this.isFootnote,
      );
      for (const name in flattenedCurrentStyle) {
        if (!CssCascade.isInherited(name)) {
          continue;
        }
        const value = flattenedCurrentStyle[name].evaluate(this.context, name);
        if (
          value &&
          value !== Css.ident.inherit &&
          value !== Css.ident.unset &&
          value !== Css.empty &&
          !Css.isRollbackValue(value)
        ) {
          blockedInheritedByCurrent.add(name);
        }
      }
    }

    const isRoot = steps === 0;
    const fontSize = this.context.queryUnitSize("em", isRoot);
    const props = {
      "font-size": new CssCascade.CascadeValue(
        new Css.Numeric(fontSize, "px"),
        0,
      ),
    } as CssCascade.ElementStyle;
    if (isRoot) {
      props["line-height"] = new CssCascade.CascadeValue(
        new Css.Num(this.context.pref.lineHeight),
        0,
      );
    }
    const inheritanceVisitor = new CssCascade.InheritanceVisitor(
      props,
      this.context,
    );
    for (let i = styles.length - 1; i >= 0; --i) {
      const style = styles[i];
      const propList: string[] = [];
      for (const propName in style) {
        if (CssCascade.isInherited(propName)) {
          propList.push(propName);
        }
      }
      propList.sort(Css.processingOrderFn);
      let fontSize: Css.Val | undefined;
      let lineHeight: Css.Val | undefined;

      for (const name of propList) {
        if (
          i > 0 &&
          shouldSkipAncestorMarkerProps &&
          name.startsWith("--viv-marker-")
        ) {
          continue;
        }
        if (i > 0 && blockedInheritedByCurrent.has(name)) {
          continue;
        }
        inheritanceVisitor.setPropName(name);
        const prop = CssCascade.getProp(style, name);
        let prop1 = prop;
        if (prop.value === Css.ident.initial) {
          // `initial` means use the CSS initial value, not inherit from
          // ancestor. This is needed for `all: initial` to work on elements
          // detached from their source parent (e.g. footnotes). (Issue #1696)
          delete props[name];
        } else if (!Css.isDefaultingValue(prop.value)) {
          if (
            name === "font-size" &&
            i === styles.length - 1 &&
            this.context.isRelativeRootFontSize &&
            this.context.rootFontSize
          ) {
            // Fix for issue #608, #549
            prop1 = new CssCascade.CascadeValue(
              new Css.Numeric(this.context.rootFontSize, "px"),
              prop.priority,
            );
          } else if (
            name === "line-height" &&
            i === styles.length - 1 &&
            ((prop.value instanceof Css.Numeric &&
              (prop.value.unit === "lh" || prop.value.unit === "rlh")) ||
              this.context.isRootLineHeightFromRelativeCalc)
          ) {
            // line-height with lh or rlh unit on root element
            prop1 = new CssCascade.CascadeValue(
              new Css.Numeric(this.context.rootLineHeight, "px"),
              prop.priority,
            );
          } else if (
            i === 0 &&
            prop.value instanceof Css.Numeric &&
            prop.value.unit === "lh"
          ) {
            // line-height with lh unit on current element
            const lhUnitSize = this.getLineHeightUnitSize(
              name,
              fontSize,
              lineHeight,
            );
            if (lhUnitSize != null) {
              prop1 = new CssCascade.CascadeValue(
                new Css.Numeric(prop.value.num * lhUnitSize, "px"),
                prop.priority,
              );
            }
          } else if (!Css.isCustomPropName(name)) {
            prop1 = prop.filterValue(inheritanceVisitor);
          }

          if (name === "font-size") {
            fontSize = prop1.value;
          } else if (name === "line-height") {
            lineHeight = prop1.value;
          }

          props[name] = prop1;
        }
      }
    }
    for (const sname in elementStyle) {
      if (!CssCascade.isInherited(sname)) {
        props[sname] = elementStyle[sname];
      }
    }
    return { lang, elementStyle: props };
  }

  resolveURL(url: string): string {
    url = Base.resolveURL(url, this.xmldoc.url);
    return this.fallbackMap[url] || url;
  }

  inheritLangAttribute(nodeContext: Vtree.NodeContext) {
    nodeContext.lang =
      Base.getLangAttribute(nodeContext.sourceNode as Element) ||
      (nodeContext.parent && nodeContext.parent.lang) ||
      nodeContext.lang;
  }

  transferPolyfilledInheritedProps(
    nodeContext: Vtree.NodeContext,
    computedStyle: { [key: string]: Css.Val },
  ) {
    const polyfilledInheritedProps =
      CssCascade.getPolyfilledInheritedProps().filter(
        (name) => computedStyle[name],
      );
    if (polyfilledInheritedProps.length) {
      let props = nodeContext.inheritedProps;
      if (nodeContext.parent) {
        props = nodeContext.inheritedProps = {};
        for (const n in nodeContext.parent.inheritedProps) {
          props[n] = nodeContext.parent.inheritedProps[n];
        }
      }
      polyfilledInheritedProps.forEach((name) => {
        const value = computedStyle[name];
        if (value) {
          if (Css.isDefaultingValue(value)) {
            if (value === Css.ident.initial) {
              props[name] = undefined;
            }
          } else if (value instanceof Css.Int) {
            props[name] = (value as Css.Int).num;
          } else if (value instanceof Css.Ident) {
            props[name] = (value as Css.Ident).name;
          } else if (value instanceof Css.Numeric) {
            const numericVal = value as Css.Numeric;
            switch (numericVal.unit) {
              case "dpi":
              case "dpcm":
              case "dppx":
                props[name] =
                  numericVal.num * Exprs.defaultUnitSizes[numericVal.unit];
                break;
              default:
                props[name] = value;
            }
          } else {
            props[name] = value;
          }
          if (!["widows", "orphans"].includes(name)) {
            // Note: widows and orphans are polyfilled for page and
            // root multi-column, but they should be left to the browser
            // for multi-column boxes inside body. (Issue #1182)
            delete computedStyle[name];
          }
        }
      });
    }
  }

  resolveFormattingContext(
    nodeContext: Vtree.NodeContext,
    firstTime: boolean,
    display: Css.Val | null | undefined,
    position: Css.Ident | null | undefined,
    float: Css.Val | null | undefined,
    isRoot: boolean,
  ) {
    const hooks: Plugin.ResolveFormattingContextHook[] = Plugin.getHooksForName(
      Plugin.HOOKS.RESOLVE_FORMATTING_CONTEXT,
    );
    for (let i = 0; i < hooks.length; i++) {
      const formattingContext = hooks[i](
        nodeContext,
        firstTime,
        display,
        position,
        float,
        isRoot,
      );
      if (formattingContext) {
        nodeContext.formattingContext = formattingContext;
        return;
      }
    }
  }

  /**
   * @return holding true if children should be processed
   */
  private createElementView(
    nodeContext: Vtree.NodeContext,
    firstTime: boolean,
  ): Task.Result<boolean> {
    let needToProcessChildren = true;
    const frame: Task.Frame<boolean> = Task.newFrame("createElementView");

    // Figure out element's styles
    let element = this.sourceNode as Element;
    const styler = nodeContext.shadowContext
      ? nodeContext.shadowContext.styler
      : this.styler;
    let elementStyle = styler.getStyle(element, false);
    this.syncSemanticFootnoteCounterToTarget(element);
    if (!nodeContext.shadowContext) {
      const offset = this.xmldoc.getElementOffset(element);
      Matchers.NthFragmentMatcher.registerFragmentIndex(
        offset,
        nodeContext.fragmentIndex,
        0,
      );
    }
    const computedStyle: { [key: string]: Css.Val } = {};
    const semanticFootnoteStyleAccess: SemanticFootnote.SemanticFootnoteStyleAccess =
      {
        getStyle: (target) => this.styler.getStyle(target, false),
        getProp: (style, propName) =>
          style ? CssCascade.getProp(style, propName) : null,
        getStyleMap: (style, mapName) => CssCascade.getStyleMap(style, mapName),
        getMutableStyleMap: (style, mapName) =>
          CssCascade.getMutableStyleMap(style, mapName),
        createCascadeValue: (value, priority) =>
          new CssCascade.CascadeValue(value, priority),
        filterFootnoteMarkerContent: (content, target) =>
          content.filterValue(
            new CssCascade.ContentPropVisitor(
              this.styler.cascade,
              target,
              this.styler.cascade.counterResolver,
              this.styler.elementWindow.currentStyle,
              "footnote-marker",
            ),
          ).value,
      };
    if (!nodeContext.parent) {
      const inheritedValues = this.inheritFromSourceParent(
        nodeContext,
        elementStyle,
      );
      elementStyle = inheritedValues.elementStyle;
      nodeContext.lang = inheritedValues.lang;
    }
    const positionCV: CssCascade.CascadeValue = elementStyle["position"];
    const floatCV: CssCascade.CascadeValue = elementStyle["float"];
    const floatReferenceCV: CssCascade.CascadeValue =
      elementStyle["float-reference"];
    const floatReference =
      floatCV &&
      !Css.isDefaultingValue(floatCV.value) &&
      floatCV.value !== Css.ident.none &&
      floatReferenceCV &&
      !Css.isDefaultingValue(floatReferenceCV.value)
        ? PageFloats.floatReferenceOf(floatReferenceCV.value.toString())
        : null;
    const isSemanticFootnoteInRootedShadow =
      !!nodeContext.shadowContext &&
      nodeContext.shadowContext.type === Vtree.ShadowType.ROOTED &&
      SemanticFootnote.isSemanticFootnoteElement(element);
    if (
      nodeContext.parent &&
      (Display.isRunning(positionCV?.value) ||
        (floatReference && PageFloats.isPageFloat(floatReference)) ||
        isSemanticFootnoteInRootedShadow)
    ) {
      // Detached or transcluded content should inherit from the source tree,
      // not from the synthetic view parent.
      const inheritedValues = this.inheritFromSourceParent(
        nodeContext,
        elementStyle,
      );
      elementStyle = inheritedValues.elementStyle;
      nodeContext.lang = inheritedValues.lang;
    }
    elementStyle = SemanticFootnote.mergeSemanticFootnoteIncludeStyle(
      element,
      elementStyle,
      nodeContext.shadowContext,
      this.xmldoc.url,
      (reference) => this.xmldoc.getElement(reference),
      CssCascade.FOOTNOTE_COUNTER_ATTR,
      semanticFootnoteStyleAccess,
    );
    elementStyle = SemanticFootnote.mergeSemanticFootnoteRootStyle(
      element,
      elementStyle,
      nodeContext.shadowContext,
      this.context,
      semanticFootnoteStyleAccess,
    );
    nodeContext.vertical = this.computeStyle(
      nodeContext.vertical,
      nodeContext.direction === "rtl",
      elementStyle,
      computedStyle,
    );
    if (
      floatReference &&
      PageFloats.isPageFloat(floatReference) &&
      computedStyle["display"] === Css.ident.block
    ) {
      // Fix page float margin collapsing issue (Issue #1282)
      computedStyle["display"] = Css.ident.flow_root;
    }
    styler.processContent(element, computedStyle, nodeContext);
    this.transferPolyfilledInheritedProps(nodeContext, computedStyle);
    this.inheritLangAttribute(nodeContext);
    if (computedStyle["direction"]) {
      nodeContext.direction = computedStyle["direction"].toString();
    }

    // Sort out the properties
    const flow = computedStyle["flow-into"];
    if (flow && flow.toString() != this.flowName) {
      // foreign flow, don't create a view
      frame.finish(false);
      return frame.result();
    }
    if (
      Scripts.allowScripts &&
      element.localName === "script" &&
      element.namespaceURI === Base.NS.XHTML
    ) {
      Scripts.loadScript(
        element as HTMLScriptElement,
        this.viewport.window,
      ).thenFinish(frame);
      return frame.result();
    }

    let display: Css.Val | null | undefined = computedStyle["display"];

    if (
      SemanticFootnote.isSemanticFootnoteElement(element) &&
      !isSemanticFootnoteInRootedShadow &&
      element.hasAttribute(SemanticFootnote.SEMANTIC_FOOTNOTE_REFERENCED_ATTR)
    ) {
      display = computedStyle["display"] = Css.ident.none;
    }

    if (Css.isDefaultingValue(display)) {
      if (display === Css.ident.initial || display === Css.ident.unset) {
        display = Css.ident.inline;
      } else if (display === Css.ident.inherit) {
        display = nodeContext.parent?.display
          ? Css.getName(nodeContext.parent.display)
          : null;
      } else {
        display = null;
      }
    }
    if (display === Css.ident.none) {
      // no content
      frame.finish(false);
      return frame.result();
    }
    const isRoot = nodeContext.parent == null;
    const blockSize = computedStyle[nodeContext.vertical ? "width" : "height"];
    // Issue #1999: fixed-size grid boxes used as synthetic page references
    // must stay whole. Once fragmented, continuation fragments lose the block
    // size and later reference pages collapse.
    const isFixedSizeGridContainer =
      (display === Css.ident.grid || display === Css.ident.inline_grid) &&
      !!blockSize &&
      !(blockSize === Css.ident.auto || Css.isDefaultingValue(blockSize));
    nodeContext.flexContainer =
      display === Css.ident.flex || isFixedSizeGridContainer;
    this.createShadows(
      nodeContext,
      element,
      isRoot,
      elementStyle,
      computedStyle,
      styler,
      this.context,
      nodeContext.shadowContext,
    ).then((shadowParam) => {
      nodeContext.nodeShadow = shadowParam;
      const position = computedStyle["position"] as Css.Ident;
      let floatSide: Css.Val | null = computedStyle["float"];
      let clearSide: Css.Ident | null = computedStyle["clear"] as Css.Ident;
      const writingMode = nodeContext.vertical
        ? Css.ident.vertical_rl
        : Css.ident.horizontal_tb;
      const parentWritingMode = nodeContext.parent
        ? nodeContext.parent.vertical
          ? Css.ident.vertical_rl
          : Css.ident.horizontal_tb
        : writingMode;
      const isFlowRoot = Display.isFlowRoot(element);
      const columnCount = computedStyle["column-count"];
      const columnWidth = computedStyle["column-width"];
      const isMultiColumn =
        (columnCount &&
          columnCount !== Css.ident.auto &&
          !Css.isDefaultingValue(columnCount)) ||
        (columnWidth &&
          columnWidth !== Css.ident.auto &&
          !Css.isDefaultingValue(columnWidth));
      nodeContext.establishesBFC = Display.establishesBFC(
        display,
        position,
        floatSide,
        computedStyle["overflow"] as Css.Ident,
        writingMode,
        parentWritingMode,
        isMultiColumn || isFlowRoot,
      );
      nodeContext.containingBlockForAbsolute =
        Display.establishesCBForAbsolute(position);
      if (
        nodeContext.isInsideBFC() &&
        floatSide !== Css.ident.footnote &&
        !(floatReference && PageFloats.isPageFloat(floatReference))
      ) {
        // When the element is already inside a block formatting context
        // (except one from the root), float and clear can be controlled by
        // the browser and we don't need to care.
        floatSide = null;
        clearSide = null;
      }
      let footnoteDisplay: Css.Val | null = null;
      let usesOutsideFootnoteMarker = false;
      const isFootnoteBodyInFootnoteArea =
        this.isFootnote &&
        (!nodeContext.parent ||
          nodeContext.pluginProps["nestedFootnoteDetached"] ||
          isSemanticFootnoteInRootedShadow);
      const semanticFootnoteStyle =
        SemanticFootnote.getSemanticFootnoteStyleState(
          element,
          nodeContext.shadowContext,
          semanticFootnoteStyleAccess,
        );
      SemanticFootnote.refreshSemanticFootnoteMarkerContent(
        semanticFootnoteStyle.sourceStyle,
        computedStyle,
        this.context,
      );
      footnoteDisplay = semanticFootnoteStyle.footnoteDisplay;

      const floatSideName =
        floatSide instanceof Css.SpaceList ||
        floatSide === Css.ident.left ||
        floatSide === Css.ident.right ||
        floatSide === Css.ident.top ||
        floatSide === Css.ident.bottom ||
        floatSide === Css.ident.inline_start ||
        floatSide === Css.ident.inline_end ||
        floatSide === Css.ident.block_start ||
        floatSide === Css.ident.block_end ||
        floatSide === Css.ident.snap_block ||
        floatSide === Css.ident.snap_inline ||
        floatSide === Css.ident.inside ||
        floatSide === Css.ident.outside ||
        floatSide === Css.ident.footnote
          ? floatSide.toString()
          : null;
      let floating = floatSideName !== null;
      if (floatSide) {
        // Don't want to set it in view DOM CSS.
        delete computedStyle["float"];
        if (floatSide === Css.ident.footnote) {
          footnoteDisplay =
            computedStyle["footnote-display"] || footnoteDisplay;
          usesOutsideFootnoteMarker = !!computedStyle["--viv-marker-content"];
          if (isFootnoteBodyInFootnoteArea) {
            // Root of the footnote body being rendered in footnote area.
            // Nested footnote inside a footnote area: render as a detached block
            // entry, with call marker handled separately. (Issue #1352)
            floating = false;
            const footnoteDisplayName = footnoteDisplay?.toString();
            if (footnoteDisplayName) {
              computedStyle["--viv-footnote-display"] =
                Css.getName(footnoteDisplayName);
            }
            display = usesOutsideFootnoteMarker
              ? Css.getName("list-item")
              : footnoteDisplayName === "inline" ||
                  footnoteDisplayName === "compact"
                ? Css.ident.inline
                : Css.ident.block;
            computedStyle["display"] = display;
          } else {
            // Footnote body in main flow (not yet in footnote area):
            // render inline (only the call marker is visible), but keep
            // the blockified display variable so nodeContext.inline stays
            // false — layout needs this to collect the float properly.
            computedStyle["display"] = Css.ident.inline;
          }
        }
      }
      if (
        isFootnoteBodyInFootnoteArea &&
        SemanticFootnote.isSemanticFootnoteElement(element)
      ) {
        usesOutsideFootnoteMarker =
          usesOutsideFootnoteMarker || !!computedStyle["--viv-marker-content"];
        const footnoteDisplayName = footnoteDisplay?.toString();
        if (footnoteDisplayName) {
          computedStyle["--viv-footnote-display"] =
            Css.getName(footnoteDisplayName);
        }
        if (usesOutsideFootnoteMarker) {
          display = computedStyle["display"] = Css.getName("list-item");
        }
        if (
          !usesOutsideFootnoteMarker &&
          (footnoteDisplayName === "inline" ||
            footnoteDisplayName === "compact")
        ) {
          display = computedStyle["display"] = Css.ident.inline;
        }
      }
      if (clearSide) {
        if (clearSide === Css.ident.inherit) {
          if (nodeContext.parent && nodeContext.parent.clearSide) {
            clearSide = Css.getName(nodeContext.parent.clearSide);
          }
        }
        if (
          clearSide === Css.ident.left ||
          clearSide === Css.ident.right ||
          clearSide === Css.ident.top ||
          clearSide === Css.ident.bottom ||
          clearSide === Css.ident.inline_start ||
          clearSide === Css.ident.inline_end ||
          clearSide === Css.ident.block_start ||
          clearSide === Css.ident.block_end ||
          clearSide === Css.ident.inside ||
          clearSide === Css.ident.outside ||
          clearSide === Css.ident.both ||
          clearSide === Css.ident.all ||
          clearSide === Css.ident.same ||
          clearSide === Css.ident.column ||
          clearSide === Css.ident.region ||
          clearSide === Css.ident.page
        ) {
          delete computedStyle["clear"];
          if (
            floating ||
            (computedStyle["display"] &&
              computedStyle["display"] != Css.ident.inline)
          ) {
            nodeContext.clearSide = clearSide.toString();
          }
        }
      }
      const isListItem =
        Display.isListItem(display) &&
        !!(
          computedStyle["ua-list-item-count"] ||
          computedStyle["--viv-marker-content"]
        );
      const breakInside = computedStyle["break-inside"];
      if (
        floating ||
        (breakInside &&
          !Css.isDefaultingValue(breakInside) &&
          breakInside !== Css.ident.auto)
      ) {
        nodeContext.breakPenalty++;
      }
      if (
        display &&
        display !== Css.ident.inline &&
        Display.isInlineLevel(display)
      ) {
        // Don't break inside ruby, inline-block, etc.
        nodeContext.breakPenalty++;
      }
      nodeContext.inline =
        (!floating && !display) ||
        Display.isInlineLevel(display) ||
        Display.isRubyInternalDisplay(display);
      nodeContext.display = display ? display.toString() : "inline";
      nodeContext.floatSide = floating ? floatSideName : null;
      nodeContext.floatReference =
        floatReference || PageFloats.FloatReference.INLINE;
      const floatMinWrapBlock = computedStyle["float-min-wrap-block"];
      nodeContext.floatMinWrapBlock =
        floatMinWrapBlock && !Css.isDefaultingValue(floatMinWrapBlock)
          ? (floatMinWrapBlock as Css.Numeric)
          : null;

      // Leaves handling of multicol specified on non-root/body elements to the browser
      const insideNonRootMultiColumn =
        this.isInsideNonRootMultiColumn(nodeContext);

      const columnSpan = computedStyle["column-span"];
      nodeContext.columnSpan =
        !insideNonRootMultiColumn &&
        columnSpan &&
        !Css.isDefaultingValue(columnSpan)
          ? columnSpan
          : null;
      if (!nodeContext.inline) {
        const breakAfter = computedStyle["break-after"];
        if (
          breakAfter &&
          !Css.isDefaultingValue(breakAfter) &&
          !(insideNonRootMultiColumn && breakAfter === Css.ident.column)
        ) {
          nodeContext.breakAfter = breakAfter.toString();
          if (Break.forcedBreakValues[nodeContext.breakAfter]) {
            // delete computedStyle["break-after"];

            // Instead of deleting, set to "column" so that the browser can handle it.
            computedStyle["break-after"] = Css.ident.column;
          }
        }
        const breakBefore = computedStyle["break-before"];
        if (
          breakBefore &&
          !Css.isDefaultingValue(breakBefore) &&
          !(insideNonRootMultiColumn && breakBefore === Css.ident.column)
        ) {
          nodeContext.breakBefore = breakBefore.toString();
          if (Break.forcedBreakValues[nodeContext.breakBefore]) {
            if (this.isAtStartOfPage()) {
              delete computedStyle["break-before"];
            } else {
              // Set to "column" so that the browser can handle it.
              computedStyle["break-before"] = Css.ident.column;
            }
          }
          if (nodeContext.fragmentIndex !== 1) {
            nodeContext.breakBefore = null;
          }
        }
        // Named page type
        const pageVal: Css.Val = computedStyle["page"];
        const specifiedPageType =
          pageVal && !Css.isDefaultingValue(pageVal)
            ? pageVal.toString()
            : null;
        let pageType = specifiedPageType;
        if (
          !pageType &&
          !nodeContext.parent &&
          (nodeContext.shadowContext ||
            display === Css.ident.table_header_group ||
            display === Css.ident.table_footer_group)
        ) {
          // Keep currentPageType for shadowContext (Fix for issue #1233)
          pageType = this.styler.cascade.currentPageType;
        }
        if (!pageType || pageType.toLowerCase() === "auto") {
          pageType = nodeContext.pageType;
        } else {
          nodeContext.pageType = pageType;
        }
        const hasExplicitPageType =
          specifiedPageType != null &&
          specifiedPageType.toLowerCase() !== "auto";
        const effectivePageType = hasExplicitPageType
          ? nodeContext.fragmentIndex === 1
            ? this.getEffectiveStartPageType(element, pageType)
            : (this.styler.cascade.currentPageType ?? pageType)
          : pageType;
        if (
          this.styler.cascade.currentPageType !== effectivePageType &&
          // Fixed positioned or running elements should not affect page type
          // unless page type is explicitly set
          !(
            !hasExplicitPageType &&
            computedStyle["position"] === Css.ident.fixed
          )
        ) {
          if (
            nodeContext.fragmentIndex === 1 &&
            !Break.isSpreadBreakValue(nodeContext.breakBefore)
          ) {
            nodeContext.breakBefore = "page";
          }
          // Fix for issue #1309
          if (effectivePageType !== this.styler.cascade.previousPageType) {
            this.styler.cascade.previousPageType =
              this.styler.cascade.currentPageType;
          }
          this.styler.cascade.currentPageType = effectivePageType;
        }
      }
      nodeContext.captionSide =
        (computedStyle["caption-side"] &&
          computedStyle["caption-side"].toString()) ||
        "top";
      const borderCollapse = computedStyle["border-collapse"];
      if (!borderCollapse || borderCollapse === Css.getName("separate")) {
        const borderSpacing = computedStyle["border-spacing"];
        let inlineBorderSpacing: Css.Val;
        let blockBorderSpacing: Css.Val;
        if (borderSpacing) {
          if (borderSpacing instanceof Css.SpaceList) {
            inlineBorderSpacing = borderSpacing.values[0];
            blockBorderSpacing = borderSpacing.values[1];
          } else {
            inlineBorderSpacing = blockBorderSpacing = borderSpacing;
          }
          if (inlineBorderSpacing.isNumeric()) {
            nodeContext.inlineBorderSpacing = Css.toNumber(
              inlineBorderSpacing,
              this.context,
            );
          }
          if (blockBorderSpacing.isNumeric()) {
            nodeContext.blockBorderSpacing = Css.toNumber(
              blockBorderSpacing,
              this.context,
            );
          }
        }
      }
      const footnotePolicy =
        (computedStyle["footnote-policy"] as Css.Ident) ||
        semanticFootnoteStyle.footnotePolicy;
      if (footnotePolicy && !Css.isDefaultingValue(footnotePolicy)) {
        computedStyle["--viv-footnote-policy"] = footnotePolicy;
      }
      nodeContext.footnotePolicy =
        footnotePolicy && !Css.isDefaultingValue(footnotePolicy)
          ? footnotePolicy
          : null;
      const firstPseudo = computedStyle["x-first-pseudo"] as Css.Int;
      if (firstPseudo) {
        const outerPseudo = nodeContext.parent
          ? nodeContext.parent.firstPseudo
          : null;
        nodeContext.firstPseudo = new Vtree.FirstPseudo(
          outerPseudo,
          /** Css.Int */
          firstPseudo.num,
        );
      }
      if (!nodeContext.inline) {
        this.processAfterIfcontinues(
          nodeContext,
          element,
          elementStyle,
          styler,
          this.context,
        );
      }
      const whitespace = computedStyle["white-space"];
      if (whitespace) {
        const whitespaceValue = Vtree.whitespaceFromPropertyValue(
          whitespace.toString(),
        );
        if (whitespaceValue !== null) {
          nodeContext.whitespace = whitespaceValue;
        }
      }
      const hyphenateCharacter = computedStyle["hyphenate-character"];
      if (hyphenateCharacter && hyphenateCharacter instanceof Css.Str) {
        nodeContext.hyphenateCharacter = hyphenateCharacter.str;
      }
      const wordBreak = computedStyle["word-break"];
      const lineBreak = computedStyle["line-break"];
      const overflowWrap = computedStyle["overflow-wrap"];
      if (
        wordBreak === Css.ident.break_all ||
        lineBreak === Css.ident.anywhere ||
        overflowWrap === Css.ident.break_word ||
        overflowWrap === Css.ident.anywhere
      ) {
        nodeContext.breakWord = true;
      }

      // Resolve formatting context
      this.resolveFormattingContext(
        nodeContext,
        firstTime,
        display,
        position,
        floatSide,
        isRoot,
      );
      if (nodeContext.parent) {
        firstTime = nodeContext.parent.formattingContext.isFirstTime(
          nodeContext,
          firstTime,
        );
      }
      if (!nodeContext.inline) {
        nodeContext.repeatOnBreak = this.processRepeatOnBreak(computedStyle);
        this.findAndProcessRepeatingElements(nodeContext, element, styler);
      }

      // Create the view element
      let custom = false;
      let inner: Element | null = null;
      const fetchers: TaskUtil.Fetcher<string>[] = [];
      let ns = element.namespaceURI;
      let tag = element.localName;
      let originalTag = tag;
      if (ns == Base.NS.XHTML) {
        if (xhtmlElementsRenderedAsDiv.has(tag)) {
          tag = "div";
        } else if (tag == "vide_") {
          tag = "video";
        } else if (tag == "audi_") {
          tag = "audio";
        } else if (tag == "object") {
          custom = true;
        }
        if (
          element.hasAttribute(PseudoElement.PSEUDO_ATTR) &&
          element.hasAttribute("src") &&
          computedStyle["content"] instanceof Css.URL
        ) {
          tag = "img";
        }
      } else if (ns == Base.NS.epub) {
        tag = "span";
        ns = Base.NS.XHTML;
      } else if (ns == Base.NS.SHADOW) {
        ns = Base.NS.XHTML;
        tag = nodeContext.inline ? "span" : "div";
      } else {
        custom = true;
      }
      if (isListItem) {
        // Keep display: list-item so the browser's native ::marker is used.
        if (firstTime) {
          tag = "li";
          if (computedStyle["--viv-marker-content"]) {
            // We control marker content via --viv-marker-content CSS custom
            // property. WebKit cannot render content on ::marker, so fall
            // back to list-style-* when the resolved marker can be expressed
            // there. (Issue #2017)
            if (!applyWebKitMarkerFallback(computedStyle)) {
              computedStyle["list-style-type"] = Css.ident.none;
              computedStyle["list-style-image"] = Css.ident.none;
            }
          }
        } else {
          // Subsequent fragments: no marker
          display = Display.isInlineLevel(display)
            ? Css.ident.inline
            : Css.ident.block;
          computedStyle["display"] = display;
          tag = "div";
        }
      } else if (tag == "body" || tag == "li") {
        tag = "div";
      } else if (tag == "q") {
        tag = "span";
      }
      if (computedStyle["behavior"]) {
        const behavior = computedStyle["behavior"].toString();
        if (behavior != "none") {
          custom = true;
        }
      }
      if (
        (element as HTMLElement).dataset &&
        element.getAttribute("data-math-typeset") === "true"
      ) {
        custom = true;
      }
      let elemResult: Task.Result<Element | null>;
      if (custom) {
        const parentNode = nodeContext.parent
          ? nodeContext.parent.viewNode
          : null;
        elemResult = this.customRenderer(
          element,
          parentNode as Element,
          computedStyle,
        );
      } else {
        elemResult = Task.newResult(null);
      }
      elemResult.then((result) => {
        if (result) {
          if (custom) {
            needToProcessChildren =
              result.getAttribute("data-adapt-process-children") == "true";
          }
        } else if (computedStyle["display"] === Css.ident.none) {
          // No element should be created if display:none is set.
          // (Fix issue #924)
          frame.finish(false);
          return;
        } else {
          result = this.createElement(ns, tag);
        }

        if (
          !isRoot &&
          isMultiColumn &&
          computedStyle["column-fill"] === Css.ident.auto
        ) {
          const blockSize = nodeContext.vertical
            ? computedStyle["width"]
            : computedStyle["height"];
          if (
            !blockSize ||
            blockSize === Css.ident.auto ||
            Css.isDefaultingValue(blockSize)
          ) {
            // To make `column-fill: auto` with auto block size work on non-root multi-column,
            // we change it to `balance` here, and after layout, we change it back.
            // (Issue #1720, #1758)
            result.setAttribute("data-viv-saved-column-fill", "auto");
            computedStyle["column-fill"] = Css.ident.balance;
          }
        }

        if (tag != originalTag) {
          result.setAttribute("data-vivliostyle-original-tag", originalTag);
          if (originalTag === "html" || originalTag === "body") {
            result.role = "presentation";
          }
        }
        if (tag == "a") {
          result.addEventListener("click", this.page.hrefHandler, false);
        }
        if (inner) {
          this.applyPseudoelementStyle(nodeContext, "inner", inner);
          result.appendChild(inner);
        }
        if (
          result.localName == "iframe" &&
          result.namespaceURI == Base.NS.XHTML
        ) {
          initIFrame(result as HTMLIFrameElement);
        }
        const imageResolution = nodeContext.inheritedProps[
          "image-resolution"
        ] as number | undefined;
        const images: {
          image: HTMLElement;
          element: HTMLElement;
          fetcher: TaskUtil.Fetcher<string>;
        }[] = [];
        const cssWidth = computedStyle["width"];
        const cssHeight = computedStyle["height"];
        const attrWidth = element.getAttribute("width");
        const attrHeight = element.getAttribute("height");
        const hasAutoWidth =
          cssWidth === Css.ident.auto || (!cssWidth && !attrWidth);
        const hasAutoHeight =
          cssHeight === Css.ident.auto || (!cssHeight && !attrHeight);
        const attributes = element.attributes;
        const attributeCount = attributes.length;
        let delayedSrc: string | null = null;
        let delayedAlt: string | null = null;

        // Workaround for issue #1439
        // `<tr><a id="…"></a><td>…` causes table layout issue, so change to
        // `<tr><td><a id="…"></a>…`
        const parentLastElementChild = (
          nodeContext.parent?.viewNode as Element | null
        )?.lastElementChild;
        if (
          display === Css.ident.table_cell &&
          parentLastElementChild?.localName === "a"
        ) {
          result.appendChild(parentLastElementChild);
        }

        for (let i = 0; i < attributeCount; i++) {
          const attribute = attributes[i];
          const attributeNS = attribute.namespaceURI;
          let attributeName = attribute.localName;
          let attributeValue = attribute.value;
          if (!attributeNS) {
            if (!Scripts.allowScripts && attributeName.startsWith("on")) {
              continue; // don't propagate JavaScript code
            }
            if (attributeName == "style") {
              continue; // we do styling ourselves
            }
            if (
              attributeName === "media" &&
              tag === "source" &&
              ns === Base.NS.XHTML &&
              element.parentElement?.localName === "picture"
            ) {
              // Evaluate the media query on <source> inside <picture>
              // using Vivliostyle's media context (print mode by default).
              // The browser evaluates media queries in screen mode,
              // so we need to adjust the media attribute to match.
              try {
                const scope = this.context.rootScope;
                const handler = new CssParser.ParserHandler(scope);
                const tokenizer = new CssTokenizer.Tokenizer(
                  attributeValue,
                  handler,
                );
                const condExpr = CssParser.parseMediaQuery(
                  tokenizer,
                  handler,
                  "",
                );
                if (condExpr) {
                  const matches = condExpr.toExpr().evaluate(this.context);
                  if (matches) {
                    // Media matches: remove the media attribute so the
                    // browser uses this source unconditionally.
                    continue;
                  } else {
                    // Media doesn't match: prevent browser from using
                    // this source.
                    attributeValue = "not all";
                  }
                }
              } catch {
                // If parsing fails, leave the attribute as-is.
              }
            }
            if (attributeName == "id" || attributeName == "name") {
              // Propagate transformed ids and collect them on the page
              // (only first time).
              if (firstTime) {
                const transformedValue =
                  this.documentURLTransformer.transformFragment(
                    attributeValue,
                    this.xmldoc.url,
                  );

                // Keep original id value so that JavaScript can manipulate it
                result.setAttribute(attributeName, attributeValue);
                result.setAttribute("data-vivliostyle-id", transformedValue);

                // Create an anchor element with transformed id, necessary for internal links in output PDF
                // (issue #877)
                const anchorElem = result.ownerDocument.createElement("a");
                anchorElem.setAttribute(attributeName, transformedValue);
                anchorElem.setAttribute(LayoutHelper.SPECIAL_ATTR, "1");
                anchorElem.style.position = "absolute";
                result.appendChild(anchorElem);

                this.page.registerElementWithId(result, transformedValue);
                continue;
              }
            }

            // TODO: understand the element we are working with.
            if (
              attributeName == "src" ||
              attributeName == "href" ||
              attributeName == "poster"
            ) {
              attributeValue = this.resolveURL(attributeValue);
              if (attributeName === "href") {
                attributeValue = this.documentURLTransformer.transformURL(
                  attributeValue,
                  this.xmldoc.url,
                );
              } else {
                // Convert WPT raw.githack.com URLs to wpt.live for resource
                // attributes (src, poster) so dynamic endpoints work.
                attributeValue = Base.resolveWptResourceURL(attributeValue);
              }
              // Convert about:blank to data:text/html, so iframes and other
              // embedded elements load natively without stalling on a missed
              // load event.
              if (attributeName === "src") {
                attributeValue = Base.convertAboutBlankURL(attributeValue);
              }
            } else if (attributeName == "srcset") {
              attributeValue = attributeValue
                .split(",")
                .map((entry) => {
                  const parts = entry.trim().split(/\s+/);
                  const url = Base.resolveWptResourceURL(
                    this.resolveURL(parts[0]),
                  );
                  return parts.length > 1
                    ? `${url} ${parts.slice(1).join(" ")}`
                    : url;
                })
                .join(",");
            } else if (
              attributeName === "data" &&
              custom &&
              tag === "object" &&
              result.hasAttribute("data")
            ) {
              // the data attribute is already set in OPFView.makeObjectView()
              continue;
            }
            if (
              attributeName === "poster" &&
              tag === "video" &&
              ns === Base.NS.XHTML
            ) {
              const image = new Image();
              const fetcher = Net.loadElement(image, attributeValue);
              if (hasAutoWidth && hasAutoHeight) {
                fetchers.push(fetcher);
                images.push({
                  image,
                  element: result as HTMLElement,
                  fetcher,
                });
              } else {
                this.page.fetchers.push(fetcher);
              }
            }
          } else if (attributeNS == "http://www.w3.org/2000/xmlns/") {
            continue; // namespace declaration (in Firefox)
          } else if (attributeNS == Base.NS.XLINK) {
            if (attributeName == "href") {
              attributeValue = this.documentURLTransformer.transformURL(
                this.resolveURL(attributeValue),
                this.xmldoc.url,
              );
            }
          }
          if (this.isSVGUrlAttribute(attributeName)) {
            attributeValue = Urls.transformURIs(
              attributeValue,
              this.xmldoc.url,
              this.documentURLTransformer,
            );
          }
          if (attributeNS) {
            const attributePrefix = namespacePrefixMap[attributeNS];
            if (attributePrefix) {
              attributeName = `${attributePrefix}:${attributeName}`;
            }
          }
          if (
            attributeName == "src" &&
            !attributeNS &&
            (tag == "img" || tag == "input") &&
            ns == Base.NS.XHTML
          ) {
            // HTML img element should start loading only once all
            // attributes are assigned.
            delayedSrc = attributeValue;
          } else if (
            attributeName == "alt" &&
            !attributeNS &&
            tag == "img" &&
            ns == Base.NS.XHTML
          ) {
            // The alt attribute should be assigned after the src attribute
            // to avoid the image box size being determined by the alt text.
            // (Issue #1343)
            delayedAlt = attributeValue;
          } else if (
            attributeName == "href" &&
            tag == "image" &&
            ns == Base.NS.SVG &&
            (attributeNS == Base.NS.XLINK || !attributeNS)
          ) {
            // For SVG2 namespace-less href, also set the href attribute
            // on the element since loadElement only sets xlink:href.
            if (!attributeNS) {
              result.setAttribute(attributeName, attributeValue);
            }
            this.page.fetchers.push(Net.loadElement(result, attributeValue));
          } else {
            // When the document is not XML document (e.g. non-XML HTML)
            // attributeNS can be null
            if (attributeNS) {
              result.setAttributeNS(attributeNS, attributeName, attributeValue);
            } else {
              try {
                result.setAttribute(attributeName, attributeValue);
              } catch (err) {
                Logging.logger.warn(err);
              }
            }
          }
        }
        if (delayedSrc) {
          const image = tag === "input" ? new Image() : result;
          const imageFetcher = Net.loadElement(image, delayedSrc, delayedAlt);
          if (image !== result) {
            (result as HTMLImageElement).src = delayedSrc;
          }
          const isInsideRunningElement = (): boolean => {
            // Check if the image is inside a position:fixed or running element
            // which is converted to position:fixed.
            if (computedStyle["position"] === Css.ident.fixed) {
              return true;
            }
            for (
              let p = nodeContext.parent?.viewNode as HTMLElement | null;
              p && p !== this.viewRoot;
              p = p.parentElement
            ) {
              if (p.style?.["position"] === "fixed") {
                return true;
              }
            }
            return false;
          };
          const hasPercentBlockSize = (): boolean => {
            // Check if the image has percentage block size, which is usually same as auto,
            // which means the size is not determined until the image is loaded.
            const blockSize = nodeContext.vertical ? cssWidth : cssHeight;
            return blockSize instanceof Css.Numeric && blockSize.unit === "%";
          };
          if (
            !hasAutoWidth &&
            !hasAutoHeight &&
            !hasPercentBlockSize() &&
            !isInsideRunningElement()
          ) {
            // No need to wait for the image, does not affect layout
            this.page.fetchers.push(imageFetcher);
          } else {
            if (
              hasAutoWidth &&
              hasAutoHeight &&
              imageResolution &&
              imageResolution !== 1
            ) {
              images.push({
                image: image as HTMLElement,
                element: result as HTMLElement,
                fetcher: imageFetcher,
              });
            }
            fetchers.push(imageFetcher);
          }
        } else if (
          !delayedSrc &&
          tag === "img" &&
          ns === Base.NS.XHTML &&
          ((result as HTMLImageElement).srcset ||
            element.parentElement?.localName === "picture")
        ) {
          // <img srcset="..."> without src, or <img> inside <picture>:
          // wait for the image to load.
          // Use page.fetchers (not layout-blocking fetchers) because the
          // image source may only be resolved after DOM insertion (e.g.,
          // <picture><source srcset="..."><img></picture>).
          this.page.fetchers.push(Net.loadElement(result));
        }
        delete computedStyle["content"];

        // Preload marker images referenced via --viv-marker-content so that
        // pagination waits for them, avoiding late reflow.
        const markerContent = computedStyle["--viv-marker-content"];
        if (markerContent) {
          const markerValues =
            markerContent instanceof Css.SpaceList
              ? markerContent.values
              : [markerContent];
          for (const v of markerValues) {
            if (v instanceof Css.URL && v.url) {
              fetchers.push(Net.loadElement(new Image(), v.url));
            }
          }
        }

        // Wait for object element content to load (e.g., embedded HTML via
        // <object data="...">). This ensures proper pagination by waiting for
        // the embedded document to fully render before proceeding.
        // Use result.localName instead of tag because custom renderer may
        // convert <object> to <iframe> (e.g., for bound content).
        if (
          result.localName === "object" &&
          result.namespaceURI === Base.NS.XHTML &&
          result.hasAttribute("data")
        ) {
          this.page.fetchers.push(Net.loadElement(result));
        }

        // Wait for embed element content to load (e.g., <embed src="image.png">).
        if (
          result.localName === "embed" &&
          result.namespaceURI === Base.NS.XHTML &&
          result.hasAttribute("src")
        ) {
          this.page.fetchers.push(Net.loadElement(result));
        }

        // Wait for iframe content to load. This ensures embedded documents
        // (including their images and resources) are fully rendered.
        // Handle loading="lazy" by forcing eager loading to prevent blocking.
        if (
          result.localName === "iframe" &&
          result.namespaceURI === Base.NS.XHTML &&
          result.hasAttribute("src")
        ) {
          const iframeElem = result as HTMLIFrameElement;
          if (iframeElem.loading === "lazy") {
            iframeElem.loading = "eager";
          }
          this.page.fetchers.push(Net.loadElement(result));
        }

        this.preprocessElementStyle(nodeContext, computedStyle);
        this.applyComputedStyles(result, computedStyle);

        if (nodeContext.inline) {
          if (!firstTime) {
            Break.setBoxBreakFlag(result, "inline-start");
            if (Break.isCloneBoxDecorationBreak(result)) {
              Break.setBoxBreakFlag(result, "clone");
            }
          }
        } else {
          if (!firstTime) {
            const blockSizeP = nodeContext.vertical ? "width" : "height";
            if (Base.getCSSProperty(result, blockSizeP)) {
              // When a box with a specified block size is fragmented,
              // the fragmented box should not have the block size.
              // If the box is table-row, set a very small block size
              // (0 does not work in Firefox, so use 0.01px instead)
              // to prevent the row block size from expanding due to
              // large rowspanning cells.
              Base.setCSSProperty(
                result,
                blockSizeP,
                nodeContext.display === "table-row" ? "0.01px" : "",
              );
            }
            Break.setBoxBreakFlag(result, "block-start");
            if (Break.isCloneBoxDecorationBreak(result)) {
              Break.setBoxBreakFlag(result, "clone");
            }
            Break.setMarginDiscardFlag(result, "block-start");
          } else if (
            !Display.isAbsolutelyPositioned(computedStyle["position"])
          ) {
            const marginBreak = computedStyle["margin-break"];

            // Detect forced or unforced break at this point
            // to handle margin-break properly.
            const breakType = this.getBreakTypeAt(nodeContext);
            const anyBreak = breakType !== null;
            const unforcedBreak = breakType === "auto";
            if (
              (marginBreak === Css.ident.discard && anyBreak) ||
              (marginBreak !== Css.ident.keep &&
                unforcedBreak &&
                !nodeContext.floatSide)
            ) {
              Break.setMarginDiscardFlag(result, "block-start");
            }
          }
        }
        if (isListItem) {
          if (computedStyle["ua-list-item-count"]) {
            result.setAttribute(
              "value",
              computedStyle["ua-list-item-count"].stringValue(),
            );
          }
        }

        this.viewNode = result;
        if (fetchers.length) {
          TaskUtil.waitForFetchers(fetchers).then(() => {
            if (imageResolution !== undefined && imageResolution > 0) {
              this.modifyElemDimensionWithImageResolution(
                images,
                imageResolution,
                computedStyle,
                nodeContext.vertical,
              );
            }
            frame.finish(needToProcessChildren);
          });
        } else {
          frame.timeSlice().then(() => {
            frame.finish(needToProcessChildren);
          });
        }
      });
    });
    return frame.result();
  }

  /**
   * Check if the current position is at the start of a page.
   * This is used to determine whether a forced break should be ignored.
   * (Issue #1608)
   */
  private isAtStartOfPage(): boolean {
    for (let nc = this.nodeContext; nc?.parent && !nc.after; nc = nc.parent) {
      let node =
        nc === this.nodeContext && !nc.viewNode
          ? nc.parent.viewNode?.lastChild
          : nc.viewNode?.previousSibling;
      while (
        node &&
        (Vtree.canIgnore(node, nc.parent.whitespace) ||
          LayoutHelper.isOutOfFlow(node))
      ) {
        node = node.previousSibling;
      }
      if (node) {
        return false;
      }
    }
    return true;
  }

  /**
   * Check if the current element is inside multi-column element
   * that is not root or body element in the source tree.
   *
   * Note: vivliostyle handles multi-column on the root and body element on its own,
   * but leaves it to the browser to handle other multi-column.
   * This check is for such non-root/body multi-column.
   */
  private isInsideNonRootMultiColumn(nodeContext: Vtree.NodeContext): boolean {
    const element = nodeContext.parent?.viewNode as Element;
    return !!(element && LayoutHelper.findAncestorNonRootMultiColumn(element));
  }

  /**
   * Check if the current position is at a forced or unforced break
   * (Fix for Issue #690)
   *
   * @param nodeContext
   * @returns forced break type, or "auto" for unforced break, or null for not break
   */
  private getBreakTypeAt(nodeContext: Vtree.NodeContext): string | null {
    // Skip break detection for tables; fragmentation is handled by table.ts
    if (this.isInsideTable(nodeContext)) {
      return null;
    }
    for (
      let nc: Vtree.NodeContext | null = nodeContext;
      nc && !nc.after;
      nc = nc.parent
    ) {
      if (Break.isForcedBreakValue(nc.breakBefore)) {
        return nc.breakBefore; // forced break
      }
      const parent = nc.parent;
      if (nc.fragmentIndex === 1 && !parent) {
        if (nc.sourceNode === nc.sourceNode.ownerDocument?.documentElement) {
          // beginning of document
          return "page";
        } else {
          // page floats, etc.
          return null;
        }
      }
      if (!parent) {
        continue;
      }
      if (parent.floatSide) {
        // inside float, not break (Issue #1282)
        return null;
      }
      const parentViewNode = parent.viewNode as Element;
      if (parentViewNode) {
        const style = this.viewport.window.getComputedStyle(parentViewNode);
        const paddingBlockStart = parseFloat(style.paddingBlockStart);
        const borderBlockStartWidth = parseFloat(style.borderBlockStartWidth);
        if (paddingBlockStart || borderBlockStartWidth) {
          // parent's viewNode has block-start padding or border
          return null;
        }
        let node = parentViewNode?.firstChild;
        while (
          node &&
          (Vtree.canIgnore(node, parent.whitespace) ||
            (!nc.floatSide && LayoutHelper.isOutOfFlow(node)))
        ) {
          node = node.nextSibling;
        }
        if (node && node !== nc.viewNode) {
          // parent's viewNode already has other content
          return null;
        }
      }
    }

    const startBreakType =
      (
        this.context as Exprs.Context & {
          currentLayoutPosition: Vtree.LayoutPosition | null;
        }
      )?.currentLayoutPosition?.flowPositions[this.flowName]?.startBreakType ??
      null;

    if (Break.isForcedBreakValue(startBreakType)) {
      return startBreakType; // forced break
    } else {
      return "auto"; // unforced break
    }
  }

  private isInsideTable(nodeContext: Vtree.NodeContext): boolean {
    for (
      let nc: Vtree.NodeContext | null = nodeContext;
      nc && !nc.after;
      nc = nc.parent
    ) {
      if (nc.display && nc.display.startsWith("table")) {
        return true;
      }
    }
    return false;
  }

  private processAfterIfcontinues(
    nodeContext: Vtree.NodeContext,
    element: Element,
    cascStyle: CssCascade.ElementStyle,
    styler: CssStyler.AbstractStyler,
    context: Exprs.Context,
  ) {
    const pseudoMap = this.getPseudoMap(
      cascStyle,
      this.regionIds,
      this.isFootnote,
      nodeContext,
      context,
    );
    if (!pseudoMap) {
      return;
    }
    if (
      pseudoMap["after-if-continues"] &&
      pseudoMap["after-if-continues"]["content"]
    ) {
      const shadowStyler = new PseudoElement.PseudoelementStyler(
        element,
        cascStyle,
        styler,
        context,
        this.exprContentListener,
      );
      nodeContext.afterIfContinues = new Layout.AfterIfContinues(
        element,
        shadowStyler,
      );
    }
  }

  isSVGUrlAttribute(attributeName: string): boolean {
    return ViewFactory.SVG_URL_ATTRIBUTES.includes(attributeName.toLowerCase());
  }

  modifyElemDimensionWithImageResolution(
    images: {
      image: HTMLElement;
      element: HTMLElement;
      fetcher: TaskUtil.Fetcher<string>;
    }[],
    imageResolution: number,
    computedStyle: { [key: string]: Css.Val },
    isVertical: boolean,
  ) {
    images.forEach((param) => {
      if (param.fetcher.get().get() === "load") {
        const img = param.image;
        let scaledWidth = (img as HTMLImageElement).width / imageResolution;
        let scaledHeight = (img as HTMLImageElement).height / imageResolution;
        const elem = param.element;
        if (scaledWidth > 0 && scaledHeight > 0) {
          if (computedStyle["box-sizing"] === Css.ident.border_box) {
            if (computedStyle["border-left-style"] !== Css.ident.none) {
              scaledWidth += Css.toNumber(
                computedStyle["border-left-width"],
                this.context,
              );
            }
            if (computedStyle["border-right-style"] !== Css.ident.none) {
              scaledWidth += Css.toNumber(
                computedStyle["border-right-width"],
                this.context,
              );
            }
            if (computedStyle["border-top-style"] !== Css.ident.none) {
              scaledHeight += Css.toNumber(
                computedStyle["border-top-width"],
                this.context,
              );
            }
            if (computedStyle["border-bottom-style"] !== Css.ident.none) {
              scaledHeight += Css.toNumber(
                computedStyle["border-bottom-width"],
                this.context,
              );
            }
          }
          if (imageResolution > 1) {
            const maxWidth = computedStyle["max-width"] || Css.ident.none;
            const maxHeight = computedStyle["max-height"] || Css.ident.none;
            if (maxWidth === Css.ident.none && maxHeight === Css.ident.none) {
              Base.setCSSProperty(elem, "max-width", `${scaledWidth}px`);
            } else if (
              maxWidth !== Css.ident.none &&
              maxHeight === Css.ident.none
            ) {
              Base.setCSSProperty(elem, "width", `${scaledWidth}px`);
            } else if (
              maxWidth === Css.ident.none &&
              maxHeight !== Css.ident.none
            ) {
              Base.setCSSProperty(elem, "height", `${scaledHeight}px`);
            } else {
              // maxWidth != none && maxHeight != none
              Asserts.assert(maxWidth.isNumeric());
              Asserts.assert(maxHeight.isNumeric());
              const numericMaxWidth = maxWidth as Css.Numeric;
              const numericMaxHeight = maxHeight as Css.Numeric;
              if (numericMaxWidth.unit !== "%") {
                Base.setCSSProperty(
                  elem,
                  "max-width",
                  `${Math.min(
                    scaledWidth,
                    Css.toNumber(numericMaxWidth, this.context),
                  )}px`,
                );
              } else if (numericMaxHeight.unit !== "%") {
                Base.setCSSProperty(
                  elem,
                  "max-height",
                  `${Math.min(
                    scaledHeight,
                    Css.toNumber(numericMaxHeight, this.context),
                  )}px`,
                );
              } else {
                if (isVertical) {
                  Base.setCSSProperty(elem, "height", `${scaledHeight}px`);
                } else {
                  Base.setCSSProperty(elem, "width", `${scaledWidth}px`);
                }
              }
            }
          } else if (imageResolution < 1) {
            const minWidth = computedStyle["min-width"] || Css.numericZero;
            const minHeight = computedStyle["min-height"] || Css.numericZero;
            Asserts.assert(minWidth.isNumeric());
            const numericMinWidth = minWidth as Css.Numeric;
            const numericMinHeight = minHeight as Css.Numeric;
            if (numericMinWidth.num === 0 && numericMinHeight.num === 0) {
              Base.setCSSProperty(elem, "min-width", `${scaledWidth}px`);
            } else if (
              numericMinWidth.num !== 0 &&
              numericMinHeight.num === 0
            ) {
              Base.setCSSProperty(elem, "width", `${scaledWidth}px`);
            } else if (
              numericMinWidth.num === 0 &&
              numericMinHeight.num !== 0
            ) {
              Base.setCSSProperty(elem, "height", `${scaledHeight}px`);
            } else {
              // minWidth != 0 && minHeight != 0
              if (numericMinWidth.unit !== "%") {
                Base.setCSSProperty(
                  elem,
                  "min-width",
                  `${Math.max(
                    scaledWidth,
                    Css.toNumber(numericMinWidth, this.context),
                  )}px`,
                );
              } else if (numericMinHeight.unit !== "%") {
                Base.setCSSProperty(
                  elem,
                  "min-height",
                  `${Math.max(
                    scaledHeight,
                    Css.toNumber(numericMinHeight, this.context),
                  )}px`,
                );
              } else {
                if (isVertical) {
                  Base.setCSSProperty(elem, "height", `${scaledHeight}px`);
                } else {
                  Base.setCSSProperty(elem, "width", `${scaledWidth}px`);
                }
              }
            }
          }
        }
      }
    });
  }

  private preprocessElementStyle(
    nodeContext: Vtree.NodeContext,
    computedStyle: { [key: string]: Css.Val },
  ) {
    const hooks: Plugin.PreProcessElementStyleHook[] = Plugin.getHooksForName(
      Plugin.HOOKS.PREPROCESS_ELEMENT_STYLE,
    );
    hooks.forEach((hook) => {
      hook(nodeContext, computedStyle);
    });
  }

  private findAndProcessRepeatingElements(
    nodeContext: Vtree.NodeContext,
    element: Element,
    styler: CssStyler.AbstractStyler,
  ) {
    for (
      let child: Node | null = element.firstChild;
      child;
      child = child.nextSibling
    ) {
      if (child.nodeType !== 1) {
        continue;
      }
      const computedStyle: { [key: string]: Css.Val } = {};
      const elementStyle = styler.getStyle(child as Element, false);
      this.computeStyle(
        nodeContext.vertical,
        nodeContext.direction === "rtl",
        elementStyle,
        computedStyle,
      );
      const processRepeatOnBreak = this.processRepeatOnBreak(computedStyle);
      if (!processRepeatOnBreak) {
        continue;
      }
      if (
        nodeContext.formattingContext instanceof
          RepetitiveElement.RepetitiveElementsOwnerFormattingContext &&
        !nodeContext.belongsTo(nodeContext.formattingContext)
      ) {
        return;
      }
      const parent = nodeContext.parent;
      const parentFormattingContext = parent ? parent.formattingContext : null;
      nodeContext.formattingContext =
        new RepetitiveElement.RepetitiveElementsOwnerFormattingContext(
          parentFormattingContext,
          nodeContext.sourceNode as Element,
        );
      (
        nodeContext.formattingContext as RepetitiveElement.RepetitiveElementsOwnerFormattingContext
      ).initializeRepetitiveElements(nodeContext.vertical);
      return;
    }
  }

  private processRepeatOnBreak(computedStyle: { [key: string]: Css.Val }) {
    let repeatOnBreak = computedStyle["repeat-on-break"];
    if (repeatOnBreak !== Css.ident.none) {
      if (
        repeatOnBreak === Css.ident.auto ||
        Css.isDefaultingValue(repeatOnBreak)
      ) {
        if (computedStyle["display"] === Css.ident.table_header_group) {
          repeatOnBreak = Css.ident.header;
        } else if (computedStyle["display"] === Css.ident.table_footer_group) {
          repeatOnBreak = Css.ident.footer;
        } else {
          repeatOnBreak = Css.ident.none;
        }
      }
      if (repeatOnBreak && repeatOnBreak !== Css.ident.none) {
        return repeatOnBreak.toString();
      }
    }
    return null;
  }

  private createTextNodeView(
    nodeContext: Vtree.NodeContext,
  ): Task.Result<boolean> {
    const frame: Task.Frame<boolean> = Task.newFrame("createTextNodeView");
    this.preprocessTextContent(nodeContext).then((preprocessedTextContent) => {
      const offsetInNode = this.offsetInNode || 0;
      const textContent = Diff.restoreNewText(preprocessedTextContent).slice(
        offsetInNode,
      );
      this.viewNode = document.createTextNode(textContent);
      frame.finish(true);
    });
    return frame.result();
  }

  private preprocessTextContent(
    nodeContext: Vtree.NodeContext,
  ): Task.Result<Diff.Change[]> {
    if (nodeContext.preprocessedTextContent != null) {
      return Task.newResult(nodeContext.preprocessedTextContent);
    }
    let originl: string;
    let textContent = (originl = nodeContext.sourceNode.textContent ?? "");
    const frame: Task.Frame<Diff.Change[]> = Task.newFrame(
      "preprocessTextContent",
    );
    const hooks: Plugin.PreProcessTextContentHook[] = Plugin.getHooksForName(
      Plugin.HOOKS.PREPROCESS_TEXT_CONTENT,
    );
    let index = 0;
    frame
      .loop(() => {
        if (index >= hooks.length) {
          return Task.newResult(false);
        }
        return hooks[index++](nodeContext, textContent).thenAsync(
          (processedText) => {
            textContent = processedText;
            return Task.newResult(true);
          },
        );
      })
      .then(() => {
        const preprocessedTextContent = Diff.diffChars(originl, textContent);
        nodeContext.preprocessedTextContent = preprocessedTextContent;
        frame.finish(preprocessedTextContent);
      });
    return frame.result();
  }

  /**
   * @return holding true if children should be processed
   */
  createNodeView(
    nodeContext: Vtree.NodeContext,
    firstTime: boolean,
  ): Task.Result<boolean> {
    const frame: Task.Frame<boolean> = Task.newFrame("createNodeView");
    let result: Task.Result<boolean>;
    let needToProcessChildren = true;
    if (nodeContext.sourceNode.nodeType == 1) {
      result = this.createElementView(nodeContext, firstTime);
    } else {
      if (nodeContext.sourceNode.nodeType == 8) {
        this.viewNode = null; // comment node
        result = Task.newResult(true);
      } else {
        result = this.createTextNodeView(nodeContext);
      }
    }
    result.then((processChildren) => {
      needToProcessChildren = processChildren;
      nodeContext.viewNode = this.viewNode;
      if (this.viewNode) {
        const isPseudo = (node: Node | null, name: string): boolean =>
          node?.nodeType === 1 &&
          PseudoElement.getPseudoName(node as Element) === name;
        const p = nodeContext.parent;
        // A first-letter pseudo-element view is only generated below its
        // originating element's context, so a context bearing one has a parent.
        const pFirstLetter =
          p &&
          isPseudo(this.viewNode, "after") &&
          isPseudo(p.viewNode, "first-letter")
            ? (p as Vtree.ChildNodeContext)
            : null;
        let parent = p
          ? pFirstLetter?.viewNode?.hasChildNodes()
            ? (pFirstLetter.parent.viewNode as Element) // Fix for issue #1175
            : (p.viewNode as Element)
          : this.viewRoot;
        if (nodeContext.pluginProps["nestedFootnoteDetached"]) {
          // Nested footnote, attach to the root (Issue #1352)
          parent = this.viewRoot;
        }
        if (parent) {
          if (
            nodeContext.inline &&
            // ignore whitespace text node
            !(this.viewNode.nodeType === 3 && Vtree.canIgnore(this.viewNode)) &&
            !parent.hasChildNodes() &&
            Break.getBoxBreakFlags(parent).includes("block-start")
          ) {
            Break.setBoxBreakFlag(parent, "text-start");
          }
          parent.appendChild(this.viewNode);

          // Fix overflow caused by forced column breaks
          LayoutHelper.fixOverflowAtForcedColumnBreak(this.viewNode);
        }
      }
      frame.finish(needToProcessChildren);
    });
    return frame.result();
  }

  /** @override */
  setCurrent(
    nodeContext: Vtree.NodeContext,
    firstTime: boolean,
    atUnforcedBreak?: boolean,
  ): Task.Result<boolean> {
    this.nodeContext = nodeContext;
    this.sourceNode = nodeContext.sourceNode;
    this.offsetInNode = nodeContext.offsetInNode;
    this.viewNode = null;
    return this.createNodeView(nodeContext, firstTime);
  }

  processShadowContent(pos: Vtree.ChildNodeContext): Vtree.NodeContext {
    if (
      pos.shadowContext == null ||
      (pos.sourceNode as Element).localName != "content" ||
      (pos.sourceNode as Element).namespaceURI != Base.NS.SHADOW
    ) {
      return pos;
    }
    const boxOffset = pos.boxOffset;
    const shadow = pos.shadowContext;

    // content that will be inserted
    let contentNode: Node | null;
    let contentShadowType: Vtree.ShadowType;
    const contentShadow = shadow.subShadow || shadow.parentShadow;
    if (shadow.subShadow) {
      // If there is a nested shadow, insert that nested shadow's content
      // at this <shadow:content> slot.
      contentNode = shadow.subShadow.root;
      contentShadowType = shadow.subShadow.type;
      if (contentShadowType == Vtree.ShadowType.ROOTLESS) {
        contentNode = contentNode.firstChild;
      }
    } else {
      contentNode = shadow.owner.firstChild;
      contentShadowType = Vtree.ShadowType.ROOTLESS;
    }
    const nextSibling = pos.sourceNode.nextSibling;
    let nextPos: Vtree.NodeContext | null;
    if (nextSibling) {
      pos.sourceNode = nextSibling;
      pos.resetView();
      nextPos = pos;
    } else if (pos.shadowSibling) {
      nextPos = pos.shadowSibling;
    } else {
      nextPos = null;
    }
    if (contentNode) {
      const r = Vtree.NodeContext.childOf(contentNode, pos.parent, boxOffset);
      r.shadowContext = contentShadow;
      r.shadowType = contentShadowType;
      r.shadowSibling = nextPos;
      return this.processShadowContent(r);
    }
    if (nextPos === null) {
      nextPos = pos.parent.modify();
      nextPos.after = true;
    }
    nextPos.boxOffset = boxOffset;
    return nextPos;
  }

  private nextPositionInTree(
    pos: Vtree.NodeContext,
    preprocessedTextContent: Diff.Change[] | null,
  ): Vtree.NodeContext | null {
    let boxOffset = pos.boxOffset + 1; // offset for the next position
    if (pos.after) {
      // root, that was the last possible position
      let cur = Vtree.asChildNodeContext(pos);
      if (!cur) {
        return null;
      }

      // we are done with this sourceNode, see if there is a next sibling,
      // unless this is the root of the shadow tree
      if (cur.shadowType != Vtree.ShadowType.ROOTED) {
        const next = cur.sourceNode.nextSibling;
        if (next) {
          cur = cur.modify();

          // keep shadowType
          cur.boxOffset = boxOffset;
          cur.sourceNode = next;
          cur.resetView();
          return this.processShadowContent(cur);
        }
      }

      // if no viable siblings, check if there are shadow siblings
      if (cur.shadowSibling) {
        // our next position is the element after shadow:content in the parent
        // shadow tree
        const sibling = cur.shadowSibling.modify();
        sibling.boxOffset = boxOffset;
        return sibling;
      }

      // if not rootless shadow, move to the "after" position for the parent
      const afterParent = cur.parent.modify();
      afterParent.boxOffset = boxOffset;
      afterParent.after = true;
      return afterParent;
    } else {
      // any shadow trees?
      if (pos.nodeShadow) {
        let shadowNode: Node | null = pos.nodeShadow.root;
        if (pos.nodeShadow.type == Vtree.ShadowType.ROOTLESS) {
          shadowNode = shadowNode.firstChild;
        }
        if (shadowNode) {
          const sr = Vtree.NodeContext.childOf(shadowNode, pos, boxOffset);
          sr.shadowContext = pos.nodeShadow;
          sr.shadowType = pos.nodeShadow.type;
          return this.processShadowContent(sr);
        }
      }

      // any children?
      const child = pos.sourceNode.firstChild;
      if (child) {
        return this.processShadowContent(
          Vtree.NodeContext.childOf(child, pos, boxOffset),
        );
      }

      // no children - was there text content?
      if (preprocessedTextContent) {
        const content = Diff.restoreNewText(preprocessedTextContent);
        boxOffset += content.length - 1 - pos.offsetInNode;
      }
      pos = pos.modify();
      pos.boxOffset = boxOffset;
      pos.after = true;
      return pos;
    }
  }

  /**
   * Find a footnote-call element immediately before the given view node.
   */
  private findImmediateFootnoteCallSibling(
    footnoteNodeContext: Vtree.NodeContext,
  ): Element | null {
    const ownerOffset = this.xmldoc.getElementOffset(
      footnoteNodeContext.sourceNode as Element,
    );
    const viewNode = footnoteNodeContext.viewNode;
    if (!viewNode) {
      return null;
    }
    let prev: Node | null = viewNode.previousSibling;
    while (prev) {
      if (prev.nodeType === Node.TEXT_NODE) {
        if ((prev.textContent ?? "").trim().length === 0) {
          prev = prev.previousSibling;
          continue;
        }
        return null;
      }
      if (prev.nodeType === Node.ELEMENT_NODE) {
        const prevElem = prev as Element;
        return PseudoElement.getPseudoName(prevElem) === "footnote-call" &&
          prevElem.getAttribute(ViewFactory.FOOTNOTE_CALL_OWNER_ATTR) ===
            ownerOffset.toString()
          ? prevElem
          : null;
      }
      return null;
    }
    return null;
  }

  /**
   * True for semantic footnotes that already provide a noteref call in source
   * (EPUB or DPUB-ARIA pattern), so an extra ::footnote-call must not be inserted.
   */
  private isSemanticFootnoteElement(footnoteNodeContext: Vtree.NodeContext) {
    const sourceNode = footnoteNodeContext.sourceNode;
    return (
      sourceNode instanceof Element &&
      SemanticFootnote.isSemanticFootnoteElement(sourceNode)
    );
  }

  /**
   * Insert a footnote-call NodeContext before the footnote element.
   * The footnote-call will be processed as a normal inline element,
   * then shadowSibling will lead to the footnote element.
   * (Issue #868)
   */
  private insertFootnoteCall(
    footnoteNodeContext: Vtree.NodeContext,
  ): Task.Result<Vtree.NodeContext> {
    const frame: Task.Frame<Vtree.NodeContext> =
      Task.newFrame("insertFootnoteCall");

    // Create a pseudo source node for footnote-call
    const footnoteCallSourceNode = PseudoElement.document.createElementNS(
      Base.NS.XHTML,
      "span",
    );
    PseudoElement.setPseudoName(footnoteCallSourceNode, "footnote-call");
    const footnoteOffset = this.xmldoc.getElementOffset(
      footnoteNodeContext.sourceNode as Element,
    );
    footnoteCallSourceNode.setAttribute(
      ViewFactory.FOOTNOTE_CALL_OWNER_ATTR,
      footnoteOffset.toString(),
    );

    // Create NodeContext for footnote-call with the same parent as footnote
    const footnoteCallContext = Vtree.NodeContext.siblingOf(
      footnoteCallSourceNode,
      footnoteNodeContext,
      footnoteNodeContext.boxOffset,
    );

    // Set up properties for inline element
    footnoteCallContext.inline = true;

    // Create shadow context for footnote-call styling
    // Use the footnote element's styler to get ::footnote-call styles
    const shadowStyler = new PseudoElement.PseudoelementStyler(
      footnoteNodeContext.sourceNode as Element,
      this.styler.getStyle(footnoteNodeContext.sourceNode as Element, false),
      this.styler,
      this.context,
      this.exprContentListener,
    );
    footnoteCallContext.shadowContext = new Vtree.ShadowContext(
      footnoteNodeContext.sourceNode as Element,
      footnoteCallSourceNode, // Use the span directly as root, not a shadow:root
      null,
      footnoteNodeContext.parent?.shadowContext || null,
      null,
      Vtree.ShadowType.ROOTLESS,
      shadowStyler,
    );

    // Set up shadow sibling to return to footnote after footnote-call is done
    footnoteCallContext.shadowSibling =
      footnoteNodeContext as Vtree.NodeContext;

    // Increment footnote's boxOffset since footnote-call takes one position
    (footnoteNodeContext as Vtree.NodeContext).boxOffset++;

    // Remove the footnote element's viewNode from DOM if it was already created
    // (setCurrent was called before we detected this is a footnote)
    if (footnoteNodeContext.viewNode?.parentNode) {
      footnoteNodeContext.viewNode.parentNode.removeChild(
        footnoteNodeContext.viewNode,
      );
    }

    // Now create the view for footnote-call
    this.setCurrent(footnoteCallContext, true, false).then(
      (processChildren) => {
        // If processChildren is true and the source node has children (generated content),
        // let the normal layout flow process them by NOT setting after=true.
        // This ensures text-spacing polyfill is applied via postLayoutBlock.
        if (processChildren && footnoteCallSourceNode.hasChildNodes()) {
          // Return the footnote-call context as-is to process children
          frame.finish(footnoteCallContext);
        } else {
          // No children to process, mark as done
          const modified = footnoteCallContext.modify();
          modified.after = true;
          if (!footnoteCallContext.viewNode) {
            modified.inline = true;
          }
          frame.finish(modified);
        }
      },
    );

    return frame.result();
  }

  /** @override */
  nextInTree(
    position: Vtree.NodeContext,
    atUnforcedBreak?: boolean,
  ): Task.Result<Vtree.NodeContext | null> {
    const preprocessResult: Task.Result<Diff.Change[] | null> =
      !position.after && position.sourceNode.nodeType != 1
        ? this.preprocessTextContent(position)
        : Task.newResult<Diff.Change[] | null>(null);
    return preprocessResult.thenAsync((preprocessedTextContent) =>
      this.nextInTreeWithPreprocessedText(
        position,
        preprocessedTextContent,
        atUnforcedBreak,
      ),
    );
  }

  private nextInTreeWithPreprocessedText(
    position: Vtree.NodeContext,
    preprocessedTextContent: Diff.Change[] | null,
    atUnforcedBreak?: boolean,
  ): Task.Result<Vtree.NodeContext | null> {
    const nextPosition = this.nextPositionInTree(
      position,
      preprocessedTextContent,
    );
    if (!nextPosition || nextPosition.after) {
      return Task.newResult<Vtree.NodeContext | null>(nextPosition);
    }
    this.syncTextNodePageTypeBoundary(nextPosition);
    let nodeContext = nextPosition;
    const frame: Task.Frame<Vtree.NodeContext | null> =
      Task.newFrame("nextInTree");
    this.setCurrent(nodeContext, true, atUnforcedBreak).then(
      (processChildren) => {
        if (!nodeContext.viewNode || !processChildren) {
          nodeContext = nodeContext.modify();
          nodeContext.after = true; // skip
          if (!nodeContext.viewNode) {
            nodeContext.inline = true;
          }
        }

        // Issue #868: Insert footnote-call before footnote element
        // Only insert if footnote-call hasn't been processed yet for this footnote.
        // Skip semantic EPUB/DPUB footnotes because the call already exists in
        // source HTML as a noteref link (no extra ::footnote-call is needed).
        // Also skip pseudo-elements (shadowContext exists) because they are not in the
        // source document tree (PR #1607 follow-up fix).
        if (
          nodeContext.floatSide === "footnote" &&
          !(this.isFootnote && !nodeContext.parent) &&
          !nodeContext.after &&
          !nodeContext.pluginProps["footnoteCallProcessed"] &&
          !nodeContext.shadowContext &&
          !this.isSemanticFootnoteElement(nodeContext)
        ) {
          const existingFootnoteCall =
            this.findImmediateFootnoteCallSibling(nodeContext);
          if (existingFootnoteCall?.parentNode) {
            existingFootnoteCall.parentNode.removeChild(existingFootnoteCall);
          }
          if (this.isFootnote && nodeContext.parent) {
            // Detach nested footnote content into footnote area while keeping
            // the call marker in the parent footnote text. (Issue #1352)
            nodeContext.pluginProps["nestedFootnoteDetached"] = 1;
          }
          // Mark as processed to avoid infinite loop when returning via shadowSibling
          nodeContext.pluginProps["footnoteCallProcessed"] = 1;
          // Return footnote-call first, footnote will be processed via shadowSibling
          this.insertFootnoteCall(nodeContext).then((footnoteCallContext) => {
            this.dispatchEvent({
              type: "nextInTree",
              nodeContext: footnoteCallContext,
            } as any);
            frame.finish(footnoteCallContext);
          });
          return;
        }

        this.dispatchEvent({ type: "nextInTree", nodeContext } as any);
        frame.finish(nodeContext);
      },
    );
    return frame.result();
  }

  addImageFetchers(bg: Css.Val) {
    addImageFetchersToPage(bg, this.page);
  }

  applyComputedStyles(
    target: Element,
    computedStyle: { [key: string]: Css.Val },
  ) {
    const bg = computedStyle["background-image"];
    if (bg) {
      this.addImageFetchers(bg);
    }
    const borderImageSource = computedStyle["border-image-source"];
    if (borderImageSource) {
      this.addImageFetchers(borderImageSource);
    }
    const listStyleImage = computedStyle["list-style-image"];
    if (listStyleImage) {
      this.addImageFetchers(listStyleImage);
    }
    const maskImage = computedStyle["mask-image"];
    if (maskImage) {
      this.addImageFetchers(maskImage);
    }
    const clipPath = computedStyle["clip-path"];
    if (clipPath) {
      this.addImageFetchers(clipPath);
    }
    const filter = computedStyle["filter"];
    if (filter) {
      this.addImageFetchers(filter);
    }
    const shapeOutside = computedStyle["shape-outside"];
    if (shapeOutside) {
      this.addImageFetchers(shapeOutside);
    }
    const markerContent = computedStyle["--viv-marker-content"];
    if (markerContent) {
      this.addImageFetchers(markerContent);
    }
    const isRelativePositioned =
      computedStyle["position"] === Css.ident.relative;
    const isRoot =
      this.nodeContext?.parent === null &&
      this.sourceNode?.parentElement === null &&
      !!this.viewRoot?.parentElement;

    const propList = Object.keys(computedStyle);
    propList.sort(Css.processingOrderFn);
    let fontSize: Css.Val | undefined;
    let lineHeight: Css.Val | undefined;

    for (const propName of propList) {
      if (propertiesNotPassedToDOM[propName]) {
        continue;
      }
      let value = computedStyle[propName];
      if (!value || (value === Css.empty && !Css.isCustomPropName(propName))) {
        continue;
      }
      value = value.visit(
        new CssProp.UrlTransformVisitor(
          this.xmldoc.url,
          this.documentURLTransformer,
        ),
      );
      if (value instanceof Css.Numeric) {
        if (value.unit === "em") {
          const emUnitSize = this.getEmUnitSize(propName, fontSize);
          if (emUnitSize != null) {
            value = new Css.Numeric(value.num * emUnitSize, "px");
          }
        } else if (value.unit === "lh") {
          const lhUnitSize = this.getLineHeightUnitSize(
            propName,
            fontSize,
            lineHeight,
          );
          if (lhUnitSize != null) {
            value = new Css.Numeric(value.num * lhUnitSize, "px");
          }
        } else if (Exprs.needUnitConversion(value.unit)) {
          // font-size for the root element is already converted to px
          value = Css.convertNumericToPx(value, this.context);
        }
      }

      if (propName === "font-size" || propName === "line-height") {
        if (propName === "font-size") {
          fontSize = value;
        } else {
          lineHeight = value;
        }

        // Adjust font-size and line-height to prevent rounding issues
        // when calculating the size of text and line boxes. (Issue #1590)
        //
        // Chromium and Firefox round to the nearest multiple of LayoutUnit
        // (the smallest unit of length in the browser) when positioning boxes,
        // which may cause the box size to be slightly larger than specified,
        // resulting in text not fitting in the specified number of characters/lines.
        // To prevent this, we adjust the font size and line height to be
        // 1 LayoutUnit less.
        if (
          this.viewport.layoutUnitAdj &&
          value instanceof Css.Numeric &&
          value.unit !== "%" &&
          value.unit !== "em" &&
          value.unit !== "lh"
        ) {
          value = new Css.AnyToken(
            `calc(${value.toString()} - var(--viv-layoutUnitAdj))`,
          );
        }
      }

      if (
        Vtree.delayedProps[propName] ||
        (isRelativePositioned &&
          Vtree.delayedPropsIfRelativePositioned[propName])
      ) {
        // Set it after page layout is done.
        this.page.delayedItems.push(
          new Vtree.DelayedItem(target, propName, value),
        );
        continue;
      }
      if (
        isRoot &&
        this.page.pageAreaElement &&
        CssCascade.isInherited(propName)
      ) {
        // Fix for Issue #568
        Base.setCSSProperty(
          // the page area element is always nested in bleed box and container
          this.page.pageAreaElement.parentElement!.parentElement!,
          propName,
          value.toString(),
        );
        // Also propagate to the layout box so that page float areas laid out
        // there (e.g. during stash re-layout before the root element is
        // processed on the new page) inherit the correct values. (Issue #1752)
        // Exclude writing-mode and direction: these affect page box positioning
        // inside the layout box (e.g. vertical-rl right-aligns children) and
        // are already set on the page box when needed.
        if (propName !== "writing-mode" && propName !== "direction") {
          Base.setCSSProperty(
            this.viewport.layoutBox,
            propName,
            value.toString(),
          );
        }
      } else {
        Base.setCSSProperty(target, propName, value.toString());
      }
    }
  }

  /**
   * Parse a CSS value with "px" unit plus layoutUnitAdj.
   * This is to get accurate font-size and line-height values from computed style
   * that have been set with minus layoutUnitAdj.
   * @param val CSS value string
   * @returns parsed and adjusted value in px, or null if cannot parse as "px" unit, e.g. "normal"
   */
  private parsePlusLayoutUnitAdj(val: string): number | null {
    if (val.endsWith("px")) {
      const parsedVal = parseFloat(val);
      if (!isNaN(parsedVal)) {
        return (
          Math.round(
            (parsedVal + this.viewport.layoutUnitAdj) *
              this.viewport.layoutUnitPerPixel,
          ) / this.viewport.layoutUnitPerPixel
        );
      }
    }
    return null;
  }

  private getFootnoteAreaInheritedMetrics(): {
    fontSize: number | null;
    lineHeight: number | null;
  } {
    const pageContextElement = this.page.pageAreaElement?.parentElement
      ?.parentElement as HTMLElement | null;
    const pageContextStyle = pageContextElement
      ? this.viewport.window.getComputedStyle(pageContextElement)
      : null;
    const fontSize =
      (pageContextStyle &&
        this.parsePlusLayoutUnitAdj(pageContextStyle.fontSize)) ||
      this.context.rootFontSize ||
      this.context.initialFontSize;
    const lineHeight =
      (pageContextStyle &&
        this.parsePlusLayoutUnitAdj(pageContextStyle.lineHeight)) ||
      this.context.rootLineHeight ||
      fontSize * this.context.pref.lineHeight;
    return { fontSize, lineHeight };
  }

  private getComputedFontMetrics(
    element: Element,
    fallback: { fontSize: number | null; lineHeight: number | null },
  ): { fontSize: number | null; lineHeight: number | null } {
    const style = this.viewport.window.getComputedStyle(element);
    const fontSize =
      this.parsePlusLayoutUnitAdj(style.fontSize) ?? fallback.fontSize;
    const lineHeight =
      this.parsePlusLayoutUnitAdj(style.lineHeight) ??
      fallback.lineHeight ??
      (fontSize != null ? fontSize * this.context.pref.lineHeight : null);
    return { fontSize, lineHeight };
  }

  private getParentViewStyle(): CSSStyleDeclaration | null {
    return this.nodeContext?.parent?.viewNode?.nodeType === 1
      ? this.viewport.window.getComputedStyle(
          this.nodeContext.parent.viewNode as Element,
        )
      : null;
  }

  private getParentComputedMetrics(parentStyle: CSSStyleDeclaration | null): {
    fontSize: number | null;
    lineHeight: number | null;
  } {
    return {
      fontSize:
        this.computedStyleParentFontSizeOverride ??
        (parentStyle
          ? this.parsePlusLayoutUnitAdj(parentStyle.fontSize)
          : this.context.rootFontSize),
      lineHeight:
        this.computedStyleParentLineHeightOverride ??
        (parentStyle
          ? this.parsePlusLayoutUnitAdj(parentStyle.lineHeight)
          : this.context.rootLineHeight),
    };
  }

  /**
   * Get "lh" unit size in px
   * @return line-height in px, or null if cannot be determined
   */
  private getLineHeightUnitSize(
    propName: string,
    fontSize: Css.Val | undefined,
    lineHeight: Css.Val | undefined,
  ): number | null {
    const parentStyle = this.getParentViewStyle();
    const parentMetrics = this.getParentComputedMetrics(parentStyle);
    const parentLineHeight = parentMetrics.lineHeight;

    if (propName === "line-height" || propName === "font-size") {
      // For line-height property or for font-size property, return parent line-height.
      // Note: parentLineHeight may be null (cannot determine).
      return parentLineHeight;
    }

    // Font-size relative line-height value
    let lineHeightNum: number | null = null;

    if (lineHeight) {
      if (
        lineHeight instanceof Css.Num ||
        (lineHeight instanceof Css.Numeric &&
          (lineHeight.unit === "em" || lineHeight.unit === "%"))
      ) {
        // The line-height is relative to the font-size
        lineHeightNum =
          lineHeight instanceof Css.Numeric && lineHeight.unit === "%"
            ? lineHeight.num / 100
            : lineHeight.num;
      } else {
        if (lineHeight instanceof Css.Numeric && lineHeight.unit !== "lh") {
          const unitSize = this.context.queryUnitSize(lineHeight.unit, false);
          if (unitSize != null) {
            // Return line-height in px
            return lineHeight.num * unitSize;
          }
        }
        return null; // cannot determine
      }
    }

    if (lineHeightNum == null) {
      // Try to get font-size relative line-height value from ancestor elements
      for (
        let viewNode: Node | null | undefined =
          this.nodeContext?.parent?.viewNode;
        viewNode && viewNode.nodeType === 1;
        viewNode = viewNode.parentNode
      ) {
        const ancestorLH = (viewNode as HTMLElement)?.style?.lineHeight;
        if (ancestorLH) {
          // Found line-height style in ancestor
          if (/^[0-9.]+$/.test(ancestorLH)) {
            // If it's a number without unit, it's relative to font-size
            lineHeightNum = parseFloat(ancestorLH);
          }
          break;
        }
      }
    }

    if (lineHeightNum != null) {
      // The line-height is relative to the font-size
      if (fontSize && !(fontSize instanceof Css.Numeric)) {
        return null; // cannot determine
      }
      const parentFontSize = parentMetrics.fontSize;
      if (fontSize instanceof Css.Numeric) {
        const fontSizePx = CssCascade.convertFontSizeToPx(
          fontSize,
          parentFontSize,
          this.context,
        ).num;
        // parentFontSize may be null and the fontSizePx may be NaN
        if (typeof fontSizePx !== "number" || isNaN(fontSizePx)) {
          return null; // cannot determine
        }
        return lineHeightNum * fontSizePx;
      } else {
        if (parentFontSize == null) {
          return null;
        }
        return lineHeightNum * parentFontSize;
      }
    }
    // parentLineHeight may be null (cannot determine)
    return parentLineHeight;
  }

  /**
   * Get "em" unit size in px
   * @return font-size in px, or null if cannot be determined
   */
  private getEmUnitSize(
    propName: string,
    fontSize: Css.Val | undefined,
  ): number | null {
    const parentStyle = this.getParentViewStyle();
    const parentFontSize = this.getParentComputedMetrics(parentStyle).fontSize;

    if (propName === "font-size" || fontSize == null) {
      // For font-size property or when font-size is not specified, return parent font-size.
      // Note: parentFontSize may be null (cannot determine).
      return parentFontSize;
    }
    if (fontSize instanceof Css.Numeric) {
      // When font-size is specified, convert it to px
      const fontSizePx = CssCascade.convertFontSizeToPx(
        fontSize,
        parentFontSize,
        this.context,
      ).num;
      if (typeof fontSizePx === "number" && !isNaN(fontSizePx)) {
        return fontSizePx;
      }
    }
    return null; // cannot determine
  }

  /** @override */
  applyPseudoelementStyle(
    nodeContext: Vtree.NodeContext,
    pseudoName: string,
    target: Element,
  ): void {
    if (nodeContext.after) {
      return;
    }
    const element = this.sourceNode as Element;
    const styler = nodeContext.shadowContext
      ? (nodeContext.shadowContext.styler as CssStyler.AbstractStyler)
      : this.styler;
    let elementStyle = styler.getStyle(element, false);
    const pseudoMap = CssCascade.getStyleMap(elementStyle, "_pseudos");
    if (!pseudoMap) {
      return;
    }
    elementStyle = pseudoMap[pseudoName];
    if (!elementStyle) {
      return;
    }
    const computedStyle: { [key: string]: Css.Val } = {};
    nodeContext.vertical = this.computeStyle(
      nodeContext.vertical,
      nodeContext.direction === "rtl",
      elementStyle,
      computedStyle,
    );
    const content = computedStyle["content"];
    if (Vtree.nonTrivialContent(content)) {
      content.visit(
        new Vtree.ContentPropertyHandler(
          target,
          this.context,
          content,
          this.exprContentListener,
        ),
      );
      delete computedStyle["content"];
    }
    this.applyComputedStyles(target, computedStyle);
  }

  /** @override */
  peelOff(
    nodeContext: Vtree.ChildNodeContext,
    nodeOffset: number,
  ): Task.Result<Vtree.NodeContext> {
    const frame: Task.Frame<Vtree.NodeContext> = Task.newFrame("peelOff");
    const firstPseudo = nodeContext.firstPseudo;
    let offsetInNode = nodeContext.offsetInNode;
    const after = nodeContext.after;
    if (nodeOffset > 0) {
      offsetInNode += nodeOffset;
    } else if (!after && nodeContext.viewNode && offsetInNode == 0) {
      const parent = nodeContext.viewNode.parentNode;
      if (parent) {
        parent.removeChild(nodeContext.viewNode);
      }
    }
    const boxOffset = nodeContext.boxOffset + nodeOffset;

    // arr collects the chain strictly below its container, innermost first
    const arr: Vtree.NodeContext[] = [];
    let container: Vtree.NodeContext = nodeContext;
    for (
      let parent: Vtree.NodeContext | null = nodeContext.parent;
      parent && parent.firstPseudo === firstPseudo;
      parent = container.parent
    ) {
      arr.push(container);
      container = parent;
    }
    let shadowSibling = container.shadowSibling;
    let i = arr.length - 1;
    let rebuilt: Vtree.NodeContext | null = null;
    frame
      .loop(() => {
        while (i >= 0) {
          const pn = arr[i];
          const parentContext = rebuilt ?? container.parent;
          const child = new Vtree.NodeContext(
            pn.sourceNode,
            parentContext,
            boxOffset,
            (parentContext ?? container).formattingContext,
          );
          child.blockContainer =
            parentContext && Vtree.blockContainerForChildrenOf(parentContext);
          if (i == 0) {
            child.offsetInNode = offsetInNode;
            child.after = after;
          }
          child.shadowType = pn.shadowType;
          child.shadowContext = pn.shadowContext;
          child.nodeShadow = pn.nodeShadow;
          child.shadowSibling = pn.shadowSibling
            ? pn.shadowSibling
            : shadowSibling;
          shadowSibling = null;
          rebuilt = child;
          i--;
          const result = this.setCurrent(child, false);
          if (result.isPending()) {
            return result;
          }
        }
        return Task.newResult(false);
      })
      .then(() => {
        frame.finish(rebuilt ?? nodeContext.parent);
      });
    return frame.result();
  }

  createElement(ns: string | null, tag: string): Element {
    if (ns == Base.NS.XHTML) {
      return this.document.createElement(tag);
    }
    return this.document.createElementNS(ns, tag);
  }

  /** @override */
  applyFootnoteStyle(
    vertical: boolean,
    rtl: boolean,
    target: Element,
  ): Task.Result<boolean> {
    const computedStyle: { [key: string]: Css.Val } = {};
    const fetchers: TaskUtil.Fetcher<string>[] = [];

    let footnoteStyle = this.footnoteStyle;
    if (this.cascadedPageStyle) {
      const footnoteAreaMap = CssCascade.getStyleMap(
        this.cascadedPageStyle,
        CssPage.footnoteAreaKey,
      );
      if (footnoteAreaMap && footnoteAreaMap["area"]) {
        // Styles defined in @page @footnote override any top-level @footnote.
        footnoteStyle = footnoteAreaMap["area"];
      }
    }

    const pseudoMap = CssCascade.getStyleMap(footnoteStyle, "_pseudos");
    vertical = this.computeStyle(vertical, rtl, footnoteStyle, computedStyle);
    const inheritedMetrics = this.getFootnoteAreaInheritedMetrics();
    if (!computedStyle["font-size"] && inheritedMetrics.fontSize != null) {
      computedStyle["font-size"] = new Css.Numeric(
        inheritedMetrics.fontSize,
        "px",
      );
    }
    delete computedStyle["content"];
    const prevFontSizeOverride = this.computedStyleParentFontSizeOverride;
    const prevLineHeightOverride = this.computedStyleParentLineHeightOverride;
    // @footnote and @footnote::before resolve em/lh units from the page context,
    // not from the noteref that triggered semantic footnote generation.
    this.computedStyleParentFontSizeOverride = inheritedMetrics.fontSize;
    this.computedStyleParentLineHeightOverride = inheritedMetrics.lineHeight;
    try {
      this.applyComputedStyles(target, computedStyle);
      const targetMetrics = this.getComputedFontMetrics(
        target,
        inheritedMetrics,
      );
      this.computedStyleParentFontSizeOverride = targetMetrics.fontSize;
      this.computedStyleParentLineHeightOverride = targetMetrics.lineHeight;
      if (pseudoMap && pseudoMap["before"]) {
        const pseudoStyle = pseudoMap["before"];
        const hasSpecifiedDisplay = !!CssCascade.getProp(
          pseudoStyle,
          "display",
        );
        const childComputedStyle: { [key: string]: Css.Val } = {};
        const span = this.createElement(Base.NS.XHTML, "span");
        PseudoElement.setPseudoName(span, "before");
        target.appendChild(span);
        this.computeStyle(vertical, rtl, pseudoStyle, childComputedStyle);
        if (!hasSpecifiedDisplay) {
          childComputedStyle["display"] = Css.ident.block;
        }

        const contentCascadeValue = CssCascade.getProp(pseudoStyle, "content");
        if (contentCascadeValue) {
          const contentElement =
            this.sourceNode?.nodeType === 1
              ? (this.sourceNode as Element)
              : this.xmldoc.root;
          childComputedStyle["content"] = contentCascadeValue
            .filterValue(
              new CssCascade.ContentPropVisitor(
                this.styler.cascade,
                contentElement,
                this.styler.cascade.counterResolver,
                this.styler.elementWindow.currentStyle,
                "before",
              ),
            )
            .evaluate(this.context, "content");
        }

        const content = childComputedStyle["content"];
        if (Vtree.nonTrivialContent(content)) {
          content.visit(
            new Vtree.ContentPropertyHandler(
              span,
              this.context,
              content,
              this.exprContentListener,
            ),
          );

          const images = span.querySelectorAll("img[src]");
          for (let i = 0; i < images.length; i++) {
            const image = images[i] as HTMLImageElement;
            const src = image.getAttribute("src");
            if (!src) {
              continue;
            }
            const fetcher = Net.loadElement(image, src);
            fetchers.push(fetcher);
            this.page.fetchers.push(fetcher);
          }

          const rootSrc = span.getAttribute("src");
          if (rootSrc) {
            let image = span.querySelector("img") as HTMLImageElement | null;
            if (!image) {
              image = this.document.createElement("img");
              image.setAttribute("src", rootSrc);
              span.appendChild(image);
            }
            const fetcher = Net.loadElement(image, rootSrc);
            fetchers.push(fetcher);
            this.page.fetchers.push(fetcher);
          }
        }
        delete childComputedStyle["content"];
        this.applyComputedStyles(span, childComputedStyle);
      }
    } finally {
      this.computedStyleParentFontSizeOverride = prevFontSizeOverride;
      this.computedStyleParentLineHeightOverride = prevLineHeightOverride;
    }
    if (fetchers.length) {
      return TaskUtil.waitForFetchers(fetchers).thenReturn(vertical);
    }
    return Task.newResult(vertical);
  }

  /** @override */
  processFragmentedBlockEdge(nodeContext: Vtree.NodeContext) {
    const nodeContext1 =
      !nodeContext.inline && nodeContext.after
        ? nodeContext.parent
        : nodeContext;
    // Fix for problem with math (Issue #1038)
    let isBeforeBlock = false;
    if (
      nodeContext.inline &&
      nodeContext.after &&
      !nodeContext.shadowContext &&
      nodeContext.sourceNode.nextSibling?.nodeType === 1
    ) {
      const nextElem = nodeContext.sourceNode.nextSibling as Element;
      const display = CssCascade.getProp(
        this.styler.getStyle(nextElem, false),
        "display",
      )?.value.toString();
      isBeforeBlock =
        (display && !Display.isInlineLevel(display)) ||
        (nextElem.getAttribute("data-math-typeset") === "true" &&
          /^\s*(\$\$|\\\[)/.test(nextElem.textContent));
    }

    let blockNestCount = 0;
    for (let nc = nodeContext1; nc; nc = nc.parent) {
      if (nc.viewNode?.nodeType !== 1) continue;

      const elem = nc.viewNode as HTMLElement;
      if (!elem.style) continue;

      if (nc.inline) {
        Break.setBoxBreakFlag(elem, "inline-end");
        if (Break.isCloneBoxDecorationBreak(elem)) {
          const extentBefore = nc.vertical
            ? elem.offsetWidth
            : elem.offsetHeight;
          Break.setBoxBreakFlag(elem, "clone");
          const extentAfter = nc.vertical
            ? elem.offsetWidth
            : elem.offsetHeight;
          if (extentAfter > extentBefore) {
            // Workaround for Chrome box-decoration-break:clone problem
            this.fixClonedBoxDecorationOverflow(elem);
          }
        }
      } else {
        const blockSizeP = nodeContext.vertical ? "width" : "height";
        if (Base.getCSSProperty(elem, blockSizeP)) {
          // When a box with a specified block size is fragmented,
          // the fragmented box should not have the block size.
          Base.setCSSProperty(elem, blockSizeP, "");
        }
        Break.setBoxBreakFlag(elem, "block-end");
        if (!blockNestCount++) {
          if (nc !== nodeContext1) {
            const { textAlign } = this.viewport.window.getComputedStyle(elem);
            if (textAlign === "justify" && !isBeforeBlock) {
              // Workaround for the problem that text-align-last:justify is
              // not only effective at the last line of the block but also
              // effective at lines just before child block-level or `<br>`
              // elements.
              const elem2 = this.createChildAnonymousBlockIfNeeded(elem);
              if (elem2) {
                if (elem2 !== elem) {
                  // child anonymous block created
                  Break.setBoxBreakFlags(elem2, [
                    "block-start",
                    "text-start",
                    "block-end",
                    "text-end",
                    "justify",
                  ]);
                } else {
                  Break.setBoxBreakFlag(elem, "text-end");
                  Break.setBoxBreakFlag(elem, "justify");
                }
              } else {
                // text-align-last:justify is not necessary (`<br>` at very last)
                // or not appropriate (e.g. the last `<br>` is in middle of nested inline)
                Break.setBoxBreakFlag(elem, "text-end");
              }
            } else {
              Break.setBoxBreakFlag(elem, "text-end");
            }
          }
        }
        if (Break.isCloneBoxDecorationBreak(elem)) {
          Break.setBoxBreakFlag(elem, "clone");
        }
        Break.setMarginDiscardFlag(elem, "block-end");
      }
    }
  }

  private fixClonedBoxDecorationOverflow(elem: HTMLElement): void {
    const computedStyle = this.viewport.window.getComputedStyle(elem);
    const paddingInlineEnd = parseFloat(computedStyle.paddingInlineEnd);
    const borderInlineEndWidth = parseFloat(computedStyle.borderInlineEndWidth);
    const adjust = -(paddingInlineEnd + borderInlineEndWidth);
    if (!isNaN(adjust)) {
      elem.style.marginInlineEnd = `${adjust}px`;
    }
  }

  private createChildAnonymousBlockIfNeeded(
    elem: HTMLElement,
  ): HTMLElement | null {
    const checkForcedLineBreakElem = (elem1: Element): boolean | null => {
      const { display, position, float } =
        this.viewport.window.getComputedStyle(elem1);
      if (elem1.localName === "ruby" || Base.mediaTags[elem1.localName]) {
        return false;
      }
      if (elem1.localName === "br") {
        return true;
      }
      if (
        (display === "inline" || display === "contents") &&
        elem1.hasChildNodes()
      ) {
        const lastChild = elem1.lastElementChild;
        if (
          lastChild &&
          (!lastChild.nextSibling ||
            (lastChild.nextSibling === elem1.lastChild &&
              Vtree.canIgnore(lastChild.nextSibling)))
        ) {
          const found = checkForcedLineBreakElem(lastChild);
          if (found || found === null) {
            return found;
          }
        }
        for (
          let child = lastChild?.previousElementSibling;
          child;
          child = child.previousElementSibling
        ) {
          const found = checkForcedLineBreakElem(child);
          if (found || found === null) {
            // forced line break is found at middle of nested inline
            return null;
          }
        }
        return false;
      }
      if (
        display === "none" ||
        position === "absolute" ||
        position === "fixed" ||
        (float && float !== "none") ||
        elem1.hasAttribute(LayoutHelper.SPECIAL_ATTR)
      ) {
        const prevElem = elem1.previousElementSibling;
        if (
          prevElem &&
          (prevElem.nextSibling === elem1 ||
            (prevElem.nextSibling === elem1.previousSibling &&
              Vtree.canIgnore(prevElem.nextSibling)))
        ) {
          return checkForcedLineBreakElem(prevElem);
        }
        return false;
      }
      if (!display || Display.isInlineLevel(display)) {
        return false;
      }
      return true;
    };

    let forcedBreakElem: Element | null = null;
    for (
      let child = elem.lastElementChild;
      child;
      child = child.previousElementSibling
    ) {
      const found = checkForcedLineBreakElem(child);
      if (found) {
        forcedBreakElem = child;
        break;
      }
      if (found === null) {
        // forced line break is found at middle of nested inline
        return null;
      }
    }

    if (!forcedBreakElem) {
      // forced line break is not found
      return elem;
    }

    if (
      forcedBreakElem === elem.lastElementChild &&
      (!forcedBreakElem.nextSibling ||
        (forcedBreakElem.nextSibling === elem.lastChild &&
          Vtree.canIgnore(forcedBreakElem.nextSibling)))
    ) {
      // forced line break is found at very last
      return null;
    }

    const anonymousBlock = elem.ownerDocument.createElement("span");
    anonymousBlock.className = "viv-anonymous-block";

    for (
      let node: Node | null = forcedBreakElem.nextSibling,
        nextNode: Node | null = null;
      node;
      node = nextNode
    ) {
      nextNode = node.nextSibling;
      anonymousBlock.appendChild(node);
    }
    elem.appendChild(anonymousBlock);
    return anonymousBlock;
  }

  /** @override */
  convertLengthToPx(
    numeric: Css.Numeric,
    viewNode: Node,
    clientLayout: Vtree.ClientLayout,
  ): number | Css.Numeric {
    const num = numeric.num;
    const unit = numeric.unit;
    if (Exprs.isFontRelativeLengthUnit(unit)) {
      let elem: Node | null = viewNode;
      while (elem && elem.nodeType !== 1) {
        elem = elem.parentNode;
      }
      Asserts.assert(elem);
      const fontSize = parseFloat(
        clientLayout.getElementComputedStyle(elem as Element)["font-size"],
      );
      return CssCascade.convertFontRelativeLengthToPx(
        numeric,
        fontSize,
        this.context,
      ).num;
    } else {
      const unitSize = this.context.queryUnitSize(unit, false);
      if (unitSize) {
        return num * unitSize;
      } else {
        return numeric;
      }
    }
  }

  /**
   * Returns if two NodePositionStep are equivalent.
   */
  isSameNodePositionStep(
    step1: Vtree.NodePositionStep,
    step2: Vtree.NodePositionStep,
  ): boolean {
    if (step1.shadowContext) {
      if (!step2.shadowContext) {
        return false;
      }
      const elem1 =
        step1.node.nodeType === 1
          ? (step1.node as Element)
          : (step1.node.parentElement as Element);
      const elem2 =
        step2.node.nodeType === 1
          ? (step2.node as Element)
          : (step2.node.parentElement as Element);
      return (
        step1.shadowContext.owner === step2.shadowContext.owner &&
        PseudoElement.getPseudoName(elem1) ===
          PseudoElement.getPseudoName(elem2)
      );
    } else {
      return step1.node === step2.node;
    }
  }

  /** @override */
  isSameNodePosition(
    nodePosition1: Vtree.NodePosition,
    nodePosition2: Vtree.NodePosition,
  ): boolean {
    return (
      nodePosition1.offsetInNode === nodePosition2.offsetInNode &&
      nodePosition1.after == nodePosition2.after &&
      nodePosition1.steps.length === nodePosition2.steps.length &&
      nodePosition1.steps.every((step1, i) => {
        const step2 = nodePosition2.steps[i];
        return this.isSameNodePositionStep(step1, step2);
      })
    );
  }
}

export const propertiesNotPassedToDOM = {
  "float-min-wrap-block": true,
  "float-reference": true,
  "flow-into": true,
  "flow-linger": true,
  "flow-options": true,
  "flow-priority": true,
  "footnote-display": true,
  "footnote-policy": true,
  "margin-break": true,
  page: true,
};

export class DefaultClientLayout implements Vtree.ClientLayout {
  layoutBox: Element;
  window: Window;
  pixelRatio: number;
  scaleRatio: number;
  layoutUnitPerPixel: number;

  constructor(viewport: Viewport) {
    this.layoutBox = viewport.layoutBox;
    this.window = viewport.window;
    this.pixelRatio = viewport.pixelRatio;
    this.scaleRatio = viewport.scaleRatio;
    this.layoutUnitPerPixel = viewport.layoutUnitPerPixel;
  }

  private subtractOffsets(
    rect: Vtree.ClientRect,
    originRect: Vtree.ClientRect,
  ): Vtree.ClientRect {
    const viewportLeft = originRect.left;
    const viewportTop = originRect.top;
    return {
      left: rect.left - viewportLeft,
      top: rect.top - viewportTop,
      right: rect.right - viewportLeft,
      bottom: rect.bottom - viewportTop,
      width: rect.width,
      height: rect.height,
    } as Vtree.ClientRect;
  }

  /** @override */
  getRangeClientRects(range: Range): Vtree.ClientRect[] {
    const rects = range.getClientRects();
    const layoutBoxRect = this.layoutBox.getBoundingClientRect();
    return Array.from(rects).map((rect) =>
      this.subtractOffsets(rect, layoutBoxRect),
    );
  }

  /** @override */
  getElementClientRect(element: Element): Vtree.ClientRect {
    const htmlElement = element as HTMLElement;
    const rect = htmlElement.getBoundingClientRect() as Vtree.ClientRect;
    if (
      rect.left === 0 &&
      rect.top === 0 &&
      rect.right === 0 &&
      rect.bottom === 0
    ) {
      // getBoundingClientRect() returns 0,0,0,0 for WBR element (Chrome)
      // (Fix for issue #802)
      return rect;
    }
    const layoutBoxRect = this.layoutBox.getBoundingClientRect();
    return this.subtractOffsets(rect, layoutBoxRect);
  }

  /** @override */
  getElementComputedStyle(element: Element): CSSStyleDeclaration {
    return this.window.getComputedStyle(element, null);
  }

  /**
   * Adjust length value with rendering precision.
   * @param value Length value to adjust
   * @return Adjusted length value
   * @override
   */
  adjustLengthValue(value: number): number {
    return this.layoutUnitPerPixel
      ? Math.floor(value * this.layoutUnitPerPixel) / this.layoutUnitPerPixel
      : value;
  }
}

export class Viewport {
  document: Document;
  root: HTMLElement;
  private outerZoomBox: HTMLElement;
  contentContainer: HTMLElement;
  layoutBox: HTMLElement;
  width: number;
  height: number;
  scaleRatio: number = 1;
  layoutUnitPerPixel: number = 64;
  layoutUnitAdj: number = 0;

  constructor(
    public readonly window: Window,
    public readonly fontSize: number,
    public readonly pixelRatio: number,
    opt_root?: HTMLElement,
    opt_width?: number,
    opt_height?: number,
  ) {
    this.document = window.document;
    this.root = opt_root || this.document.body;

    if (this.root.hasAttribute("data-vivliostyle-toc-box")) {
      // TOC viewport does not need zoom box and layout box.
      this.outerZoomBox = this.contentContainer = this.layoutBox = this.root;
      this.width = opt_width || this.root.clientWidth;
      this.height = opt_height || this.root.clientHeight;
      return;
    }

    let outerZoomBox = this.root.firstElementChild as HTMLElement;
    if (!outerZoomBox) {
      outerZoomBox = this.document.createElement("div");
      outerZoomBox.setAttribute("data-vivliostyle-outer-zoom-box", "true");
      outerZoomBox.role = "presentation";
      this.root.appendChild(outerZoomBox);
    }
    let contentContainer = outerZoomBox.firstElementChild as HTMLElement;
    if (!contentContainer) {
      contentContainer = this.document.createElement("div");
      contentContainer.setAttribute(
        "data-vivliostyle-spread-container",
        "true",
      );
      contentContainer.role = "presentation";
      outerZoomBox.appendChild(contentContainer);
    }

    if (pixelRatio > 0 && CSS.supports("zoom", "8")) {
      // Emulate high pixel ratio using zoom and transform:scale().
      // Workaround for issue #419 (minimum border width too thick)
      // and #1076 (layout depends on device pixel ratio).
      //
      // CSS variables --viv-outputPixelRatio, --viv-devicePixelRatio,
      // and --viv-outputScale are used in zoom and transform property values
      // to emulate high pixel ratio output.
      // (see VivliostyleViewportCss in assets.ts)
      Base.setCSSProperty(this.root, "--viv-outputPixelRatio", `${pixelRatio}`);
      Base.setCSSProperty(
        this.root,
        "--viv-devicePixelRatio",
        `${window.devicePixelRatio}`,
      );

      this.scaleRatio = pixelRatio / window.devicePixelRatio;
    }

    // Determine layout unit per CSS pixel and adjustment value needed for
    // accurate layout of text and line boxes to avoid rounding issues
    // based on browser type. (Issue #1590)
    switch (Base.browserType) {
      case "chromium":
        this.layoutUnitPerPixel =
          64 * (this.pixelRatio || window.devicePixelRatio);
        this.layoutUnitAdj = 1 / this.layoutUnitPerPixel;
        break;
      case "firefox":
        this.layoutUnitPerPixel = 60;
        this.layoutUnitAdj = 1 / this.layoutUnitPerPixel;
        break;
      case "webkit":
      default:
        // WebKit uses 1/64 px layout unit, but it seems to floor
        // the position values instead of rounding them,
        // so text overflow does not occur without adjustment.
        this.layoutUnitPerPixel = 64;
        this.layoutUnitAdj = 0;
    }
    if (this.layoutUnitAdj) {
      Base.setCSSProperty(
        this.root,
        "--viv-layoutUnitAdj",
        `${this.layoutUnitAdj}px`,
      );
    }

    let layoutBox = outerZoomBox.nextElementSibling as HTMLElement;
    if (!layoutBox) {
      layoutBox = this.document.createElement("div");
      layoutBox.setAttribute("data-vivliostyle-layout-box", "true");
      layoutBox.role = "presentation";
      this.root.appendChild(layoutBox);
    }
    this.outerZoomBox = outerZoomBox;
    this.contentContainer = contentContainer;
    this.layoutBox = layoutBox;
    this.width =
      opt_width ||
      parseFloat(window.getComputedStyle(this.root).width) ||
      this.root.offsetWidth ||
      window.innerWidth;
    this.height =
      opt_height ||
      parseFloat(window.getComputedStyle(this.root).height) ||
      this.root.offsetHeight ||
      window.innerHeight;

    // Use the fallbackPageSize if window size is 0 or browser is in headless mode.
    const fallbackPageSize = {
      // compromise between A4 (210mm 297mm) and letter (8.5in 11in)
      width: 794, // 210mm (8.27in)
      height: 1056, // 279.4mm (11in)
    };
    const isHeadlessBrowser =
      (!window.outerWidth && !window.outerHeight) ||
      /Headless/.test(navigator.userAgent) ||
      (navigator.webdriver &&
        window.innerWidth === 800 &&
        window.innerHeight === 600);

    if (!this.width || (!opt_width && isHeadlessBrowser)) {
      this.width = fallbackPageSize.width;
    }
    if (!this.height || (!opt_height && isHeadlessBrowser)) {
      this.height = fallbackPageSize.height;
    }
  }

  /**
   * Reset zoom.
   */
  resetZoom() {
    Base.setCSSProperty(this.outerZoomBox, "width", "");
    Base.setCSSProperty(this.outerZoomBox, "height", "");
    Base.setCSSProperty(this.contentContainer, "width", "");
    Base.setCSSProperty(this.contentContainer, "height", "");
    Base.setCSSProperty(this.contentContainer, "transform", "");
  }

  /**
   * Zoom viewport.
   * @param width Overall width of contents before scaling (px)
   * @param height Overall height of contents before scaling (px)
   * @param scale Factor to which the viewport will be scaled.
   */
  zoom(width: number, height: number, scale: number) {
    Base.setCSSProperty(this.root, "--viv-outputScale", `${scale}`);
    Base.setCSSProperty(this.outerZoomBox, "width", `${width * scale}px`);
    Base.setCSSProperty(this.outerZoomBox, "height", `${height * scale}px`);
    Base.setCSSProperty(this.contentContainer, "width", `${width}px`);
    Base.setCSSProperty(this.contentContainer, "height", `${height}px`);
  }

  /**
   * Remove all pages inside the viewport.
   */
  clear() {
    const root = this.root;
    while (root.lastChild) {
      root.removeChild(root.lastChild);
    }
  }
}

/**
 * Recursively walk a CSS value tree and push image-load fetchers for any
 * URL values found. Used to preload images referenced by background-image,
 * border-image-source, filter, etc.
 */
export function addImageFetchersToPage(val: Css.Val, page: Vtree.Page): void {
  if (val instanceof Css.CommaList) {
    for (const v of val.values) {
      addImageFetchersToPage(v, page);
    }
  } else if (val instanceof Css.URL) {
    const url = Base.resolveWptResourceURL(val.url);
    page.fetchers.push(Net.loadElement(new Image(), url));
  } else if (val instanceof Css.Func) {
    for (const v of val.values) {
      addImageFetchersToPage(v, page);
    }
  } else if (val instanceof Css.SpaceList) {
    for (const v of val.values) {
      addImageFetchersToPage(v, page);
    }
  }
}
