/**
 * Copyright 2016 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @fileoverview Counters, named strings, and running elements
 */
import * as Asserts from "./asserts";
import * as Base from "./base";
import * as Css from "./css";
import * as CssCascade from "./css-cascade";
import * as CssProp from "./css-prop";
import * as CssStyler from "./css-styler";
import * as Exprs from "./exprs";
import * as Vgen from "./vgen";
import * as Vtree from "./vtree";
import { Layout } from "./types";

/**
 * Clone counter values.
 */
function cloneCounterValues(
  counters: CssCascade.CounterValues,
): CssCascade.CounterValues {
  const result = Object.create(null) as CssCascade.CounterValues;
  Object.keys(counters).forEach((name) => {
    result[name] = Array.from(counters[name]);
  });
  return result;
}

/**
 * Decode CSS string escape sequences.
 * e.g., `\22` → `"`, `\A` → newline, `\\` → `\`
 */
function decodeCssString(s: string): string {
  return s.replace(/\\([0-9a-fA-F]{1,6})\s?|\\(.)/g, (_, hex, ch) => {
    if (hex) {
      return String.fromCodePoint(parseInt(hex, 16));
    }
    return ch;
  });
}

/**
 * Extract text content from an element for a specific pseudo-element.
 * @param element The DOM element to extract text from
 * @param pseudoElement The pseudo-element type: "content", "before", "after" or "marker"
 * @returns The extracted text, or empty string if not found
 */
function extractPseudoElementText(
  element: Element,
  pseudoElement: "content" | "before" | "after" | "marker",
): string {
  if (pseudoElement === "content") {
    // Get main content (excluding ::before and ::after)
    const clone = element.cloneNode(true) as Element;
    const pseudos = clone.querySelectorAll("[data-adapt-pseudo]");
    pseudos.forEach((pseudo) => pseudo.remove());
    return clone.textContent || "";
  } else if (pseudoElement === "marker") {
    // First check for traditional marker span (e.g., footnote-marker inside)
    const pseudoElem = element.querySelector(
      `[data-adapt-pseudo="marker"], [data-adapt-pseudo="footnote-marker"]`,
    );
    if (pseudoElem) {
      return pseudoElem.textContent || "";
    }
    // Native ::marker: read from --viv-marker-content CSS custom property.
    // The property is always set as an inline style on the element itself
    // (via computedStyle in vgen.ts), so element.style is sufficient.
    // Avoid getComputedStyle here as it can cause unwanted style computation
    // side effects on unrelated elements (e.g., canvas image-orientation).
    const markerContent = (element as HTMLElement).style?.getPropertyValue(
      "--viv-marker-content",
    );
    if (markerContent) {
      // Extract only string components from the CSS content value.
      // e.g., url(icon.png) "1. " → "1. " (url() tokens are ignored)
      const stringMatches = markerContent.match(
        /"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g,
      );
      if (stringMatches && stringMatches.length > 0) {
        return stringMatches
          .map((s) => decodeCssString(s.substring(1, s.length - 1)))
          .join("");
      }
    }
    return "";
  } else {
    // Extract ::before or ::after content
    const pseudoElem = element.querySelector(
      `[data-adapt-pseudo="${pseudoElement}"]`,
    );
    return pseudoElem ? pseudoElem.textContent || "" : "";
  }
}

/**
 * Class representing a reference by target-counter(s).
 * @param targetId ID of the referenced element (transformed by
 *     DocumentURLTransformer to handle a reference across multiple source
 *     documents)
 * @param resolved If the reference is already resolved or not
 */
export class TargetCounterReference {
  pageCounters: CssCascade.CounterValues | null = null;
  spineIndex: number = -1;
  pageIndex: number = -1;

  constructor(
    public readonly targetId: string,
    public resolved: boolean,
  ) {}

  equals(other: TargetCounterReference): boolean {
    if (this === other) {
      return true;
    }
    if (!other) {
      return false;
    }
    return (
      this.targetId === other.targetId &&
      this.resolved === other.resolved &&
      this.spineIndex === other.spineIndex &&
      this.pageIndex === other.pageIndex
    );
  }

  /**
   * Returns if the reference is resolved or not.
   */
  isResolved(): boolean {
    return this.resolved;
  }

  /**
   * Marks that this reference is resolved.
   */
  resolve() {
    this.resolved = true;
  }

  /**
   * Marks that this reference is unresolved.
   */
  unresolve() {
    this.resolved = false;
  }
}

class CounterListener implements CssCascade.CounterListener {
  constructor(
    public readonly counterStore: CounterStore,
    public readonly baseURL: string,
  ) {}

  /** @override */
  countersOfId(id: string, counters: CssCascade.CounterValues) {
    id = this.counterStore.documentURLTransformer.transformFragment(
      id,
      this.baseURL,
    );
    this.counterStore.countersById[id] = counters;
  }

  getExprContentListener(): Vtree.ExprContentListener {
    return this.counterStore.getExprContentListener();
  }
}

/**
 * Map for named string name, element offset, and the string value.
 * The value is normally a plain string, but when the `string-set` value
 * contains page-based counters it is kept as a `Css.Val` content list so the
 * counters can be resolved per page (Issue #1997).
 */
type NamedRunningValues = {
  [name: string]: { [elementOffset: number]: string | Css.Val };
};

/**
 * A `named-string-*` native expression that also exposes the stored content
 * list so page-based counters can be rendered as patchable nodes (Issue #1997).
 */
type NamedStringNative = Exprs.Native & {
  getContentList?: () => Css.Val | null;
};

class CounterResolver implements CssCascade.CounterResolver {
  styler: CssStyler.Styler | null = null;
  namedStringValues: NamedRunningValues = Object.create(null);
  runningElements: NamedRunningValues = Object.create(null);

  constructor(
    public readonly counterStore: CounterStore,
    public readonly baseURL: string,
    public readonly rootScope: Exprs.LexicalScope,
    public readonly pageScope: Exprs.LexicalScope,
  ) {}

  setStyler(styler: CssStyler.Styler): void {
    this.styler = styler;
  }

  private getFragment(url: string): string | null {
    const r = url.match(/^[^#]*#(.*)$/);
    return r ? r[1] : null;
  }

  private getTransformedId(url: string): string {
    let transformedId = this.counterStore.documentURLTransformer.transformURL(
      Base.resolveURL(url, this.baseURL),
      this.baseURL,
    );
    if (transformedId.startsWith("#")) {
      transformedId = transformedId.substring(1);
    }
    return transformedId;
  }

  /** @override */
  getPageCounterVal(
    name: string,
    format: (p1: number | null) => string,
  ): Exprs.Val {
    const getCounterNumber = () => {
      const values = this.counterStore.currentPageCounters[name];
      return values && values.length ? values.at(-1) : null;
    };

    const expr = new Exprs.Native(
      this.pageScope,
      () => format(getCounterNumber()),
      `page-counter-${name}`,
    );

    const arrayFormat = (arr: number[]) => {
      return format(arr.at(-1));
    };

    this.counterStore.registerPageCounterExpr(name, arrayFormat, expr);
    return expr;
  }

  /** @override */
  getPageCountersVal(
    name: string,
    format: (p1: number[]) => string,
  ): Exprs.Val {
    const getCounterNumbers = () => {
      return this.counterStore.currentPageCounters[name] || [];
    };

    const expr = new Exprs.Native(
      this.pageScope,
      () => format(getCounterNumbers()),
      `page-counters-${name}`,
    );
    this.counterStore.registerPageCounterExpr(name, format, expr);
    return expr;
  }

  /**
   * Returns (non page-based) counter values for an element with the specified
   * ID. Returns null if the style of the elements has not been calculated yet
   * (i.e. the element does not exit or it is in a source document which is not
   * loaded yet).
   * @param id Original ID value
   * @param transformedId ID transformed by DocumentURLTransformer to handle a
   *     reference across multiple source documents
   * @param lookForElement If true, look ahead for an element with the ID in the
   *     current source document when such an element has not appeared yet. Do
   *     not set to true during Styler.styleUntil is being called, since in that
   *     case Styler.styleUntil can be called again and may lead to internal
   *     inconsistency.
   */
  private getTargetCounters(
    id: string | null,
    transformedId: string,
    lookForElement: boolean,
  ): CssCascade.CounterValues | null {
    let targetCounters = this.counterStore.countersById[transformedId];
    if (!targetCounters && lookForElement && id) {
      this.styler.styleUntilIdIsReached(id);
      targetCounters = this.counterStore.countersById[transformedId];
    }
    return targetCounters || null;
  }

  /**
   * Returns page-based counter values for an element with the specified ID.
   * Returns null if the element has not been laid out yet.
   * @param transformedId ID transformed by DocumentURLTransformer to handle a
   *     reference across multiple source documents
   */
  private getTargetPageCounters(
    transformedId: string,
  ): CssCascade.CounterValues | null {
    if (this.counterStore.currentPage.elementsById[transformedId]) {
      return this.counterStore.currentPageCounters;
    } else {
      return this.counterStore.pageCountersById[transformedId] || null;
    }
  }

  /**
   * Returns document counter snapshot at the start of the page where the
   * target element was laid out. Returns null if the element has not been
   * laid out yet.
   */
  private getTargetPageDocCounters(
    transformedId: string,
  ): CssCascade.CounterValues | null {
    if (this.counterStore.currentPage.elementsById[transformedId]) {
      return this.counterStore.currentPageDocCounters;
    } else {
      return this.counterStore.pageDocCountersById[transformedId] || null;
    }
  }

  /**
   * Adjust element counter values for cross-scope page-controlled counters.
   * The page counter operates at the outermost scope, so only the first
   * (outermost) counter value is adjusted. Returns the adjusted array.
   */
  private adjustCountersForCrossScope(
    name: string,
    elementCounters: number[],
    pageCounters: CssCascade.CounterValues | null,
    docStartCounters: CssCascade.CounterValues | null,
  ): number[] {
    if (!this.counterStore.isPageControlledCounter(name) || !pageCounters) {
      return elementCounters;
    }
    const pageVals = pageCounters[name] || [];
    const pageVal = pageVals.length ? pageVals.at(-1) : 0;
    const docStartVals = docStartCounters?.[name] || [];
    const docStartVal = docStartVals.length ? docStartVals[0] : 0;
    if (!elementCounters.length) {
      return [pageVal];
    }
    const adjustedFirst = pageVal + (elementCounters[0] - docStartVal);
    return [adjustedFirst, ...elementCounters.slice(1)];
  }

  /**
   * Returns page-based text content for an element with the specified ID.
   * Returns null if the element has not been laid out yet.
   * @param transformedId ID transformed by DocumentURLTransformer to handle a
   *     reference across multiple source documents
   * @param pseudoElement Pseudo-element to extract text from (content, before, after, first-letter, marker)
   */
  private getTargetPageText(
    transformedId: string,
    pseudoElement: string,
  ): string | null {
    if (this.counterStore.currentPage.elementsById[transformedId]) {
      // Element is on current page - extract text for specific pseudo-element
      const elements =
        this.counterStore.currentPage.elementsById[transformedId];
      if (elements && elements.length > 0) {
        const element = elements[0];

        if (
          pseudoElement === "before" ||
          pseudoElement === "after" ||
          pseudoElement === "marker"
        ) {
          return extractPseudoElementText(element, pseudoElement);
        }
        // For content and other pseudo-elements, fall back to content (excluding ::before and ::after)
        return extractPseudoElementText(element, "content");
      }
      return "";
    } else {
      // Check if the ID exists in pageTextById
      // Need to distinguish between "not yet laid out" (undefined) and "empty text" ("")
      if (transformedId in this.counterStore.pageTextById) {
        const textMap = this.counterStore.pageTextById[transformedId];
        return textMap[pseudoElement] !== undefined
          ? textMap[pseudoElement]
          : textMap["content"] || "";
      }
      return null;
    }
  }

  /** @override */
  getTargetCounterVal(
    url: string,
    name: string,
    format: (p1: number | null) => string,
  ): Exprs.Val {
    const id = this.getFragment(url);
    const transformedId = this.getTransformedId(url);

    // Always use a Native expression so the value is resolved at layout time.
    // This ensures page-controlled counters get the cross-scope adjustment
    // (pageControlledCounterNames may not be set during initial styling).
    const expr = new Exprs.Native(
      this.pageScope,
      () => {
        // Since this block is evaluated during layout, lookForElement
        // argument can be set to true.
        const counters = this.getTargetCounters(id, transformedId, true);

        if (counters) {
          if (counters[name]) {
            const countersOfName = counters[name];
            // Apply cross-scope adjustment for page-controlled counters
            const pageCounters = this.getTargetPageCounters(transformedId);
            const docStartCounters =
              this.getTargetPageDocCounters(transformedId);
            const adjusted = this.adjustCountersForCrossScope(
              name,
              countersOfName,
              pageCounters,
              docStartCounters,
            );
            if (pageCounters) {
              this.counterStore.resolveReference(transformedId);
            }
            return format(adjusted.at(-1) || null);
          } else {
            const pageCounters = this.getTargetPageCounters(transformedId);
            if (pageCounters) {
              // The target element has already been laid out.
              this.counterStore.resolveReference(transformedId);

              if (pageCounters[name]) {
                const pageCountersOfName = pageCounters[name];
                return format(pageCountersOfName.at(-1) || null);
              } else {
                // No corresponding counter with the name.
                return format(0);
              }
            } else {
              // The target element has not been laid out yet.
              this.counterStore.saveReferenceOfCurrentPage(
                transformedId,
                false,
              );
              return "??"; // TODO more reasonable placeholder?
            }
          }
        } else {
          // The style of target element has not been calculated yet.
          // (The element is in another source document that is not parsed
          // yet)
          this.counterStore.saveReferenceOfCurrentPage(transformedId, false);
          return "??"; // TODO more reasonable placeholder?
        }
      },
      `target-counter-${name}-of-${url}`,
    );

    this.counterStore.registerTargetCounterExpr(
      name,
      format,
      expr,
      transformedId,
    );
    return expr;
  }

  /** @override */
  getTargetCountersVal(
    url: string,
    name: string,
    format: (p1: number[]) => string,
  ): Exprs.Val {
    const id = this.getFragment(url);
    const transformedId = this.getTransformedId(url);
    return new Exprs.Native(
      this.pageScope,
      () => {
        const pageCounters = this.getTargetPageCounters(transformedId);

        if (!pageCounters) {
          // The target element has not been laid out yet.
          this.counterStore.saveReferenceOfCurrentPage(transformedId, false);
          return "??"; // TODO more reasonable placeholder?
        } else {
          this.counterStore.resolveReference(transformedId);
          const elementCounters = this.getTargetCounters(
            id,
            transformedId,
            true,
          );
          const elementCountersOfName = elementCounters?.[name] || [];
          // Apply cross-scope adjustment for page-controlled counters
          const docStartCounters = this.getTargetPageDocCounters(transformedId);
          const adjusted = this.adjustCountersForCrossScope(
            name,
            elementCountersOfName,
            pageCounters,
            docStartCounters,
          );
          if (adjusted.length) {
            return format(adjusted);
          }
          // Fall back to page-only counters if no element counters
          const pageCountersOfName = pageCounters[name] || [];
          return format(pageCountersOfName);
        }
      },
      `target-counters-${name}-of-${url}`,
    );
  }

  /** @override */
  getTargetTextVal(url: string, pseudoElement: string): Exprs.Val {
    const transformedId = this.getTransformedId(url);

    const expr = new Exprs.Native(
      this.pageScope,
      () => {
        // Handle first-letter separately
        if (pseudoElement === "first-letter") {
          // Respect pseudo-elements
          const beforeText = this.getTargetPageText(transformedId, "before");
          const contentText = this.getTargetPageText(transformedId, "content");
          const afterText = this.getTargetPageText(transformedId, "after");

          // Check if target element has been laid out
          if (
            beforeText === null &&
            contentText === null &&
            afterText === null
          ) {
            this.counterStore.saveReferenceOfCurrentPage(transformedId, false);
            return "??";
          }

          const text =
            (beforeText ?? "") + (contentText ?? "") + (afterText ?? "");
          this.counterStore.resolveReference(transformedId);

          const match = text.match(Base.firstLetterPattern);
          return match ? match[0] : "";
        }

        // For other pseudo-elements, get specific text
        let pageText = this.getTargetPageText(transformedId, pseudoElement);
        if (pageText !== null) {
          // The target element has already been laid out.
          this.counterStore.resolveReference(transformedId);
          return pageText;
        } else {
          // The target element has not been laid out yet.
          this.counterStore.saveReferenceOfCurrentPage(transformedId, false);
          return "??"; // TODO more reasonable placeholder?
        }
      },
      `target-text-${pseudoElement}-of-${url}`,
    );

    this.counterStore.registerTargetTextExpr(
      pseudoElement,
      expr,
      transformedId,
    );
    return expr;
  }

  /**
   * Get value of the CSS string() function
   * https://drafts.csswg.org/css-gcpm-3/#using-named-strings
   */
  getNamedStringVal(name: string, retrievePosition: string): Exprs.Val {
    const native = new Exprs.Native(
      this.pageScope,
      () =>
        this.getRunningValue(this.namedStringValues, name, retrievePosition),
      `named-string-${retrievePosition}-${name}`,
    );
    // Expose the stored content list (when the value contains page-based
    // counters) so ContentPropertyHandler can render the counters as patchable
    // nodes instead of a frozen string (Issue #1997).
    (native as NamedStringNative).getContentList = () =>
      this.getRunningContentList(name, retrievePosition);
    return native;
  }

  /**
   * Get value of the CSS element() function
   * https://drafts.csswg.org/css-gcpm-3/#running-elements
   */
  getRunningElementVal(name: string, retrievePosition: string): Exprs.Val {
    return new Exprs.Native(
      this.pageScope,
      () => this.getRunningValue(this.runningElements, name, retrievePosition),
      `running-element-${retrievePosition}-${name}`,
    );
  }

  private getRunningValue(
    namedRunningValues: NamedRunningValues,
    name: string,
    retrievePosition: string,
  ): string {
    const raw = this.getRunningRawValue(
      namedRunningValues,
      name,
      retrievePosition,
    );
    if (typeof raw.value === "string") {
      return raw.value;
    }
    return this.contentListToString(
      this.resolveDeferredContentList(raw.value, raw.offset),
    );
  }

  /**
   * Get the stored content list for a named string used in the current page,
   * or null when the stored value is a plain string. Used to render page-based
   * counters inside named strings as patchable nodes (Issue #1997).
   */
  getRunningContentList(
    name: string,
    retrievePosition: string,
  ): Css.Val | null {
    const raw = this.getRunningRawValue(
      this.namedStringValues,
      name,
      retrievePosition,
    );
    if (typeof raw.value === "string") {
      return null;
    }
    return this.resolveDeferredContentList(raw.value, raw.offset);
  }

  /**
   * Resolve a stored named-string content list for rendering (Issue #1997).
   *
   * `counter(page)` (and any page-controlled counter other than `pages`) is
   * resolved against the page that actually contains the assignment element
   * (snapshot semantics, looked up by its element offset), but kept as a
   * patchable expression node so cross-spine repagination
   * (`adjustPageCountersOfLaterSpines` + `updatePageCounterNodesInPages`) can
   * update the rendered page number. `counter(pages)` is likewise kept as a
   * patchable expression filled with the final page count later.
   */
  private resolveDeferredContentList(val: Css.Val, offset: number): Css.Val {
    return this.freezePageCounters(val, offset);
  }

  private freezePageCounters(val: Css.Val, offset: number): Css.Val {
    if (val instanceof Css.Expr) {
      const ex = val.expr;
      if (ex instanceof Exprs.Native) {
        const m = /^page-counters?-(.+)$/.exec(ex.str);
        if (m) {
          if (m[1] === "pages") {
            // Total page count: keep as a patchable expression.
            return val;
          }
          // counter(page) (and other page-controlled counters): bind to the
          // assignment-page snapshot but keep it patchable so the rendered
          // page number is updated when later pagination shifts page numbers.
          const store = this.counterStore;
          const counterName = m[1];
          const format =
            store.getPageCounterFormat(ex) ||
            ((arr: number[]) => (arr.length ? String(arr.at(-1)) : ""));
          const patchExpr = store.getOrCreateNamedStringPageCounterExpr(
            this.pageScope,
            offset,
            counterName,
            format,
          );
          return new Css.Expr(patchExpr);
        }
      }
      return val;
    }
    if (val instanceof Css.SpaceList) {
      return new Css.SpaceList(
        val.values.map((v) => this.freezePageCounters(v, offset)),
      );
    }
    if (val instanceof Css.CommaList) {
      return new Css.CommaList(
        val.values.map((v) => this.freezePageCounters(v, offset)),
      );
    }
    return val;
  }

  /**
   * Best-effort conversion of a stored named-string content list to a string.
   * Page-based counters are evaluated against the current page counters; the
   * total page count (`counter(pages)`) is only finalized later by the DOM
   * patching in finishLastPage, so this is used only as a fallback when the
   * value is not rendered through ContentPropertyHandler.
   */
  private contentListToString(val: Css.Val): string {
    if (val instanceof Css.Str) {
      return val.stringValue();
    }
    if (val instanceof Css.Expr) {
      const ex = val.expr;
      if (ex instanceof Exprs.Native) {
        const result = ex.fn.call(null);
        return result == null ? "" : String(result);
      }
      return "";
    }
    if (val instanceof Css.SpaceList) {
      return val.values.map((v) => this.contentListToString(v)).join("");
    }
    if (val instanceof Css.CommaList) {
      return val.values.map((v) => this.contentListToString(v)).join("");
    }
    return "";
  }

  private getRunningRawValue(
    namedRunningValues: NamedRunningValues,
    name: string,
    retrievePosition: string,
  ): { value: string | Css.Val; offset: number } {
    const runningValues = namedRunningValues[name];
    if (!runningValues) {
      return { value: "", offset: -1 };
    }
    const offsets = Object.keys(runningValues)
      .map((a) => parseInt(a, 10))
      .sort(Base.numberCompare);

    const currentPage = this.counterStore.currentPage;
    if (!currentPage) {
      return { value: "", offset: -1 };
    }
    const pageStartOffset = currentPage.isBlankPage
      ? currentPage.offset - 1
      : currentPage.offset;
    const pageLastOffset = currentPage.isBlankPage
      ? pageStartOffset
      : Math.max(
          pageStartOffset,
          ...Array.from(
            currentPage.container.querySelectorAll(
              `[${Base.ELEMENT_OFFSET_ATTR}]`,
            ),
          ).map((e) => parseInt(e.getAttribute(Base.ELEMENT_OFFSET_ATTR), 10)),
        );

    let firstOffset = -1;
    let startOffset = -1;
    let lastOffset = -1;
    let firstExceptOffset = -1;

    for (let i = 0; i < offsets.length; i++) {
      const offset = offsets[i];
      const offsetPrev = i > 0 ? offsets[i - 1] : -1;
      const offsetNext = i < offsets.length - 1 ? offsets[i + 1] : -1;
      if (offset > pageLastOffset) {
        break;
      }
      if (offset >= pageStartOffset) {
        if (firstOffset < 0) {
          firstOffset = offset;
          firstExceptOffset = -1;
        }
        if (startOffset < 0) {
          if (offset === pageStartOffset) {
            startOffset = offset;
          } else {
            if (offsetPrev < firstOffset) {
              startOffset = offsetPrev;
            }
            // Check if the element at the offset is at beginning of the page
            const elementAtOffset = currentPage.container.querySelector(
              `[${Base.ELEMENT_OFFSET_ATTR}="${offset}"]`,
            );
            if (!elementAtOffset) {
              // title or meta elements are not output, but should be treated as start
              if (startOffset < 0) {
                startOffset = offset;
              }
            } else {
              let elementAtPageStartOffset =
                currentPage.container.querySelector(
                  `[${Base.ELEMENT_OFFSET_ATTR}="${pageStartOffset}"]`,
                );
              if (!elementAtPageStartOffset) {
                // The element at pageStartOffset is not found when page break occured
                // within an element, so use the ancestor element with offset 0 instead.
                elementAtPageStartOffset = currentPage.container.querySelector(
                  `[${Base.ELEMENT_OFFSET_ATTR}="0"]`,
                );
              }
              if (elementAtPageStartOffset) {
                // Find if the element at the offset is (the first child of)* the element at page start
                for (
                  let element: Element | null = elementAtPageStartOffset;
                  element;
                  element = element.firstElementChild
                ) {
                  if (element === elementAtOffset) {
                    startOffset = offset;
                    break;
                  }
                }
              }
            }
          }
        }
        lastOffset = offset;
      } else if (offsetNext > pageLastOffset || offsetNext < 0) {
        firstOffset = startOffset = lastOffset = firstExceptOffset = offset;
      }
    }

    const runningValue =
      runningValues[
        {
          first: firstOffset,
          start: startOffset,
          last: lastOffset,
          "first-except": firstExceptOffset,
        }[retrievePosition]
      ] || "";

    return {
      value: runningValue,
      offset: {
        first: firstOffset,
        start: startOffset,
        last: lastOffset,
        "first-except": firstExceptOffset,
      }[retrievePosition],
    };
  }

  /**
   * Set named string for the CSS string-set property
   * https://drafts.csswg.org/css-gcpm-3/#setting-named-strings-the-string-set-pro
   */
  setNamedString(
    name: string,
    stringValue: string | Css.Val,
    elementOffset: number,
  ): void {
    const values =
      this.namedStringValues[name] ||
      (this.namedStringValues[name] = Object.create(null));
    values[elementOffset] = stringValue;
    if (typeof stringValue !== "string") {
      // A deferred content list (contains page-based counters); enable
      // per-page counter snapshotting so the value can be resolved against the
      // page that actually contains the assignment element (Issue #1997).
      this.counterStore.hasDeferredNamedStrings = true;
    }
  }

  /**
   * Set running element
   * https://drafts.csswg.org/css-gcpm-3/#running-elements
   */
  setRunningElement(name: string, elementOffset: number): void {
    const values =
      this.runningElements[name] ||
      (this.runningElements[name] = Object.create(null));
    values[elementOffset] = String(elementOffset);
  }
}

export class CounterStore {
  countersById: { [key: string]: CssCascade.CounterValues } =
    Object.create(null);
  pageCountersById: { [key: string]: CssCascade.CounterValues } =
    Object.create(null);
  pageDocCountersById: { [key: string]: CssCascade.CounterValues } =
    Object.create(null);
  pageTextById: { [key: string]: { [pseudoElement: string]: string } } =
    Object.create(null);
  currentPageDocCounters: CssCascade.CounterValues | null = null;
  previousPageDocCounters: CssCascade.CounterValues | null = null;
  currentPageDocCounterChanges: { [key: string]: boolean } =
    Object.create(null);
  currentPageDocCounterChangeTypes: {
    [key: string]: "reset" | "set" | "increment";
  } = Object.create(null);
  currentPageCounters: CssCascade.CounterValues = Object.create(null);
  previousPageCounters: CssCascade.CounterValues = Object.create(null);
  // Issue #1999: remember the page-counter base from before a page-local
  // override so later pages can resume the inherited sequence.
  pageCountersBeforeOverride: CssCascade.CounterValues = Object.create(null);
  // Issue #1997: per-page snapshot of the page counters, keyed by the page's
  // start element offset, recorded when each page is finished. Used to resolve
  // page-based counters in named strings (string-set) against the page that
  // actually contains the assignment element, regardless of which page first
  // uses the named string.
  hasDeferredNamedStrings = false;
  namedStringPageSnapshots: {
    [startOffset: number]: {
      lastOffset: number;
      spineIndex: number;
      counters: CssCascade.CounterValues;
    };
  } = Object.create(null);
  // Issue #1997: patchable counter(page) expressions used inside named strings,
  // keyed by the expression key. Each reads its value from the assignment-page
  // snapshot (via getPageCountersForOffset) so the rendered running-header page
  // number can be updated when cross-spine repagination shifts page numbers.
  namedStringPageCounterExprMap: {
    [exprKey: string]: {
      expr: Exprs.Val;
      offset: number;
      counterName: string;
      format: (p1: number[]) => string;
    };
  } = Object.create(null);
  currentPageCountersStack: CssCascade.CounterValues[] = [];
  pageIndicesById: {
    [key: string]: { spineIndex: number; pageIndex: number };
  } = Object.create(null);
  currentPage: Vtree.Page | null = null;
  newReferencesOfCurrentPage: TargetCounterReference[] = [];
  referencesToSolve: TargetCounterReference[] = [];
  referencesToSolveStack: TargetCounterReference[][] = [];
  unresolvedReferences: { [key: string]: TargetCounterReference[] } =
    Object.create(null);
  resolvedReferences: { [key: string]: TargetCounterReference[] } =
    Object.create(null);
  private referenceTargetIdsBySourcePage = new Map<
    number,
    Map<number, Set<string>>
  >();
  private targetsMovedEarlierAfterPageBreak = new Set<string>();
  pageControlledCounterNames: { [key: string]: boolean } = Object.assign(
    Object.create(null),
    { page: true },
  );
  private pagesCounterExprs: {
    expr: Exprs.Val;
    format: (p1: number[]) => string;
  }[] = [];
  private pageCounterExprs: {
    expr: Exprs.Val;
    format: (p1: number[]) => string;
  }[] = [];

  private targetCounterExprs: {
    name: string;
    expr: Exprs.Val;
    format: (p1: number) => string;
    transformedId: string;
  }[] = [];

  private targetTextExprs: {
    pseudoElement: string;
    expr: Exprs.Val;
    transformedId: string;
  }[] = [];

  constructor(
    public readonly documentURLTransformer: Base.DocumentURLTransformer,
  ) {
    this.currentPageCounters["page"] = [0];
  }

  createCounterListener(baseURL: string): CssCascade.CounterListener {
    return new CounterListener(this, baseURL);
  }

  createCounterResolver(
    baseURL: string,
    rootScope: Exprs.LexicalScope,
    pageScope: Exprs.LexicalScope,
  ): CssCascade.CounterResolver {
    return new CounterResolver(this, baseURL, rootScope, pageScope);
  }

  setCurrentPage(page: Vtree.Page) {
    this.currentPage = page;
  }

  setCurrentPageDocCounters(
    counters: CssCascade.CounterValues | null,
    changes: string[] | null,
    changeTypes?: { [key: string]: "reset" | "set" | "increment" },
  ) {
    this.previousPageDocCounters = this.currentPageDocCounters
      ? cloneCounterValues(this.currentPageDocCounters)
      : null;
    this.currentPageDocCounters = counters
      ? cloneCounterValues(counters)
      : null;
    this.currentPageDocCounterChanges = Object.create(null);
    this.currentPageDocCounterChangeTypes = changeTypes
      ? { ...changeTypes }
      : Object.create(null);
    if (changes) {
      changes.forEach((name) => {
        this.currentPageDocCounterChanges[name] = true;
      });
    }
  }

  setPageControlledCounterNames(names: string[]) {
    const map: { [key: string]: boolean } = Object.assign(Object.create(null), {
      page: true,
    });
    names.forEach((name) => {
      map[name] = true;
    });
    this.pageControlledCounterNames = map;
  }

  isPageControlledCounter(name: string): boolean {
    return !!this.pageControlledCounterNames[name];
  }

  private definePageCounter(counterName: string, value: number) {
    if (this.currentPageCounters[counterName]) {
      this.currentPageCounters[counterName].push(value);
    } else {
      this.currentPageCounters[counterName] = [value];
    }
  }

  /**
   * Forcefully set the `page` page-based counter to the specified value.
   */
  forceSetPageCounter(pageNumber: number) {
    const counters = this.currentPageCounters["page"];
    if (!counters || !counters.length) {
      this.currentPageCounters["page"] = [pageNumber];
    } else {
      counters[counters.length - 1] = pageNumber;
    }
  }

  /**
   * Update the page-based counters with 'counter-reset' and 'counter-increment'
   * properties within the page context. Call before starting layout of the
   * page.
   */
  updatePageCounters(
    cascadedPageStyle: CssCascade.ElementStyle,
    context: Exprs.Context,
  ) {
    // Save page counters to previousPageCounters before updating
    this.previousPageCounters = cloneCounterValues(this.currentPageCounters);
    // Track document counter changes so page-controlled counters can be
    // advanced from the page-start snapshot without double counting.
    const docChanges = this.currentPageDocCounterChanges || {};
    const docChangeTypes = this.currentPageDocCounterChangeTypes || {};
    const docCounterInfo: {
      [key: string]: { delta: number; reset: boolean; value: number };
    } = Object.create(null);
    if (this.currentPageDocCounters) {
      const prevDocCounters = this.previousPageDocCounters || {};
      for (const counterName in this.currentPageDocCounters) {
        if (!docChanges[counterName]) {
          continue;
        }
        const docCounters = this.currentPageDocCounters[counterName];
        const docVal = docCounters.length ? docCounters.at(-1) : 0;
        const prevDocCountersOfName = prevDocCounters[counterName] || [];
        const prevDocVal = prevDocCountersOfName.length
          ? prevDocCountersOfName.at(-1)
          : 0;
        const delta = docVal - prevDocVal;
        const changeType = docChangeTypes[counterName];
        const isResetOrSet = changeType === "reset" || changeType === "set";
        docCounterInfo[counterName] = {
          delta,
          reset: isResetOrSet,
          value: docVal,
        };
      }
    }
    const skipIncrement: { [key: string]: boolean } = Object.create(null);
    let resetMap: { [key: string]: number } | undefined;
    let resetIsNone = false;
    const reset = cascadedPageStyle["counter-reset"] as CssCascade.CascadeValue;
    if (reset) {
      const resetVal = reset.evaluate(context);
      if (resetVal) {
        resetIsNone = resetVal === Css.ident.none;
        if (!resetIsNone) {
          resetMap = CssProp.toCounters(resetVal, { reset: true });
        }
      }
    }
    if (resetMap && "pages" in resetMap) {
      delete resetMap["pages"];
    }
    let setMap: { [key: string]: number } | undefined;
    const set = cascadedPageStyle["counter-set"] as CssCascade.CascadeValue;
    if (set) {
      const setVal = set.evaluate(context);
      if (setVal) {
        setMap = CssProp.toCounters(setVal, { defaultValue: 0 });
      }
    }
    if (setMap && "pages" in setMap) {
      delete setMap["pages"];
    }
    const pageControlledNames: string[] = [];
    if (resetMap) {
      for (const resetCounterName in resetMap) {
        pageControlledNames.push(resetCounterName);
      }
    }
    if (setMap) {
      for (const setCounterName in setMap) {
        pageControlledNames.push(setCounterName);
      }
    }
    let incrementMap: { [key: string]: number } | undefined;
    const increment = cascadedPageStyle[
      "counter-increment"
    ] as CssCascade.CascadeValue;
    if (increment) {
      const incrementVal = increment.evaluate(context);
      if (incrementVal) {
        incrementMap = CssProp.toCounters(incrementVal);
      }
    }
    if (incrementMap && "pages" in incrementMap) {
      delete incrementMap["pages"];
    }

    // If 'counter-increment' for the builtin 'page' counter is absent, add it
    // with value 1.
    if (incrementMap) {
      if (
        !("page" in incrementMap) &&
        !(docCounterInfo["page"] && docCounterInfo["page"].reset)
      ) {
        incrementMap["page"] = 1;
      }
    } else {
      incrementMap = Object.create(null) as { [key: string]: number };
      if (!(docCounterInfo["page"] && docCounterInfo["page"].reset)) {
        incrementMap["page"] = 1;
      }
    }
    for (const incrementCounterName in incrementMap) {
      pageControlledNames.push(incrementCounterName);
    }
    this.setPageControlledCounterNames(pageControlledNames);
    // Start from previous page counters, then reconcile with document counters
    // so page-scoped and document-scoped counters stay consistent.
    const baseCounters = cloneCounterValues(this.previousPageCounters);
    if (resetIsNone) {
      // Issue #1999: clearing a page-local override must restore the
      // pre-override page-counter base instead of leaking the previous page's
      // overridden value into the next page.
      for (const counterName in this.pageCountersBeforeOverride) {
        baseCounters[counterName] = Array.from(
          this.pageCountersBeforeOverride[counterName],
        );
      }
    }
    if (this.currentPageDocCounters) {
      for (const counterName in this.currentPageDocCounters) {
        if (this.isPageControlledCounter(counterName)) {
          const info = docCounterInfo[counterName];
          if (info) {
            if (info.reset) {
              baseCounters[counterName] = [info.value];
              skipIncrement[counterName] = true;
            } else if (info.delta !== 0) {
              if (!baseCounters[counterName]) {
                baseCounters[counterName] = [0];
              }
              const counterValues = baseCounters[counterName];
              counterValues[counterValues.length - 1] += info.delta;
            }
          } else if (!baseCounters[counterName]) {
            // When a counter first becomes page-controlled, seed it from the
            // inherited document state so the page's own increment starts from
            // the current document value rather than from zero.
            baseCounters[counterName] = Array.from(
              this.currentPageDocCounters[counterName],
            );
          }
          continue;
        }
        baseCounters[counterName] = Array.from(
          this.currentPageDocCounters[counterName],
        );
      }
    }
    this.currentPageCounters = baseCounters;
    const countersBeforeOverride: CssCascade.CounterValues =
      Object.create(null);
    const rememberCounterBase = (counterName: string): void => {
      if (!Object.hasOwn(countersBeforeOverride, counterName)) {
        const counterValues = baseCounters[counterName];
        if (counterValues) {
          countersBeforeOverride[counterName] = Array.from(counterValues);
        }
      }
    };
    if (resetMap) {
      for (const resetCounterName in resetMap) {
        rememberCounterBase(resetCounterName);
        this.definePageCounter(resetCounterName, resetMap[resetCounterName]);
      }
    }
    for (const incrementCounterName in incrementMap) {
      if (skipIncrement[incrementCounterName]) {
        continue;
      }
      if (!this.currentPageCounters[incrementCounterName]) {
        this.definePageCounter(incrementCounterName, 0);
      }
      const counterValues = this.currentPageCounters[incrementCounterName];
      counterValues[counterValues.length - 1] +=
        incrementMap[incrementCounterName];
    }
    if (setMap) {
      // Match the standard counter update order:
      // counter-reset -> counter-increment -> counter-set.
      for (const setCounterName in setMap) {
        rememberCounterBase(setCounterName);
        if (!this.currentPageCounters[setCounterName]) {
          this.definePageCounter(setCounterName, setMap[setCounterName]);
        } else {
          const counterValues = this.currentPageCounters[setCounterName];
          counterValues[counterValues.length - 1] = setMap[setCounterName];
        }
      }
    }
    for (const counterName in countersBeforeOverride) {
      this.pageCountersBeforeOverride[counterName] = Array.from(
        countersBeforeOverride[counterName],
      );
    }
  }

  /**
   * Save current page-based counters values and set them to the values passed
   * in. The saved counter values can be restored by popPageCounters method.
   */
  pushPageCounters(counters: CssCascade.CounterValues) {
    this.currentPageCountersStack.push(this.currentPageCounters);
    this.currentPageCounters = cloneCounterValues(counters);
  }

  /**
   * Restore previously saved page-based counter values.
   */
  popPageCounters() {
    this.currentPageCounters = this.currentPageCountersStack.pop();
  }

  /**
   * Resolve a reference with the specified ID.
   */
  resolveReference(id: string) {
    const unresolvedRefs = this.unresolvedReferences[id];
    let resolvedRefs = this.resolvedReferences[id];
    if (!resolvedRefs) {
      resolvedRefs = this.resolvedReferences[id] = [];
    }
    for (let i = 0; i < this.referencesToSolve.length;) {
      const ref = this.referencesToSolve[i];
      if (ref.targetId === id) {
        ref.resolve();
        this.referencesToSolve.splice(i, 1);
        if (unresolvedRefs) {
          const j = unresolvedRefs.indexOf(ref);
          if (j >= 0) {
            unresolvedRefs.splice(j, 1);
          }
        }
        resolvedRefs.push(ref);
      } else {
        i++;
      }
    }
    // Record the reference at its current source page as well as resolving
    // the old record. A rerender can move generated target-counter()/
    // target-text() content to another page; finishPage replaces the old
    // page's records with these newly observed references.
    this.saveReferenceOfCurrentPage(id, true);
  }

  /**
   * Save a reference appeared in the current page.
   * @param resolved If the reference is already resolved or not.
   */
  saveReferenceOfCurrentPage(id: string, resolved: boolean) {
    if (!this.newReferencesOfCurrentPage.some((ref) => ref.targetId === id)) {
      const ref = new TargetCounterReference(id, resolved);
      this.newReferencesOfCurrentPage.push(ref);
    }
  }

  /**
   * Finish the current page; elements with ID are collected and saved with
   * current page-based counter values internally.
   * @param spineIndex Index of the currently laid out spine item
   * @param pageIndex Index of the currently laid out page in its spine item
   */
  finishPage(spineIndex: number, pageIndex: number) {
    const ids = Object.keys(this.currentPage.elementsById);
    if (ids.length > 0) {
      const currentPageCounters = cloneCounterValues(this.currentPageCounters);
      const currentPageDocCounters = this.currentPageDocCounters
        ? cloneCounterValues(this.currentPageDocCounters)
        : null;
      ids.forEach((id) => {
        this.pageCountersById[id] = currentPageCounters;
        if (currentPageDocCounters) {
          this.pageDocCountersById[id] = currentPageDocCounters;
        }

        // Capture text content for target-text()
        const elements = this.currentPage.elementsById[id];
        if (elements && elements.length > 0) {
          const element = elements[0];
          this.pageTextById[id] = {
            content: extractPseudoElementText(element, "content"),
            before: extractPseudoElementText(element, "before"),
            after: extractPseudoElementText(element, "after"),
            marker: extractPseudoElementText(element, "marker"),
          };
        }

        const oldPageIndex = this.pageIndicesById[id];
        if (oldPageIndex && oldPageIndex.pageIndex < pageIndex) {
          this.unresolveReferences(id);
        }
        this.pageIndicesById[id] = { spineIndex, pageIndex };
      });
    }
    this.discardReferencesFromPage(spineIndex, pageIndex);
    const prevPageCounters = this.previousPageCounters;
    let ref: TargetCounterReference | undefined;
    while ((ref = this.newReferencesOfCurrentPage.shift())) {
      ref.pageCounters = prevPageCounters;
      ref.spineIndex = spineIndex;
      ref.pageIndex = pageIndex;
      let arr: TargetCounterReference[];
      if (ref.isResolved()) {
        arr = this.resolvedReferences[ref.targetId];
        if (!arr) {
          arr = this.resolvedReferences[ref.targetId] = [];
        }
      } else {
        arr = this.unresolvedReferences[ref.targetId];
        if (!arr) {
          arr = this.unresolvedReferences[ref.targetId] = [];
        }
      }
      if (arr.every((r) => !ref.equals(r))) {
        arr.push(ref);
      }
      let targetIdsByPage = this.referenceTargetIdsBySourcePage.get(spineIndex);
      if (!targetIdsByPage) {
        targetIdsByPage = new Map();
        this.referenceTargetIdsBySourcePage.set(spineIndex, targetIdsByPage);
      }
      let targetIds = targetIdsByPage.get(pageIndex);
      if (!targetIds) {
        targetIds = new Set();
        targetIdsByPage.set(pageIndex, targetIds);
      }
      targetIds.add(ref.targetId);
    }
    if (this.hasDeferredNamedStrings && this.currentPage) {
      this.recordNamedStringPageSnapshot(spineIndex);
    }
    this.currentPage = null;
  }

  discardReferencesFromPage(spineIndex: number, pageIndex: number): void {
    const targetIdsByPage = this.referenceTargetIdsBySourcePage.get(spineIndex);
    const targetIds = targetIdsByPage?.get(pageIndex);
    if (!targetIds) {
      return;
    }
    const keepOtherPage = (ref: TargetCounterReference) =>
      ref.spineIndex !== spineIndex || ref.pageIndex !== pageIndex;
    for (const id of targetIds) {
      this.retainReferences(id, keepOtherPage);
    }
    this.referencesToSolve = this.referencesToSolve.filter(keepOtherPage);
    this.referencesToSolveStack = this.referencesToSolveStack.map((refs) =>
      refs.filter(keepOtherPage),
    );
    targetIdsByPage.delete(pageIndex);
    if (targetIdsByPage.size === 0) {
      this.referenceTargetIdsBySourcePage.delete(spineIndex);
    }
  }

  /**
   * Keep only the resolved/unresolved references of the target that satisfy
   * the given predicate, removing the arrays entirely when they become empty.
   */
  private retainReferences(
    id: string,
    keep: (ref: TargetCounterReference) => boolean,
  ): void {
    const resolved = (this.resolvedReferences[id] || []).filter(keep);
    const unresolved = (this.unresolvedReferences[id] || []).filter(keep);
    if (resolved.length) {
      this.resolvedReferences[id] = resolved;
    } else {
      delete this.resolvedReferences[id];
    }
    if (unresolved.length) {
      this.unresolvedReferences[id] = unresolved;
    } else {
      delete this.unresolvedReferences[id];
    }
  }

  isReferenceTracked(ref: TargetCounterReference): boolean {
    return (
      (this.resolvedReferences[ref.targetId] || []).includes(ref) ||
      (this.unresolvedReferences[ref.targetId] || []).includes(ref)
    );
  }

  /**
   * Record a snapshot of the current page counters keyed by the page's element
   * offset range, so page-based counters in named strings (string-set) can be
   * resolved against the page that contains the assignment element (Issue
   * #1997). Re-finishing a page (relayout) overwrites the previous snapshot.
   * The spine index is stored so the snapshot can be shifted together with
   * pageCountersById when a preceding spine's page count changes (see
   * adjustPageCountersOfLaterSpines).
   */
  private recordNamedStringPageSnapshot(spineIndex: number) {
    const page = this.currentPage;
    const startOffset = page.isBlankPage ? page.offset - 1 : page.offset;
    const lastOffset = page.isBlankPage
      ? startOffset
      : Math.max(
          startOffset,
          ...Array.from(
            page.container.querySelectorAll(`[${Base.ELEMENT_OFFSET_ATTR}]`),
          ).map((e) => parseInt(e.getAttribute(Base.ELEMENT_OFFSET_ATTR), 10)),
        );
    // Repagination (e.g. after target-text/TOC expansion) can change page
    // boundaries, so a previously recorded snapshot may now span a different
    // offset range. Drop only stale entries that start at/after the new page's
    // start offset (i.e. later pages) so getPageCountersForOffset never matches
    // an outdated later-page snapshot. Earlier-starting snapshots are kept: the
    // same element offset can legitimately appear on multiple consecutive pages
    // (a fragmented element, or a blank page using offset-1), and in that case
    // the earlier page's snapshot must remain the one returned so counter(page)
    // freezes to the assignment page (Issue #1997).
    for (const key of Object.keys(this.namedStringPageSnapshots)) {
      const existingStart = parseInt(key, 10);
      if (existingStart <= startOffset) continue;
      const existing = this.namedStringPageSnapshots[existingStart];
      if (existingStart <= lastOffset && startOffset <= existing.lastOffset) {
        delete this.namedStringPageSnapshots[existingStart];
      }
    }
    this.namedStringPageSnapshots[startOffset] = {
      lastOffset,
      spineIndex,
      counters: cloneCounterValues(this.currentPageCounters),
    };
  }

  /**
   * Return the page counters captured for the finished page whose element
   * offset range contains the given offset, or null when no such page has been
   * finished yet (Issue #1997).
   */
  getPageCountersForOffset(offset: number): CssCascade.CounterValues | null {
    // Snapshot keys are numeric page start offsets; Object.keys returns them in
    // ascending order, so once a page starts after the target offset no later
    // page can contain it.
    for (const key of Object.keys(this.namedStringPageSnapshots)) {
      const startOffset = parseInt(key, 10);
      if (startOffset > offset) {
        break;
      }
      const snap = this.namedStringPageSnapshots[startOffset];
      if (offset <= snap.lastOffset) {
        return snap.counters;
      }
    }
    return null;
  }

  /**
   * Adjust page counter snapshots for elements in spines after the specified
   * spine. Called when a preceding spine's page count changes (e.g. TOC
   * expands after target-text resolution), shifting all subsequent pages.
   */
  adjustPageCountersOfLaterSpines(
    expandedSpineIndex: number,
    pageDelta: number,
  ): void {
    if (pageDelta <= 0) return;
    // Multiple IDs on the same page share the same counter object reference
    // (assigned in finishPage). Use a Set to avoid adjusting the same object
    // multiple times.
    const adjusted = new Set<CssCascade.CounterValues>();
    for (const id of Object.keys(this.pageIndicesById)) {
      const idx = this.pageIndicesById[id];
      if (idx.spineIndex > expandedSpineIndex) {
        const counters = this.pageCountersById[id];
        if (counters && counters["page"] && !adjusted.has(counters)) {
          adjusted.add(counters);
          counters["page"] = counters["page"].map((v) => v + pageDelta);
        }
      }
    }
    // Issue #1997: keep named-string page snapshots (used to freeze
    // counter(page) for deferred named strings) in sync with the shifted page
    // numbers so running headers assigned in later spines stay correct.
    for (const key of Object.keys(this.namedStringPageSnapshots)) {
      const snap = this.namedStringPageSnapshots[parseInt(key, 10)];
      if (
        snap.spineIndex > expandedSpineIndex &&
        snap.counters["page"] &&
        !adjusted.has(snap.counters)
      ) {
        adjusted.add(snap.counters);
        snap.counters["page"] = snap.counters["page"].map((v) => v + pageDelta);
      }
    }
  }

  /**
   * Drop references whose source page belongs to spine items that are about to
   * be rebuilt, and invalidate target snapshots owned by that suffix. Retain
   * pageIndicesById so unresolved forward references can still locate and
   * render their targets while the suffix is reconstructed.
   */
  discardReferencesFromSpine(firstSpineIndex: number): void {
    const targetIds = new Set([
      ...Object.keys(this.resolvedReferences),
      ...Object.keys(this.unresolvedReferences),
    ]);

    const keepEarlierSource = (ref: TargetCounterReference) =>
      ref.spineIndex < firstSpineIndex;
    for (const id of targetIds) {
      this.retainReferences(id, keepEarlierSource);
    }

    for (const id of Object.keys(this.pageIndicesById)) {
      if (this.pageIndicesById[id].spineIndex >= firstSpineIndex) {
        delete this.pageCountersById[id];
        delete this.pageDocCountersById[id];
        delete this.pageTextById[id];
      }
    }

    for (const key of Object.keys(this.namedStringPageSnapshots)) {
      const snapshot = this.namedStringPageSnapshots[parseInt(key, 10)];
      if (snapshot.spineIndex >= firstSpineIndex) {
        delete this.namedStringPageSnapshots[parseInt(key, 10)];
      }
    }

    for (const spineIndex of this.referenceTargetIdsBySourcePage.keys()) {
      if (spineIndex >= firstSpineIndex) {
        this.referenceTargetIdsBySourcePage.delete(spineIndex);
      }
    }

    this.newReferencesOfCurrentPage =
      this.newReferencesOfCurrentPage.filter(keepEarlierSource);
    this.referencesToSolve = this.referencesToSolve.filter(keepEarlierSource);
    this.referencesToSolveStack = this.referencesToSolveStack.map((refs) =>
      refs.filter(keepEarlierSource),
    );
  }

  /**
   * Walk through target-counter DOM nodes in the given page containers and
   * update their text content from the current pageCountersById snapshots.
   */
  updateTargetCounterNodesInPages(
    pages: Vtree.Page[],
    changedTargetIds?: Set<string>,
  ): Set<Vtree.Page> {
    return this.updateGeneratedContentNodesInPages(
      pages,
      TARGET_COUNTER_ATTR,
      (key) => {
        const expr = this.targetCounterExprs.find((o) => o.expr.key === key);
        if (!expr || !expr.transformedId) {
          return null;
        }
        const arr: number[] | undefined =
          this.pageCountersById[expr.transformedId]?.[expr.name];
        if (!arr) {
          return null;
        }
        return {
          id: expr.transformedId,
          value: expr.format(arr.at(-1)),
        };
      },
      changedTargetIds,
    );
  }

  /**
   * Update target-text() nodes retained outside a rebuilt spine suffix.
   */
  updateTargetTextNodesInPages(
    pages: Vtree.Page[],
    changedTargetIds?: Set<string>,
  ): Set<Vtree.Page> {
    return this.updateGeneratedContentNodesInPages(
      pages,
      TARGET_TEXT_ATTR,
      (key) => {
        const expr = this.targetTextExprs.find((o) => o.expr.key === key);
        if (!expr || !expr.transformedId) {
          return null;
        }
        const text = this.pageTextById[expr.transformedId];
        if (!text) {
          return null;
        }
        let value: string;
        if (expr.pseudoElement === "first-letter") {
          const fullText =
            (text.before ?? "") + (text.content ?? "") + (text.after ?? "");
          value = fullText.match(Base.firstLetterPattern)?.[0] ?? "";
        } else {
          value = text[expr.pseudoElement] ?? "";
        }
        return { id: expr.transformedId, value };
      },
      changedTargetIds,
    );
  }

  /**
   * Shared walker for patching generated-content nodes (target-counter/
   * target-text) in retained pages from the current target snapshots.
   */
  private updateGeneratedContentNodesInPages(
    pages: Vtree.Page[],
    attrName: string,
    resolveValue: (key: string | null) => { id: string; value: string } | null,
    changedTargetIds?: Set<string>,
  ): Set<Vtree.Page> {
    const changedPages = new Set<Vtree.Page>();
    for (const page of pages) {
      if (!page || !page.container) continue;
      const nodes = page.container.querySelectorAll(`[${attrName}]`);
      for (const node of nodes) {
        const resolved = resolveValue(node.getAttribute(attrName));
        if (resolved && node.textContent !== resolved.value) {
          node.textContent = resolved.value;
          changedPages.add(page);
          changedTargetIds?.add(resolved.id);
        }
      }
    }
    return changedPages;
  }

  /**
   * Resolve page-level counter values for a page.
   *
   * Prefer an explicit per-page snapshot when one is supplied. Otherwise fall
   * back to looking up tracked element IDs on the page via pageCountersById.
   *
   * Note: explicitCounters are pageCounterStarts (pre-increment snapshots),
   * while pageCountersById stores post-increment values. When using
   * explicitCounters as a fallback, the caller should be aware of this
   * distinction. For the "page" counter the difference is +1, but this
   * method returns whichever snapshot it finds without adjustment.
   */
  private getPageCountersForPage(
    page: Vtree.Page,
    explicitCounters?: CssCascade.CounterValues | null,
  ): CssCascade.CounterValues | null {
    // First try pageCountersById (post-render values) via any tracked element
    const elementIds = Object.keys(page.elementsById);
    for (const elementId of elementIds) {
      const counters = this.pageCountersById[elementId];
      if (counters) {
        return counters;
      }
    }
    // Fall back to explicit per-page counters (e.g. pageCounterStarts)
    if (explicitCounters) {
      return explicitCounters;
    }
    return null;
  }

  /**
   * Walk through page-counter DOM nodes in the given page containers and
   * update their text content from the adjusted pageCountersById snapshots.
   * Called after adjustPageCountersOfLaterSpines has shifted the counters.
   *
   * When available, pass explicit per-page counter snapshots aligned with the
   * given pages so pages without tracked element IDs are also updated.
   */
  updatePageCounterNodesInPages(
    pages: Vtree.Page[],
    pageCountersByPage?: Array<CssCascade.CounterValues | null>,
  ): void {
    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      if (!page?.container) continue;

      // Issue #1997: patch counter(page) nodes inside named strings from the
      // assignment-page snapshot (which adjustPageCountersOfLaterSpines has
      // already shifted), independent of this page's own page counters.
      const nsNodes = page.container.querySelectorAll(
        `[${NAMED_STRING_PAGE_COUNTER_ATTR}]`,
      );
      for (const node of nsNodes) {
        const key = node.getAttribute(NAMED_STRING_PAGE_COUNTER_ATTR);
        const entry = this.namedStringPageCounterExprMap[key];
        if (!entry) continue;
        const counters = this.getPageCountersForOffset(entry.offset);
        const values = counters?.[entry.counterName];
        if (values) {
          node.textContent = entry.format(values);
        }
      }

      const counters = this.getPageCountersForPage(
        page,
        pageCountersByPage?.[i],
      );
      if (!counters) continue;

      const nodes = page.container.querySelectorAll(`[${PAGE_COUNTER_ATTR}]`);
      for (const node of nodes) {
        const key = node.getAttribute(PAGE_COUNTER_ATTR);
        const counterExpr = this.pageCounterExprs.find(
          (o) => o.expr.key === key,
        );
        if (!counterExpr) continue;
        const str = (counterExpr.expr as Exprs.Native)?.str;
        const counterName = str?.replace(/^page-counters?-/, "");
        const counterValues = counters[counterName];
        if (counterValues) {
          node.textContent = counterExpr.format(counterValues);
        }
      }
    }
  }

  /**
   * Returns unresolved references pointing to the specified page.
   */
  getUnresolvedRefsToPage(page: Vtree.Page): {
    spineIndex: number;
    pageIndex: number;
    pageCounters: CssCascade.CounterValues | null;
    refs: TargetCounterReference[];
  }[] {
    let refs: TargetCounterReference[] = [];
    const ids = Object.keys(page.elementsById);
    ids.forEach((id) => {
      const idRefs = this.unresolvedReferences[id];
      if (idRefs) {
        refs = refs.concat(idRefs);
      }
    });
    refs.sort(
      (r1, r2) => r1.spineIndex - r2.spineIndex || r1.pageIndex - r2.pageIndex,
    );
    const result: {
      spineIndex: number;
      pageIndex: number;
      pageCounters: CssCascade.CounterValues | null;
      refs: TargetCounterReference[];
    }[] = [];
    let o: {
      spineIndex: number;
      pageIndex: number;
      pageCounters: CssCascade.CounterValues | null;
      refs: TargetCounterReference[];
    } | null = null;
    refs.forEach((ref) => {
      if (
        !o ||
        o.spineIndex !== ref.spineIndex ||
        o.pageIndex !== ref.pageIndex
      ) {
        o = {
          spineIndex: ref.spineIndex,
          pageIndex: ref.pageIndex,
          pageCounters: ref.pageCounters,
          refs: [ref],
        };
        result.push(o);
      } else {
        o.refs.push(ref);
      }
    });
    return result;
  }

  /**
   * Save current references to solve and set them to the values passed in.
   * The saved references can be restored by popReferencesToSolve method.
   */
  pushReferencesToSolve(refs: TargetCounterReference[]) {
    this.referencesToSolveStack.push(this.referencesToSolve);
    this.referencesToSolve = refs;
  }

  /**
   * Restore previously saved references to solve.
   */
  popReferencesToSolve() {
    this.referencesToSolve = this.referencesToSolveStack.pop();
  }

  registerPageCounterExpr(
    name: string,
    format: (p1: number[]) => string,
    expr: Exprs.Val,
  ) {
    if (name === "pages") {
      this.pagesCounterExprs.push({ expr, format });
    } else {
      this.pageCounterExprs.push({ expr, format });
    }
  }

  /**
   * Return the format function registered for a page-counter expression, or
   * null if it is not a registered page counter (Issue #1997).
   */
  getPageCounterFormat(expr: Exprs.Val): ((p1: number[]) => string) | null {
    const found = this.pageCounterExprs.find((o) => o.expr === expr);
    return found ? found.format : null;
  }

  /**
   * Get (or lazily create) a patchable expression for a counter(page) used
   * inside a named string assigned at the given element offset. The expression
   * reads its value from the assignment-page snapshot so it stays correct after
   * cross-spine repagination shifts page numbers (Issue #1997). The same
   * (offset, counterName) pair always reuses the same expression to avoid
   * unbounded growth across margin-box re-renders.
   */
  getOrCreateNamedStringPageCounterExpr(
    pageScope: Exprs.LexicalScope,
    offset: number,
    counterName: string,
    format: (p1: number[]) => string,
  ): Exprs.Val {
    for (const key in this.namedStringPageCounterExprMap) {
      const entry = this.namedStringPageCounterExprMap[key];
      if (entry.offset === offset && entry.counterName === counterName) {
        return entry.expr;
      }
    }
    const expr = new Exprs.Native(
      pageScope,
      () => {
        const counters =
          offset >= 0 ? this.getPageCountersForOffset(offset) : null;
        const values =
          (counters || this.currentPageCounters)[counterName] || [];
        return format(values);
      },
      `named-string-page-counter-${counterName}`,
    );
    this.namedStringPageCounterExprMap[expr.key] = {
      expr,
      offset,
      counterName,
      format,
    };
    return expr;
  }
  registerTargetCounterExpr(
    name: string,
    format: (p1: number) => string,
    expr: Exprs.Val,
    transformedId: string,
  ) {
    this.targetCounterExprs.push({ name, expr, format, transformedId });
  }

  registerTargetTextExpr(
    pseudoElement: string,
    expr: Exprs.Val,
    transformedId: string,
  ) {
    this.targetTextExprs.push({ pseudoElement, expr, transformedId });
  }

  getExprContentListener(): Vtree.ExprContentListener {
    return this.exprContentListener.bind(this);
  }

  private exprContentListener(
    expr: Exprs.Val,
    val: string,
    document: Document,
  ) {
    if (expr instanceof Exprs.Native) {
      if (expr.str == "viv-leader") {
        const node = document.createElementNS(Base.NS.XHTML, "span");
        node.textContent = val;
        node.setAttribute("data-viv-leader", expr.key);
        node.setAttribute("data-viv-leader-value", val);
        return node;
      } else if (expr.str.startsWith("running-element-")) {
        const elemList =
          val &&
          document.querySelectorAll(`[${Base.ELEMENT_OFFSET_ATTR}="${val}"]`);
        if (!elemList || elemList.length === 0) {
          return null;
        }
        const lastElem = elemList[elemList.length - 1];
        const clonedElem = lastElem.cloneNode(true) as HTMLElement;
        this.fixPageCounterInRunningElement(clonedElem);
        clonedElem.style.position = "";
        clonedElem.style.visibility = "";
        return clonedElem;
      } else if (expr.str.startsWith("target-counter-")) {
        const node = document.createElementNS(Base.NS.XHTML, "span");
        node.textContent = val;
        node.setAttribute(TARGET_COUNTER_ATTR, expr.key);
        return node;
      } else if (expr.str.startsWith("target-text-")) {
        const node = document.createElementNS(Base.NS.XHTML, "span");
        node.textContent = val;
        node.setAttribute(TARGET_TEXT_ATTR, expr.key);
        return node;
      } else if (expr.str.startsWith("named-string-page-counter-")) {
        // counter(page) inside a named string (Issue #1997): render as a
        // patchable span so cross-spine repagination can update its value.
        const node = document.createElementNS(Base.NS.XHTML, "span");
        node.textContent = val;
        node.setAttribute(NAMED_STRING_PAGE_COUNTER_ATTR, expr.key);
        return node;
      }
    }

    const foundPagesCounter =
      this.pagesCounterExprs.findIndex((o) => o.expr === expr) >= 0;
    const foundPageCounter =
      !foundPagesCounter &&
      this.pageCounterExprs.findIndex((o) => o.expr === expr) >= 0;

    if (foundPagesCounter || foundPageCounter) {
      const node = document.createElementNS(Base.NS.XHTML, "span");
      node.textContent = val;
      node.setAttribute(
        foundPagesCounter ? PAGES_COUNTER_ATTR : PAGE_COUNTER_ATTR,
        expr.key,
      );
      return node;
    } else {
      return null;
    }
  }

  private fixPageCounterInRunningElement(runningElem: Element): void {
    const nodes = runningElem.querySelectorAll(`[${PAGE_COUNTER_ATTR}]`);
    for (const node of nodes) {
      const key = node.getAttribute(PAGE_COUNTER_ATTR);
      const counterExpr = this.pageCounterExprs.find((o) => o.expr.key === key);
      const str = (counterExpr?.expr as Exprs.Native).str;
      const counterName = str?.replace(/^page-counters?-/, "");
      const counterValues = this.currentPageCounters[counterName];
      if (counterValues) {
        node.textContent = counterExpr.format(counterValues);
      }
    }
    const targetNodes = runningElem.querySelectorAll(
      `[${TARGET_COUNTER_ATTR}]`,
    );

    for (const node of targetNodes) {
      node.setAttribute(TARGET_COUNTER_IN_RUNNING_ATTR, true);
    }

    const targetTextNodes = runningElem.querySelectorAll(
      `[${TARGET_TEXT_ATTR}]`,
    );

    for (const node of targetTextNodes) {
      node.setAttribute(TARGET_TEXT_IN_RUNNING_ATTR, true);
    }
  }

  finishLastPage(viewport: Vgen.Viewport) {
    const nodes = viewport.root.querySelectorAll(`[${PAGES_COUNTER_ATTR}]`);
    const pages = viewport.contentContainer.childElementCount;
    for (const node of nodes) {
      const key = node.getAttribute(PAGES_COUNTER_ATTR);
      const i = this.pagesCounterExprs.findIndex((o) => o.expr.key === key);
      Asserts.assert(i >= 0);
      node.textContent = this.pagesCounterExprs[i].format([pages]);
    }

    const runningNodes = viewport.root.querySelectorAll(
      `[${TARGET_COUNTER_IN_RUNNING_ATTR}]`,
    );

    for (const node of runningNodes) {
      const key = node.getAttribute(TARGET_COUNTER_ATTR);
      const expr = this.targetCounterExprs.find((o) => o.expr.key === key);
      if (expr && expr.transformedId) {
        const counterValue = this.pageCountersById[expr.transformedId];
        if (counterValue) {
          const arr: number[] = counterValue[expr.name];
          if (arr) {
            node.textContent = expr.format(arr.at(-1));
          }
        }
      }
    }

    const runningTextNodes = viewport.root.querySelectorAll(
      `[${TARGET_TEXT_IN_RUNNING_ATTR}]`,
    );

    for (const node of runningTextNodes) {
      const key = node.getAttribute(TARGET_TEXT_ATTR);
      const expr = this.targetTextExprs.find((o) => o.expr.key === key);
      if (expr && expr.transformedId) {
        const text = this.pageTextById[expr.transformedId];
        if (text) {
          node.textContent = text[expr.pseudoElement] ?? "";
        }
      }
    }
  }

  createLayoutConstraint(pageIndex: number): Layout.LayoutConstraint {
    return new LayoutConstraint(this, pageIndex);
  }

  moveTargetEarlierAfterPageBreak(id: string, pageIndex: number): boolean {
    const oldPageIndex = this.pageIndicesById[id];
    if (!oldPageIndex || pageIndex >= oldPageIndex.pageIndex) {
      return true;
    }
    // Keep the anti-oscillation guarantee introduced by b0288a35: a target
    // gets one earlier-page correction for a break that has already been
    // satisfied, but cannot repeatedly alternate between earlier and later
    // pages. Commit the correction at the point it is accepted so subsequent
    // constraint checks use the new position instead of retrying indefinitely.
    if (this.targetsMovedEarlierAfterPageBreak.has(id)) {
      return false;
    }
    this.targetsMovedEarlierAfterPageBreak.add(id);
    this.pageIndicesById[id] = { ...oldPageIndex, pageIndex };
    this.unresolveReferences(id);
    return true;
  }

  unresolveReferencesForTargets(targetIds: Iterable<string>): void {
    for (const id of targetIds) {
      this.unresolveReferences(id);
    }
  }

  private unresolveReferences(id: string): void {
    const resolvedRefs = this.resolvedReferences[id];
    if (!resolvedRefs) {
      return;
    }
    let unresolvedRefs = this.unresolvedReferences[id];
    if (!unresolvedRefs) {
      unresolvedRefs = this.unresolvedReferences[id] = [];
    }
    let ref: TargetCounterReference | undefined;
    while ((ref = resolvedRefs.shift())) {
      ref.unresolve();
      unresolvedRefs.push(ref);
    }
  }
}

export const PAGES_COUNTER_ATTR = "data-vivliostyle-pages-counter";
export const PAGE_COUNTER_ATTR = "data-vivliostyle-page-counter";
// Issue #1997: marks a counter(page) node rendered inside a named string, so
// it is patched from the assignment-page snapshot (not the running header's
// own page) when page numbers shift after cross-spine repagination.
export const NAMED_STRING_PAGE_COUNTER_ATTR =
  "data-vivliostyle-named-string-page-counter";
export const TARGET_COUNTER_ATTR = "data-vivliostyle-target-counter";
export const TARGET_TEXT_ATTR = "data-vivliostyle-target-text";

export const TARGET_COUNTER_IN_RUNNING_ATTR =
  "data-vivliostyle-target-counter-in-running";
export const TARGET_TEXT_IN_RUNNING_ATTR =
  "data-vivliostyle-target-text-in-running";

class LayoutConstraint implements Layout.LayoutConstraint {
  constructor(
    public readonly counterStore: CounterStore,
    public readonly pageIndex: number,
  ) {}

  /** @override */
  allowLayoutAfterPageBreak(nodeContext: Vtree.NodeContext): boolean {
    if (this.allowLayout(nodeContext)) {
      return true;
    }
    const id = this.getReferencedTargetId(nodeContext);
    return (
      !!id &&
      this.counterStore.moveTargetEarlierAfterPageBreak(id, this.pageIndex)
    );
  }

  allowLayout(nodeContext: Vtree.NodeContext): boolean {
    const id = this.getReferencedTargetId(nodeContext);
    if (!id) {
      return true;
    }
    const pageIndex = this.counterStore.pageIndicesById[id];
    if (!pageIndex) {
      return true;
    }
    return this.pageIndex >= pageIndex.pageIndex;
  }

  private getReferencedTargetId(nodeContext: Vtree.NodeContext): string | null {
    if (!nodeContext || nodeContext.after) {
      return null;
    }
    const viewNode = nodeContext.viewNode;
    if (!viewNode || viewNode.nodeType !== 1) {
      return null;
    }
    const id =
      (viewNode as Element).getAttribute("data-vivliostyle-id") ||
      (viewNode as Element).getAttribute("id") ||
      (viewNode as Element).getAttribute("name");
    if (!id) {
      return null;
    }
    if (
      !this.counterStore.resolvedReferences[id] &&
      !this.counterStore.unresolvedReferences[id]
    ) {
      return null;
    }
    return id;
  }
}
