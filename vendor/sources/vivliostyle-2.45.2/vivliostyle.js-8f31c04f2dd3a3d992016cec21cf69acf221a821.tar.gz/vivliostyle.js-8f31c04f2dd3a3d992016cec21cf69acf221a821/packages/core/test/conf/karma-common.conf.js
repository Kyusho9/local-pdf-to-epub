/**
 * Copyright 2017 Daishinsha Inc.
 * Copyright 2019 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 */
/*eslint-env node */

const webpack = require("webpack");

// Preserve karma-webpack 4's per-entry module isolation for a simpler migration to Webpack 5.
class IsolateTestEntriesPlugin {
  apply(compiler) {
    compiler.options.optimization.runtimeChunk = false;
    compiler.options.optimization.splitChunks = false;
    compiler.options.optimization.usedExports = false;
  }
}
var testFiles = [
  "test/util/dom.js",
  "test/util/matchers.js",
  // "test/util/mock/vivliostyle/logging-mock.js",
  // "test/util/mock/vivliostyle/plugin-mock.js",
  "test/spec/**/*.js",
  // "plugins/*/test/spec/**/*.js"
];

module.exports = function (config) {
  return {
    basePath: "../..",
    frameworks: ["jasmine", "webpack"],
    files: testFiles,
    preprocessors: {
      "test/{util,spec}/**/*.js": ["webpack", "sourcemap"],
    },
    webpack: {
      mode:
        process.env.NODE_ENV === "production" ? "production" : "development",
      devtool: "inline-source-map",
      stats: "errors-warnings",
      resolve: {
        extensions: [".ts", ".js"],
      },
      module: {
        rules: [
          {
            test: /\.ts$/,
            loader: "ts-loader",
          },
          {
            test: /\.(css|txt|xml)$/,
            type: "asset/source",
          },
        ],
      },
      plugins: [
        new IsolateTestEntriesPlugin(),
        new webpack.DefinePlugin({
          VIVLIOSTYLE_DEBUG: JSON.stringify(
            process.env.NODE_ENV !== "production",
          ),
        }),
      ],
    },
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    webpackMiddleware: {
      stats: "errors-warnings",
    },
  };
};
