/**
 * Copyright 2017 Daishinsha Inc.
 * Copyright 2026 Vivliostyle Foundation
 *
 * Vivliostyle.js is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Vivliostyle.js is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with Vivliostyle.js.  If not, see <http://www.gnu.org/licenses/>.
 */

import * as adapt_csscasc from "../../../src/vivliostyle/css-cascade";
import * as adapt_css from "../../../src/vivliostyle/css";
import * as adapt_exprs from "../../../src/vivliostyle/exprs";
import * as adapt_cssparse from "../../../src/vivliostyle/css-parser";
import * as adapt_cssvalid from "../../../src/vivliostyle/css-validator";
import * as adapt_task from "../../../src/vivliostyle/task";
import * as vivliostyle_logging from "../../../src/vivliostyle/logging";

describe("css-validator", function () {
  function cascadeParserHandler(validatorSet) {
    const scope = new adapt_exprs.LexicalScope(null);
    const dispatchHandler = new adapt_cssparse.DispatchParserHandler(
      scope,
      (owner) =>
        new adapt_csscasc.CascadeParserHandler(
          scope,
          owner,
          null,
          null,
          null,
          validatorSet,
          null,
        ),
    );
    return dispatchHandler.initialSlave;
  }

  function parseCascade(cssText, done, callback) {
    var handler = cascadeParserHandler(adapt_cssvalid.baseValidatorSet());
    handler.owner.startStylesheet(adapt_cssparse.StylesheetFlavor.AUTHOR);
    adapt_task.start(function () {
      adapt_cssparse
        .parseStylesheetFromText(cssText, handler.owner, null, null, null)
        .then(function (result) {
          expect(result).toBe(true);
          callback(handler.finish(), handler);
          done();
        });
      return adapt_task.newResult(true);
    });
  }

  describe("background shorthand regression", function () {
    it("keeps color in cascade for a semicolonless declaration", function (done) {
      parseCascade("h1 { color: blue }", done, function (cascade) {
        expect(cascade.tags.get("h1")).toBeDefined();
        expect(cascade.tags.get("h1").style.color).toBeDefined();
      });
    });

    it("keeps background-color in cascade for a semicolonless declaration", function (done) {
      parseCascade("ul { background: green }", done, function (cascade) {
        expect(cascade.tags.get("ul")).toBeDefined();
        expect(cascade.tags.get("ul").style["background-color"]).toBeDefined();
      });
    });

    it("keeps background-color in cascade when semicolonless declarations precede nested rules", function (done) {
      parseCascade(
        "ul { background: green } li:has(strong) { display: none; :has(> &) { background: red; } }",
        done,
        function (cascade) {
          expect(cascade.tags.get("ul")).toBeDefined();
          expect(
            cascade.tags.get("ul").style["background-color"],
          ).toBeDefined();
        },
      );
    });
  });

  describe("browser shorthand expansion", function () {
    it("expands place-items into longhands", function (done) {
      parseCascade(
        "div { place-items: center start; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["align-items"]).toBeDefined();
          expect(cascade.tags.get("div").style["justify-items"]).toBeDefined();
          expect(
            cascade.tags.get("div").style["align-items"].value.toString(),
          ).toBe("center");
          expect(
            cascade.tags.get("div").style["justify-items"].value.toString(),
          ).toBe("start");
        },
      );
    });

    it("preserves cascade order when longhands override browser shorthand expansion", function (done) {
      parseCascade(
        "div { place-items: center start; justify-items: stretch; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["align-items"]).toBeDefined();
          expect(cascade.tags.get("div").style["justify-items"]).toBeDefined();
          expect(
            cascade.tags.get("div").style["align-items"].value.toString(),
          ).toBe("center");
          expect(
            cascade.tags.get("div").style["justify-items"].value.toString(),
          ).toBe("stretch");
        },
      );
    });

    it("propagates CSS-wide values from browser shorthands to their longhands", function (done) {
      parseCascade("div { place-items: initial; }", done, function (cascade) {
        expect(cascade.tags.get("div")).toBeDefined();
        expect(cascade.tags.get("div").style["align-items"]).toBeDefined();
        expect(cascade.tags.get("div").style["justify-items"]).toBeDefined();
        expect(cascade.tags.get("div").style["align-items"].value).toBe(
          adapt_css.ident.initial,
        );
        expect(cascade.tags.get("div").style["justify-items"].value).toBe(
          adapt_css.ident.initial,
        );
      });
    });

    it("caches non-shorthand properties after the first browser probe miss", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      spyOn(validatorSet, "expandBrowserShorthand").and.callThrough();

      expect(validatorSet.getShorthand("accent-color", "red")).toBeNull();
      expect(validatorSet.getShorthand("accent-color", "blue")).toBeNull();
      expect(validatorSet.expandBrowserShorthand).toHaveBeenCalledTimes(1);
    });

    it("does not probe the browser for properties Vivliostyle validates itself", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      spyOn(validatorSet, "expandBrowserShorthand").and.callThrough();

      // These are shorthands in the browser CSSOM, but Vivliostyle looks them
      // up by their own name after the cascade. (Issue #2116)
      expect(
        validatorSet.getShorthand("background-position", "var(--pos)"),
      ).toBeNull();
      expect(validatorSet.getShorthand("overflow", "var(--ov)")).toBeNull();
      expect(validatorSet.getShorthand("white-space", "var(--ws)")).toBeNull();
      expect(validatorSet.expandBrowserShorthand).not.toHaveBeenCalled();
    });

    it("looks properties up case-insensitively", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      spyOn(validatorSet, "expandBrowserShorthand").and.callThrough();

      // CSS property names are ASCII case-insensitive, so a name that kept the
      // author's casing must not fall through to browser expansion. (Issue #2116)
      expect(
        validatorSet.getShorthand("BACKGROUND-POSITION", "var(--pos)"),
      ).toBeNull();
      expect(
        validatorSet.getShorthand("Border-Spacing", "var(--bs)"),
      ).toBeNull();
      expect(validatorSet.expandBrowserShorthand).not.toHaveBeenCalled();

      // Vivliostyle's own shorthands are found regardless of casing too.
      expect(validatorSet.getShorthand("MARGIN")).toBe(
        validatorSet.getShorthand("margin"),
      );
    });

    it("stores var() declarations of mixed-case properties under the lowercased name", function (done) {
      parseCascade(
        "div { BORDER-SPACING: var(--bs); }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["border-spacing"]).toBeDefined();
          expect(
            cascade.tags.get("div").style["BORDER-SPACING"],
          ).toBeUndefined();
        },
      );
    });

    it("does not cache a browser shorthand miss for unresolved var values", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      spyOn(validatorSet, "expandBrowserShorthand").and.callFake(
        function (name, value) {
          if (name !== "place-items") {
            return null;
          }
          if (value === "var(--items)") {
            return null;
          }
          if (value === "center start") {
            return {
              propList: ["align-items", "justify-items"],
              values: {
                "align-items": "center",
                "justify-items": "start",
              },
            };
          }
          return null;
        },
      );

      expect(
        validatorSet.getShorthand("place-items", "var(--items)"),
      ).toBeNull();
      expect(
        validatorSet.getShorthand("place-items", "center start"),
      ).not.toBeNull();
      expect(validatorSet.expandBrowserShorthand).toHaveBeenCalledTimes(2);
    });

    it("accepts browser shorthands with comma-list syntax", function (done) {
      parseCascade(
        "div { transition: opacity 1s ease, transform 2s linear; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(
            cascade.tags.get("div").style["transition-property"],
          ).toBeDefined();
          expect(
            cascade.tags.get("div").style["transition-duration"],
          ).toBeDefined();
          expect(
            cascade.tags
              .get("div")
              .style["transition-property"].value.toString(),
          ).toBe("opacity,transform");
          expect(
            cascade.tags
              .get("div")
              .style["transition-duration"].value.toString(),
          ).toBe("1s,2s");
        },
      );
    });

    it("lets all reset browser shorthand longhands that are not in ValidationTxt", function (done) {
      parseCascade(
        "div { transition: opacity 1s ease; all: initial; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(
            cascade.tags.get("div").style["transition-property"],
          ).toBeDefined();
          expect(
            cascade.tags.get("div").style["transition-duration"],
          ).toBeDefined();
          expect(
            cascade.tags.get("div").style["transition-property"].value,
          ).toBe(adapt_css.ident.initial);
          expect(
            cascade.tags.get("div").style["transition-duration"].value,
          ).toBe(adapt_css.ident.initial);
        },
      );
    });

    it("does not enumerate browser properties while creating the base validator set", function () {
      spyOn(window, "getComputedStyle").and.callThrough();

      adapt_cssvalid.baseValidatorSet();

      expect(window.getComputedStyle).not.toHaveBeenCalled();
    });

    it("reuses cached browser property names for repeated all lookups", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      spyOn(validatorSet, "getBrowserPropertyNamesForAll").and.callThrough();

      expect(validatorSet.getShorthand("all")).not.toBeNull();
      expect(validatorSet.getShorthand("all")).not.toBeNull();
      expect(validatorSet.getBrowserPropertyNamesForAll).toHaveBeenCalledTimes(
        1,
      );
    });

    it("filters cached browser property names against later shorthand registrations", function () {
      var validatorSet = adapt_cssvalid.baseValidatorSet();

      validatorSet.allPropertyNames = null;
      validatorSet.browserPropertyNamesForAll = [
        "inset",
        "transition-property",
      ];

      expect(validatorSet.getPropertiesForAll()).not.toContain("inset");
      expect(validatorSet.getPropertiesForAll()).toContain(
        "transition-property",
      );
    });

    it("does not keep browser shorthand names in all after refresh", function (done) {
      parseCascade(
        "div { all: initial; position: absolute; top: 0; right: 0; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["inset"]).toBeUndefined();
          expect(
            cascade.tags.get("div").style["inset-block-start"],
          ).toBeUndefined();
          expect(
            cascade.tags.get("div").style["inset-block-end"],
          ).toBeUndefined();
          expect(
            cascade.tags.get("div").style["inset-inline-start"],
          ).toBeUndefined();
          expect(
            cascade.tags.get("div").style["inset-inline-end"],
          ).toBeUndefined();
          expect(
            cascade.tags.get("div").style["position"].value.toString(),
          ).toBe("absolute");
          expect(cascade.tags.get("div").style["top"].value.toString()).toBe(
            "0",
          );
          expect(cascade.tags.get("div").style["right"].value.toString()).toBe(
            "0",
          );
        },
      );
    });

    it("keeps self-referential custom property declarations through the parser path", function (done) {
      parseCascade("div { --a: var(--a, red); }", done, function (cascade) {
        expect(cascade.tags.get("div")).toBeDefined();
        expect(cascade.tags.get("div").style["--a"]).toBeDefined();
        expect(cascade.tags.get("div").style["--a"].value.toString()).toBe(
          "var(--a,red)",
        );
      });
    });
  });

  describe("invalid selector list recovery", function () {
    it("drops an invalid selector list instead of salvaging later selectors", function (done) {
      parseCascade(
        "p { background: lime; } foo % address, p { background: red; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("p")).toBeDefined();
          expect(cascade.tags.get("p").style["background-color"]).toBeDefined();
          expect(
            cascade.tags.get("p").style["background-color"].value.toString(),
          ).toBe("lime");
        },
      );
    });

    it("drops an invalid selector list even when it uses !important", function (done) {
      parseCascade(
        "foo % address, p { background: red ! important; } p { background: lime; }",
        done,
        function (cascade) {
          expect(cascade.tags.get("p")).toBeDefined();
          expect(cascade.tags.get("p").style["background-color"]).toBeDefined();
          expect(
            cascade.tags.get("p").style["background-color"].value.toString(),
          ).toBe("lime");
        },
      );
    });
  });

  describe("contextually invalid selectors", function () {
    it("invalidates selectors continued after pseudo-elements inside :is()", function (done) {
      parseCascade(
        ":is(*, ::before) * { color: purple; }",
        done,
        function (_cascade, handler) {
          expect(handler.invalid).toBe(true);
        },
      );
    });

    it("invalidates pseudo-elements continued after pseudo-elements inside :is()", function (done) {
      parseCascade(
        ":is(*, ::before)::after { color: purple; }",
        done,
        function (_cascade, handler) {
          expect(handler.invalid).toBe(true);
        },
      );
    });
  });

  describe("typed attr() nested grammar regression", function () {
    it("accepts typed attr() inside string-set content lists", function (done) {
      parseCascade(
        'div { string-set: chapter attr(data-title type(<string>), "fallback"); }',
        done,
        function (cascade) {
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["string-set"]).toBeDefined();
        },
      );
    });

    it("rejects unsupported attr() type() syntax inside string-set content lists", function (done) {
      parseCascade(
        'div { string-set: chapter attr(data-title type(<transform-list>), "fallback"); }',
        done,
        function (cascade, handler) {
          expect(handler.invalid).toBe(true);
          expect(cascade.tags.get("div")).toBeDefined();
          expect(cascade.tags.get("div").style["string-set"]).toBeUndefined();
        },
      );
    });
  });

  describe("typed attr() helper regression", function () {
    it("returns null for unsupported type() syntax", function () {
      expect(
        adapt_cssvalid.parseAttrValue(
          new adapt_exprs.LexicalScope(null),
          "rotate(30deg)",
          { kind: "syntax", syntax: "<transform-list>" },
        ),
      ).toBeNull();
    });

    it("parses frequency syntax using lowercase normalized units", function () {
      var value = adapt_cssvalid.parseAttrValue(
        new adapt_exprs.LexicalScope(null),
        "1kHz",
        {
          kind: "syntax",
          syntax: "<frequency>",
        },
      );
      expect(value && value.toString()).toBe("1khz");
    });
  });

  describe("ValidatorSet", function () {
    it("should parse simple validator and simple rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo-or = bar | [ baz || biz ];");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo-or: bar; }\n.test2 { foo-or: baz biz; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });

    it("rejects invalid single values for text-autospace-like nested alternates", function () {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse(
        "foo = normal | auto | no-autospace | [[ ideograph-alpha || ideograph-numeric || punctuation ] || [ insert | replace ]];",
      );

      expect(
        adapt_css.getName("x").visit(validatorSet.validators.get("foo")),
      ).toBe(null);
    });

    it("accepts valid single values for text-autospace-like nested alternates", function () {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse(
        "foo = normal | auto | no-autospace | [[ ideograph-alpha || ideograph-numeric || punctuation ] || [ insert | replace ]];",
      );

      expect(
        adapt_css
          .getName("punctuation")
          .visit(validatorSet.validators.get("foo")),
      ).not.toBe(null);
    });

    it("should parse simple validator that compare values case-insensitively.", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo = bAr | Baz | bIZ ;");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo: bar; }\n" +
              ".test2 { foo: BAR; }" +
              ".test3 { foo: Bar; }" +
              ".test4 { foo: bAr; }" +
              ".test5 { foo: baR; }" +
              ".test6 { foo: BAZ; }" +
              ".test6 { foo: biz; }" +
              "",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });

    it("should parse selector functions through the dispatch owner", function (done) {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      var handler = cascadeParserHandler(validatorSet);
      handler.owner.startStylesheet(adapt_cssparse.StylesheetFlavor.USER_AGENT);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            '@namespace epub "http://www.idpf.org/2007/ops";\n:not(a[epub|type~="noteref"], a[epub\\:type~="noteref"], a[role~="doc-noteref"])::footnote-call { content: counter(footnote); }',
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
    it("should parse semantic footnote noteref default selectors", function (done) {
      var validatorSet = adapt_cssvalid.baseValidatorSet();
      var handler = cascadeParserHandler(validatorSet);
      handler.owner.startStylesheet(adapt_cssparse.StylesheetFlavor.USER_AGENT);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            '@namespace epub "http://www.idpf.org/2007/ops";\na[epub|type="noteref"]:not(sup > *, :has(> sup)),\na[epub\\:type="noteref"]:not(sup > *, :has(> sup)),\na[role="doc-noteref"]:not(sup > *, :has(> sup)) { font-size: 0.75em; vertical-align: super; line-height: 0; }',
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
    it("should parse validator and space rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo = SPACE(IDENT+);");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo: bar; }\n.test2 { foo: bar baz boo; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });

    it("should parse validator and comma rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo = COMMA( IDENT+ );");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo: bar,baz; }\n .test2{ foo: bar; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });

    it("should parse validator and complex comma rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo-comma = none | COMMA( [ bar | baz ]+ );");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo-comma: none; }\n.test2 { foo-comma: bar,baz; }\n .test3 { foo-comma: bar; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });

    it("should parse validator and complex space rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("spacefoo = none | SPACE( [ bar | baz ]+ );");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { spacefoo: none; }\n.test2 { spacefoo: bar baz; }\n .test3 { spacefoo: bar; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
    it("should parse rule that contains function", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      var validation_txt =
        "THE_VALUE = SPACE(IDENT+);\n" +
        "PRED_VALUE = [ fff | SPACE(bb bz)];" +
        "THE_FUNCTION = the-function(PRED_VALUE? THE_VALUE+);\n" +
        "AC_VALUES = STRING | THE_FUNCTION;" +
        "accept-function = COMMA(AC_VALUES+);";

      validatorSet.parse(validation_txt);
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { accept-function: the-function(foo bar); }\n" +
              ".test2 { accept-function: the-function(foo bar, bar baz); }\n" +
              ".test3 { accept-function: the-function(fff, foo bar, bar baz); }\n" +
              ".test4 { accept-function: the-function(bb bz, foo bar, bar baz); }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
    it("should parse rule that contains slash", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse("foo = bar( SPACE( POS_NUM [ SLASH POS_NUM ]? ) );");
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test { foo: bar( 10 / 10 ) ; }\n" + ".test2 { foo: bar( 10 ) ; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
    it("should parse font shorthand rule", function (done) {
      var validatorSet = new adapt_cssvalid.ValidatorSet();
      validatorSet.initBuiltInValidators();
      validatorSet.parse(
        "PPLENGTH = POS_LENGTH | ZERO | POS_PERCENTAGE;" +
          "FAMILY = SPACE(IDENT+) | STRING;" +
          "FAMILY_LIST = COMMA( FAMILY+ );" +
          "font-family = FAMILY_LIST;" +
          "font-size = xx-small | x-small | small | medium | large | x-large | xx-large | larger | smaller | PPLENGTH | POS_NUM;" +
          "font-style = normal | italic | oblique;" +
          "font-variant = normal | small-caps;" +
          "font-weight = normal | bold | bolder | lighter | 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900;" +
          "font-stretch = normal | wider | narrower | ultra-condensed | extra-condensed | condensed | semi-condensed | semi-expanded | expanded | extra-expanded | ultra-expanded;" +
          "line-height = normal | POS_NUM | PPLENGTH;" +
          "\n\n" +
          "DEFAULTS\n\n" +
          "font-family: serif;" +
          "font-style: normal;" +
          "font-size: medium;" +
          "font-variant: normal;" +
          "line-height: normal;" +
          "font-weight: normal;" +
          "\n\n" +
          "SHORTHANDS\n\n" +
          "font = FONT font-style font-variant font-weight font-stretch ;",
      );
      var handler = cascadeParserHandler(validatorSet);
      var warnListener = jasmine.createSpy("warn listener");
      vivliostyle_logging.logger.addListener(
        vivliostyle_logging.LogLevel.WARN,
        warnListener,
      );
      adapt_task.start(function () {
        adapt_cssparse
          .parseStylesheetFromText(
            ".test  { font: 80% sans-serif ; }\n" +
              '.test2 { font: 12px/14px "Times" ; }\n' +
              '.test3 { font: oblique small-caps bold 12px/14px "Times" ; }\n' +
              '.test4 { font: small-caps oblique 12px "Times" ; }\n' +
              '.test5 { font: oblique small-caps bold ultra-condensed 12px/14px "Times" ; }\n' +
              '.test6 { font: small-caps wider oblique 12px "Times" ; }\n' +
              ".test7 { font: status-bar ; }",
            handler.owner,
            null,
            null,
            null,
          )
          .then(function (result) {
            expect(result).toBe(true);
            expect(warnListener).not.toHaveBeenCalled();
            done();
          });
        return adapt_task.newResult(true);
      });
    });
  });
});
